This is the source to MMBasic for the Micromite and the Micromite Plus.
See http://geoffg.net/micromite.html for details of the Micromite.

This compiles correctly with:
 - Microchip MPLAB X V2.26
 - Microchip XC32 V1.33

Micromite:
==========
You should compile for the PIC32MX170F128D (44-pin chip) but the resultant hex
file will run on either the PIC32MX170F128B (28-pin chip) or the PIC32MX170F128D
(44-pin chip) as the firmware automatically reconfigures itself as required.

Note that you cannot use the free edition of the XC32 compiler because a high
level of optimisation is used.

Micromite Plus:
===============
You should compile for the PIC32MX470F512H (100-pin chip) but the resultant hex
file will run on either the PIC32MX470F512L (64-pin chip) or the PIC32MX470F512H
(100-pin chip) as the firmware automatically reconfigures itself as required.

Note that if you use the free edition of the XC32 compiler you will need to:
  - Change the optimisation for gcc to -O1 (level 1).
  - Go through the source and delete the qualifier __attribute__((mips16)) which 
    is placed in front of some functions.
  - When the source is compiled with a lower optimisation it might not fit in 
    the available flash and in that case you will have to reduce the amount of 
    flash allocated to the BASIC program. You do this by adjusting the value 
    assigned to PROG_FLASH_SIZE which is defined in Flash.h


Go to http://mmbasic.com for updates and licensing

Copyright 2011-2015 Geoff Graham - http://mmbasic.com
These files and modified versions of these files are supplied to specific
individuals under the following provisions:

- They may be used for personal use only and may not be distributed or copied
  without written permission.

- Object files (.o and .hex files) generated using these files (modified or
  not) are for personal use only and may not be distributed without written
  permission.

- These files are provided in the hope that it will be useful, but WITHOUT ANY
  WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
  FOR A PARTICULAR PURPOSE.

Please note that I do not wish to endorse any public forks in this firmware,
released either as source or as compiled hex files.  This is because the Micromite
will have a much better chance of gaining a broad acceptance if everyone has
access to the same, consistent and reliable version of the firmware.  For this
reason this code is provided for your personal interest and use only.  If you
do have a bug fix or genuinely useful addition to the source please let me know
and I will happily consider adding it to the next public release with full credit
and thanks to you.

Geoff Graham
projects@geoffg.net
