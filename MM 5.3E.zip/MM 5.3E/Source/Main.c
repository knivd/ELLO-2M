/*****************************************************************************************************************************
Micromite

Main.c

Copyright 2011 - 2017 Geoff Graham.  All Rights Reserved.

This file and modified versions of this file are supplied to specific individuals or organisations under the following
provisions:

- This file, or any files that comprise the MMBasic source (modified or not), may not be distributed or copied to any other
  person or organisation without written permission.

- Object files (.o and .hex files) generated using this file (modified or not) may not be distributed or copied to any other
  person or organisation without written permission.

- This file is provided in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.


This is the main source file for the Micromite project.

Development Environment
    To compile this you need:
     - Microchip MPLAB X IDE V1.95 or later (www.microchip.com)
     - Microchip XC32 C Compiler V1.33 full version or running in evaluation mode (www.microchip.com)

 NOTE:  If you are using a later compiler version you might need to download and separately install the Microchip
        PIC32 Peripheral Library.  This is because Microchip has warned that this functionality will be removed in
        future compiler releases.

You must use the MPLAB X project files distributed with this source as it has many customised settings.

Micromite:
==========
You should compile for the PIC32MX170F128D (44-pin chip) but the resultant hex file will run on either the 
PIC32MX170F128B (28-pin chip) or the PIC32MX170F128D (44-pin chip) as the firmware automatically reconfigures 
itself as required.

Note that you cannot use the free edition of the XC32 compiler because a high level of optimisation is used.

Micromite Plus:
===============
You should compile for the PIC32MX470F512H (100-pin chip) but the resultant hex file will run on either the 
PIC32MX470F512L (64-pin chip) or the PIC32MX470F512H (100-pin chip) as the firmware automatically reconfigures 
itself as required.

Note that if you use the free edition of the XC32 compiler you will need to:
  - Change the optimisation for gcc to -O1 (level 1).
  - Go through the source and delete the qualifier __attribute__((mips16)) which 
    is placed in front of some functions.
  - When the source is compiled with a lower optimisation it might not fit in 
    the available flash and in that case you will have to reduce the amount of 
    flash allocated to the BASIC program. You do this by adjusting the value 
    assigned to PROG_FLASH_SIZE which is defined in Flash.h



----------------------- PIC32 HARDWARE --------------------------
Interrupts.......................................................
PRIORITY     DESCRIPTION                    MAX SPEED
   7         Not Used
   6         COM2 serial interface          up to every 17uS when open (not used in the MX470)
   5         I2C interface                  ?
   4         Not Used
   3         Console and serial interfaces  every 40 uS when receiving a char
   2         Counting pins (15 to 18)       up to every 5uS
   1         MMBasic clocks and timers      every 500 uS (MX470) or mSec (MX170)

If you modify these priorities then you must also adjust the code of lower priority interrupts
to take into account that something like LATBbits.LATB4 = 1 is a macro and not not an atomic operation
and a higher interrupt might change PORTB while the macro is being executed.

Timers...........................................................
TIMER NBR    DESCRIPTION                 INTERRUPT
  core       Used by the uSec() macro       no
   1         IR Decoder -or- CFunction      yes, if used by a CFunction
   2         Used by PWM channel 1          no
   3         Used by PWM channel 2          no
   4         MMBasic clocks and timers      yes
   5         MX170: COM2 serial interface   yes
             On the MX470 a CFunction can use timer 5


********************************************************************************************************************************/


#include <stdlib.h>
extern long long int llabs (long long int n);

#include <string.h>

#include "MMBasic_Includes.h"
#include "Hardware_Includes.h"

// global variables used in MMBasic but must be maintained outside of the interpreter
int MMCharPos;
int MMAbort = false;
char *InterruptReturn = NULL;

struct s_PinDef *PinDef;

char BreakKey = BREAK_KEY;                                          // defaults to CTRL-C.  Set to zero to disable the break function
char IgnorePIN = false;
char WatchdogSet = false;
char fwu_checked = false;

extern void InitProcessor(void);

int BasicRunning = false;


#if defined(MX170) && !defined(MX270D)
    #include "MX170/Configuration_Bits.h"                           // config pragmas
#elif defined(MX270D)
    #include "MX270D/Configuration_Bits.h"
#elif defined(MX470) && !defined(MZEF)
    int PromptFont, PromptFC, PromptBC;                             // the font and colours selected at the prompt
    #include "MX470/Configuration_Bits.h"                           // config pragmas
    #elif defined(MZEF)
    int PromptFont, PromptFC, PromptBC;                             // the font and colours selected at the prompt
    #include "MZEF/Configuration_Bits.h"                            // config pragmas
#endif


int main(int argc, char* argv[]) {
    int i;
    static int ErrorInPrompt;

    if((RCON & 0b11000) == 0b11000) __asm__ ("eret");               // quick check if watchdog and sleep bits are set.  If so exit and let the CPU SLEEP command handle it
    ClearEventWDT();                                                // clear the watchdog

    InitProcessor();                                                // do the setup stuff specific to the particular chip
    InitBasic();   
    
    #if defined(MX470)
        if(_excep_cause != CAUSE_DISPLAY) {
            i = _excep_cause;
            _excep_cause = CAUSE_DISPLAY;
            InitDisplaySSD();                                       // setup the SSD display early in case it is being used as the console output
            _excep_cause = i;
        }
    #endif
    BasicRunning = true;
    ErrorInPrompt = false;

    WatchdogSet = false;
    if(RCON & 0x0040) {                                             // this will only happen if we had a software triggered reset
        if(!(_excep_code == RESET_COMMAND || _excep_code == RESTART_NOAUTORUN)) {
            if(_excep_code == WATCHDOG_TIMEOUT) {
                WatchdogSet = true;                                 // remember if it was a watchdog timeout
                MMPrintString("\r\n\nWatchdog timeout");
            } else if(_excep_code != PIN_RESTART) {
                if(_excep_cause != CAUSE_NOTHING) {
                    if(_excep_cause == CAUSE_MMSTARTUP)
                        MMPrintString("\r\n\nError in MM.STARTUP");
                    else {
                        MMPrintString("\r\n\nOption error - Cleared OPTION ");
                        switch(_excep_cause) {
                            case CAUSE_DISPLAY:     MMPrintString("LCDPANEL"); Option.DISPLAY_TYPE = 0;             break;
    #if defined(MX470)
                            case CAUSE_FILEIO:      MMPrintString("SDCARD");   Option.SDCARD[0].CS = 0;  Option.SDCARD[1].CS = 0; Option.SDCARD[2].CS = 0; Option.SDCARD[3].CS = 0; break;
                            case CAUSE_KEYBOARD:    MMPrintString("KEYBOARD"); Option.KeyboardConfig = NO_KEYBOARD; break;
                            case CAUSE_RTC:         MMPrintString("RTC");      Option.RTC_Data = 0;                 break;
    #endif
                            case CAUSE_TOUCH:       MMPrintString("TOUCH");    Option.TOUCH_CS = 0;                 break;
                        }
                        SaveOptions();
                    }
                } else {
                    MMPrintString("\r\n\nCPU exception #");
                    IntToStrPad(inpbuf, _excep_code, '0', 1, 10); MMPrintString(inpbuf);
#if defined(MX470)
                    switch(_excep_code) {
                        case 4:  MMPrintString(" (address error on load or ifetch)"); break;
                        case 5:  MMPrintString(" (address error on store)"); break;
                        case 6:  MMPrintString(" (bus error on ifetch)"); break;
                        case 7:  MMPrintString(" (bus error on load or store)"); break;
                        case 12: MMPrintString(" (arithmetic overflow)"); break;
                        case 13: MMPrintString(" (possible divide by zero)"); break;
                    }
#endif
                    PrepareProgram(false);
                    if(CFunctionFlash != NULL && _excep_addr >= (unsigned int)CFunctionFlash && _excep_addr < (unsigned int)ProgFlash + PROG_FLASH_SIZE) {
                        unsigned int *wrd;
                        char *p;
                        MMPrintString("\r\nIn CFunction ");
                        wrd = (unsigned int *)CFunctionFlash;
                        while(*wrd != 0xffffffff) {
                            if(_excep_addr <= (unsigned int)wrd + wrd[1] + 4) {
                                _excep_addr -= ((unsigned int)wrd + 12);
                                p = (char *)wrd[0];
                                p++; skipspace(p);
                                MMputchar(*p++);
                                while(isnamechar(*p)) MMputchar(*p++);
                                break;
                            }
                            wrd++;
                            wrd += (*wrd + 4) / sizeof(unsigned int);
                        }
                    }
                    MMPrintString(" at address 0x");
                    IntToStrPad(inpbuf, _excep_addr, '0', 4, 16); MMPrintString(inpbuf);
                }
            }
            MMPrintString("\r\nProcessor restarted\r\n\n");
        }
        RCONCLR = 0x0040;                                           // clear the source of the restart
    }
    else {
#if defined(DEBUGMODE) || defined(__DEBUG)
        dp("Debug mode.  %d command and %d token slots free.", 127 - CommandTableSize, 127 - TokenTableSize);
#else
        MMPrintString(MES_SIGNON);                                  // print sign on message
        MMPrintString(COPYRIGHT);                                   // print copyright message
        MMPrintString("\r\n");
#endif
    }

    // setup the devices that optionally need to reserve resources at startup
    _excep_cause = CAUSE_DISPLAY; InitDisplaySPI(false);
    #if defined(MX470)
        _excep_cause = CAUSE_FILEIO;   InitFileIO();
        _excep_cause = CAUSE_KEYBOARD; initKeyboard();
        _excep_cause = CAUSE_RTC;      if(Option.RTC_Data != 0) RtcGetTime();
    #endif
    _excep_cause = CAUSE_TOUCH;        InitTouch();

    if(setjmp(mark) != 0) {
        // we got here via a long jump which means an error or CTRL-C or the program wants to exit to the command prompt
        ContinuePoint = nextstmt;                                   // in case the user wants to use the continue command
        *tknbuf = 0;                                                // we do not want to run whatever is in the token buffer
    } else {
        if(_excep_cause != CAUSE_MMSTARTUP) {
            ClearProgram();
            PrepareProgram(true);
            _excep_cause = CAUSE_MMSTARTUP;
            if(FindSubFun("MM.STARTUP", 0) >= 0) ExecuteProgram("MM.STARTUP\0");
            _excep_cause = CAUSE_NOTHING;
            if(Option.Autorun && *ProgFlash == 0x01 && _excep_code != RESTART_NOAUTORUN) {
                if(Option.ProgFlashSize != PROG_FLASH_SIZE) ExecuteProgram(ProgFlash + Option.ProgFlashSize);       // run anything that might be in the library
                ExecuteProgram(ProgFlash);                                                                          // then run the program if autorun is on
            }
        }
    }
    _excep_cause = CAUSE_NOTHING;

    while(1) {
#if defined(MX470)
    if(Option.DISPLAY_CONSOLE) {
        SetFont(PromptFont);
        gui_fcolour = PromptFC;
        gui_bcolour = PromptBC;
        if(CurrentX != 0) MMPrintString("\r\n");                   // prompt should be on a new line
    }
#endif
        MMAbort = false;
        BreakKey = BREAK_KEY;
        EchoOption = true;
        LocalIndex = 0;                                             // this should not be needed but it ensures that all space will be cleared
        ClearTempMemory();                                          // clear temp string space (might have been used by the prompt)
        CurrentLinePtr = NULL;                                      // do not use the line number in error reporting
        if(MMCharPos > 1) MMPrintString("\r\n");                    // prompt should be on a new line
        while(Option.PIN && !IgnorePIN) {
            _excep_code = PIN_RESTART;
            if(Option.PIN == 99999999)                              // 99999999 is permanent lockdown
                MMPrintString("Console locked, press enter to restart: ");
            else
                MMPrintString("Enter PIN or 0 to restart: ");
            MMgetline(0, inpbuf);
            if(Option.PIN == 99999999) SoftReset();
            if(*inpbuf != 0) {
                uSec(3000000);
                i = atoi(inpbuf);
                if(i == 0) SoftReset();
                if(i == Option.PIN) {
                    IgnorePIN = true;
                    break;
                }
            }
        }
        _excep_code = 0;
        PrepareProgram(false);
        if(!ErrorInPrompt && FindSubFun("MM.PROMPT", 0) >= 0) {
            ErrorInPrompt = true;
            ExecuteProgram("MM.PROMPT\0");
        } else
            MMPrintString(GetPrompt());                             // print the prompt
        ErrorInPrompt = false;
        
#ifdef ELLO_2M
    if(!fwu_checked) {
        fwu_checked=TRUE;
        CNPUBbits.CNPUB7=1; // enable pull-up on RB7
        uSec(10000);
        if(!PORTBbits.RB7) cmd_fwupdate();  // enable the bootloader if the PGD pin is permanently set low on start    
    }
#endif        

        MMgetline(0, inpbuf);                                       // get the input
        if(!*inpbuf) continue;                                      // ignore an empty line
        tokenise(true);                                             // turn into executable code
        if(*tknbuf == T_LINENBR)                                    // don't let someone use line numbers at the prompt
            tknbuf[0] = tknbuf[1] = tknbuf[2] = ' ';                // convert the line number into spaces
        ExecuteProgram(tknbuf);                                     // execute the line straight away
    }
}



// put a character out to the serial console
char MMputchar(char c) {
    putConsole(c);
    if(c<0 || c>127 || isprint(c)) MMCharPos++;
    if(c == '\r') {
        MMCharPos = 1;
    }
    return c;
}



/*****************************************************************************************
The vt100 escape code sequences
===============================
3 char codes            Arrow Up    esc [ A
                        Arrow Down  esc [ B
                        Arrow Right esc [ C
                        Arrow Left  esc [ D

4 char codes            Home        esc [ 1 ~
                        Insert      esc [ 2 ~
                        Del         esc [ 3 ~
                        End         esc [ 4 ~
                        Page Up     esc [ 5 ~
                        Page Down   esc [ 6 ~

5 char codes            F1          esc [ 1 1 ~
                        F2          esc [ 1 2 ~
                        F3          esc [ 1 3 ~
                        F4          esc [ 1 4 ~
                        F5          esc [ 1 5 ~         note the
                        F6          esc [ 1 7 ~         disconnect
                        F7          esc [ 1 8 ~
                        F8          esc [ 1 9 ~
                        F9          esc [ 2 0 ~
                        F10         esc [ 2 1 ~         note the
                        F11         esc [ 2 3 ~         disconnect
                        F12         esc [ 2 4 ~

                        SHIFT-F3    esc [ 2 5 ~         used in the editor

*****************************************************************************************/

// check if there is a keystroke waiting in the buffer and, if so, return with the char
// returns -1 if no char waiting
// the main work is to check for vt100 escape code sequences and map to Maximite codes
int MMInkey(void) {
    unsigned int c = -1;                                            // default no character
    unsigned int tc = -1;                                           // default no character
    unsigned int ttc = -1;                                          // default no character
    static unsigned int c1 = -1;
    static unsigned int c2 = -1;
    static unsigned int c3 = -1;
    static unsigned int c4 = -1;

    if(c1 != -1) {                                                  // check if there are discarded chars from a previous sequence
        c = c1; c1 = c2; c2 = c3; c3 = c4; c4 = -1;                 // shuffle the queue down
        return c;                                                   // and return the head of the queue
    }

    c = getConsole();                                               // do discarded chars so get the char
    if(c == 0x1b) {
        InkeyTimer = 0;                                             // start the timer
        while((c = getConsole()) == -1 && InkeyTimer < 30);         // get the second char with a delay of 30mS to allow the next char to arrive
        if(c != '[') { c1 = c; return 0x1b; }                       // must be a square bracket
        while((c = getConsole()) == -1 && InkeyTimer < 50);         // get the third char with delay
        if(c == 'A') return UP;                                     // the arrow keys are three chars
        if(c == 'B') return DOWN;
        if(c == 'C') return RIGHT;
        if(c == 'D') return LEFT;
        if(c < '1' && c > '6') { c1 = '['; c2 = c; return 0x1b; }   // the 3rd char must be in this range
        while((tc = getConsole()) == -1 && InkeyTimer < 70);        // delay some more to allow the final chars to arrive, even at 1200 baud
        if(tc == '~') {                                             // all 4 char codes must be terminated with ~
            if(c == '1') return HOME;
            if(c == '2') return INSERT;
            if(c == '3') return DEL;
            if(c == '4') return END;
            if(c == '5') return PUP;
            if(c == '6') return PDOWN;
            c1 = '['; c2 = c; c3 = tc; return 0x1b;                 // not a valid 4 char code
        }
        while((ttc = getConsole()) == -1 && InkeyTimer < 90);       // get the 5th char with delay
        if(ttc == '~') {                                            // must be a ~
            if(c == '1') {
                if(tc >='1' && tc <= '5') return F1 + (tc - '1');   // F1 to F5
                if(tc >='7' && tc <= '9') return F6 + (tc - '7');   // F6 to F8
            }
            if(c == '2') {
                if(tc =='0' || tc == '1') return F9 + (tc - '0');   // F9 and F10
                if(tc =='3' || tc == '4') return F11 + (tc - '3');  // F11 and F12
                if(tc =='5') return F3 + 0x20;                      // SHIFT-F3
            }
        }
        // nothing worked so bomb out
        c1 = '['; c2 = c; c3 = tc; c4 = ttc;
        return 0x1b;
    }
    return c;
}


/*******************************************************************************************************************/


// convert a integer to a string.
// sstr is a buffer where the chars are to be written to
// sum is the number to be converted
// base is the numbers base radix (10 = decimal, 16 = hex, etc)
// if base 10 the number will be signed otherwise it will be unsigned
void IntToStr(char *strr, long long int nbr, unsigned int base) {
    int i, negative;
    unsigned char digit;
    unsigned long long int sum;

    #define IntToStrBufSize 65
    unsigned char str[IntToStrBufSize];

    if(nbr < 0 && base == 10) {                                     // we can have negative numbers in base 10 only
        nbr = llabs(nbr);
        negative = true;
    } else
        negative = false;

    // this generates the digits in reverse order
    sum = (unsigned long long int) nbr;
    i = 0;
    do {
        digit = sum % base;
        if (digit < 0xA)
            str[i++] = '0' + digit;
        else
            str[i++] = 'A' + digit - 0xA;
        sum /= base;
    } while (sum && i < IntToStrBufSize);

    if(negative) *strr++ = '-';

    // we now need to reverse the digits into their correct order
    for(i--; i >= 0; i--) *strr++ = str[i];
    *strr = 0;
}


// convert an integer to a string padded with a leading character
// p is a pointer to the destination
// nbr is the number to convert (can be signed in which case the number is preceeded by '-')
// padch is the leading padding char (usually a space)
// maxch is the desired width of the resultant string (incl padding chars)
// radix is the base of the number (10 = decimal)
// Special case (used by FloatToStr() only):
//    if padch is negative and nbr is zero prefix the number with the - sign
void IntToStrPad(char *p, long long int nbr, signed char padch, int maxch, int radix) {
    int i, j;
    char buf[IntToStrBufSize];

    i = 0;
    if(maxch < 0) {                                                 // do we always display the sign?
        maxch = abs(maxch);
        if(nbr >= 0 && padch >= 0) buf[i++] = '+';                  // if yes and nbr is positive insert the + sign
    }
    if(padch < 0 && nbr == 0) {                                     // special case, the number is negative zero (used by FloatToStr() only)
        padch = abs(padch);
        buf[i++] = '-';                                             // insert the - symbol
    }
    IntToStr(buf + i, nbr, radix);
    j = maxch - strlen(buf);
    for(i = 0; i < j; i++) p[i] = padch;
    strcpy(&p[i], buf) ;
}



// convert a float to a string including scientific notation if necessary
// p is the buffer to store the string
// f is the number
// m is the nbr of chars before the decimal point (if negative print the + sign)
// n is the nbr chars after the point
// ch is the leading pad char
void FloatToStr(char *p, float f, int m, int n, unsigned char ch) {
    int exp, nbra, trim = false;
    float rounding;
    char *pp;

    ch &= 0x7f;                                                     // make sure that ch is an ASCII char
    if( sizeof(f) == 4 ) {
        nbra = 5;
    }
    else {
        nbra = 8;
    }
    exp = floor(log10l(fabs(f)));                                   // get the exponent part
    if((fabs(f) >= 1000000 || fabs(f) < 0.0001) && f != 0 && n == -1) {
        // we must use scientific notation
        f /= pow(10, exp);                                          // scale the number to 1.2345
        FloatToStr(p, f, m, nbra, ch);                              // recursively call ourself to convert that to a string
        p = p + strlen(p);
        *p++ = 'e';                                                 // add the exponent
        if(exp >= 0) {
            *p++ = '+';
            IntToStrPad(p, exp, '0', 2, 10);                        // add a positive exponent
        } else {
            *p++ = '-';
            IntToStrPad(p, exp * -1, '0', 2, 10);                   // add a negative exponent
        }
    } else {
        // we can treat it as a normal number

        // first figure out how many decimal places we want.
        // n == -1 means that we should automatically determine the precision
        if(n == -1) {
            trim = true;
            n = nbra - exp;
            if(n < 0) n = 0;
        }

        // add rounding to hide the vagarities of floating point
        if(n > 0)
            rounding = 0.5/pow(10, n);
        else
            rounding = 0.5;

        if(f > 0) f += rounding;                                    // add rounding for positive numbers
        if(f < 0) f -= rounding;                                    // add rounding for negative numbers

        // convert the digits before the decimal point
        if((int)f == 0 && f < 0)
            IntToStrPad(p, 0, -ch, m, 10);                          // convert -0 incl padding if necessary
        else
            IntToStrPad(p, f, ch, m, 10);                           // convert the integer incl padding if necessary
        p += strlen(p);                                             // point to the end of the integer
        pp = p;

        // convert the digits after the decimal point
        if(f < 0) f = -f;                                           // make the number positive
        if(n > 0) {                                                 // if we need to have a decimal point and following digits
            *pp++ = '.';                                            // add the decimal point
            f -= (int)f;                                            // get just the fractional part
            while(n--) {
                f *= 10;                                            // get the digit
                *pp++ = ((int)f % 10) + '0';                        // and convert
            }

            // if we do not have a fixed number of decimal places step backwards removing trailing zeros and the decimal point if necessary
            while(trim && pp > p) {
                pp--;
                if(*pp == '.') break;
                if(*pp != '0') { pp++; break; }
            }
        }
        *pp = 0;
    }
 }



// general purpose time delay
// it is based on the core timer and is quite accurate even if interrupts have occured
// maximum delay is 4.29 seconds
// minimum is 3uS at 40MHz, 6uS at 20MHz, 12uS  at 10MHz, and 24uS at 5MHz
#define SetupTime 51                                                // the time it takes to call the function and setup the loop (in core timer ticks)
void uSec(unsigned int us) {
     us = ((us * 1000u) / (2000000000u/ClockSpeed)) - SetupTime;    // convert to core timer cycles (these are CPU cycles not Peripheral Bus Cycles)
     WriteCoreTimer(0);
     while(ReadCoreTimer() < us);
}



// trap an unhandled error (exception)

/* list of exception codes
    0 = EXCEP_IRQ,              // interrupt
    4 = EXCEP_AdEL,             // address error exception (load or ifetch)
    5 = EXCEP_AdES,             // address error exception (store)
    6 = EXCEP_IBE,              // bus error (ifetch)
    7 = EXCEP_DBE,              // bus error (load/store)
    8 = EXCEP_Sys,              // syscall
    9 = EXCEP_Bp,               // breakpoint
    10 = EXCEP_RI,              // reserved instruction
    11 = EXCEP_CpU,             // coprocessor unusable
    12 = EXCEP_Overflow,        // arithmetic overflow
    13 = EXCEP_Trap,            // trap (possible divide by zero)
    14 = EXCEP_IS1 = 16,        // implementation specfic 1
    15 = EXCEP_CEU,             // CorExtend Unuseable
    16 = EXCEP_C2E              // coprocessor 2
*/

/* exception handler
   this function overrides the normal _weak_ generic handler and uses two variables (_excep_code and _excep_addr) to save the cause
   and address of the exception.  These are saved in a special section of memory which is not initialised by the startup code.
   For details see the following:
            http://www.microchip.com/forums/tm.aspx?m=434737&mpage=1&key=%F1%AA%88%B1
            http://www.microchip.com/forums/tm.aspx?m=458360&high=persist

*/
#if defined(MX170) //|| defined(MX470)
unsigned int _excep_dummy  __attribute__ ((persistent));            // for some reason the first entry is not useable
unsigned int _excep_code  __attribute__ ((persistent));
unsigned int _excep_addr  __attribute__ ((persistent));
unsigned int _excep_cause  __attribute__ ((persistent));
#endif

void  __attribute__((nomips16)) _general_exception_handler(void) {
    unsigned int tmp_excep_code;
    unsigned int tmp_excep_addr;   
    asm volatile("mfc0 %0,$13" : "=r" (tmp_excep_code));
    asm volatile("mfc0 %0,$14" : "=r" (tmp_excep_addr));
    _excep_code = (tmp_excep_code & 0x0000007C) >> 2;
    _excep_addr = tmp_excep_addr;
    SoftReset();        // this will restart the processor - only works when not in debug
}



#if defined(DEBUGMODE)

void dump(char *p, int nbr) {
    char buf1[60], buf2[30], *b1, *b2;
    b1 = buf1; b2 = buf2;
    b1 += sprintf(b1, "%8x: ", (unsigned int)p);
    while(nbr > 0) {
        b1 += sprintf(b1, "%02x ", *p);
        b2 += sprintf(b2, "%c", (*p >= ' ' && *p < 0x7f) ? *p : ' ');
        p++;
        nbr--;
        if((unsigned int)p % 16 == 0) {
            sprintf(inpbuf, "%s   %s", buf1, buf2);
            MMPrintString(inpbuf);
            b1 = buf1; b2 = buf2;
            b1 += sprintf(b1, "\r\n%8x: ", (unsigned int)p);
        }
    }
    if(b2 != buf2) {
        sprintf(inpbuf, "%s   %s", buf1, buf2);
        MMPrintString(inpbuf);
    }
    MMPrintString("\r\n");
}
#endif

// a crude memory dump that does not use sprintf()
void cdump(char *p, int nbr) {
    while(nbr--) {
        if(((int)p & 0b11111) == 0) MMPrintString("\r\n");
        if(*p == 0)
            MMPrintString("= ");
        else if(*p == T_LINENBR)
            MMPrintString("@ ");
        else if(*p<0 || *p>127 || isprint(*p))
            { MMputchar(*p); MMputchar(' '); }
        else MMPrintString(". ");
        p++;
    }
    MMPrintString("\r\n");
}



