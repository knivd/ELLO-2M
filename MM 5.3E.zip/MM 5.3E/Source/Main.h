/***********************************************************************************************************************
Main.h

Include file that contains the globals and defines for Main.c in MMBasic.

Copyright 2011 - 2017 Geoff Graham.  All Rights Reserved.

This file and modified versions of this file are supplied to specific individuals or organisations under the following
provisions:

- This file, or any files that comprise the MMBasic source (modified or not), may not be distributed or copied to any other
  person or organisation without written permission.

- Object files (.o and .hex files) generated using this file (modified or not) may not be distributed or copied to any other
  person or organisation without written permission.

- This file is provided in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

************************************************************************************************************************/

// global variables
extern int MMCharPos;
extern char *StartEditPoint;
extern int StartEditChar;
extern char *InterruptReturn;
extern char IgnorePIN;
extern char WatchdogSet;
extern int BasicRunning;
extern int PromptFont, PromptFC, PromptBC;                          // the font and colours selected at the prompt;

// console related functions
extern int MMInkey(void);
extern char MMputchar(char c);


void IntToStrPad(char *p, long long int nbr, signed char padch, int maxch, int radix);
void IntToStr(char *strr, long long int nbr, unsigned int base);
void FloatToStr(char *p, float f, int m, int n, unsigned char ch);
void FLOAT64_to_string(long double number, char *str_ptr, UINT8 decimal_precision);

// Use the core timer for misc delays.  The maximum delay is 4 seconds
void uSec(unsigned int us);

// used to control the processor reset
#define RESET_COMMAND       9999                                // indicates that the reset was caused by the RESET command
#define WATCHDOG_TIMEOUT    9998                                // reset caused by the watchdog timer
#define PIN_RESTART         9997                                // reset caused by entering 0 at the PIN prompt
#define RESTART_NOAUTORUN   9996                                // reset required after changing the LCD or touch config
#if defined(MX170)
    extern unsigned int _excep_dummy  __attribute__ ((persistent)); // for some reason persistent does not work on the first variable
    extern unsigned int _excep_code  __attribute__ ((persistent));  // if there was an exception this is the exception code
    extern unsigned int _excep_addr  __attribute__ ((persistent));  // and this is the address
    extern unsigned int _excep_cause  __attribute__ ((persistent)); // if this happend during setup this is the cause
#elif defined(MX470)
    /* Variables from linker script.*/   
#if 1    
    const extern unsigned int _EXEPT_CODE_ADDRESS;
    const extern unsigned int _EXEPT_ADDR_ADDRESS;
    const extern unsigned int _EXEPT_CAUSE_ADDRESS;

    #define _excep_code     (*(unsigned int*)((unsigned int) &_EXEPT_CODE_ADDRESS))  // if there was an exception this is the exception code
    #define _excep_addr     (*(unsigned int*)((unsigned int) &_EXEPT_ADDR_ADDRESS))  // and this is the address
    #define _excep_cause    (*(unsigned int*)((unsigned int) &_EXEPT_CAUSE_ADDRESS)) // if this happend during setup this is the cause
#else
    extern unsigned int _excep_dummy  __attribute__ ((persistent)); // for some reason persistent does not work on the first variable
    extern unsigned int _excep_code  __attribute__ ((persistent));  // if there was an exception this is the exception code
    extern unsigned int _excep_addr  __attribute__ ((persistent));  // and this is the address
    extern unsigned int _excep_cause  __attribute__ ((persistent)); // if this happend during setup this is the cause
#endif
#endif

// used to determin if the exception occured during setup
#define CAUSE_NOTHING           0
#define CAUSE_DISPLAY           1
#define CAUSE_FILEIO            2
#define CAUSE_KEYBOARD          3
#define CAUSE_RTC               4
#define CAUSE_TOUCH             5
#define CAUSE_MMSTARTUP         6


#if defined(DEBUGMODE)
    void dump(char *p, int nbr);
#endif
