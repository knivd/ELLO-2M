/***********************************************************************************************************************
MMBasic

functions.c

Handles all the functions in MMBasic.

Copyright 2011 - 2017 Geoff Graham.  All Rights Reserved.

This file and modified versions of this file are supplied to specific individuals or organisations under the following 
provisions:

- This file, or any files that comprise the MMBasic source (modified or not), may not be distributed or copied to any other
  person or organisation without written permission.

- Object files (.o and .hex files) generated using this file (modified or not) may not be distributed or copied to any other
  person or organisation without written permission.

- This file is provided in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of 
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

************************************************************************************************************************/

#include <math.h>

#include "../MMBasic_Includes.h"
#include "../Hardware_Includes.h"


#define RADCONV 57.2957795130823229	/* Used when converting degrees -> radians and vice versa */


/********************************************************************************************************************************************
 basic functions
 each function is responsible for decoding a basic function
 all function names are in the form fun_xxxx() so, if you want to search for the function responsible for the ASC() function look for fun_asc

 There are 4 globals used by these functions:

 char *ep       This is a pointer to the argument of the function
                Eg, in the case of INT(35/7) ep would point to "35/7)"

 fret           Is the return value for a basic function that returns a float

 iret           Is the return value for a basic function that returns an integer

 sret           Is the return value for a basic function that returns a string

 tret           Is the type of the return value.  normally this is set by the caller and is not changed by the function

 ********************************************************************************************************************************************/



// return the absolute value of a number (ie, without the sign)
// a = ABS(nbr)
void fun_abs(void) {
    char *p, *s;
    float f;
    long long int i64;

    targ = T_INT;
    p = evaluate(ep, &f, &i64, &s, &targ, false);                   // get the value and type of the argument
    if(targ & T_NBR)
	fret = (float)fabs(f);
    else {
        iret = i64;
        if(iret < 0) iret = -iret;
    }
}



// return the ASCII value of the first character in a string (ie, its number value)
// a = ASC(str$)
void fun_asc(void) {
	char *s;

	s = getstring(ep);
	if(*s == 0)
	    iret = 0;
	else
    	iret = *(s + 1);
    targ = T_INT;
}



// return the arctangent of a number in radians
void fun_atn(void) {
	fret = (float)atan(getnumber(ep));
    targ = T_NBR;
}



// convert a number into a one character string
// s$ = CHR$(nbr)
void fun_chr(void) {
	int i;

	i = getint(ep, 0, 0xff);
	sret = GetTempStrMemory();									// this will last for the life of the command
	sret[0] = 1;
	sret[1] = i;
    targ = T_STR;
}



// Round numbers with fractional portions up or down to the next whole number or integer.
void fun_cint(void) {
	iret = getinteger(ep);
    targ = T_INT;
}



// return the cosine of a number in radians
void fun_cos(void) {
	fret = (float)cos(getnumber(ep));
    targ = T_NBR;
}


// convert radians to degrees.  Thanks to Alan Williams for the contribution
void fun_deg(void) {
	fret = (float)((double)getnumber(ep)*RADCONV);
    targ = T_NBR;
}



// Returns the exponential value of a number.
void fun_exp(void) {
	fret = (float)exp(getnumber(ep));
    targ = T_NBR;
}


// utility function used by HEX$(), OCT$() and BIN$()
void DoHexOctBin(int base) {
	unsigned long long int i;
    int j = 1;
	getargs(&ep, 3, ",");
	i = (unsigned long long int)getinteger(argv[0]);                // get the number
    if(argc == 3) j = getint(argv[2], 1, MAXSTRLEN);                // get the optional number of chars to return
	sret = GetTempStrMemory();                                    // this will last for the life of the command
    IntToStrPad(sret, (signed long long int)i, '0', j, base);
	CtoM(sret);
    targ = T_STR;
}



// return the hexadecimal representation of a number
// s$ = HEX$(nbr)
void fun_hex(void) {
    DoHexOctBin(16);
}



// return the octal representation of a number
// s$ = OCT$(nbr)
void fun_oct(void) {
    DoHexOctBin(8);
}



// return the binary representation of a number
// s$ = BIN$(nbr)
void fun_bin(void) {
    DoHexOctBin(2);
}



// syntax:  nbr = INSTR([start,] string1, string2)
//          find the position of string2 in string1 starting at start chars in string1
// returns an integer
void fun_instr(void) {
	char *s1 = NULL, *s2 = NULL;
	int start = 0;
	getargs(&ep, 5, ",");

	if(argc == 5) {
		start = getinteger(argv[0]) - 1;
		s1 = getstring(argv[2]);
		s2 = getstring(argv[4]);
		if(start < 0 || start > MAXSTRLEN) error("Number out of bounds");
	}
	else if(argc == 3) {
		start = 0;
		s1 = getstring(argv[0]);
		s2 = getstring(argv[2]);
	}
	else
		error("Incorrect number of arguments");

    targ = T_INT;
	if(start > *s1 - *s2 + 1 || *s2 == 0)
		iret = 0;
	else {
		// find s2 in s1 using MMBasic strings
		int i;
		for(i = start; i < *s1 - *s2 + 1; i++) {
			if(memcmp(s1 + i + 1, s2 + 1, *s2) == 0) {
				iret = i + 1;
				return;
			}
		}
	}
	iret = 0;
}



// Truncate an expression to the next whole number less than or equal to the argument. 
void fun_int(void) {
	iret = floorf(getnumber(ep));
    targ = T_INT;
}


// Truncate a number to a whole number by eliminating the decimal point and all characters 
// to the right of the decimal point.
void fun_fix(void) {
	iret = getnumber(ep);
    targ = T_INT;
}



// Return a substring offset by a number of characters from the left (beginning) of the string.
// s$ = LEFT$( string$, nbr )
void fun_left(void) {
	int i;
    char *s;
	getargs(&ep, 3, ",");

	if(argc != 3) error("Incorrect argument count");
	s = GetTempStrMemory();                                       // this will last for the life of the command
	Mstrcpy(s, getstring(argv[0]));
	i = getinteger(argv[2]);
	if(i < 0 || i > MAXSTRLEN) error("Number out of bounds");
	if(i < *s) *s = i;                                              // truncate if it is less than the current string length
    sret = s;
    targ = T_STR;
}



// Return a substring of ?string$? with ?number-of-chars? from the right (end) of the string.
// s$ = RIGHT$( string$, number-of-chars )
void fun_right(void) {
	int nbr;
	char *s, *p1, *p2;
	getargs(&ep, 3, ",");

	if(argc != 3) error("Incorrect number of arguments");
	s = getstring(argv[0]);
	nbr = getinteger(argv[2]);
	if(nbr < 0 || nbr > MAXSTRLEN) error("Number out of bounds");
	if(nbr > *s) nbr = *s;											// get the number of chars to copy
	sret = GetTempStrMemory();									// this will last for the life of the command
	p1 = sret; p2 = s + (*s - nbr) + 1;
	*p1++ = nbr;													// inset the length of the returned string
	while(nbr--) *p1++ = *p2++;										// and copy the characters
    targ = T_STR;
}



// return the length of a string
// nbr = LEN( string$ )
void fun_len(void) {
	iret = *(unsigned char *)getstring(ep);                         // first byte is the length
    targ = T_INT;
}



// Return the natural logarithm of the argument 'number'.
// n = LOG( number )
void fun_log(void) {
    float f;
	f = getnumber(ep);
    if(f == 0) error("Divide by zero");
	if(f < 0) error("Negative argument");
	fret = (float)log(f);
    targ = T_NBR;
}



// Returns a substring of ?string$? beginning at ?start? and continuing for ?nbr? characters.
// S$ = MID$(s, spos [, nbr])
void fun_mid(void) {
	char *s, *p1, *p2;
	int spos, nbr = 0, i;
	getargs(&ep, 5, ",");

	if(argc == 5) {													// we have MID$(s, n, m)
		nbr = getinteger(argv[4]);									// nbr of chars to return
	}
	else if(argc == 3) {											// we have MID$(s, n)
		nbr = MAXSTRLEN;											// default to all chars
	}
	else
		error("Incorrect argument count");

	s = getstring(argv[0]);											// the string
	spos = getinteger(argv[2]);										// the mid position
	if(nbr < 0 || nbr > MAXSTRLEN || spos < 1 || spos > MAXSTRLEN) error("Number out of bounds");

	sret = GetTempStrMemory();									// this will last for the life of the command
    targ = T_STR;
	if(spos > *s || nbr == 0)										// if the numeric args are not in the string
		return;														// return a null string
	else {
		i = *s - spos + 1;											// find how many chars remaining in the string
		if(i > nbr) i = nbr;										// reduce it if we don't need that many
		p1 = sret; p2 = s + spos;
		*p1++ = i;													// set the length of the MMBasic string
		while(i--) *p1++ = *p2++;									// copy the nbr chars required
	}
}



// Return the value of Pi.  Thanks to Alan Williams for the contribution
// n = PI
void fun_pi(void) {
	fret = (float)3.14159265358979L;
    targ = T_NBR;
}



// convert degrees to radians.  Thanks to Alan Williams for the contribution
// r = RAD( degrees )
void fun_rad(void) {
	fret = (float)((double)getnumber(ep)/RADCONV);
    targ = T_NBR;
}


// generate a random number that is greater than or equal to 0 but less than 1
// n = RND()
void fun_rnd(void) {
	fret = (float)rand()/((float)RAND_MAX + (float)RAND_MAX/1000000);
    targ = T_NBR;
}



// Return the sign of the argument
// n = SGN( number )
void fun_sgn(void) {
	float f;
	f = getnumber(ep);
	if(f > 0)
		iret = +1;
	else if(f < 0)
		iret = -1;
	else
		iret = 0;
    targ = T_INT;
}



// Return the sine of the argument 'number' in radians.
// n = SIN( number )
void fun_sin(void) {
	fret = (float)sin(getnumber(ep));
    targ = T_NBR;
}



// Return the square root of the argument 'number'.
// n = SQR( number )
void fun_sqr(void) {
	float f;
	f = getnumber(ep);
	if(f < 0) error("Negative argument");
	fret = (float)sqrt(f);
    targ = T_NBR;
}



// Return the tangent of the argument 'number' in radians.
// n = TAN( number )
void fun_tan(void) {
	fret = (float)tan(getnumber(ep));
    targ = T_NBR;
}



// Returns the numerical value of the ?string$?.
// n = VAL( string$ )
void fun_val(void) {
	char *p, *t1, *t2;
	p = getCstring(ep);
    targ = T_INT;
	if(*p == '&') {
		switch(*++p) {
			case 'h':
			case 'H': iret = strtoll(++p, &t1, 16); break;
			case 'o':
			case 'O': iret = strtoll(++p, &t1, 8); break;
			case 'b':
			case 'B': iret = strtoll(++p, &t1, 2); break;
			default : error("Invalid prefix");
		}
	} else {
        fret = (float) strtod(p, &t1);
        iret = strtoll(p, &t2, 10);
        if (t1 > t2) targ = T_NBR;
    }
}



#if defined(MX470)
void fun_eval(void) {
    char *s, *st, *temp_tknbuf;
    temp_tknbuf = GetTempStrMemory();
    strcpy(temp_tknbuf, tknbuf);                                    // first save the current token buffer in case we are in immediate mode
    // we have to fool the tokeniser into thinking that it is processing a program line entered at the console
    st = GetTempStrMemory();
    strcpy(st, getstring(ep));                                      // then copy the argument
    MtoC(st);                                                       // and convert to a C string
    inpbuf[0] = 'r'; inpbuf[1] = '=';                               // place a dummy assignment in the input buffer to keep the tokeniser happy
    strcpy(inpbuf + 2, st);
    tokenise(true);                                                 // and tokenise it (the result is in tknbuf)
    strcpy(st, tknbuf + 3);
    targ = T_NOTYPE;
    evaluate(st, &fret, &iret, &s, &targ, false);                   // get the value and type of the argument
    if(targ & T_STR) {
        Mstrcpy(st, s);                                             // if it is a string then save it
        sret = st;
    }
    strcpy(tknbuf, temp_tknbuf);                                    // restore the saved token buffer
}
#endif



// Returns a string of blank spaces 'number' bytes long.
// s$ = SPACE$( number )
void fun_space(void) {
	int i;

	i = getint(ep, 0, MAXSTRLEN);
	sret = GetTempStrMemory();									// this will last for the life of the command
	memset(sret + 1, ' ', i);
	*sret = i;
    targ = T_STR;
}



// Returns a string in the decimal (base 10) representation of  'number'.
// s$ = STR$( number, m, n, c$ )
void fun_str(void) {
	char *s;
	float f;
    long long int i64;
	int t;
    int m, n;
    char ch, *p;

    getargs(&ep, 7, ",");
    if((argc & 1) != 1) error("Invalid syntax");
    t = T_NOTYPE;
    p = evaluate(argv[0], &f, &i64, &s, &t, false);                 // get the value and type of the argument
    if(t & T_STR) error("Expected a number");
    m = 0; n = -1; ch = ' ';
    if(argc > 2) m = getint(argv[2], -128, 128);                    // get the number of digits before the point
    if(argc > 4) n = getint(argv[4], 0, 7);                         // get the number of digits after the point
	if(argc == 7) {
        p = getstring(argv[6]);
        if(*p == 0) error("Zero length argument");
        ch = ((unsigned char)p[1] & 0x7f);
	}

	sret = GetTempStrMemory();									    // this will last for the life of the command
    if(t & T_NBR)
        FloatToStr(sret, f, m, n, ch);                              // convert the float
    else {
        IntToStrPad(sret, i64, ch, m, 10);                          // convert the integer
        if(n > 0) {
            strcat(sret, ".");
            while(n--) strcat(sret, "0");                           // and add on any zeros after the point
        }
    }
	CtoM(sret);
    targ = T_STR;
}



// Returns a string 'nbr' bytes long
// s$ = STRING$( nbr,  string$ )
void fun_string(void) {
	int i, j;
	char *p;
	getargs(&ep, 3, ",");
	if(argc != 3) error("Invalid syntax");

	i = getint(ep, 0, MAXSTRLEN);
	if(isdigit(*argv[2]))
		j = getint(argv[2], ' ', 0x7e);
	else {
		p = getstring(argv[2]);
		if(*p == 0) error("Zero length argument");
		j = p[1];
	}
	sret = GetTempStrMemory();									// this will last for the life of the command
	memset(sret + 1, j, i);
	*sret = i;
    targ = T_STR;
}



// Returns ?string$? converted to uppercase characters.
// s$ = UCASE$( string$ )
void fun_ucase(void) {
	char *s, *p;
	int i;

	s = getstring(ep);
	p = sret = GetTempStrMemory();								// this will last for the life of the command
	i = *p++ = *s++;												// get the length of the string and save in the destination
	while(i--) {
		*p = toupper(*s);
		p++; s++;
	}
    targ = T_STR;
}



// Returns ?string$? converted to lowercase characters.
// s$ = LCASE$( string$ )
void fun_lcase(void) {
	char *s, *p;
	int i;

	s = getstring(ep);
	p = sret = GetTempStrMemory();								// this will last for the life of the command
	i = *p++ = *s++;												// get the length of the string and save in the destination
	while(i--) {
		*p = tolower(*s);
		p++; s++;
	}
    targ = T_STR;
}


// utility function used by fun_peek() to validate an address
unsigned int GetPeekAddr(char *p) {
    unsigned int i;
    i = getinteger(p);
    if(!PEEKRANGE(i)) error("Invalid address");
    return i;
}


// function to find a CFunction
// only used by fun_peek() below
unsigned int GetCFunAddr(int *ip, int i) {
    while(*ip != 0xffffffff) {
        if(*ip++ == (unsigned int)subfun[i]) {                      // if we have a match
            ip++;                                                   // step over the size word
            i = *ip++;                                              // get the offset
            return (unsigned int)(ip + i);                          // return the entry point
        }
        ip += (*ip + 4) / sizeof(unsigned int);
    }
    return 0;
}


// Will return a byte within the PIC32 virtual memory space.
void fun_peek(void) {
    char *p;
    int i, j;
    void *pp;
	getargs(&ep, 3, ",");
    if((p = checkstring(argv[0], "VARADDR"))){
        if(argc != 1) error("Invalid syntax");
        pp = findvar(p, V_FIND | V_EMPTY_OK | V_NOFIND_ERR);
        iret = (unsigned int)pp;
        targ = T_INT;
        return;
        }
    
    if((p = checkstring(argv[0], "CFUNADDR"))){
        if(argc != 1) error("Invalid syntax");
        skipspace(p);
        i = FindSubFun(p, true);                                    // search for a function first
        if(i == -1) i = FindSubFun(p, false);                       // and if not found try for a subroutine
        if(i == -1 || !(*subfun[i] == cmdCFUN || *subfun[i] == cmdCSUB)) error("Invalid argument");
        // search through program flash and the library looking for a match to the function being called
        j = GetCFunAddr((int *)CFunctionFlash, i);
        if(!j) j = GetCFunAddr((int *)CFunctionLibrary, i);
        if(!j) error("Internal fault (sorry)");
        iret = (unsigned int)j;                                     // return the entry point
        targ = T_INT;
        return;
    }
    
    if((p = checkstring(argv[0], "BYTE"))){
        if(argc != 1) error("Invalid syntax");
        iret = *(unsigned char *)GetPeekAddr(p);
        targ = T_INT;
        return;
        }
    
    if((p = checkstring(argv[0], "WORD"))){
        if(argc != 1) error("Invalid syntax");
        iret = *(unsigned int *)(GetPeekAddr(p) & 0b11111111111111111111111111111100);
        targ = T_INT;
        return;
        }
    
    if(argc != 3) error("Invalid syntax");

    if((p = checkstring(argv[0], "PROGMEM"))){
        iret = *((char *)ProgFlash + (int)getinteger(argv[2]));
        targ = T_INT;
        return;
    }

    if((p = checkstring(argv[0], "VARTBL"))){
        iret = *((char *)vartbl + (int)getinteger(argv[2]));
        targ = T_INT;
        return;
    }

    if((p = checkstring(argv[0], "VAR"))){
		pp = findvar(p, V_FIND | V_EMPTY_OK | V_NOFIND_ERR);
        iret = *((char *)pp + (int)getinteger(argv[2]));
        targ = T_INT;
        return;
    }

    // default action is the old syntax of  b = PEEK(hiaddr, loaddr)
	iret = *(char *)(((int)getinteger(argv[0]) << 16) + (int)getinteger(argv[2]));
    targ = T_INT;
}



// function (which looks like a pre defined variable) to return the version number
// it pulls apart the VERSION string to generate the number
void fun_version(void){
	char *p;
    fret = strtol(VERSION, &p, 10);
    fret += strtof(p + 1, &p)/100;
    targ = T_NBR;
}



// Returns the current cursor position in the line in characters.
// n = POS
void fun_pos(void){
	iret = MMCharPos;
    targ = T_INT;
}



// Outputs spaces until the column indicated by 'number' has been reached.
// PRINT TAB( number )
void fun_tab(void) {
	int i;
	char *p;

	i = getinteger(ep);
	if(i < 1 || i > 255) error("Number out of bounds");
	sret = p = GetTempStrMemory();							    // this will last for the life of the command
	if(MMCharPos > i) {
		i--;
		*p++ = '\r';
		*p++ = '\n';
	}
	else
		i -= MMCharPos;
	memset(p, ' ', i);
	p[i] = 0;
	CtoM(sret);
    targ = T_STR;
}



// get a character from the console input queue
// s$ = INKEY$
void fun_inkey(void){
    int i;

	sret = GetTempStrMemory();									// this buffer is automatically zeroed so the string is zero size

	i = getConsole();
	if(i != -1) {
		sret[0] = 1;												// this is the length
		sret[1] = i;												// and this is the character
	}
    targ = T_STR;
}




// to shift the bits in a number left or right
// A = BITSHIFT(nbr, bits)
//void fun_bitshift(void){
//    long long int i1, i2;
//	getargs(&ep, 3, ",");
//	if(argc != 3) error("Invalid syntax");
//    i1 = getinteger(argv[0]);
//    i2 = getinteger(argv[2]);
//    if(i2 >= 0)
//        iret = (long long int)((unsigned long long int)i1 << (unsigned long long int)i2);
//    else
//        iret = (long long int)((unsigned long long int)i1 >> (unsigned long long int)(-i2));
//
//    targ = T_INT;
//}



// used by ACos() and ASin() below
float arcsinus(float x) {
     return (float)(2 * atan(x / (1 + sqrt(1 - x * x))));
}


// Return the arcsine (in radians) of the argument 'number'.
// n = ASIN(number)
void fun_asin(void) {
     float f = getnumber(ep);
     if(f < -1.0 || f > 1.0) error("Number out of bounds");
     if (f == 1.0) {
          fret = 1.5707963268;
     } else if (f == -1.0) {
          fret = -1.5707963268;
     } else {
          fret = arcsinus(f);
     }
    targ = T_NBR;
}

// Return the arccosine (in radians) of the argument 'number'.
// n = ACOS(number)
void fun_acos(void) {
     float f = getnumber(ep);
     if(f < -1.0 || f > 1.0) error("Number out of bounds");
     if (f == 1.0) {
          fret = 0.0;
     } else if (f == -1.0) {
          fret = M_PI;
     } else {
          fret = 1.5707963268 - arcsinus(f);
     }
    targ = T_NBR;
}