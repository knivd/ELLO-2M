/***********************************************************************************************************************
MMBasic

FileIO.c

Does all the SD Card related file I/O in MMBasic.

Copyright 2011 - 2017 Geoff Graham.  All Rights Reserved.

This file and modified versions of this file are supplied to specific individuals or organisations under the following
provisions:

- This file, or any files that comprise the MMBasic source (modified or not), may not be distributed or copied to any other
  person or organisation without written permission.

- Object files (.o and .hex files) generated using this file (modified or not) may not be distributed or copied to any other
  person or organisation without written permission.

- This file is provided in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

************************************************************************************************************************/


#include "../MMBasic_Includes.h"
#include "../Hardware_Includes.h"

//** SD CARD INCLUDES ***********************************************************
#include "SDCard/SDCard.h"
#include "SDCard/FSconfig.h"
#include <stdio.h>
#include "./usb/system/fs/fat_fs/src/file_system/ff.h"


static char *pcmdl = NULL;

int SDCardPresent[SDCARD_MAX_NUM];

void File_fopen(char *fname, char *mode, int fnbr);
void FileClose(int fnbr);
char FileGetChar(int fnbr);
char FilePutChar(char c, int fnbr);
int FileEOF(int fnbr);
char *GetCWD(void);
void File_CloseAll(void);
int InitSDCard(void);
int FindFreeFileNbr(void);
char *ChangeToDir(char *p);
int CheckFileName(char *p);
void LoadImage(char *p);
void LoadFont(char *p);
static void close_Adrive(int fnbr);

/*****************************************************************************************
Mapping of errors reported by the Microchip FAT 16/32 file system to MMBasic file errors
*****************************************************************************************/
const int ErrorMap[34] = {          0,  // 0  =   No error
                                    11, // 1  =   An erase failed
                                    1,  // 2  =   No SD card found
                                    15, // 3  =   The disk is of an unsupported format
                                    15, // 4  =   The boot record is bad
                                    15, // 5  =   The file system type is unsupported
                                    15, // 6  =   An initialization error has occurred
                                    15, // 7  =   An operation was performed on an uninitialized device
                                    10, // 8  =   A bad read of a sector occurred
                                    11, // 9  =   Could not write to a sector
                                    15, // 10 =  Invalid cluster value
                                    6,  // 11 =  Could not find the file on the device
                                    7,  // 12 =  Could not find the directory
                                    10, // 13 =  File is corrupted
                                    0,  // 14 =  No more files in this directory
                                    15, // 15 =  Could not load/allocate next cluster in file
                                    5,  // 16 =  A specified file name is too long to use
                                    9,  // 17 =  A specified filename already exists on the device
                                    5,  // 18 =  Invalid file name
                                    12, // 19 =  Attempt to delete a directory with KILL
                                    4,  // 20 =  All root directory entries are taken
                                    3,  // 21 =  All clusters in partition are taken
                                    14, // 22 =  This directory is not empty yet, remove files before deleting
                                    15, // 23 =  The disk is too big to format as FAT16
                                    2,  // 24 =  Card is write protected
                                    11, // 25 =  File not opened for the write
                                    11, // 26 =  File location could not be changed successfully
                                    10, // 27 =  Bad cache read
                                    15, // 28 =  FAT 32 - card not supported
                                    8,  // 29 =  The file is read-only
                                    10, // 30 =  The file is write-only
                                    15, // 31 =  Invalid argument
                                    9,  // 32 =  Too many files are already open
                                    15, // 33 =  Unsupported sector size
                            };

/******************************************************************************************
Text for the file related error messages reported by MMBasic
******************************************************************************************/

const char *FErrorMsg[NBRERRMSG] = {    "No error",                                 // 0
                                        "SD card not present",                      // 1
                                        "SD card is write protected",               // 2
                                        "No space on media",                        // 3
                                        "All root directory entries are taken",     // 4
                                        "Invalid file or directory name",           // 5
                                        "Cannot find file",                         // 6
                                        "Cannot find or create directory",          // 7
                                        "File is read only",                        // 8
                                        "Cannot open file",                         // 9
                                        "Cannot read from file",                    // 10
                                        "Cannot write to file",                     // 11
                                        "Not a file",                               // 12
                                        "Not a directory",                          // 13
                                        "Directory not empty",                      // 14
                                        "Cannot access the SD card",                // 15
                                        "Flash memory write failure"                // 16
                                    };

//
//
char* GetPrompt(void) {
char* pPrompt;

    switch(Option.DEFAULT_DRIVE) {
        case SDFS1:
            pPrompt = "B>";
            break;
        case SDFS2:
            pPrompt = "C>";
            break;            
        case SDFS3:
            pPrompt = "D>";
            break;     
        case SDFS4:
            pPrompt = "E>";
            break;
        case FLASHFS:
            pPrompt = "A>";
            break;
        default:
            pPrompt = "> ";
            break;
    }
    return pPrompt;
}

//////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////// MMBASIC COMMANDS & FUNCTIONS FOR THE SDCARD /////////////////////////////



////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// configure the SD card parameters (chip select, write protect and card detect pins)
// this is called by the OPTION SDCARD command
void ConfigSDCard(char *p, unsigned char sd_number) {  
unsigned char i;
unsigned char cnt = 0;
unsigned char arg_offset = 0;
sdcard_t tmp_sdc;

    getargs(&p, 11, ",");
    if(!(argc & 1)) error("Incorrect argument count");
    if(sd_number >= SDCARD_MAX_NUM) error("Incorrect argument count");
    
    tmp_sdc.CS = tmp_sdc.CD = tmp_sdc.WP = 0;
    tmp_sdc.MUX_ENABLE = FALSE; tmp_sdc.MUXn = 0;
    tmp_sdc.DRV0 = tmp_sdc.DRV1 = 0;
    
    if(checkstring(argv[0], "MUX0")) {
       tmp_sdc.MUX_ENABLE = TRUE; 
       tmp_sdc.MUXn = 0;
    }
    else if(checkstring(argv[0], "MUX1")) {
        tmp_sdc.MUX_ENABLE = TRUE;
        tmp_sdc.MUXn = 1;
    }    
    else if(checkstring(argv[0], "MUX2")) {
        tmp_sdc.MUX_ENABLE = TRUE;
        tmp_sdc.MUXn = 2;        
    }  
    else if(checkstring(argv[0], "MUX3")) {
        tmp_sdc.MUX_ENABLE = TRUE;
        tmp_sdc.MUXn = 3;        
    }      
    
    if(tmp_sdc.MUX_ENABLE) {
        if( argc < 7 ) error("Incorrect argument count");
        arg_offset = 6;        
    }
    
    if(FALSE == tmp_sdc.MUX_ENABLE) {
        CheckPin(getinteger(argv[arg_offset+0]), CP_IGNORE_INUSE); // | CP_IGNORE_BOOTRES | CP_IGNORE_RESERVED);
        if(argc > arg_offset+2) {
            CheckPin(abs(getinteger(argv[arg_offset+2])), CP_IGNORE_INUSE); // | CP_IGNORE_BOOTRES | CP_IGNORE_RESERVED);
            tmp_sdc.CD = getinteger(argv[arg_offset+2]);
        }
        tmp_sdc.CS = getinteger(argv[arg_offset+0]);
    }
    if(argc == arg_offset+5) {
        CheckPin(abs(getinteger(argv[arg_offset+4])), CP_IGNORE_INUSE); // | CP_IGNORE_BOOTRES | CP_IGNORE_RESERVED);
        tmp_sdc.WP = getinteger(argv[arg_offset+4]);
    }    
  
    Option.SDCARD[sd_number].WP          = tmp_sdc.WP;
    Option.SDCARD[sd_number].MUX_ENABLE  = tmp_sdc.MUX_ENABLE;
    Option.SDCARD[sd_number].MUXn        = tmp_sdc.MUXn;
    
    if(tmp_sdc.MUX_ENABLE) {
        for(i=0; i<SDCARD_MAX_NUM; i++) {
            if(Option.SDCARD[i].MUX_ENABLE) ++cnt;
        }
        if(cnt == 1) {
            CheckPin(getinteger(argv[6]), CP_IGNORE_INUSE); // | CP_IGNORE_BOOTRES | CP_IGNORE_RESERVED);
            if(argc > 8) {
                CheckPin(abs(getinteger(argv[8])), CP_IGNORE_INUSE); // | CP_IGNORE_BOOTRES | CP_IGNORE_RESERVED);
                tmp_sdc.CD = getinteger(argv[8]);
            }
            tmp_sdc.CS = getinteger(argv[6]);                    
            CheckPin(abs(getinteger(argv[2])), CP_IGNORE_INUSE); // | CP_IGNORE_BOOTRES | CP_IGNORE_RESERVED);
            tmp_sdc.DRV0 = getinteger(argv[2]);        
            CheckPin(abs(getinteger(argv[4])), CP_IGNORE_INUSE); // | CP_IGNORE_BOOTRES | CP_IGNORE_RESERVED);
            tmp_sdc.DRV1 = getinteger(argv[4]);         
            SetAndReserve(tmp_sdc.DRV0, P_OUTPUT, (tmp_sdc.MUXn&1), EXT_BOOT_RESERVED);            // config DRV0 as an output
            SetAndReserve(tmp_sdc.DRV1, P_OUTPUT, (tmp_sdc.MUXn&2)>>1, EXT_BOOT_RESERVED);         // config DRV1 as an output  
        }
        else if(cnt > 1) {
            for(i=0; i<SDCARD_MAX_NUM; i++) { 
                if(Option.SDCARD[i].MUX_ENABLE && (Option.SDCARD[i].DRV0 > 0)) {
                    tmp_sdc.CS = Option.SDCARD[i].CS;
                    tmp_sdc.CD =  Option.SDCARD[i].CD;
                    tmp_sdc.DRV0 = Option.SDCARD[i].DRV0;
                    tmp_sdc.DRV1 = Option.SDCARD[i].DRV1;
                    break;
                }
            }
        }
    }

    Option.SDCARD[sd_number].CS          = tmp_sdc.CS;
    Option.SDCARD[sd_number].CD          = tmp_sdc.CD;    
    Option.SDCARD[sd_number].DRV0        = tmp_sdc.DRV0;
    Option.SDCARD[sd_number].DRV1        = tmp_sdc.DRV1;    
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// disable the SD card, parameter - sd_number
// this is called by the OPTION SDCARD command
void DisableSDCard(unsigned char sd_number) {
unsigned char i; 
unsigned char cnt = 0; 

    if(sd_number >= SDCARD_MAX_NUM) error("Incorrect argument count");
    if(Option.SDCARD[sd_number].MUX_ENABLE) {
        for(i=0; i<SDCARD_MAX_NUM; i++)
        {
            if(Option.SDCARD[i].MUX_ENABLE) ++cnt;
        }
        if(cnt == 1) {
            SetAndReserve(Option.SDCARD[sd_number].DRV0, P_INPUT, 0, EXT_NOT_CONFIG);
            SetAndReserve(Option.SDCARD[sd_number].DRV1, P_INPUT, 0, EXT_NOT_CONFIG);
        }
    }
    Option.SDCARD[sd_number].CS = Option.SDCARD[sd_number].CD = Option.SDCARD[sd_number].WP = 0;
    Option.SDCARD[sd_number].MUX_ENABLE = FALSE; Option.SDCARD[sd_number].MUXn = 0;
    Option.SDCARD[sd_number].DRV0 = Option.SDCARD[sd_number].DRV1 = 0;    
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// setup the SD Card based on the settings saved in flash
void InitFileIO(void) {
    unsigned char i;
    unsigned char cnt_cs = 0;
    unsigned char cnt_mux = 0;
    
    for(i=0; i<SDCARD_MAX_NUM; i++){
        if(Option.SDCARD[i].CS){
            ++cnt_cs;
            SetAndReserve(Option.SDCARD[i].CS, P_OUTPUT, 1, EXT_BOOT_RESERVED);           // config CS as an output
            if(Option.SDCARD[i].CD) {
                SetAndReserve(abs(Option.SDCARD[i].CD), P_INPUT, 0, EXT_BOOT_RESERVED);       // config card detect as an input
                PinSetBit(abs(Option.SDCARD[i].CD), CNPUSET);                                 // set a pullup on it
            }
            if(Option.SDCARD[i].WP) {
                SetAndReserve(abs(Option.SDCARD[i].WP), P_INPUT, 0, EXT_BOOT_RESERVED);       // config write protect as an input
                PinSetBit(abs(Option.SDCARD[i].WP), CNPUSET);                                 // set a pullup on it
            }
            if(Option.SDCARD[i].MUX_ENABLE && (cnt_mux == 0))
            {
                ++cnt_mux;
                SetAndReserve(Option.SDCARD[i].DRV0, P_OUTPUT, (Option.SDCARD[i].MUXn&1), EXT_BOOT_RESERVED);            // config DRV0 as an output
                SetAndReserve(Option.SDCARD[i].DRV1, P_OUTPUT, (Option.SDCARD[i].MUXn&2)>>1, EXT_BOOT_RESERVED);         // config DRV1 as an output                  
            }            
        }// set a pullup on MISO as the SD card initially uses open collector
    }
    if(cnt_cs)
    {
        OpenSpiChannel();
        PinSetBit(SPI2_INP_PIN, CNPUSET);        
    }
    if(Option.MSDStatus) {
        MSD_NVM_Attach(true);
    }
    
}

    

void cmd_save(void) {
    int fnbr, err;
    char *p, *pp;
    char b[STRINGSIZE];

//    if(CurrentLinePtr) error("Invalid in a program");
    fnbr = FindFreeFileNbr();
    if(FLASHFS == Option.DEFAULT_DRIVE) {       
        if(SYS_FS_Mount("/dev/nvma1", "/mnt/MM Drive", FAT, 0, NULL) != 0) {
            error("Cannot access drive A");
            return;
        }        
    }
    else {
        if(!InitSDCard()) return;
        if(year > 2010) SetClockVars(year, month, day, hour, minute, second);
    }
    p = getCstring(cmdline);                           // get the file name and change to the directory
	if(strchr(p, '.') == NULL) strcat(p, ".BAS");
    if(FLASHFS == Option.DEFAULT_DRIVE) {
        appData.fileHandle = SYS_FS_FileOpen(p, SYS_FS_FILE_OPEN_WRITE);
        if(appData.fileHandle == SYS_FS_HANDLE_INVALID) {
            /* Could not open the file. Error out*/
            SYS_FS_Unmount("/mnt/MM Drive");
            uSec(10000);
            error("Could not open the file");
        }        
        OpenFileTable[fnbr] = (unsigned int)appData.fileHandle;        
    } 
    else {
        OpenFileTable[fnbr] = (unsigned int)FSfopen(p, "w");
        if((err = FSerror()) != 0) {
            ErrorThrow(ErrorMap[err]);
            return;
        }
    }
    p  = ProgFlash;
    while(!(*p == 0 || *p == 0xff)) {                               // this is a safety precaution
        p = llist(b, p);                                            // expand the line
        pp = b;
        while(*pp) FilePutChar(*pp++, fnbr);                        // write the line to the SD card
        FilePutChar('\r', fnbr); FilePutChar('\n', fnbr);           // terminate the line
        if(p[0] == 0 && p[1] == 0) break;                           // end of the listing ?
    }

    FileClose(fnbr); 
}

#if 1
/* Create a C array image of drive A. For developer use only. */
void cmd_adriveimage(void) {
    unsigned int i, j, k, p;
    unsigned int num_imagesize;
    unsigned int *pdiskimage;
    unsigned int *pdataimage;
    unsigned char dataimg[4];
    char s[12];
    char * ps;
    int fnbr, err;

    num_imagesize = A_DISK_BYTE_SIZE;
    pdiskimage = (unsigned int *)KVA0_TO_KVA1(AdiskImage);
    pdataimage = (unsigned int *)dataimg;
            
    if(FLASHFS == Option.DEFAULT_DRIVE) {
        error("The image can not be saved to A drive");
    }
    fnbr = FindFreeFileNbr();   
    if(!InitSDCard()) return;
    if(year > 2010) SetClockVars(year, month, day, hour, minute, second);    
    OpenFileTable[fnbr] = (unsigned int)FSfopen("Aimg.c", "w");
    if((err = FSerror()) != 0) {
        ErrorThrow(ErrorMap[err]);
        return;
    } 
    if(Option.MSDStatus) {    
        MSD_NVM_Attach(false);
    }
    ps = "const unsigned char AdiskImage[A_DISK_BYTE_SIZE] = \r\n";
    while(!(*ps == 0)) {
        FilePutChar(*ps++, fnbr); 
    }
    
    FilePutChar('{', fnbr); FilePutChar('\r', fnbr); FilePutChar('\n', fnbr);
    for(i=0; i < num_imagesize; i+=512) {
        for(j=0; j < 32; j++) {
            for(k=0; k < 16; k+=4) {
                *pdataimage = *pdiskimage;
                for(p = 0; p < 4; p++) {
                    ps = s;
                    if((k == 0)&&(p == 0)) {
                        *ps++   = 0x09;                 // HTab
                    }
                    *ps++   = '0';
                    *ps++   = 'x'; 
                    if(dataimg[p] < 16) {
                        *ps++   = '0';     
                    }
                    *ps     = '\0';

                    IntToStr(ps, dataimg[p], 16);
                    ps = s;
                    while(!(*ps == 0)) {
                        FilePutChar(*ps++, fnbr); 
                    }
                    FilePutChar(',', fnbr); FilePutChar(' ', fnbr);
                }
                ++pdiskimage;
            }
            FilePutChar('\r', fnbr); FilePutChar('\n', fnbr);
        }
        FilePutChar('\r', fnbr); FilePutChar('\n', fnbr);
    }
    FilePutChar('}', fnbr); FilePutChar(';', fnbr); FilePutChar('\r', fnbr); FilePutChar('\n', fnbr);
    if(Option.MSDStatus) {
        MSD_NVM_Attach(true);
    }
    FileClose(fnbr);    
}
#endif

void cmd_imagea(void) {
    char *fname;
    int fnbr, err; 
    unsigned int i;
    unsigned int num_imagesize;
    unsigned int *pdiskimage;
    unsigned int *pdataimage;
    unsigned char dataimg[4];
    
    getargs(&cmdline, 5, ",");    
    if(argc != 3) {
        error("Invalid Syntax");
    }
    
    if((toupper(*argv[0]) != 'C') && (toupper(*argv[0]) != 'L')) {
        error("Invalid Argument");
    }
    
    if(FLASHFS == Option.DEFAULT_DRIVE) {
        error("The image can not be saved/loaded to/from drive A");
    }    
    
    fname = getCstring(argv[2]);
    fnbr = FindFreeFileNbr();   
    if(!InitSDCard()) return;
    if(year > 2010) SetClockVars(year, month, day, hour, minute, second);     
    
    num_imagesize = A_DISK_BYTE_SIZE;
    pdataimage = (unsigned int *)dataimg;     
    
    if(toupper(*argv[0]) == 'C') {
        OpenFileTable[fnbr] = (unsigned int)FSfopen(fname, "w");
        if((err = FSerror()) != 0) {
            OpenFileTable[fnbr] = 0;
            ErrorThrow(ErrorMap[err]);
            return;
        }
        pdiskimage = (unsigned int *)KVA0_TO_KVA1(AdiskImage);
        if(Option.MSDStatus) {
            MSD_NVM_Attach(false); 
            uSec(600000);
        }
        for(i=0; i < num_imagesize; i+=4) {
            *pdataimage = *pdiskimage; 
            if(FSfwrite(dataimg, 1, 4, (FSFILE *)OpenFileTable[fnbr]) == 0) {
                if(ErrorCheck() == 0) {
                    if(Option.MSDStatus) {
                        MSD_NVM_Attach(true);
                    }
                    FileClose(fnbr);
                    ErrorThrow(9);
                }
            }
            ++pdiskimage;
        }
        if(Option.MSDStatus) {
            MSD_NVM_Attach(true);
        }
        FileClose(fnbr);        
    }
    else if(toupper(*argv[0]) == 'L') {   
        OpenFileTable[fnbr] = (unsigned int)FSfopen(fname, "r");
        if((err = FSerror()) != 0) {
            OpenFileTable[fnbr] = 0;
            ErrorThrow(ErrorMap[err]);
            return;
        }    
        unsigned int adrive_base;
        adrive_base = A_DISK_START_ADDRESS;
        if(Option.MSDStatus) {
            MSD_NVM_Attach(false);       
            uSec(600000);
        }
        for(i=0; i < A_DISK_BYTE_SIZE/A_DISK_BYTE_PAGE_SIZE; i++) {
            /* Erase flash page */
            NVMErasePage((unsigned int *)(adrive_base + i * A_DISK_BYTE_PAGE_SIZE)); 
        }        
        
        for(i=0; i < num_imagesize; i+=4) {
            if(FSfread(dataimg, 1, 4, (FSFILE *)OpenFileTable[fnbr]) == 0) {
                if(ErrorCheck() == 0) {
                    for(i=0; i < A_DISK_BYTE_SIZE/A_DISK_BYTE_PAGE_SIZE; i++) {
                        /* Erase flash page */
                        NVMErasePage((unsigned int *)(adrive_base + i * A_DISK_BYTE_PAGE_SIZE)); 
                    } 
                    if(Option.MSDStatus) {
                        MSD_NVM_Attach(true);
                    }
                    FileClose(fnbr);
                    ErrorThrow(9);
                }
            }
            /* Write word to flash memory. */
            NVMWriteWord((unsigned int*)(adrive_base + i), *pdataimage);
        }
        if(Option.MSDStatus) {
            MSD_NVM_Attach(true);
        }
        FileClose(fnbr);        
    }
}



void cmd_load(void) {
    int fnbr, err, autorun = false;
    char *p, *buf;
    int c;

    p = checkstring(cmdline, "IMAGE");
	if(p) {
        if(FLASHFS == Option.DEFAULT_DRIVE) {
            error("unsupported function IMAGE for drive A");
            return;
        }
        LoadImage(p);
        return;
    }

    // else it must be a normal LOAD program command
    else {
        getargs(&cmdline, 3, ",");
        if(!(argc & 1) || argc == 0) error("Invalid syntax");
        if(argc == 3) {
            if(toupper(*argv[2]) == 'R')
                autorun = true;
            else
                error("Invalid syntax");
        }

        ClearProgram();												// clear any leftovers from the previous program
        fnbr = FindFreeFileNbr();

        if(FLASHFS != Option.DEFAULT_DRIVE) {
            if(!InitSDCard()) return;
            if(year > 2010) SetClockVars(year, month, day, hour, minute, second);
        }
        p = getCstring(argv[0]);                       // get the file name and change to the directory
        if(strchr(p, '.') == NULL) strcat(p, ".BAS");
        if(FLASHFS == Option.DEFAULT_DRIVE) {          
            if(SYS_FS_Mount("/dev/nvma1", "/mnt/MM Drive", FAT, 0, NULL) != 0) {
                error("Cannot access drive A");
                return;
            }           
            appData.fileHandle = SYS_FS_FileOpen(p, SYS_FS_FILE_OPEN_READ);
            if(appData.fileHandle == SYS_FS_HANDLE_INVALID) {
                /* Could not open the file. Error out*/
                SYS_FS_Unmount("/mnt/MM Drive");
                uSec(10000);
                error("Could not open the file");
            }        
            OpenFileTable[fnbr] = (unsigned int)appData.fileHandle;
            p = buf = GetTempMemory(EDIT_BUFFER_SIZE - 512);
            while(!SYS_FS_FileEOF(appData.fileHandle)) {                                     // while waiting for the end of file
                if((p - buf) >= EDIT_BUFFER_SIZE - 512) {
                    SYS_FS_FileClose((SYS_FS_HANDLE)OpenFileTable[fnbr]);
                    SYS_FS_Unmount("/mnt/MM Drive");
                    uSec(10000);
                    error("Not enough memory");
                }
                c = FileGetChar(fnbr);
                if(c<0 || c>127 || isprint(c) || c == '\r' || c == '\n' || c == TAB) {
                    if(c == TAB) c = ' ';
                    *p++ = c;                                           // get the input into RAM
                }
            }            
        }
        else {
            OpenFileTable[fnbr] = (unsigned int)FSfopen(p, "r");
            if((err = FSerror()) != 0) {
                ErrorThrow(ErrorMap[err]);
                return;
            }
            
            p = buf = GetTempMemory(EDIT_BUFFER_SIZE - 512);
            while(!FileEOF(fnbr)) {                                     // while waiting for the end of file
                if((p - buf) >= EDIT_BUFFER_SIZE - 512) error("Not enough memory");
                c = FileGetChar(fnbr);
                if(c<0 || c>127 || isprint(c) || c == '\r' || c == '\n' || c == TAB) {
                    if(c == TAB) c = ' ';
                    *p++ = c;                                           // get the input into RAM
                }
            }
        }
        *p = 0;                                                     // terminate the string in RAM
        
        if(FLASHFS == Option.DEFAULT_DRIVE) {
            close_Adrive(fnbr);
        }
        else {
            FileClose(fnbr);
        }        
	
        SaveProgramToFlash(buf, false);
        SaveProgramToFlash(buf, false);
        if(autorun) {
            if(*ProgFlash != 0x01) return;                          // no program to run
            ClearRuntime();
            WatchdogSet = false;
            PrepareProgram(true);
            IgnorePIN = false;
            if(Option.ProgFlashSize != PROG_FLASH_SIZE) ExecuteProgram(ProgFlash + Option.ProgFlashSize);       // run anything that might be in the library
            nextstmt = ProgFlash;
        }
    }
}



void cmd_init(void) {
char *p;
int err = 0;
int i;
    
	p = getCstring(cmdline);
    if(*p == 'A' || *p == 'a') {
        error("unsupported function for drive A");
        return;
    }
    else if(*p == 'B' || *p == 'b') {
		Option.DEFAULT_DRIVE = SDFS1;
	}
	else if(*p == 'C' || *p == 'c') {
		Option.DEFAULT_DRIVE = SDFS2;
    }
	else if(*p == 'D' || *p == 'd') {
		Option.DEFAULT_DRIVE = SDFS3;
    }
	else if(*p == 'E' || *p == 'e') {
		Option.DEFAULT_DRIVE = SDFS4;
    }    
	else {
        error("Unrecognised drive letter");
    }
    // reset mm.errno to zero
    ErrorThrow(0); 
    
    if(Option.SDCARD[Option.DEFAULT_DRIVE].MUX_ENABLE) {
        PinSetBit(Option.SDCARD[Option.DEFAULT_DRIVE].DRV0, (Option.SDCARD[Option.DEFAULT_DRIVE].MUXn&1) ? LATSET : LATCLR);
        PinSetBit(Option.SDCARD[Option.DEFAULT_DRIVE].DRV1, (Option.SDCARD[Option.DEFAULT_DRIVE].MUXn&2)>>1 ? LATSET : LATCLR);
    }
        
    while(1)
    {
        if(!Option.SDCARD[Option.DEFAULT_DRIVE].CS) { 
//            MMPrintString("Cannot access the SD card\r\n");
            err = 15;
            break;
        }
        for(i = 0; i < MAXOPENFILES; i++) 
            if(OpenFileTable[i] > MAXOPENFILES) 
                OpenFileTable[i] = 0;                                // delete any file handles (but not open COM ports)
        if(!MDD_MediaDetect()) {  
//            MMPrintString("SD card not present\r\n");
            err = 1; 
            break;
        }
        if(!FSInit())  
        { 
//            MMPrintString("Cannot access the SD card\r\n");
            err = 15;
            break;
        }  
        break;
    }
    if(err != 0) {
        if(FLASHFS == Option.PREV_DRIVE) {
            SDCardPresent[Option.DEFAULT_DRIVE] = false;
            Option.DEFAULT_DRIVE = Option.PREV_DRIVE;             
        }
        else {
            SDCardPresent[Option.DEFAULT_DRIVE] = false;
            Option.DEFAULT_DRIVE = Option.PREV_DRIVE;
            SDCardPresent[Option.DEFAULT_DRIVE] = false;
            if(Option.SDCARD[Option.DEFAULT_DRIVE].MUX_ENABLE) {
                PinSetBit(Option.SDCARD[Option.DEFAULT_DRIVE].DRV0, (Option.SDCARD[Option.DEFAULT_DRIVE].MUXn&1) ? LATSET : LATCLR);
                PinSetBit(Option.SDCARD[Option.DEFAULT_DRIVE].DRV1, (Option.SDCARD[Option.DEFAULT_DRIVE].MUXn&2)>>1 ? LATSET : LATCLR);
            }
            (void)InitSDCard();
            ErrorThrow(err);
        }
    }
    else {
        SDCardPresent[Option.DEFAULT_DRIVE] = true;
        FSformat(0,mSecTimer,"MM DriveSD");
        err = FSerror();
        if(FLASHFS == Option.PREV_DRIVE) {
            SDCardPresent[Option.DEFAULT_DRIVE] = false;
            Option.DEFAULT_DRIVE = Option.PREV_DRIVE;             
        }
        else {
            SDCardPresent[Option.DEFAULT_DRIVE] = false;
            Option.DEFAULT_DRIVE = Option.PREV_DRIVE;
            SDCardPresent[Option.DEFAULT_DRIVE] = false;
            if(Option.SDCARD[Option.DEFAULT_DRIVE].MUX_ENABLE) {
                PinSetBit(Option.SDCARD[Option.DEFAULT_DRIVE].DRV0, (Option.SDCARD[Option.DEFAULT_DRIVE].MUXn&1) ? LATSET : LATCLR);
                PinSetBit(Option.SDCARD[Option.DEFAULT_DRIVE].DRV1, (Option.SDCARD[Option.DEFAULT_DRIVE].MUXn&2)>>1 ? LATSET : LATCLR);
            }
            (void)InitSDCard();
        }
        if(err != 0) {
            ErrorThrow(err);
            return;
        }
    }
    
    uSec(10000);      
}



// search for a volume label, directory or file
// s$ = DIR$(fspec, VOL|DIR|FILE)       will return the first entry
// s$ = DIR$()                          will return the next
// If s$ is empty then no (more) files found
void fun_dir(void) {
    static SearchRec file;
    int r, flags = 0;
    char *p;

    if(FLASHFS == Option.DEFAULT_DRIVE) {
        error("unsupported function for drive A");
    }    
    getargs(&ep, 3, ",");
    if(!(argc == 0 || argc == 3)) error("Invalid syntax");

    if(argc == 3) {
        if(checkstring(argv[2], "VOL"))
            flags = ATTR_VOLUME;
        else if(checkstring(argv[2], "DIR"))
            flags = ATTR_DIRECTORY;
        else if(checkstring(argv[2], "FILE"))
            flags = ATTR_HIDDEN | ATTR_SYSTEM | ATTR_READ_ONLY | ATTR_ARCHIVE;
        else
            error("Invalid flag specification");
    }

    if(!InitSDCard()) ErrorThrow(1);                            // setup the SD card

    if(argc != 0) {
        // this must be the first call eg:  DIR$("*.*", FILE)
        p = getCstring(argv[0]);
        r = FindFirst(p, flags, &file);
    } else
        // this is a subsequent call for more files
        r = FindNext(&file);

    sret = GetTempStrMemory();                                    // this will last for the life of the command
    if(r) return;                                                   // no more file names so return empty
    ErrorCheck();

    strcpy(sret, file.filename);
    CtoM(sret);                                                     // convert to a MMBasic style string
    targ = T_STR;
}



void cmd_mkdir(void) {
    char *p;

    if(FLASHFS == Option.DEFAULT_DRIVE) {
        error("unsupported function for drive A");
    }
    p = getCstring(cmdline);                                        // get the directory name and convert to a standard C string
    if(!InitSDCard()) return;
    FSmkdir(p);
    ErrorCheck();
}



void cmd_rmdir(void){
    char *p;

    if(FLASHFS == Option.DEFAULT_DRIVE) {
        error("unsupported function for drive A");
    }  
    p = getCstring(cmdline);                                        // get the directory name and convert to a standard C string
    if(!InitSDCard()) return;
    FSrmdir(p, false);
    ErrorCheck();
}



void cmd_chdir(void){
    char *p;

    if(FLASHFS == Option.DEFAULT_DRIVE) {
        error("unsupported function for drive A");
    }  
    p = getCstring(cmdline);                                        // get the directory name and convert to a standard C string
    if(!InitSDCard()) return;
    FSchdir(p);
    ErrorCheck();
}



void fun_cwd(void) {
    MMerrno = 0;
    sret = CtoM(GetCWD());
    targ = T_STR;
}



void fun_drive(void) {
    if(FLASHFS == Option.DEFAULT_DRIVE) {
        iret = 0;
    }
    else {
        iret = Option.DEFAULT_DRIVE + 1;                         // first byte is the length
    }
    targ = T_INT;
}



void cmd_kill(void){
    char *p;
    int err;

    p = getCstring(cmdline);                                        // get the file name
    
    if(FLASHFS == Option.DEFAULT_DRIVE) {
        SYS_FS_RESULT res;
        
        if(!CheckFileName(p)) { ErrorThrow(6); return; }
        if(SYS_FS_Mount("/dev/nvma1", "/mnt/MM Drive", FAT, 0, NULL) != 0) {
            error("Cannot access drive A");
            return;
        } 
        res = SYS_FS_FileDirectoryRemove(p);
        if(res == SYS_FS_RES_FAILURE) {
            SYS_FS_Unmount("/mnt/MM Drive");
            error("Directory remove operation failed");
        }
        SYS_FS_Unmount("/mnt/MM Drive");
        if(Option.MSDStatus) {
            MSD_NVM_Attach(false);
            uSec(600000);
            MSD_NVM_Attach(true); 
        }        
    }
    else {
        if(!InitSDCard()) return;
        if(!CheckFileName(p)) { ErrorThrow(6); return; }
        FSremove(p);
        if((err = FSerror()) != 0) {
            ErrorThrow(ErrorMap[err]);
            return;
        }
        ErrorCheck();
    }   
}


void cmd_drive(void) {
    char *p;
    char *ptmp_cmd;
    int err = 0;
    int i;
    
    ptmp_cmd = pcmdl;
    pcmdl = 0;
    if(ptmp_cmd) {
        p = getCstring(ptmp_cmd);
    }
    else {
        p = getCstring(cmdline);
    }

    if(*p == 'A' || *p == 'a') {
        if(SYS_FS_Mount("/dev/nvma1", "/mnt/MM Drive", FAT, 0, NULL) != 0) {
            MMPrintString("Cannot access drive A\r\n");
            uSec(10000);
            return;
        }    
        Option.DEFAULT_DRIVE = FLASHFS;
        for(i = 0; i < MAXOPENFILES; i++) 
            if(OpenFileTable[i] > MAXOPENFILES) 
                OpenFileTable[i] = 0;                                // delete any file handles (but not open COM ports)
        if(FLASHFS != Option.PREV_DRIVE) {
            SDCardPresent[Option.PREV_DRIVE] = false;
        }
        Option.PREV_DRIVE = Option.DEFAULT_DRIVE;
        SYS_FS_Unmount("/mnt/MM Drive");
        uSec(10000);
        return;
    }
    else if(*p == 'B' || *p == 'b') {
        if(Option.SDCARD[SDCARD_1].CS) {
            Option.DEFAULT_DRIVE = SDFS1;
        }
        else {
            err = 1;
        }
	}
	else if(*p == 'C' || *p == 'c') {
        if(Option.SDCARD[SDCARD_2].CS) {
            Option.DEFAULT_DRIVE = SDFS2;
        }
        else {
            err = 1;
        }
    }
	else if(*p == 'D' || *p == 'd') {
        if(Option.SDCARD[SDCARD_3].CS) {
            Option.DEFAULT_DRIVE = SDFS3;
        }
        else {
            err = 1;
        }
    }
	else if(*p == 'E' || *p == 'e') {
        if(Option.SDCARD[SDCARD_4].CS) {
            Option.DEFAULT_DRIVE = SDFS4;
        }
        else {
            err = 1;
        }
    }    
	else
    {
        error("Unrecognised drive letter");
    }
    
    if(err != 0) {
        ErrorThrow(err);
    }
    
    // reset mm.errno to zero
    ErrorThrow(0); 
    
    if(Option.SDCARD[Option.DEFAULT_DRIVE].MUX_ENABLE) {
        PinSetBit(Option.SDCARD[Option.DEFAULT_DRIVE].DRV0, (Option.SDCARD[Option.DEFAULT_DRIVE].MUXn&1) ? LATSET : LATCLR);
        PinSetBit(Option.SDCARD[Option.DEFAULT_DRIVE].DRV1, (Option.SDCARD[Option.DEFAULT_DRIVE].MUXn&2)>>1 ? LATSET : LATCLR);
    }
        
    while(1)
    {
        if(!MDD_MediaDetect()) {  
//            MMPrintString("Cannot access the SD card\r\n");
            err = 15; 
            break;
        }
        if(!FSInit())  
        { 
//            MMPrintString("Cannot access the SD card\r\n");
            err = 15;
            break;
        }  
        for(i = 0; i < MAXOPENFILES; i++) 
            if(OpenFileTable[i] > MAXOPENFILES) 
                OpenFileTable[i] = 0;                                // delete any file handles (but not open COM ports)        
        break;
    }
    if(err != 0) {
        if(FLASHFS == Option.PREV_DRIVE) {
            SDCardPresent[Option.DEFAULT_DRIVE] = false;
            Option.DEFAULT_DRIVE = Option.PREV_DRIVE;             
        }
        else {
            SDCardPresent[Option.DEFAULT_DRIVE] = false;
            Option.DEFAULT_DRIVE = Option.PREV_DRIVE;
            SDCardPresent[Option.DEFAULT_DRIVE] = false;
            if(Option.SDCARD[Option.DEFAULT_DRIVE].MUX_ENABLE) {
                PinSetBit(Option.SDCARD[Option.DEFAULT_DRIVE].DRV0, (Option.SDCARD[Option.DEFAULT_DRIVE].MUXn&1) ? LATSET : LATCLR);
                PinSetBit(Option.SDCARD[Option.DEFAULT_DRIVE].DRV1, (Option.SDCARD[Option.DEFAULT_DRIVE].MUXn&2)>>1 ? LATSET : LATCLR);
            }
            if(MDD_MediaDetect()) {
                (void)InitSDCard();   
            }
        }
        ErrorThrow(err);
    }
    else {
        Option.PREV_DRIVE = Option.DEFAULT_DRIVE;
        SDCardPresent[Option.DEFAULT_DRIVE] = true;
    }
    uSec(10000); 
}


void cmd_a_drive(void) {
    
    pcmdl = "\"a\"";
    cmd_drive();
}


void cmd_b_drive(void) {
    
    pcmdl = "\"b\"";
    cmd_drive();
}


void cmd_c_drive(void) {
    
    pcmdl = "\"c\"";
    cmd_drive();
}


void cmd_d_drive(void) {
    
    pcmdl = "\"d\"";
    cmd_drive();
}


void cmd_e_drive(void) {
    
    pcmdl = "\"e\"";
    cmd_drive();
}

/*
void cmd_name(void) {
    FSFILE *fp;
    char *old, *new, ss[2];
    ss[0] = tokenAS;                                                // this will be used to split up the argument line
    ss[1] = 0;
    {                                                               // start a new block
        getargs(&cmdline, 3, ss);                                   // getargs macro must be the first executable stmt in a block
        if(argc != 3) error("Invalid syntax");
        old = getCstring(argv[0]);                                  // get the old file name (does not have to use quote marks in immediate mode)
        new = getCstring(argv[2]);                                  // get the new file name (ditto)
        if(str_equal(old, new)) error("Old and new filenames are the same");
        if(!InitSDCard()) return;
        if(!CheckFileName(old)) { ErrorThrow(6); return; }
        if(CheckFileName(new)) { ErrorThrow(9); return; }
        fp = FSfopen(old, "r");
        if(ErrorCheck() || fp == NULL) return;
        FSrename(new, fp);
        if(ErrorCheck()) return;
        FSfclose(fp);
    }
}

*/


void cmd_seek(void) {
    int fnbr, idx;
    getargs(&cmdline, 5, ",");
    if(argc != 3) error("Invalid syntax");
    if(*argv[0] == '#') argv[0]++;
    fnbr = getinteger(argv[0]);
    if(fnbr < 1 || fnbr > MAXOPENFILES || OpenFileTable[fnbr] <= MAXOPENFILES) error("Invalid file number");
    if(OpenFileTable[fnbr] == 0) error("File number #% is not open", fnbr);
    idx = getinteger(argv[2]) - 1;
    if(FLASHFS == Option.DEFAULT_DRIVE) {
        bool err_stat;
        err_stat = false;
        if(idx < 0) {
            err_stat = true;
        }
        else {
            int status;
            status = SYS_FS_FileSeek((SYS_FS_HANDLE)OpenFileTable[fnbr], idx, SYS_FS_SEEK_SET);
            if( status == -1 ) {
                err_stat = true;
            }
        }
        if(err_stat) {
            close_Adrive(fnbr);
            ErrorThrow(10);
        }
    }
    else {
        if(idx < 0) {
            ErrorThrow(10);
        }        
        FSfseek((FSFILE *)OpenFileTable[fnbr], idx, SEEK_SET);
        if(FSerror() == 31)                                             // if the error is "invalid argument" it generally means seek beyond end of file
            ErrorThrow(10);                                             // so throw a "cannot read" error.  This could be made more informative
        else
            ErrorCheck();                                               // otherwise the normal error check
    }
}



extern BYTE BMP_bDecode(int x, int y, FSFILE *pFile);

void LoadImage(char *p) {
	int fnbr, i;
	int xOrigin, yOrigin;

	// get the command line arguments
	getargs(&p, 5, ",");                                            // this MUST be the first executable line in the function
    if(argc == 0) error("Invalid number of parameters");
    if(!InitSDCard()) return;

    p = getCstring(argv[0]);                                        // get the file name

    xOrigin = yOrigin = 0;
	if(argc >= 3) xOrigin = getinteger(argv[2]);                    // get the x origin (optional) argument
	if(argc == 5) yOrigin = getinteger(argv[4]);                    // get the y origin (optional) argument

	// open the file
	if(strchr(p, '.') == NULL) strcat(p, ".BMP");
	fnbr = FindFreeFileNbr();
    OpenFileTable[fnbr] = (unsigned int)FSfopen(p, "r");
    if((i = FSerror()) != 0) {
        ErrorThrow(ErrorMap[i]);
        return;
    }
    BMP_bDecode(xOrigin, yOrigin, (FSFILE *)OpenFileTable[fnbr]);
    FileClose(fnbr);
}


unsigned char GetNextCh(int fnbr) {
    unsigned char c;
    do {
        c = FileGetChar(fnbr);
    } while(c == '\r' || c == '\n' || c == ' ' || c == '\t');
    return c;
}

#if defined(LOADFONT)
#define ELEMENT_BUF_SIZE    40
int GetFontElement(int fnbr, int *n) {
    char buf[ELEMENT_BUF_SIZE], *p, *endptr;
    while(1) {
        p = buf;
        do {
            *p = GetNextCh(fnbr);
            if(*p == 0xff) return false;
        } while(!isdigit(*p));
        tryagain:
        do {
            p++;
            *p = GetNextCh(fnbr);
        } while(!(*p == ',' || *p == 0xff || (p - buf) >= ELEMENT_BUF_SIZE - 1));
        if((p - buf) >= ELEMENT_BUF_SIZE - 1) {
            do {
                memcpy(buf, buf + 1, ELEMENT_BUF_SIZE - 1);
                p--;
            } while(p > buf && !isdigit(*buf));
            if(p == buf) continue;
            goto tryagain;
        }
        do {
            *n = strtol(buf, &endptr, 0);
            if(endptr == p) return true;
            memcpy(buf, buf + 1, ELEMENT_BUF_SIZE - 1);
            p--;
        } while(p > buf);
        if(*p == 0xff) return false;
    }
}



void LoadFont(char *p) {
	int fnbr, font, i, n;
	char *fname;
	char ss[2], c;                                                  // this will be used to split up the argument line

	ss[0] = tokenAS;
	ss[1] = 0;
	{																// start a new block
		getargs(&p, 3, ss);                                         // getargs macro must be the first executable stmt in a block
        if(argc != 3) error("Invalid Syntax");
		fname = getCstring(argv[0]);                                // get the file name
        if(*argv[2] == '#') argv[2]++;                              // skip a #
        font = getint(argv[2], FONT_BUILTIN_NBR + 1, FONT_TABLE_SIZE) - 1;
        FreeMemory(FontTable[font]);
        fnbr = FindFreeFileNbr();
        if(!InitSDCard()) return;
        p = NULL;
        while(1) {
            OpenFileTable[fnbr] = (unsigned int)FSfopen(fname, "r");
            if((i = FSerror()) != 0) {
                ErrorThrow(ErrorMap[i]);
                return;
            }
            do {
                do {
                    c = GetNextCh(fnbr);
                    if(c == 0xff) error("Invalid font format");
                } while(c != '=');
            } while(GetNextCh(fnbr) != '{');
            i = 0;
            while(GetFontElement(fnbr, &n)) {
                if(p == NULL)
                    i++;
                else
                    *p++ = n;
            }
            FileClose(fnbr);
            if(p != NULL) break;
            p = GetMemory(i);
            FontTable[font] = (unsigned char *)p;
        }
    }
}
#endif



// get the file name for the RUN, LOAD, SAVE, KILL, COPY, DRIVE, FILES, FONT LOAD, LOADBMP, SAVEBMP, SPRITE LOAD and EDIT commands
// this function allows the user to omit the quote marks around a string constant when in immediate mode
// the first argument is a pointer to the file name (normally on the command line of the command)
// the second argument is a pointer to the LastFile buffer.  If this pointer is NULL the LastFile buffer feature will not be used
// This returns a temporary string to the filename
char *GetFileName(char* CmdLinePtr, char *LastFilePtr) {
    char *tp, *t;

	if(CurrentLinePtr) return getCstring(CmdLinePtr);               // if running a program get the filename as an expression

    // if we reach here we are in immediate mode
    if(*CmdLinePtr == 0 && LastFilePtr != NULL) return LastFilePtr; // if the command line is empty and we have a pointer to the last file, return that

   	if(strchr(CmdLinePtr, '"') == NULL && strchr(CmdLinePtr, '$') == NULL) {// quotes or a $ symbol indicate that it is an expression
        tp = GetTempStrMemory();                                  // this will last for the life of the command
    	strcpy(tp, CmdLinePtr);	                                    // save the string
    	t = strchr(tp, ' '); if(t) *t = 0;                          // trim any trailing spaces
    	for(t = tp; *t; t++) if(*t <= ' ' || *t > 'z') error("Filename must be quoted");
    	return tp;
    }
    else
		return getCstring(CmdLinePtr);	                            // treat the command line as a string expression and get its value
}


char *MMgetcwd(void) {
	char *b;
	b = GetTempStrMemory();
	if(!InitSDCard()) return b;
	FSgetcwd(b + 2, STRINGSIZE - 2);
	ErrorCheck();
	if(!MMerrno) { 
        switch(Option.DEFAULT_DRIVE)
        {
            case SDFS1: 
                b[0] = 'B'; 
                break;
            case SDFS2: 
                b[0] = 'C'; 
                break;
            case SDFS3: 
                b[0] = 'D'; 
                break;
            case SDFS4: 
                b[0] = 'E'; 
                break;
            default: 
                b[0] = 'A'; 
                break;
        }
        b[1] = ':'; 
    }
	return b;
}


// this function takes a path (ie, "\dir1\dir2\file.bas") and:
//    1.  saves the current working directory in temporary buffer
//    2.  changes to the directory specified in the path
//    3.  returns with a pointer pointing to the file component
// if called with a NULL argument this function will change back to the previously saved directory
char *ChangeToDir(char *p) {
	static char *cwd = NULL;
	char *tp;

	// if the argument is NULL the caller wants to return to the previously saved directory
	if(p == NULL) {
		if(cwd != NULL)
			FSchdir(cwd);
		return NULL;
	}

	cwd = NULL;

	// adjust p to remove the drive letter if present
	if( p[1] == ':') {
            if((toupper(p[0]) == 'B') || (toupper(p[0]) == 'C') || (toupper(p[0]) == 'D') || (toupper(p[0]) == 'E'))
                p += 2;
            else
                error("Unrecognised drive letter");
	}
	if(!*p) error("Invalid file or directory name");

	// search backwards for for the directory separator and set tp to point to it
	tp = p + strlen(p);
	while(tp != p && *tp != '\\') tp--;

	// if we end up pointing to the start of the string this could because of:
	//    1.  The path started at the root (ie, "\file.bas")
	//    2.  There is no directory component (ie, "file.bas")
	if(tp == p) {
		if(*p != '\\') return p;							// if there is no directory component we can return immediately pointing to the file component
		p = "\\";											// otherwise provide the root for the rest of the function to use
	}

	cwd = GetTempStrMemory();								// allocate some memory
	FSgetcwd(cwd, STRINGSIZE - 2);							// get the current directory
	if(ErrorCheck()) return "";
	*tp = 0;												// terminate the directory component in the function's argument
	FSchdir(p);												// change to the directory component
	if(ErrorCheck()) return "";
	*tp = '\\';												// replace the character
	return tp + 1;											// return pointing to the file component of the path
}



#define MAXFILES 200
typedef struct ss_flist {
    char fn[13];
    int fs;
} s_flist;



void cmd_files(void) {
	if(CurrentLinePtr) error("Invalid in a program");
	OptionErrorAbort = 0;

	char ts[STRINGSIZE] = "";
    char tsp[STRINGSIZE] = "";
    char *p;
    char showattr=0;

	if (*cmdline) {
        char *c=cmdline;
        while (*c==' ') c++;
        if ((c[0]=='a' || c[0]=='A') && (c[1]==' ' || c[1]==0)) {
            c+=2;
            showattr=1;
        }
        if (*c) p=GetFileName(c, NULL); else p=ts;
    } else
        p=ts;

	if(!*p) strcat(p, "*.*");										// add wildcard if needed
	if(strchr(p, '.') == NULL && strchr(p, '*') == NULL && strchr(p, '?') == NULL)  strcat(p, "\\*.*");	// add wildcard if needed
    
    if( FLASHFS == Option.DEFAULT_DRIVE ) {
        int fcnt=0;
        int dirs=0;
        int ListCnt;
        long long int ftotalsize = 0;
        int i;
        s_flist flist[MAXFILES];
        SYS_FS_RESULT ret;
        // print the current directory
        MMPrintString(GetCWD()); MMPrintString(ts); MMPrintString("\r\n");    
        *ts=0;
        if(SYS_FS_Mount("/dev/nvma1", "/mnt/MM Drive", FAT, 0, NULL) != 0) {
            error("Cannot access drive A");
        }  
        appData.totalFiles = 0;
        appData.dirHandle = SYS_FS_DirOpen("/mnt/MM Drive");
        if(appData.dirHandle == SYS_FS_HANDLE_INVALID) {
            SYS_FS_Unmount("/mnt/MM Drive");
            uSec(10000);
            error("Could not open the directory");
        }

        do
        {
            if(appData.totalFiles < APP_DISK_MAX_FILES) {
                ret = SYS_FS_DirRead(appData.dirHandle,&appData.dirstat);

                // End of this directory
                if(appData.dirstat.fname[0] == '\0') {
                    break;
                }

                if(ret!= SYS_FS_RES_FAILURE) {
                    if(appData.dirstat.fattrib != SYS_FS_ATTR_DIR) {        
                    if(showattr) {
                        sprintf(ts, "%c%c%c%c%c%c   ",((appData.dirstat.fattrib & ATTR_ARCHIVE)?'A':'-'),
                                                    ((appData.dirstat.fattrib & ATTR_DIRECTORY)?'D':'-'),
                                                    ((appData.dirstat.fattrib & ATTR_VOLUME)?'V':'-'),
                                                    ((appData.dirstat.fattrib & ATTR_SYSTEM)?'S':'-'),
                                                    ((appData.dirstat.fattrib & ATTR_HIDDEN)?'H':'-'),
                                                    ((appData.dirstat.fattrib & ATTR_READ_ONLY)?'R':'-'));
                        MMPrintString(ts);
                    }                              
                    sprintf(ts, "%8lu   ", appData.dirstat.fsize);
                    ftotalsize += appData.dirstat.fsize;
                    MMPrintString(ts);
                    *ts=0;                          
                    if (strcmp(appData.dirstat.fname,".") && strcmp(appData.dirstat.fname,"..")) {
                        int t,v=256;
                        for (t=0; t<strlen(appData.dirstat.fname); t++) if (appData.dirstat.fname[t]=='.') v=t;
                        for (t=0; t<8; t++) {
                            ts[strlen(ts)+1]=0;
                            if (t<v) ts[strlen(ts)]=appData.dirstat.fname[t]; else ts[strlen(ts)]=' ';
                        }
                        strcat(ts,"   ");
                        if (v<256) strcat(ts,&appData.dirstat.fname[v]);
                    } else
                        strcpy(ts,appData.dirstat.fname);
                    while (strlen(ts)<15) strcat(ts," ");
                    MMPrintString(ts);
                    MMPrintString("\r\n");                                                     
                    fcnt++;
                    (appData.totalFiles)++;
                    }
                }
            }
            else {
                ret = SYS_FS_RES_FAILURE;
                break;
            }
        }while(ret == SYS_FS_RES_SUCCESS);
        SYS_FS_DirClose(appData.dirHandle); 
        SYS_FS_Unmount("/mnt/MM Drive");
        uSec(10000);

        // display the summary
        IntToStr(ts, dirs, 10); MMPrintString(ts);
        MMPrintString(" director"); MMPrintString(dirs==1?"y, ":"ies, ");
        IntToStr(ts, fcnt - dirs, 10); MMPrintString(ts);
        MMPrintString(" file"); MMPrintString((fcnt-dirs)==1?"":"s");
        sprintf(ts," use%s %llu bytes\r\n",(fcnt!=1?"":"s"),ftotalsize);
        MMPrintString(ts);
        longjmp(mark, 1);							// jump back to the input prompt           
    } 
    
    if(!InitSDCard()) error((char *)FErrorMsg[1]);					// setup the SD card
	p = ChangeToDir(p);
	if (!*p) { ChangeToDir(NULL); error("Invalid search specification"); }

    strcpy(tsp,MMgetcwd());
    if (*tsp && tsp[strlen(tsp)-1]!='\\') strcat(tsp,"\\");
	MMPrintString(tsp); MMPrintString(p); MMPrintString("\r\n");
    strcpy(tsp,p);  // save for later

    unsigned long cntdirs = 0;
    unsigned long cntfiles = 0;
    long long int total = 0;
    char stage=0;
    int listed=4;
    int maxlisted=23;

    while (++stage<3) {   // stage 1 is the directories; stage 2 is the files
        strcpy(p,tsp);
        SearchRec file;
        
        int err, r=FindFirst(p, (showattr? (ATTR_HIDDEN | ATTR_SYSTEM) : 0) | ATTR_READ_ONLY | ATTR_DIRECTORY | ATTR_ARCHIVE, &file);
        while (r!=-1) {

            if ((err = FSerror()) != 0) {
    			ChangeToDir(NULL);
	    		error((char *)FErrorMsg[ErrorMap[err]]);
		    }
                
            if ((stage==1 && (file.attributes & ATTR_DIRECTORY)) || (stage==2 && (file.attributes & ATTR_DIRECTORY)==0)) {
                if (showattr) {
                    sprintf(ts, "%c%c%c%c%c%c   ",((file.attributes & ATTR_ARCHIVE)?'A':'-'),
                                                  ((file.attributes & ATTR_DIRECTORY)?'D':'-'),
                                                  ((file.attributes & ATTR_VOLUME)?'V':'-'),
                                                  ((file.attributes & ATTR_SYSTEM)?'S':'-'),
                                                  ((file.attributes & ATTR_HIDDEN)?'H':'-'),
                                                  ((file.attributes & ATTR_READ_ONLY)?'R':'-'));
                    MMPrintString(ts);
                }

                if (stage==1) {
                    sprintf(ts,"   <DIR>   ");
                    cntdirs++;
                } else {
                    sprintf(ts, "%8lu   ", file.filesize);
                    total+=file.filesize;
                    cntfiles++;
                }
                MMPrintString(ts);
                *ts=0;
                    if (strcmp(file.filename,".") && strcmp(file.filename,"..")) {
                        int t,v=256;
                        for (t=0; t<strlen(file.filename); t++) if (file.filename[t]=='.') v=t;
                        for (t=0; t<8; t++) {
                            ts[strlen(ts)+1]=0;
                            if (t<v) ts[strlen(ts)]=file.filename[t]; else ts[strlen(ts)]=' ';
                        }
                        strcat(ts,"   ");
                        if (v<256) strcat(ts,&file.filename[v]);
                    } else
                        strcpy(ts,file.filename);
                    while (strlen(ts)<15) strcat(ts," ");
		        MMPrintString(ts);

		        MMPrintString("\r\n");
                listed++;
            }
                
    		r=FindNext(&file);

            // check if it is more than a screenfull
	        if (maxlisted && listed>maxlisted && (stage==1 || (stage==2 && r!=-1))) {
		        MMPrintString("PRESS ANY KEY ...");
		        MMgetchar();
		        MMPrintString("\r                             \r");
		        listed=3;
	        }
        }
    }

    if (cntdirs) {
        sprintf(ts,"%lu director%s, ",cntdirs,(cntdirs==1?"y":"ies"));
        MMPrintString(ts);
    }
    sprintf(ts,"%lu file%s use%s %llu bytes\r\n",cntfiles,(cntfiles==1?"":"s"),(cntfiles!=1?"":"s"),total);
    MMPrintString(ts);

    ChangeToDir(NULL);
	longjmp(mark, 1);   // jump back to the input prompt
}



//////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////// ERROR HANDLING ////////////////////////////////////////////


int ErrorThrow(int e) {
    MMerrno = e;
    if(e > 0 && e < NBRERRMSG && OptionErrorAbort == 0) error((char *)FErrorMsg[e]);
    return e;
}


int ErrorCheck(void) {
    int e;
    e = FSerror();
    if(e < 1 || e > 33) return e;
    return ErrorThrow(ErrorMap[e]);
}

//////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////// GENERAL I/O ////////////////////////////////////////////



void SDCardClose(void) {
    int i;
    if(!Option.SDCARD[Option.DEFAULT_DRIVE].CS) return;
    for(i = 1; i <= MAXOPENFILES; i++)
        if(OpenFileTable[i] > MAXOPENFILES)
            FileClose(i);                                           // close any open files
}



void FileOpen(char *fname, char *fmode, char *ffnbr) {
    int fnbr;
    char *mode = NULL;
    int err;
    SYS_FS_FILE_OPEN_ATTRIBUTES fs_attrib;
                                                                // start a new block
    if(str_equal(fmode, "OUTPUT"))
        mode = "w";
    else if(str_equal(fmode, "APPEND"))
        mode = "a";
    else if(str_equal(fmode, "INPUT"))
        mode = "r";
    else if(str_equal(fmode, "RANDOM"))
        mode = "x";
    else
        error("Invalid file access mode");

    if(*ffnbr == '#') ffnbr++;
    fnbr = getinteger(ffnbr);
    if(fnbr < 1 || fnbr > 10) error("Invalid file number");
    if(OpenFileTable[fnbr] != 0) error("File number is already open");
    if(FLASHFS == Option.DEFAULT_DRIVE) {
        switch(*mode) {
            case 'r':   fs_attrib = SYS_FS_FILE_OPEN_READ;
                        if(!CheckFileName(fname)) {
                            ErrorThrow(6);
                            return;
                        }
                        break;
                        
            case 'w':   fs_attrib = SYS_FS_FILE_OPEN_WRITE_PLUS;
                        break;            
            
            case 'a':   fs_attrib = SYS_FS_FILE_OPEN_APPEND;
                        break;
                        
            case 'x':   fs_attrib = SYS_FS_FILE_OPEN_READ_PLUS;
                        break;
        }
    }
    else {
        if(!InitSDCard()) return;
        if(year > 2010) SetClockVars(year, month, day, hour, minute, second);
 
        switch(*mode) {
            case 'r':   if(!CheckFileName(fname)) {
                            ErrorThrow(6);
                            return;
                        }
                        break;
            case 'w':
            case 'a':
            case 'x':   if(Option.SDCARD[Option.DEFAULT_DRIVE].WP == 0 ? false : (Option.SDCARD[Option.DEFAULT_DRIVE].WP > 0 ? PinRead(Option.SDCARD[Option.DEFAULT_DRIVE].WP) : !PinRead(-Option.SDCARD[Option.DEFAULT_DRIVE].WP))) {
                            ErrorThrow(2);
                            return;
                        } else
                            CheckFileName(fname);
                        break;
        }
    }
    if(FLASHFS == Option.DEFAULT_DRIVE) {
        if(SYS_FS_Mount("/dev/nvma1", "/mnt/MM Drive", FAT, 0, NULL) != 0) {
            error("Cannot access drive A");
            return;
        } 
        appData.fileHandle = SYS_FS_FileOpen(fname, fs_attrib);
        if(appData.fileHandle == SYS_FS_HANDLE_INVALID) {
            /* Could not open the file. Error out*/
            SYS_FS_Unmount("/mnt/MM Drive");
            uSec(10000);
            error("Could not open the file");
        }        
        OpenFileTable[fnbr] = (unsigned int)appData.fileHandle;
    }
    else {
        if(*mode == 'x')
            OpenFileTable[fnbr] = (unsigned int)FSfopen(fname, "a+");
        else
            OpenFileTable[fnbr] = (unsigned int)FSfopen(fname, mode);

        if((err = FSerror()) != 0) {
            ErrorThrow(ErrorMap[err]);
            return;
        }
    }
    if(OpenFileTable[fnbr] == 0) ErrorThrow(9);
}




void FileClose(int fnbr) {
    if(FLASHFS == Option.DEFAULT_DRIVE) {
        close_Adrive(fnbr);
        if(Option.MSDStatus) {
            MSD_NVM_Attach(false);
            uSec(600000);
            MSD_NVM_Attach(true);
        }
    }
    else {
        if(!InitSDCard()) return;
        if(year > 2010) SetClockVars(year, month, day, hour, minute, second);
        FSfclose((FSFILE *)OpenFileTable[fnbr]);
        OpenFileTable[fnbr] = 0;
        ErrorCheck();
    }
}



char FileGetChar(int fnbr) {
    char ch;
    if(FLASHFS == Option.DEFAULT_DRIVE) {
        size_t bytes_read;
        bytes_read = SYS_FS_FileRead((SYS_FS_HANDLE)OpenFileTable[fnbr], &ch, 1);
        if(bytes_read == 0) ch = 0xff;
        else if(bytes_read == -1) {
            close_Adrive(fnbr);
            ErrorThrow(10);            
        }
    }
    else {
        if(!InitSDCard()) return 0;
        if(FSfread(&ch, 1, 1, (FSFILE *)OpenFileTable[fnbr]) == 0) ch = 0xff;
        ErrorCheck();
    }
    return ch;
}



char FilePutChar(char c, int fnbr) {
    static char t;
    static int nbr;
    t = c;
    nbr = fnbr;
    if(FLASHFS == Option.DEFAULT_DRIVE) {
        size_t bytes_written;
        bytes_written = SYS_FS_FileWrite((SYS_FS_HANDLE)OpenFileTable[fnbr], (const void *)&t, 1);
        if(bytes_written == -1) {
            FileClose(fnbr);
            ErrorThrow(11);
        } 
    }
    else {
        if(!InitSDCard()) return 0;
        if(FSfwrite(&t, 1, 1, (FSFILE *)OpenFileTable[nbr]) == 0) if(ErrorCheck() == 0) ErrorThrow(9);
    }
    return t;
}



int FileEOF(int fnbr) {
    int i;
    if(FLASHFS != Option.DEFAULT_DRIVE) {
        if(!InitSDCard()) return 0;
    }
    if(OpenFileTable[fnbr] == 0) error("File number is not open");
    if(FLASHFS == Option.DEFAULT_DRIVE) {
        i = (SYS_FS_FileEOF((SYS_FS_HANDLE)OpenFileTable[fnbr]) != 0) ? -1 : 0;
    }
    else {
        i = (FSfeof((FSFILE *)OpenFileTable[fnbr]) != 0) ? -1 : 0;
        ErrorCheck();
    }
    return i;
}



unsigned long FileLOC(int fnbr) {
    unsigned long ret_seek;
    if(FLASHFS == Option.DEFAULT_DRIVE) {
        int32_t tell;
        tell = SYS_FS_FileTell((SYS_FS_HANDLE)OpenFileTable[fnbr]);
        if(tell != -1) {
            ret_seek = tell;
        } 
        else {
            FileClose(fnbr);
            ErrorThrow(10);
            ret_seek = 0;
        }
    }
    else {
        FSFILE *t;
        t = (FSFILE *)OpenFileTable[fnbr];
        ret_seek = t->seek; 
    }
    return(ret_seek + 1); 
}



unsigned long FileLOF(int fnbr) {
    unsigned long ret_size;
    if(FLASHFS == Option.DEFAULT_DRIVE) {
        long fileSize;
        fileSize = SYS_FS_FileSize((SYS_FS_HANDLE)OpenFileTable[fnbr]);
        if(fileSize != -1) {
            ret_size = fileSize;
        }
        else {
            FileClose(fnbr);
            ErrorThrow(10);
            ret_size = 0;
        }        
    }
    else {    
        FSFILE *t;
        t = (FSFILE *)OpenFileTable[fnbr];
        ret_size = t->size;
    }
    return ret_size;
}



char *GetCWD(void) {
    char *b;
    b = GetTempStrMemory();
    if(FLASHFS != Option.DEFAULT_DRIVE) {
        if(!InitSDCard()) return b;
    }
    switch(Option.DEFAULT_DRIVE)
    {
        case    SDFS1:
            *b = 'B';
            break;
        case    SDFS2:
            *b = 'C';
            break;
        case    SDFS3:
            *b = 'D';
            break;
        case    SDFS4:
            *b = 'E';
            break;
        case    FLASHFS:
            *b = 'A';
            break;
    }   
    *(b+1) = ':';
    if(FLASHFS != Option.DEFAULT_DRIVE) {
        FSgetcwd(b+2, STRINGSIZE-2);
        ErrorCheck();
    }
    else {
        *(b+2) = '\\';
    }
    return b;
}



int InitSDCard() {
    int i;
    ErrorThrow(0);                                                                  // reset mm.errno to zero
    if(SDCardPresent[Option.DEFAULT_DRIVE]) return true;                            // if the card is present and has been initialised we have nothing to do
    if(!Option.SDCARD[Option.DEFAULT_DRIVE].CS) { ErrorThrow(15); return false; }
    for(i = 0; i < MAXOPENFILES; i++) 
        if(OpenFileTable[i] > MAXOPENFILES) 
            OpenFileTable[i] = 0;                                                // delete any file handles (but not open COM ports)
    if(!MDD_MediaDetect()) { ErrorThrow(1); return false; }
    if(!FSInit())  { ErrorThrow(15); return false; }
    SDCardPresent[Option.DEFAULT_DRIVE] = true;
    return true;
}



// finds the first available free file number.  Throws an error if no free file numbers
int FindFreeFileNbr(void) {
    int i;
    for(i = 1; i <= MAXOPENFILES; i++)
        if(OpenFileTable[i] == 0) return i;
    error("Too many files open");
    return 0;
}



// confirm that a file exists and get its case mapping.
// first this searches the file system looking for a file that has the same name regardless of the case
// if found it rewrites the argument with the file name (and case) as found on the card and returns true.
// if not found it will return false.
// This is needed because the MDD file system is case sensitive and we do not want that.
int CheckFileName(char *p) {
    SearchRec file;
    char fn[256];
    int r;
    #if defined(SUPPORT_LFN)
    int i;
    #endif

    
    if(FLASHFS == Option.DEFAULT_DRIVE) {    
        SYS_FS_RESULT ret;
        
        if(SYS_FS_Mount("/dev/nvma1", "/mnt/MM Drive", FAT, 0, NULL) != 0) {
            error("Cannot access drive A");
            return false;
        }
        appData.totalFiles = 0;
        appData.dirHandle = SYS_FS_DirOpen("/mnt/MM Drive");
        if(appData.dirHandle == SYS_FS_HANDLE_INVALID) {
            SYS_FS_Unmount("/mnt/MM Drive");
            uSec(10000);
            error("Could not open the directory");
        }
        do
        {
            if(appData.totalFiles < APP_DISK_MAX_FILES) {
                ret = SYS_FS_DirRead(appData.dirHandle,&appData.dirstat);

                // End of this directory
                if(appData.dirstat.fname[0] == '\0') {
                    break;
                }
                if(ret!= SYS_FS_RES_FAILURE) {
                    if(appData.dirstat.fattrib != SYS_FS_ATTR_DIR) {

                        // and concatenate the filename found
                        strcpy(fn, appData.dirstat.fname);
                        if(str_equal(fn, p)) {
                            strcpy(p, fn);
                            SYS_FS_DirClose(appData.dirHandle);  
                            SYS_FS_Unmount("/mnt/MM Drive");
                            uSec(10000);
                            return true;
                        }
                    }
                }
            }
            else {
                ret = SYS_FS_RES_FAILURE;
                break;
            }
        }while(ret == SYS_FS_RES_SUCCESS);
        SYS_FS_DirClose(appData.dirHandle);  
        SYS_FS_Unmount("/mnt/MM Drive");
        uSec(10000);
    }
    else {
        if(!InitSDCard()) return false;
        r = FindFirst("*.*", ATTR_HIDDEN | ATTR_SYSTEM | ATTR_READ_ONLY | ATTR_DIRECTORY |ATTR_ARCHIVE, &file);
        while(r != -1) {
            if(FSerror()) {
                ErrorCheck();
                longjmp(mark, 1);
            }
            strcpy(fn, file.filename);

            if(str_equal(fn, p)) {
                strcpy(p, fn);
                return true;
            }

            r = FindNext(&file);
        }
    }
    return false;
}

static void close_Adrive(int fnbr)
{
    SYS_FS_FileClose((SYS_FS_HANDLE)OpenFileTable[fnbr]);
    SYS_FS_Unmount("/mnt/MM Drive");
    uSec(100000);
    OpenFileTable[fnbr] = 0;
}


#if 1
void cmd_help(void) {
char cd; 
int fnbr, err;
char c1,c2;
long best=0;
char cdir[65];
char helpfile[13]="MMZHELP.TXT";

    if(CurrentLinePtr) error("Invalid in a program");

    fnbr = FindFreeFileNbr();
    if(fnbr==0) error("Unable to assign file handle");
    cd = Option.DEFAULT_DRIVE;
    Option.DEFAULT_DRIVE = FLASHFS;
    
        long fpos=-1,fpbc=0;
        if (*cmdline) { // if no parameter is supplied, always the first page from the help file will be shown
            long maxsim=LONG_MIN;
            char *cml=cmdline;
            while (*cml && *cml=='\'') cml++;

            if(SYS_FS_Mount("/dev/nvma1", "/mnt/MM Drive", FAT, 0, NULL) != 0) {
                Option.DEFAULT_DRIVE = cd;
                error("Cannot access drive A");
                return;
            } 
            appData.fileHandle = SYS_FS_FileOpen(helpfile, SYS_FS_FILE_OPEN_READ);
            if(appData.fileHandle == SYS_FS_HANDLE_INVALID) {
                /* Could not open the file. Error out*/
                SYS_FS_Unmount("/mnt/MM Drive");
                uSec(10000);
                Option.DEFAULT_DRIVE = cd;
                error("Could not open MMZHELP.TXT");
            }        
            OpenFileTable[fnbr] = (unsigned int)appData.fileHandle;  
    
            while (!MMfeof(fnbr)) {
                c1=MMfgetc(fnbr);
                fpos++;
                if (!MMfeof(fnbr) && c1=='`') {
                    c2=MMfgetc(fnbr);
                    fpos++;
                    if (!MMfeof(fnbr) && c1=='`' && c2=='`') { // keyword definitions start with a `` sequence
                        fpbc=fpos;
                        char keyw[65];
                        memset(keyw,0,sizeof(keyw));
                        c1=' ';
                        while (!MMfeof(fnbr) && strlen(keyw)<(sizeof(keyw)-1) && c1>=' ' && c1!='`') {
                            c1=MMfgetc(fnbr);
                            fpos++;
                            if (c1>=' ' && c1!='`') keyw[strlen(keyw)]=c1;
                        }
                        long sim=0;
                        int t=0,r,e=0;
                        for (r=0; t<strlen(cml) && r<strlen(keyw); r++)
                            if (toupper(cml[t])==toupper(keyw[r])) {
                                sim+=(++e)*(sizeof(keyw)-strlen(keyw));
                                t++;
                            } else
                                e=0;
                        #ifdef DEBUG_HELP
                            MMPrintString("\r\n");
                            MMPrintString(keyw);
                            sprintf(keyw,"     %li (%li)  ",sim,maxsim);
                            MMPrintString(keyw);
                        #endif
                        if (sim>maxsim) {
                            #ifdef DEBUG_HELP
                                MMPrintString("*  ");    // for debug only
                            #endif
                            maxsim=sim;
                            best=fpbc;
                        }
                    }
                }
            }
            SYS_FS_FileClose((SYS_FS_HANDLE)OpenFileTable[fnbr]);
            SYS_FS_Unmount("/mnt/MM Drive");
            uSec(100000);
        }
        if(SYS_FS_Mount("/dev/nvma1", "/mnt/MM Drive", FAT, 0, NULL) != 0) {
            Option.DEFAULT_DRIVE = cd;
            error("Cannot access drive A");
            return;
        } 
        appData.fileHandle = SYS_FS_FileOpen(helpfile, SYS_FS_FILE_OPEN_READ);
        if(appData.fileHandle == SYS_FS_HANDLE_INVALID) {
            /* Could not open the file. Error out*/
            SYS_FS_Unmount("/mnt/MM Drive");
            uSec(10000);
            Option.DEFAULT_DRIVE = cd;
            error("Could not open MMZHELP.TXT");
        }         
        OpenFileTable[fnbr] = (unsigned int)appData.fileHandle;
        
        while(!MMfeof(fnbr) && best--) MMfgetc(fnbr);    // skip to _best position
        c1=' ';
        while(!MMfeof(fnbr) && c1>=' ') c1=MMfgetc(fnbr);    // skip the first line (which is the keyword definition) 
        while(!MMfeof(fnbr) && c1<' ') c1=MMfgetc(fnbr);
        MMPrintString("\r\n");
        MMputchar(c1);
        for(best=3;;) {    // re-using _best as line counter for the shown lines of text
            if(!MMfeof(fnbr)) c1=MMfgetc(fnbr); else break;
            if(c1=='`') {
                if(!MMfeof(fnbr)) c2=MMfgetc(fnbr); else break;
                if(c2=='`') break;
                MMputchar(c1);
                MMputchar(c2);
                c1=c2;
            } else
                MMputchar(c1);
            if(c1=='\n') best++;
            if(best>23 && best>=(VRes/12)) {
                MMPrintString("\rPRESS ANY KEY ...");
                MMgetchar();
                MMPrintString("\r                             \r");
                best=4;
            }
        }
        close_Adrive(fnbr);   

    Option.DEFAULT_DRIVE = cd;    
}
#endif


void cmd_verinfo(void) {
    
    MMPrintString(MES_SIGNON);                                  // print sign on message
    MMPrintString(COPYRIGHT);                                   // print copyright message
    MMPrintString("\r\n");
}

