/***********************************************************************************************************************
MMBasic

FWUpdate.c

Does all the LCD display commands and I/O in MMBasic.

Copyright 2011 - 2017 Geoff Graham.  All Rights Reserved.

This file and modified versions of this file are supplied to specific individuals or organisations under the following
provisions:

- This file, or any files that comprise the MMBasic source (modified or not), may not be distributed or copied to any other
  person or organisation without written permission.

- Object files (.o and .hex files) generated using this file (modified or not) may not be distributed or copied to any other
  person or organisation without written permission.

- This file is provided in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

************************************************************************************************************************/


#include "../MMBasic_Includes.h"
#include "../Hardware_Includes.h"


/* User defined Key address in RAM Memory - the last 4 bytes used for boot key seq.*/
//#define BOOT_KEY_ADDRESS            0xA007FFFC
#define BOOT_KEY                    0x12345678

const extern unsigned int _BOOT_KEY_ADDRESS;
static unsigned int BOOT_KEY_ADDRESS;

/****************************************************************************************************

 MMBasic commands and functions

****************************************************************************************************/

void cmd_fwupdate(void) {
int i;  

    BOOT_KEY_ADDRESS = (unsigned int) &_BOOT_KEY_ADDRESS;
    MMPrintString("Entering update mode in 5 seconds...\r\n\r\n");
    // now wait for 5 sec
    for( i=0; i < 5; i++ )
    {
        uSec(1000000);                                          
    }
    CloseUSBConsole();
    CloseSerialConsole();
    INTDisableInterrupts();
    *(int*)BOOT_KEY_ADDRESS = BOOT_KEY;
    SoftReset();
}
