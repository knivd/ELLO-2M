/***********************************************************************************************************************
MMBasic

Touch.c

Does all the touch screen related I/O in MMBasic.

Copyright 2011 - 2015 Geoff Graham.  All Rights Reserved.

This file and modified versions of this file are supplied to specific individuals or organisations under the following
provisions:

- This file, or any files that comprise the MMBasic source (modified or not), may not be distributed or copied to any other
  person or organisation without written permission.

- Object files (.o and .hex files) generated using this file (modified or not) may not be distributed or copied to any other
  person or organisation without written permission.

- This file is provided in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

************************************************************************************************************************/


#include "../MMBasic_Includes.h"
#include "../Hardware_Includes.h"

//** SD CARD INCLUDES ***********************************************************
#include "SDCard/SDCard.h"
#include "SDCard/FSconfig.h"

void TDelay(void);

volatile int TouchX, TouchY;
volatile int TouchDown = false;
volatile int TouchUp = false;

#define CMD_MEASURE_X       0b11011111
#define CMD_MEASURE_Y       0b10011111
#define CMD_PENIRQ_ON       0b10011110

#define TOUCH_SPI_SPEED     100000

void InitTouch(void) {

    // this part of the code inits the touch interface
    if(!Option.Touch) return;

    PinSetBit(TOUCH_CS, LATSET);
    ExtCfg(TOUCH_CS, EXT_DIG_OUT, 0);                               // config CS as an output
    ExtCurrentConfig[(int)TOUCH_CS] = EXT_BOOT_RESERVED;
    if(ExtCurrentConfig[SPI2_OUT_PIN] != EXT_BOOT_RESERVED) {
        ExtCfg(SPI2_OUT_PIN, EXT_DIG_OUT, 0); ExtCfg(SPI2_OUT_PIN, EXT_BOOT_RESERVED, 0);
        ExtCfg(SPI2_INP_PIN, EXT_DIG_IN, 0); ExtCfg(SPI2_INP_PIN, EXT_BOOT_RESERVED, 0);
        ExtCfg(SPI2_CLK_PIN, EXT_DIG_OUT, 0); ExtCfg(SPI2_CLK_PIN, EXT_BOOT_RESERVED, 0);
        SPI2_PPS_OPEN;                                                  // this is defined in IOPorts.h
        SpiChnOpen(SPI_CHANNEL2, SPI_OPEN_MSTEN | SPI_OPEN_CKE_REV | SPI_OPEN_MODE8 | SPI_OPEN_ON, BusSpeed/1000000);
    }
    ExtCfg(TOUCH_IRQ, EXT_DIG_IN, 0);                                       // IRQ is an input
    ExtCurrentConfig[(int)TOUCH_IRQ] = EXT_BOOT_RESERVED;
    if(Option.TOUCH_Click) {
        SetAndReserve(Option.TOUCH_Click, P_OUTPUT, 0, EXT_BOOT_RESERVED);  // config the click pin as an output
    }
    SpiChnSetBrg(SPI_CHANNEL2, SpiBrgVal(BusSpeed, TOUCH_SPI_SPEED));       // set the SPI speed for the next function
    GetTouchValue(CMD_PENIRQ_ON);                                           // send the controller the command to turn on PenIRQ
}


// this function is only used in calibration
// it draws the target, waits for the touch to stabilise and returns the x and y in raw touch controller numbers (ie, not scaled)
void GetCalibration(int x, int y, int *xval, int *yval) {
    int i, j, xx, yy, lastx = TOUCH_NOT_CALIBRATED, lasty = TOUCH_NOT_CALIBRATED;

    ClearScreenSSD1963(BLACK);
    GUIPrintString(HRes/2, VRes/2, JUSTIFY_CENTER | JUSTIFY_MIDDLE, WHITE, BLACK, "Touch and Hold");
    DrawLineSSD1963(x - (TARGET_OFFSET * 3)/4, y, x + (TARGET_OFFSET * 3)/4, y, 1, WHITE);
    DrawLineSSD1963(x, y - (TARGET_OFFSET * 3)/4, x, y + (TARGET_OFFSET * 3)/4, 1, WHITE);
    DrawCircleSSD1963(x, y, TARGET_OFFSET/2, 1, WHITE, -1, 1);
    while(!TOUCH_DOWN) CheckAbort();                                 // wait for the touch
    SpiChnSetBrg(SPI_CHANNEL2, SpiBrgVal(BusSpeed, TOUCH_SPI_SPEED));// we run the SPI 100KHz for lower noise
    PinSetBit(TOUCH_IRQ, TRISCLR);                                   // Set the PenIRQ to an output
    PinSetBit(TOUCH_IRQ, LATCLR);                                    // Drive the PenIRQ low so the diode is not forward biased

    for(i = j = 0; i < 20; i++) {
        GetTouchAxis(CMD_MEASURE_X); GetTouchAxis(CMD_MEASURE_Y);
    }

    // wait for the touch to stop sliding around (maximum half a second)
    for(i = 0; i < 10; i++) {
        xx = GetTouchAxis(CMD_MEASURE_X);
        yy = GetTouchAxis(CMD_MEASURE_Y);
        if(xx > lastx - CAL_ERROR_MARGIN && xx < lastx + CAL_ERROR_MARGIN && yy > lastx - CAL_ERROR_MARGIN && yy < lastx + CAL_ERROR_MARGIN)
            break;
        uSec(50000);
        lastx = xx; lasty = yy;
    }

    // make a lot of readings and average them
    for(i = j = 0; i < 50; i++) j += GetTouchAxis(CMD_MEASURE_X);
    *xval = j/50;
    for(i = j = 0; i < 50; i++) j += GetTouchAxis(CMD_MEASURE_Y);
    *yval = j/50;


    ClickTimer = 50;                                                // beep to say that we have finished
    GetTouchValue(CMD_PENIRQ_ON);                                   // send the command to turn PenIRQ on
    PinSetBit(TOUCH_IRQ, TRISSET);                                  // Set the PenIRQ to an input
    ClearScreenSSD1963(BLACK);
    while(TOUCH_DOWN);                                           // wait for the touch to be lifted
    uSec(250000);
}


// this is the main function used to get a touch coordinate
// it updates the global TouchX and TouchY with the coordinates scaled to the display's pixel coordinates
// it will set TouchX and TouchY to TOUCH_ERROR if the touch is not occuring or if there was an error reading the touch controller
void GetTouch(void) {
    int x, y;

    if(Option.Touch == 0 || PinRead(TOUCH_IRQ)) {                   // return an error if not configured or the pen is not down
        TouchX = TouchY = TOUCH_ERROR;
        return;
    }
    SpiChnSetBrg(SPI_CHANNEL2, SpiBrgVal(BusSpeed, TOUCH_SPI_SPEED));// we run the SPI 100KHz for lower noise

    PinSetBit(TOUCH_IRQ, TRISCLR);                                  // Set the PenIRQ to an output
    PinSetBit(TOUCH_IRQ, LATCLR);                                   // Drive the PenIRQ low so the diode is not forward biased

    // if the last reading was invalid get ourselves a reference reading and scale it to the screen coordinates
    if(TouchX == TOUCH_ERROR) {
        TouchX = ((float)(GetTouchAxis(CMD_MEASURE_X) - Option.TOUCH_XZERO) / Option.TOUCH_XSCALE) + TARGET_OFFSET ;
        TouchY = ((float)(GetTouchAxis(CMD_MEASURE_Y) - Option.TOUCH_YZERO) / Option.TOUCH_YSCALE) + TARGET_OFFSET ;
    }

    // get the current reading and scale it to the screen coordinates
    x = ((float)(GetTouchAxis(CMD_MEASURE_X) - Option.TOUCH_XZERO) / Option.TOUCH_XSCALE) + TARGET_OFFSET ;
    y = ((float)(GetTouchAxis(CMD_MEASURE_Y) - Option.TOUCH_YZERO) / Option.TOUCH_YSCALE) + TARGET_OFFSET ;

    // reject the current reading if it is outside the screen or deviates too far from the previous reading
    if(x < 0 || x >= HRes || y < 0 || y >= VRes || x < TouchX - CAL_ERROR_MARGIN || x > TouchX + CAL_ERROR_MARGIN || y < TouchY - CAL_ERROR_MARGIN || y > TouchY + CAL_ERROR_MARGIN)
        x = y = TOUCH_ERROR;

    TouchX = x; TouchY = y;                                         // set the final result
    GetTouchValue(CMD_PENIRQ_ON);                                   // send the command to turn PenIRQ on
    PinSetBit(TOUCH_IRQ, TRISSET);                                  // Set the PenIRQ to an input
}


// this will get a reading from a single axis
// the returned value is not scaled, it is the raw number produced by the touch controller
// it takes multiple readings, discards the outliers and returns the average of the medium values
// it assumes that PenIRG line has been pulled low and the SPI baudrate is correct
int GetTouchAxis(int cmd) {
    int i, j, t, b[TOUCH_SAMPLES];

    GetTouchValue(cmd);
    // we take TOUCH_SAMPLES readings and sort them into descending order in buffer b[].
    for(i = 0; i < TOUCH_SAMPLES; i++) {
        b[i] = GetTouchValue(cmd);									// get the value
        for(j = i; j > 0; j--) {							        // and sort into position
            if(b[j - 1] < b[j]) {
                t = b[j - 1];
                b[j - 1] = b[j];
                b[j] = t;
            }
            else
                break;
        }
    }

    // we then discard the top TOUCH_DISCARD samples and the bottom TOUCH_DISCARD samples and add up the remainder
    for(j = 0, i = TOUCH_DISCARD; i < TOUCH_SAMPLES - TOUCH_DISCARD; i++) j += b[i];

    // and return the average
    return j / (TOUCH_SAMPLES - (TOUCH_DISCARD * 2));
}



// this will get a single reading from the touch controller
// it assumes that PenIRG line has been pulled low and the SPI baudrate is correct
// this takes 260uS at 120MHz
int GetTouchValue(int cmd) {
    int val;

    PinSetBit(TOUCH_CS, LATCLR);                                    // Assert the CS line
    TDelay();
//    SpiChnPutC(SPI_CHANNEL2, cmd);                                  // Send the control byte

    // we need to swap X and Y if the display is in portrait or reverse portrait
    if(cmd == CMD_MEASURE_X)
        if(Option.DISPLAY_ORIENTATION & 1)
            SpiChnPutC(SPI_CHANNEL2, CMD_MEASURE_X);                // read the physical horizontal axis
        else
            SpiChnPutC(SPI_CHANNEL2, CMD_MEASURE_Y);                // read the physical vertical axis
    else if(cmd == CMD_MEASURE_Y)
        if(Option.DISPLAY_ORIENTATION & 1)
            SpiChnPutC(SPI_CHANNEL2, CMD_MEASURE_Y);                // read the physical vertical axis
        else
            SpiChnPutC(SPI_CHANNEL2, CMD_MEASURE_X);                // read the physical horizontal axis
    else
        SpiChnPutC(SPI_CHANNEL2, cmd);                              // some other command

    SpiChnGetC(SPI_CHANNEL2);                                       // Read the dummy data to clear the receive buffer
    while(SpiChnIsBusy(SPI_CHANNEL2));
    SpiChnPutC(SPI_CHANNEL2, 0x00);                                 // Send a dummy byte in order to clock the data out
    val = (SpiChnGetC(SPI_CHANNEL2) & 0b1111111) << 5;              // the top 7 bits
    while(SpiChnIsBusy(SPI_CHANNEL2));
    SpiChnPutC(SPI_CHANNEL2, 0x00);                                 // Send a dummy byte in order to clock the data out
    val |= (SpiChnGetC(SPI_CHANNEL2) >> 3) & 0b11111;               // the bottom 5 bits
    while(SpiChnIsBusy(SPI_CHANNEL2));
    PinSetBit(TOUCH_CS, LATSET);                                    // Deassert the CS line
    return val;
}


void TDelay(void)		// provides a small (~200ns) delay for the touch screen controller.
{
	Nop();	Nop();	Nop();	Nop();	Nop();	Nop();	Nop();	Nop();	Nop();	Nop();	Nop();	Nop();
	Nop();	Nop();	Nop();	Nop();	Nop();	Nop();	Nop();	Nop();	Nop();	Nop();	Nop();	Nop();
}
