/***********************************************************************************************************************
MMBasic

XModem.c

Implements the xmodem command and protocol.

Copyright 2011 - 2017 Geoff Graham.  All Rights Reserved.

This file and modified versions of this file are supplied to specific individuals or organisations under the following 
provisions:

- This file, or any files that comprise the MMBasic source (modified or not), may not be distributed or copied to any other
  person or organisation without written permission.

- Object files (.o and .hex files) generated using this file (modified or not) may not be distributed or copied to any other
  person or organisation without written permission.

- This file is provided in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of 
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

************************************************************************************************************************/

#include <stdio.h>

#include "../MMBasic_Includes.h"
#include "../Hardware_Includes.h"

void xmodemTransmit(char *p);
void xmodemReceive(char *sp, int maxbytes);

void cmd_xmodem(void) {
	char *buf, BreakKeySave, *p, *fromp;
    
    if(CurrentLinePtr) error("Invalid in a program");
    ClearProgram();
    buf = GetTempMemory(EDIT_BUFFER_SIZE);
    
    BreakKeySave = BreakKey;
    BreakKey = 0;
	if(toupper(*cmdline) == 'R') {
		xmodemReceive(buf, EDIT_BUFFER_SIZE);
        SaveProgramToFlash(buf, false);
        SaveProgramToFlash(buf, true);
    }
	else if(toupper(*cmdline) == 'S') {
        fromp  = ProgFlash;
        p = buf;
        while(1) {
            if(*fromp == T_LINENBR) {
                fromp = llist(p, fromp);                            // expand the line
                p += strlen(p);
                if(p - buf + 40 > EDIT_BUFFER_SIZE) error("Not enough memory");
                *p++ = '\n'; *p = 0;
            }

            if(fromp[0] == 0 || fromp[0] == 0xff) break;            // finally, is it the end of the program?
        }
        --p; *p = 0;                                                // erase the last line terminator
		xmodemTransmit(buf);                                        // send it off
    }
	else
		error("Invalid syntax");
		
    BreakKey = BreakKeySave;
}


int _inbyte(int timeout) {
	int c;
	
	PauseTimer = 0;
	while(PauseTimer < timeout) {
		c = getConsole();
		if(c != -1) {
			return c;
		}	
	}
	return -1;	
}


// for the MX170 we don't want any XModem data echoed to the LCD panel
#if defined(MX470)
#define putConsole(c) SerUSBPutC(c)
#endif


/***********************************************************************************************
the xmodem protocol
************************************************************************************************/

/* derived from the work of Georges Menie (www.menie.org) Copyright 2001-2010 Georges Menie
 * very much debugged and changed
 *
 * this is just the basic XModem protocol (no 1K blocks, crc, etc).  It has been tested on
 * Terra Term and is intended for use with that software.
 */


#define SOH  0x01
#define STX  0x02
#define EOT  0x04
#define ACK  0x06
#define NAK  0x15
#define CAN  0x18
#define PAD  0x1a

#define DLY_1S 1000
#define MAXRETRANS 25

#define X_BLOCK_SIZE	128
#define X_BUF_SIZE	X_BLOCK_SIZE + 6								// 128 for XModem + 3 head chars + 2 crc + nul


static int check(const unsigned char *buf, int sz)
{
	int i;
	unsigned char cks = 0;
	for (i = 0; i < sz; ++i) {
		cks += buf[i];
	}
	if (cks == buf[sz])
		return 1;

	return 0;
}


static void flushinput(void)
{
	while (_inbyte(((DLY_1S)*3)>>1) >= 0);
}


void xmodemReceive(char *sp, int maxbytes) {
	unsigned char xbuff[X_BUF_SIZE];
	unsigned char *p;
	unsigned char trychar = NAK; //'C';
	unsigned char packetno = 1;
	int i, c;
	int retry, retrans = MAXRETRANS;

	// first establish communication with the remote
	while(1) {
		for( retry = 0; retry < 32; ++retry) {
			if(trychar) putConsole(trychar);
			if ((c = _inbyte((DLY_1S)<<1)) >= 0) {
				switch (c) {
				case SOH:
					goto start_recv;
				case EOT:
					flushinput();
					putConsole(ACK);
                    if(maxbytes <= 0) error("Not enough memory");
                    *sp++ = 0;                                      // terminate the data
					return; 										// no more data
				case CAN:
					flushinput();
					putConsole(ACK);
					error("Cancelled by remote");
					break;
				default:
					break;
				}
			}
		}
		flushinput();
		putConsole(CAN);
		putConsole(CAN);
		putConsole(CAN);
		error("Remote did not respond");                            // no sync

	start_recv:
		trychar = 0;
		p = xbuff;
		*p++ = SOH;
		for (i = 0;  i < (X_BLOCK_SIZE+3); ++i) {
			if ((c = _inbyte(DLY_1S)) < 0) goto reject;
			*p++ = c;
		}

		if (xbuff[1] == (unsigned char)(~xbuff[2]) && (xbuff[1] == packetno || xbuff[1] == (unsigned char)packetno-1) && check(&xbuff[3], X_BLOCK_SIZE)) {
			if (xbuff[1] == packetno)	{
				for(i = 0 ; i < X_BLOCK_SIZE ; i++) {
                    if(--maxbytes > 0) {
                        if(xbuff[i + 3] == PAD)
                            *sp++ = 0;                                  // replace any EOF's (used to pad out a block) with NUL
                        else
                            *sp++ = xbuff[i + 3];
                    }
                }
				++packetno;
				retrans = MAXRETRANS+1;
			}
			if (--retrans <= 0) {
				flushinput();
				putConsole(CAN);
				putConsole(CAN);
				putConsole(CAN);
				error("Too many errors");
			}
			putConsole(ACK);
			continue;
		}
	reject:
		flushinput();
		putConsole(NAK);
	}
}


void xmodemTransmit(char *p)
{
	unsigned char xbuff[X_BUF_SIZE]; 
	unsigned char packetno = 1;
    char prevchar = 0;
	int i, c, len;
	int retry;

	// first establish communication with the remote
	while(1) {
		for( retry = 0; retry < 32; ++retry) {
			if ((c = _inbyte((DLY_1S)<<1)) >= 0) {
				switch (c) {
				case NAK:											// start sending
					goto start_trans;
				case CAN:
					if ((c = _inbyte(DLY_1S)) == CAN) {
						putConsole(ACK);
						flushinput();
						error("Cancelled by remote");
					}
					break;
				default:
					break;
				}
			}
		}
		putConsole(CAN);
		putConsole(CAN);
		putConsole(CAN);
		flushinput();
		error("Remote did not respond");							// no sync

		// send a packet
		while(1) {
		start_trans:
			memset (xbuff, 0, X_BUF_SIZE);							// start with an empty buffer
			
			xbuff[0] = SOH;											// copy the header
			xbuff[1] = packetno;
			xbuff[2] = ~packetno;
			
			for(len = 0; len < 128 && *p; len++) {
                if(*p == '\n' && prevchar != '\r')
                    prevchar = xbuff[len + 3] = '\r';
                else
                    prevchar = xbuff[len + 3] = *p++;						// copy the data into the packet
            }
			if (len > 0) {
				unsigned char ccks = 0;
				for (i = 3; i < X_BLOCK_SIZE+3; ++i) {
					ccks += xbuff[i];
				}
				xbuff[X_BLOCK_SIZE+3] = ccks;
				
				// now send the block
				for (retry = 0; retry < MAXRETRANS && !MMAbort; ++retry) {
					// send the block
					for (i = 0; i < X_BLOCK_SIZE+4 && !MMAbort; ++i) {
						putConsole(xbuff[i]);
					}
					// check the response
					if ((c = _inbyte(DLY_1S)) >= 0 ) {
						switch (c) {
						case ACK:
							++packetno;
							goto start_trans;
						case CAN:									// canceled by remote
							putConsole(ACK);
							flushinput();
							error("Cancelled by remote");
							break;
						case NAK:									// receiver got a corrupt block
						default:
							break;
						}
					}
				}
				// too many retrys... give up
				putConsole(CAN);
				putConsole(CAN);
				putConsole(CAN);
				flushinput();
				error("Too many errors");
			}
			
			// finished sending - send end of text
			else {
				for (retry = 0; retry < 10; ++retry) {
					putConsole(EOT);
					if ((c = _inbyte((DLY_1S)<<1)) == ACK) break;
				}
				flushinput();
				if(c == ACK) return;
				error("Error closing");
			}
		}
	}
}

