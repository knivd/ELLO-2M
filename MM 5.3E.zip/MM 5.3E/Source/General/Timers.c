/***********************************************************************************************************************
Maximite

timers.c

This module manages various timers (counting variables), the date/time,
counting inputs and generates the sound.  All this is contained within the timer 4 interrupt.
  
Copyright 2011 - 2017 Geoff Graham.  All Rights Reserved.

This file and modified versions of this file are supplied to specific individuals or organisations under the following 
provisions:

- This file, or any files that comprise the MMBasic source (modified or not), may not be distributed or copied to any other
  person or organisation without written permission.

- Object files (.o and .hex files) generated using this file (modified or not) may not be distributed or copied to any other
  person or organisation without written permission.

- This file is provided in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of 
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

************************************************************************************************************************/


#define INCLUDE_FUNCTION_DEFINES

#include "../MMBasic_Includes.h"
#include "../Hardware_Includes.h"

// timer variables
volatile unsigned int SecondsTimer = 0;
volatile unsigned int PauseTimer = 0;
volatile unsigned int IntPauseTimer = 0;
volatile unsigned int InkeyTimer = 0;
volatile unsigned int WDTimer = 0;
#if defined(MX470)
//volatile int USBBannerTimer = -5000;
// sound variables
volatile unsigned int SoundPlay;
#endif
volatile int ds18b20Timer = -1;

volatile long long int mSecTimer = 0;								// this is used to count mSec
volatile int second = 0;											// date/time counters
volatile int minute = 0;
volatile int hour = 0;
volatile int day = 1;
volatile int month = 1;
volatile int year = 2000;

const char DaysInMonth[] = { 0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };

unsigned char PulsePin[NBR_PULSE_SLOTS];
unsigned char PulseDirection[NBR_PULSE_SLOTS];
int PulseCnt[NBR_PULSE_SLOTS];
int PulseActive;

extern void CallCFuncmSec(void);                                    // this is implemented in CFunction.c
extern void CallCFuncT1(void);                                    // this is implemented in CFunction.c
extern unsigned int CFuncmSec;                                      // we should call the CFunction mSec function if this is non zero
extern unsigned int CFuncT1;                                      // we should call the CFunction T1 interrupt function if this is non zero

/***************************************************************************************************
initTimers
Initialise the 1 mSec or 500 uSec timer used for internal timekeeping.
****************************************************************************************************/
// Do not use console debugging here - the console is not set up
void __attribute__((microinstr)) initTimers(void) {
 	// setup timer 4
#if defined(MX170)
    PR4 = 1000 * (BusSpeed/2/1000000) - 1;                          // 1 mSec
#elif defined(MX470)
    PR4 = 500 * (BusSpeed/2/1000000) - 1;                           // 500 uSec
#endif
    T4CON = 0x8010;         										// T4 on, prescaler 1:2
    mT4SetIntPriority(1);  											// high priority
    mT4ClearIntFlag();      										// clear interrupt flag
    mT4IntEnable(1);       											// enable interrupt
}
void __ISR( _TIMER_1_VECTOR, ipl1AUTO) T1Interrupt(void) {
    if(CFuncT1) CallCFuncT1();                                  // T1 interrupt CFunctions (see CFunction.c)
    mT1ClearIntFlag();
}

/****************************************************************************************************************
Timer 4 interrupt processor
This fires every mSec (on the MX170) or 500 uSec (on the MX470) and is responsible for tracking the time and 
the counts of various timing variables
*****************************************************************************************************************/
void __ISR( _TIMER_4_VECTOR, IPL1AUTO) T4Interrupt(void) {
    static int IrTimeout, IrTick, NextIrTick;
    int ElapsedMicroSec, IrDevTmp, IrCmdTmp;

#if defined(MX470)
    static unsigned int mSecCheck;
    static unsigned int BacklightCount;
    static int TouchState = false;
    
    // this code is executed every 500uSec
    
    // if we are controlling the display backlight implement a simple PWM
    if(Option.DISPLAY_BL) {
        BacklightCount++;
        if(BacklightCount == 20) {
            PinSetBit(Option.DISPLAY_BL, LATSET);
            BacklightCount = 0;
        }
        if(BacklightCount == display_backlight) PinSetBit(Option.DISPLAY_BL, LATCLR);
    }
#if defined(MX470) && !defined(MZEF)   
    // if the USB has +5V on its connector check for USB activity
    if(U1OTGSTAT & 1) CheckUSB();
#endif
    // if we are not at a new millisecond return
    if((mSecCheck++) & 1) {
        mT4ClearIntFlag();
        return;
    }
#elif defined(MX270D)
    // if the USB has +5V on its connector check for USB activity
    if(U1OTGSTAT & 1) CheckUSB();
    USBTimer++;                                                     // used to tell if the USB send queue has stalled
#endif

	/////////////////// the following is executed once a millisecond/////////////////////
  
	/////////////////////////////// count up timers /////////////////////////////////////
	
	// if we are measuring period increment the count
	if(ExtCurrentConfig[INT1PIN] == EXT_PER_IN) INT1Count++;
	if(ExtCurrentConfig[INT2PIN] == EXT_PER_IN) INT2Count++;
	if(ExtCurrentConfig[INT3PIN] == EXT_PER_IN) INT3Count++;
	if(ExtCurrentConfig[INT4PIN] == EXT_PER_IN) INT4Count++;
	
	mSecTimer++;													// used by the TIMER function
	PauseTimer++;													// used by the PAUSE command
	IntPauseTimer++;												// used by the PAUSE command inside an interrupt
	InkeyTimer++;													// used to delay on an escape character

    if(CFuncmSec) CallCFuncmSec();                                  // the 1mS tick for CFunctions (see CFunction.c)

	if(InterruptUsed) {
    	int i;
	    for(i = 0; i < NBRSETTICKS; i++) TickTimer[i]++;			// used in the interrupt tick
	}
	
	if(WDTimer) {
    	if(--WDTimer == 0) {
            _excep_code = WATCHDOG_TIMEOUT;
            SoftReset();                                            // crude way of implementing a watchdog timer.
        }
    }


    if(ds18b20Timer > 0) ds18b20Timer--;

	if (I2C_Timer) {
		if (--I2C_Timer == 0) {
			I2C_Status |= I2C_Status_Timeout;
			mI2C1MSetIntFlag();
		}
	}
	if (I2C_Status & I2C_Status_MasterCmd) {
		if (!(I2C1STAT & _I2C1STAT_S_MASK)) {
			I2C_Status &= ~I2C_Status_MasterCmd;
			I2C_State = I2C_State_Start;
			I2C1CONSET =_I2C1CON_SEN_MASK;
		}
	}


    // check if any pulse commands are running
    if(PulseActive) {
        int i;
        for(PulseActive = i = 0; i < NBR_PULSE_SLOTS; i++) {
            if(PulseCnt[i] > 0) {                                   // if the pulse timer is running
                PulseCnt[i]--;                                      // and decrement our count
                if(PulseCnt[i] == 0)                                // if this is the last count reset the pulse
                    PinSetBit(PulsePin[i], PulseDirection[i] ? LATSET : LATCLR);
                else
                    PulseActive = true;                             // there is at least one pulse still active
            }
        }    
    } 

    // Handle any IR remote control activity
    ElapsedMicroSec = ((1000 * TMR1) / (BusSpeed / 64000));
    if(IrState > IR_WAIT_START && ElapsedMicroSec > 15000) IrReset();
    IrCmdTmp = -1;
    
    // check for any Sony IR receive activity
    if(IrState == SONY_WAIT_BIT_START && ElapsedMicroSec > 2800 && (IrCount == 12 || IrCount == 15 || IrCount == 20)) {
        IrDevTmp = ((IrBits >> 7) & 0b11111);
        IrCmdTmp = (IrBits & 0b1111111) | ((IrBits >> 5) & ~0b1111111);
    }
    
    // check for any NEC IR receive activity
    if(IrState == NEC_WAIT_BIT_END && IrCount == 32) {
        // check if it is a NON extended address and adjust if it is
        if((IrBits >> 24) == ~((IrBits >> 16) & 0xff)) IrBits = (IrBits & 0x0000ffff) | ((IrBits >> 8) & 0x00ff0000);
        IrDevTmp = ((IrBits >> 16) & 0xffff);
        IrCmdTmp = ((IrBits >> 8) & 0xff);
    }

    // now process the IR message, this includes handling auto repeat while the key is held down
    // IrTick counts how many mS since the key was first pressed
    // NextIrTick is used to time the auto repeat
    // IrTimeout is used to detect when the key is released
    // IrGotMsg is a signal to the interrupt handler that an interrupt is required
    if(IrCmdTmp != -1) {
        if(IrTick > IrTimeout) {
            // this is a new keypress
            IrTick = 0;
            NextIrTick = 650;
        }
        if(IrTick == 0 || IrTick > NextIrTick) {
            if(IrVarType & 0b01)
                *(float *)IrDev = IrDevTmp;
            else
                *(long long int *)IrDev = IrDevTmp;
            if(IrVarType & 0b10)
                *(float *)IrCmd = IrCmdTmp;
            else
                *(long long int *)IrCmd = IrCmdTmp;
            IrGotMsg = true;
            NextIrTick += 250;
        }
        IrTimeout = IrTick + 150;
        IrReset();
    }
    IrTick++;
#if defined(MX470)
    // check on the touch panel, is the pen down?

    TouchTimer++;
    if(CheckGuiFlag) CheckGui();                                    // are blinking LEDs or latched buttons in use?

    if(TouchIrqPortAddr && TOUCH_GETIRQTRIS){                       // is touch enabled and the PEN IRQ pin an input?
        if(TOUCH_DOWN) {                                            // is the pen down
            if(!TouchState) {                                       // yes, it is.  If we have not reported this before
                TouchState = TouchDown = true;                      // set the flags
                TouchUp = false;
            }
        } else {
            if(TouchState) {                                        // the pen is not down.  If we have not reported this before
                TouchState = TouchDown = false;                     // set the flags
                TouchUp = true;
            }
        }
    }

    if(ClickTimer) {
        ClickTimer--;
        if(Option.TOUCH_Click) PinSetBit(Option.TOUCH_Click, ClickTimer ? LATSET : LATCLR);
    }

	// check if the sound has expired
	if(SoundPlay && SoundPlay != 0xffffffff) {						// if we are still playing the sound and it is not forever
		SoundPlay--;
		if(SoundPlay < 1) {
    		StopAudio();
		}
	}		

	if(++CursorTimer > CURSOR_OFF + CURSOR_ON) CursorTimer = 0;		// used to control cursor blink rate

    if(Option.SDCARD[Option.DEFAULT_DRIVE].CD && SDCardPresent[Option.DEFAULT_DRIVE]) {
        if(Option.SDCARD[Option.DEFAULT_DRIVE].CD > 0)
            SDCardPresent[Option.DEFAULT_DRIVE] = !PinRead(Option.SDCARD[Option.DEFAULT_DRIVE].CD);
        else
            SDCardPresent[Option.DEFAULT_DRIVE] = PinRead(-Option.SDCARD[Option.DEFAULT_DRIVE].CD);
    }
    USBTimer++;                                                     // used to tell if the USB send queue has stalled

//	if(USBBannerTimer > -4000) {									// if we are timing a USB connection
//        char *p;
//		USBBannerTimer--;
//        if(USBBannerTimer == 2) for(p = MES_SIGNON; *p; p++) USBPutC(*p);
//        if(USBBannerTimer == 1) for(p = MES_COPYRIGHT; *p; p++) USBPutC(*p);
//        if(USBBannerTimer == 0 && CurrentLinePtr == NULL) for(p = "\r\n> "; *p; p++) USBPutC(*p);
//	}

#endif
    
    // if we are measuring frequency grab the count for the last second
    if(ExtCurrentConfig[INT1PIN] == EXT_FREQ_IN && --INT1Timer <= 0) { INT1Value = INT1Count; INT1Count = 0; INT1Timer = INT1InitTimer; }
    if(ExtCurrentConfig[INT2PIN] == EXT_FREQ_IN && --INT2Timer <= 0) { INT2Value = INT2Count; INT2Count = 0; INT2Timer = INT2InitTimer; }
    if(ExtCurrentConfig[INT3PIN] == EXT_FREQ_IN && --INT3Timer <= 0) { INT3Value = INT3Count; INT3Count = 0; INT3Timer = INT3InitTimer; }
    if(ExtCurrentConfig[INT4PIN] == EXT_FREQ_IN && --INT4Timer <= 0) { INT4Value = INT4Count; INT4Count = 0; INT4Timer = INT4InitTimer; }


	////////////////////////////////// this code runs once a second /////////////////////////////////
	if(++SecondsTimer >= 1000) {
		SecondsTimer -= 1000;										// reset every second (thanks to matherp)
        // keep track of the time and date
		if(++second >= 60) {
			second = 0 ;
			if(++minute >= 60) {
				minute = 0;
				if(++hour >= 24) {
					hour = 0;
					if(++day > DaysInMonth[month + ((month == 2 && (year % 4) == 0)?1:0)]) {
						day = 1;
						if(++month > 12) {
							month = 1;
							year++;
						}
					}
				}
			}
		}
	}
	
            
    // Clear the interrupt flag
    mT4ClearIntFlag();
}
