/***********************************************************************************************************************
MMBasic

MM_Custom.c

Copyright 2011 - 2017 Geoff Graham.  All Rights Reserved.

Handles all the custom commands and functions in the Maximite implementation of MMBasic.  These are commands and functions
that are not normally part of the Maximite.  This is a good place to insert your own customised commands.

************************************************************************************************************************/

#include <stdio.h>

#include "../MMBasic_Includes.h"
#include "../Hardware_Includes.h"


/*************************************************************************************************************************
**************************************************************************************************************************
IMPORTANT:
This module is empty and should be used for your special functions and commands.  In the standard distribution this file  
will never be changed, so your code should be safe here.  You should avoid placing commands and functions in other files as
they may be changed and you would then need to re insert your changes in a new release of the source.

**************************************************************************************************************************
**************************************************************************************************************************/


/********************************************************************************************************************************************
 custom commands and functions
 each function is responsible for decoding a command
 all function names are in the form cmd_xxxx() (for a basic command) or fun_xxxx() (for a basic function) so, if you want to search for the
 function responsible for the NAME command look for cmd_name

 There are 4 items of information that are setup before the command is run.
 All these are globals.

 int cmdtoken	This is the token number of the command (some commands can handle multiple
				statement types and this helps them differentiate)

 char *cmdline	This is the command line terminated with a zero char and trimmed of leading
				spaces.  It may exist anywhere in memory (or even ROM).

 char *nextstmt	This is a pointer to the next statement to be executed.  The only thing a
				command can do with it is save it or change it to some other location.

 char *CurrentLinePtr  This is read only and is set to NULL if the command is in immediate mode.

 The only actions a command can do to change the program flow is to change nextstmt or
 execute longjmp(mark, 1) if it wants to abort the program.

 ********************************************************************************************************************************************/

#if defined(MX470)
float similarity0(char *s1, char *s2) {
    int checks=0;
    int matches1=0;
    int x1,x2;
    for (x1=1; x1<=*s1; x1++)
        for (x2=1; x2<=*s2; x2++) {
            if ((s1[x1] & 0xdf)==(s2[x2] & 0xdf)) {
                matches1++;
                x1++;
            }
            if (matches1 || checks==0) checks++;
            if (x1>*s1) break;
        }
    int matches2=0;
    for (x1=*s1; x1>=1; x1--)
        for (x2=*s2; x2>=1; x2--) {
            if ((s1[x1] & 0xdf)==(s2[x2] & 0xdf)) {
                matches2++;
                x1--;
            }
            if (matches2 || checks==0) checks++;
            if (x1<1) break;
        }
    float sim;
    if (checks) sim=((float)(matches1+matches2)/checks); else sim=0;
    return sim;
}


void fun_sim(void) {
    getargs(&ep, 3, ",");
    if (argc != 3) error("Incorrect number of arguments");
    char *s1 = getstring(argv[0]);
    char *s2 = getstring(argv[2]);
    if (*s1==0 || *s2==0) {
        fret=0;
        return;
    }
    float sim1=similarity0(s1,s2);
    float sim2=similarity0(s2,s1);
    fret=(sim1+sim2)/2;
    if (fret<0) fret=0;
    if (fret>1) fret=1;
    float rl;
    if (*s1>*s2) rl=(float)(*s2)/(*s1); else rl=(float)(*s1)/(*s2);
    fret*=rl;
}
#endif
