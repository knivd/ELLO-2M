/***********************************************************************************************************************
MMBasic

Flash.h

Include file that contains the globals and defines for flash save/load in MMBasic.
  
Copyright 2011 - 2017 Geoff Graham.  All Rights Reserved.

This file and modified versions of this file are supplied to specific individuals or organisations under the following 
provisions:

- This file, or any files that comprise the MMBasic source (modified or not), may not be distributed or copied to any other
  person or organisation without written permission.

- Object files (.o and .hex files) generated using this file (modified or not) may not be distributed or copied to any other
  person or organisation without written permission.

- This file is provided in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of 
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

************************************************************************************************************************/


#if defined(MX170)
  #define FLASH_PAGE_SIZE   1024
  // the amount of flash reserved for the program.  
  // Note that the MX150 and MX170 chips have 1K erasable pages
  #if defined(DEBUGMODE)
    #define PROG_FLASH_SIZE  (FLASH_PAGE_SIZE * 45)                 // leave space for the debug executive and printfs
    #define EDIT_BUFFER_SIZE  (FLASH_PAGE_SIZE * 45)                // do not reserve too much RAM for the editor
  #else
    #if !defined(LITE)
        #define PROG_FLASH_SIZE  (FLASH_PAGE_SIZE * 58)             // the amount of flash reserved for the BASIC program
        #define EDIT_BUFFER_SIZE  (int)(RAMEND - (int)RAMBase - 256)// this is the maximum RAM that we can get
    #else
        #define PROG_FLASH_SIZE  (FLASH_PAGE_SIZE * 74)             // the amount of flash reserved for the BASIC program
        #define EDIT_BUFFER_SIZE  (int)(RAMEND - (int)RAMBase - 256)// this is the maximum RAM that we can get
    #endif
  #endif
  #define SAVEDVARS_FLASH_SIZE (FLASH_PAGE_SIZE * 2)                // amount of flash reserved for saved variables
#endif

#if defined(MX470) && !defined(MZEF)
  #define FLASH_PAGE_SIZE   4096
  // the amount of flash reserved for the program.  The MX470 has 4K erasable pages
  #if defined(DEBUGMODE)
    #define PROG_FLASH_SIZE  (FLASH_PAGE_SIZE * 16)                 // leave space for the debug executive and printfs
    #define EDIT_BUFFER_SIZE  (int)(RAMEND - (int)RAMBase - 256)    // do not reserve too much RAM for the editor
  #else
    #define PROG_FLASH_SIZE  (FLASH_PAGE_SIZE * 24)                 // the amount of flash reserved for the BASIC program
    #define EDIT_BUFFER_SIZE  (int)(RAMEND - (int)RAMBase - 256)    // this is the maximum RAM that we can get
  #endif
  #define SAVEDVARS_FLASH_SIZE (FLASH_PAGE_SIZE)                    // amount of flash reserved for saved variables
#endif

#if defined(MZEF)
  #define FLASH_PAGE_SIZE           16384
  #define PROG_FLASH_ADDRESS        0x9D100000
  #define SAVEDVARS_FLASH_ADDRESS   0x9D124000
  // the amount of flash reserved for the program.  The MZ2048EF has 16K erasable pages
  #if defined(DEBUGMODE)
    #define PROG_FLASH_SIZE  (FLASH_PAGE_SIZE * 9)                 // leave space for the debug executive and printfs
    #define EDIT_BUFFER_SIZE  (int)(RAMEND - (int)RAMBase - 256)              // this is the maximum RAM that we can get
  #else
    #define PROG_FLASH_SIZE  (FLASH_PAGE_SIZE * 9)
    #define EDIT_BUFFER_SIZE  (int)(RAMEND - (int)RAMBase - 256)              // this is the maximum RAM that we can get
  #endif
  #define SAVEDVARS_FLASH_SIZE (FLASH_PAGE_SIZE)                    // amount of flash reserved for saved variables
#endif

#if !defined(INCLUDE_COMMAND_TABLE) && !defined(INCLUDE_TOKEN_TABLE) && !defined(FLASH_INCLUDED)
#define FLASH_INCLUDED

#define SDCARD_MAX_NUM          4
#define DEFAULT_SDCARD          0
#define SDCARD_1                0
#define SDCARD_2                1
#define SDCARD_3                2
#define SDCARD_4                3

#define SDFS1                   0
#define SDFS2                   1
#define SDFS3                   2
#define SDFS4                   3
#define FLASHFS                 4
#define NOPRESRDIVE             255

typedef struct{
    char CS;
    signed char CD;
    signed char WP;   
    unsigned char MUX_ENABLE;
    unsigned char MUXn;
    char DRV0;
    char DRV1;
}sdcard_t;

struct option_s {
    char Autorun;
    char Tab;
    char Invert;
    char Listcase;
    char Height;
    char Width;
    int  PIN;
    int  Baudrate;
    int  ColourCode;
	
    // display related
    char DISPLAY_TYPE;
    char DISPLAY_ORIENTATION;
	
    // touch related
    char TOUCH_CS;
    char TOUCH_IRQ;
    char TOUCH_SWAPXY;
    int  TOUCH_XZERO;
    int  TOUCH_YZERO;
    float TOUCH_XSCALE;
    float TOUCH_YSCALE;

    // for the SPI LCDs
    char LCD_CD;
    char LCD_CS;
    char LCD_Reset;

    // these are only used in the MX470 version
    char SerialCon;
    sdcard_t SDCARD[SDCARD_MAX_NUM];
    unsigned char DEFAULT_DRIVE;
    char PREV_DRIVE;
    char DISPLAY_BL;
    char DISPLAY_CONSOLE;
    char DefaultFont;
    char KeyboardConfig;
    char TOUCH_Click;

    unsigned int ProgFlashSize;    // used to store the size of the program flash (also start of the LIBRARY code)
    char pins[8];                  // general use storage for CFunctions written by PeterM

    int DefaultFC, DefaultBC;      // the default colours
    int DefaultBrightness;         // default backlight brightness
    char RTC_Clock, RTC_Data;
    char MSDStatus;
    // To enable older CFunctions to run any new options *MUST* be added at the end of the list
	char LCD_RD;                   // used for the RD pin for SSD1963
    short MaxCtrls;                // maximum number of controls allowed
    char DriveASet;
};

extern struct option_s Option;

extern char ProgFlash[];
extern unsigned char *CFunctionFlash, *CFunctionLibrary;
extern char SavedVarsFlash[];

extern char *flashptr;

void ResetAllOptions(void);
void ResetAllFlash(void);
void SaveOptions(void);
void LoadOptions(void);
void FlashWriteInit(char *p, int nbr);
void FlashWriteByte(unsigned char b);
void FlashWriteByteErase(char c);
void FlashWriteWordErase(unsigned int i);
void FlashWriteClose(void);
int GetFlashOption(const unsigned int *w) ;
void SetFlashOption(const unsigned int *w, int x) ;
void cmd_var(void);
void ClearSavedVars(void);
void cmd_library(void);
long long int CallCFunction(char *CmdPtr, char *ArgList, char *DefP, char *CallersLinePtr);

    
#endif


/**********************************************************************************
 All command tokens tokens (eg, PRINT, FOR, etc) should be inserted in this table
**********************************************************************************/
#ifdef INCLUDE_COMMAND_TABLE

	{ "VAR",	    	T_CMD,				0, cmd_var	},
	{ "LIBRARY",	    	T_CMD,				0, cmd_library	},

#endif


/**********************************************************************************
 All other tokens (keywords, functions, operators) should be inserted in this table
**********************************************************************************/
#ifdef INCLUDE_TOKEN_TABLE
            
#endif
