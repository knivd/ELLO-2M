/***********************************************************************************************************************
MMBasic

Cfunctions.c

Handles the CSub and CFunction functionality.

Copyright 2011 - 2017 Geoff Graham.  All Rights Reserved.

This file and modified versions of this file are supplied to specific individuals or organisations under the following
provisions:

- This file, or any files that comprise the MMBasic source (modified or not), may not be distributed or copied to any other
  person or organisation without written permission.

- Object files (.o and .hex files) generated using this file (modified or not) may not be distributed or copied to any other
  person or organisation without written permission.

- This file is provided in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

************************************************************************************************************************/


#include "../MMBasic_Includes.h"
#include "../Hardware_Includes.h"

// these are floating point operators that can be used by CFunctions via CallTable[] (below)
float FMul(float a, float b){ return a * b; }
float FAdd(float a, float b){ return a + b; }
float FSub(float a, float b){ return a - b; }
float FDiv(float a, float b){ return a / b; }
int   FCmp(float a,float b){if(a>b) return 1;else if(a<b)return -1; else return 0;}
float IntToFloat(long long int a){ return a; }
float LoadFloat(unsigned long c){union ftype{ unsigned long a; float b;}f;f.a=c;return f.b; }
void SoftReset_(void){SoftReset();}

//Vector to CFunction static RAM
#define CFUNCRAM_SIZE   256
int CFuncRam[CFUNCRAM_SIZE/sizeof(int)];

//Vector to CFunction routine called every mSec
unsigned int CFuncmSec = NULL;

//Vector to CFunction routine called on timer1 interrupts
unsigned int CFuncT1 = NULL;

//Vector to CFunction routine called on timer5 interrupts
unsigned int CFuncT5 = NULL;

//Vector to CFunction routine called every command (ie, from the BASIC interrupt checker)
unsigned int CFuncInt = NULL;

//Vector to CFunction routine called by the interrupt 2 handler
unsigned int CFuncInt2 = NULL;

// jump table so that CFunctions can access certain internal MMBasic functions
// this is placed at the start of the flash memory space
__attribute__((address(0x9D000000))) const void * const CallTable[] = { (void *)&ClockSpeed,
                                                                        (void *)uSec,
                                                                        (void *)putConsole,
                                                                        (void *)getConsole,
                                                                        (void *)ExtCfg,
                                                                        (void *)ExtSet,
                                                                        (void *)ExtInp,
                                                                        (void *)PinSetBit,
                                                                        (void *)PinRead,
                                                                        (void *)GetPortAddr,
                                                                        (void *)GetPinBit,
                                                                        (void *)MMPrintString,
                                                                        (void *)IntToStr,
                                                                        (void *)FloatToStr,
                                                                        (void *)CheckAbort,
                                                                        (void *)GetMemory,
                                                                        (void *)GetTempMemory,
                                                                        (void *)FreeMemory,
                                                                        (void *)&DrawRectangle,
                                                                        (void *)&DrawBitmap,
                                                                        (void *)DrawLine,
                                                                        (void *)FontTable,
                                                                        (void *)FMul,
                                                                        (void *)FAdd,
                                                                        (void *)FSub,
                                                                        (void *)FDiv,
                                                                        (void *)FCmp,
                                                                        (void *)sinl,
                                                                        (void *)logl,
                                                                        (void *)powl,
                                                                        (void *)atanf,
                                                                        (void *)FloatToInt64,
                                                                        (void *)IntToFloat,
                                                                        (void *)&CFuncmSec,
                                                                        (void *)&ExtCurrentConfig,
                                                                        (void *)CFuncRam,
                                                                        (void *)&Option,
                                                                        (void *)&HRes,
                                                                        (void *)&VRes,
                                                                        (void *)&LoadFloat,
                                                                        (void *)&SoftReset_,
                                                                        (void *)&CFuncInt,
                                                                        (void *)&ScrollLCD,
                                                                        (void *)&CFuncT1,
                                                                        (void *)&CFuncT5,
                                                                        (void *)ExecuteProgram,
                                                                        (void *)SaveProgramToFlash,
                                                                        (void *)error,
                                                                        (void *)&ProgFlash,
                                                                        (void *)ClearProgram,
                                                                        (void *)llist,
                                                                        (void *)&CFuncInt2,
                                                                        (void *)&vartbl,
                                                                        (void *)&varcnt,
                                                                        (void *)&GetTouchAxis,
                                                                        (void *)&DrawBuffer,
                                                                        (void *)&ReadBuffer
                                                                       };

/*******************************************************************************************************************
 Code to execute a CFunction saved in flash
*******************************************************************************************************************/

// used by CallCFunction() below to find a CFunction or CSub in program flash or the library
unsigned int *FindCFunction(unsigned int *p, char *CmdPtr) {
    while(*p != 0xffffffff) {
        if(*p++ == (unsigned int)CmdPtr) return p;
        p += (*p + 4) / sizeof(unsigned int);
    }
    return p;
}


long long int CallCFunction(char *CmdPtr, char *ArgList, char *DefP, char *CallersLinePtr) {
    void *arg[10] = { NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL };
    int typ[10] = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
    long long int i64[10];
    float ff[10];
    char *pp;
    int i, type;
    unsigned int *p;

    // find the C routine's code in flash
    if(*CmdPtr == cmdCFUN && *ArgList != '(') error("Invalid syntax");  // check that a CFunction has an opening bracket
    if(*ArgList == '(') ArgList++;                                  // and step over it
    p = FindCFunction((unsigned int *)CFunctionFlash, CmdPtr);      // search through the program flash looking for a match to the function being called
    if(*p == 0xffffffff && CFunctionLibrary != NULL)
        p = FindCFunction((unsigned int *)CFunctionLibrary, CmdPtr);// if unsuccessful search the library area
    if(*p == 0xffffffff) error("Internal fault (sorry)");
    
    // next, get the argument types (if specified)
    {  // first copy the type list to a buffer and trim the following closing bracket (if there)
        char buf[MAXSTRLEN];
        char *p = buf;
        if(*DefP == '(') DefP++;
        while(*DefP && *DefP != ')' && *DefP != '\'') *p++ = *DefP++;
        *p = 0;
        p = buf;
        skipspace(p);
        CheckIfTypeSpecified(p, &i, true);
        if(i != DefaultType) {
            // if there is a type list get each entry
            getargs(&p, 19, ",");
            for(i = 0; i < argc; i+=2) {                            // get each definition
                CheckIfTypeSpecified(argv[i], &typ[i/2], false);
                typ[i/2] &= ~T_IMPLIED;
            }
        }
    }

    // we have found the CFunction or CSub and the types on its command line
    CurrentLinePtr = CallersLinePtr;                                       // report errors at the caller
    if(*ArgList != ')') {
        getargs(&ArgList, 19, ",");                                 // expand the command line of the caller
        if(argc%2 == 0) error("Invalid syntax");
        for(i = 0; i < argc; i += 2) {
            // if this is a straight variable we want to pass a pointer to its value in RAM
            if(isnamestart(*argv[i]) && (*skipvar(argv[i], false) == 0 || *skipvar(argv[i], false) == ')') && !(FindSubFun(argv[i], 1) >= 0 && strchr(argv[i], '(') != NULL)) {
                arg[i/2] = findvar(argv[i], V_FIND | V_EMPTY_OK | V_NOFIND_ERR);   // if the argument
                if(typ[i/2] != 0 && !(TypeMask(vartbl[VarIndex].type) & typ[i/2])) error("Incompatible type");
            } else {
                // else it must be an expression of some sort
                // get the value based on the type specified in the definition
                switch(typ[i/2]) {
                    case T_INT: i64[i/2] = getinteger(argv[i]);
                                arg[i/2] = &i64[i/2];
                                break;
                    case T_NBR: ff[i/2] = getnumber(argv[i]);
                                arg[i/2] = &ff[i/2];
                                break;
                    case T_STR: arg[i/2] = GetTempStrMemory();
                                Mstrcpy(arg[i/2], getstring(argv[i]));
                                break;
                    default:    // the type has not been specified (old style CFunction)
                                type = T_NOTYPE;
                                evaluate(argv[i], &ff[i/2], &i64[i/2], &pp, &type, false);
                                if(type & T_NBR) {
                                    arg[i/2] = &ff[i/2];
                                } else if(type & T_INT)
                                    arg[i/2] = &i64[i/2];
                                else {
                                    arg[i/2] = GetTempStrMemory();
                                    Mstrcpy(arg[i/2], pp);
                                }
                                break;
                }
            }
        }
    }
    p++;                                                            // step over the size word
    // run the function in flash
    i = *p++;

    //Peter Carnegie 2015-05-21 00:15
    //If b31 of the offset word in a CFunction is set to 1 then the
    //CFunction has been compiled with MIPS16 instruction set
    //In which case bit[0] of the called address must be set to 1
    if (i & 0x80000000){
        p = (unsigned int *)(((unsigned int) p) | 0x1);             //Used when calling MIPS16 code
        i &= 0x7ffffff;
    }
    return ((long long int (*)(void *, void *, void *, void *, void *, void *, void *, void *, void *, void *)) (p + i)) (arg[0], arg[1], arg[2], arg[3], arg[4], arg[5], arg[6], arg[7], arg[8], arg[9]);              // run the CFunction
}



// If the CFuncmSec vector is set then call the CFunction
inline void CallCFuncmSec(void){
    typedef void func(void);
    func* f=(func*)(void *)CFuncmSec;
    f();
}


inline void CallCFuncT1(void){
    typedef void func(void);
    func* f=(func*)(void *)CFuncT1;
    f();
}


#if defined(MX470)
inline void CallCFuncT5(void){
    typedef void func(void);
    func* f=(func*)(void *)CFuncT5;
    f();
}
#endif


// If the CFuncmInt vector is set then call the CFunction
inline void CallCFuncInt(void){
    typedef void func(void);
    func* f=(func*)(void *)CFuncInt;
    f();
}

// If the CFuncmInt2 vector is set then call the CFunction
inline void CallCFuncInt2(void){
    typedef void func(void);
    func* f=(func*)(void *)CFuncInt2;
    f();
}
