/***********************************************************************************************************************
MMBasic

Flash.c

Handles saving and restoring from flash.

Copyright 2011 - 2017 Geoff Graham.  All Rights Reserved.

This file and modified versions of this file are supplied to specific individuals or organisations under the following
provisions:

- This file, or any files that comprise the MMBasic source (modified or not), may not be distributed or copied to any other
  person or organisation without written permission.

- Object files (.o and .hex files) generated using this file (modified or not) may not be distributed or copied to any other
  person or organisation without written permission.

- This file is provided in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

************************************************************************************************************************/


#include "../MMBasic_Includes.h"
#include "../Hardware_Includes.h"



//////////////////////////////////////////////////////////////////////////////////////////////
// Macro to reserve flash memory for saving/loading data and initialise to 0xFF's
// Note that ?bytes? need to be a multiple of:-
//  - BYTE_PAGE_SIZE (and aligned that way) if you intend to erase
//  - BYTE_ROW_SIZE (and aligned that way) if you intend to write rows
//  - sizeof(int) if you intend to write words
#if !defined(MZEF)
#define NVM_ALLOCATE(name, align, bytes) char name[(bytes)] \
	     __attribute__ ((aligned(align),section(".nvm"),space(prog))) = \
	     { [0 ...(bytes)-1] = 0xFF }

NVM_ALLOCATE(ProgFlash, FLASH_PAGE_SIZE, PROG_FLASH_SIZE);

// allocate space in flash for the saved variables and options.
NVM_ALLOCATE(SavedVarsFlash, FLASH_PAGE_SIZE, SAVEDVARS_FLASH_SIZE);
#else
char ProgFlash[(PROG_FLASH_SIZE)] __attribute__ ((aligned(FLASH_PAGE_SIZE),space(prog))) __attribute__((address(PROG_FLASH_ADDRESS))) = { [0 ...(PROG_FLASH_SIZE)-1] = 0xFF };
char SavedVarsFlash[(SAVEDVARS_FLASH_SIZE)] __attribute__ ((aligned(FLASH_PAGE_SIZE),space(prog)))__attribute__((address(SAVEDVARS_FLASH_ADDRESS))) = { [0 ...(SAVEDVARS_FLASH_SIZE)-1] = 0xFF };
#endif
// The CFUNCTION data comes after the program in program memory
// and this is used to point to its start
unsigned char *CFunctionFlash = NULL;
unsigned char *CFunctionLibrary = NULL;

struct option_s Option;

// globals used when writing bytes to flash
char *flashptr;
union {
	unsigned int wrd;
	char ch[4];
} WBuf;


// erase the flash and init the variables used to buffer bytes for writing to the flash
void FlashWriteInit(char *p, int nbr) {
    flashptr = p;
    WBuf.wrd = 0;
    while(nbr > 0) {
        if(NVMErasePage((char *)p)) error("Flash write");
        p += FLASH_PAGE_SIZE;
        nbr -= FLASH_PAGE_SIZE;
    }
}

// write a byte to flash
// this will buffer four bytes so that the write to flash can be a word
void FlashWriteByte(unsigned char b) {
    WBuf.ch[(int)flashptr & 0b11] = b;
    flashptr++;
    if(((int)flashptr & 0b11) == 0) {
        if(NVMWriteWord((void *)(flashptr - 4), WBuf.wrd))
            error("Flash write");
        WBuf.wrd = 0;
    }
}


// utility routine used by SaveProgramToFlash() and cmd_var to write a byte to flash while erasing the page if needed
void FlashWriteByteErase(char c) {
    if(((int)flashptr % FLASH_PAGE_SIZE) == 0) if(NVMErasePage(flashptr)) error("Flash write");
    FlashWriteByte(c);
}



// utility routine used by SaveProgramToFlash() and cmd_var to write a byte to flash while erasing the page if needed
void FlashWriteWordErase(unsigned int i) {
    if(((int)flashptr % FLASH_PAGE_SIZE) == 0) if(NVMErasePage(flashptr)) error("Flash write");
    if(NVMWriteWord((void *)flashptr, i)) error("Flash write");
    flashptr += 4;
}



// flush any bytes in the buffer to flash
void FlashWriteClose(void) {
    while(((int)flashptr & 0b11) != 0) FlashWriteByte(0xff);
}



/*******************************************************************************************************************
 VARSAVE and VARSAVE RESTORE commands

 Variables are saved in flash as follows:
 Numeric variables:
     1 byte  = variable type
     ? bytes = the variable's name in uppercase
     1 byte  = zero byte terminating the variable's name
     4 or 8 bytes = the value of the variable
 String variables:
     1 byte  = variable type
     ? bytes = the variable's name in uppercase
     1 byte  = zero byte terminating the variable's name
     1 bytes = length of the variable's string
     ? bytes = the variables string
 Array variables (string or numeric):
     1 byte  = variable type with the top bit (bit 7) set
     ? bytes = the variable's name in uppercase
     1 byte  = zero byte terminating the variable's name
     2 bytes = length of the array data in bytes (LSB first)
     ? bytes = the array data
 

********************************************************************************************************************/



/*******************************************************************************************************************
 The variables are stored in a reserved flash area.
 The first few bytes are used for the options. So we must save the options in RAM before we erase, then write the
 options back.  The variables saved by this command are then written to flash starting just after the options.
********************************************************************************************************************/
void cmd_var(void) {
    char *p, *buf, *bufp, *varp, *vdata, lastc;
    int i, j, nbr = 1, array, type, SaveDefaultType;
    int VarList[MAX_ARG_COUNT];
    char *VarDataList[MAX_ARG_COUNT];

    
    if((p = checkstring(cmdline, "CLEAR"))) {
        checkend(p);
        ClearSavedVars();
        return;
    }

    if((p = checkstring(cmdline, "RESTORE"))) {
        char b[MAXVARLEN + 3];
        checkend(p);
        SaveDefaultType = DefaultType;                              // save the default type
        bufp = SavedVarsFlash + sizeof(struct option_s);            // point to where the variables were saved
        while(*bufp != 0xff) {                                      // 0xff is the end of the variable list
            type = *bufp++;                                         // get the variable type
            array = type & 0x80;  type &= 0x7f;                     // set array to true if it is an array
            DefaultType = TypeMask(type);                           // and set the default type to this
            if(array) {
                strcpy(b, bufp);
                strcat(b, "()");
                vdata = findvar(b, type | V_EMPTY_OK | V_FIND);     // find an array
            } else
                vdata = findvar(bufp, type | V_FIND);               // find or create a non arrayed variable
            if(TypeMask(vartbl[VarIndex].type) != TypeMask(type)) error("$ already declared with a different type", bufp);
            if(vartbl[VarIndex].type & T_CONST) error("Cannot change a constant");
            bufp += strlen((char *)bufp) + 1;                       // step over the name and the terminating zero byte
            if(array) {                                             // an array has the data size in the next two bytes
                nbr = *bufp++;
                nbr |= (*bufp++) << 8;
            } else {
               if(type & T_STR) nbr = *bufp + 1;
               if(type & T_NBR) nbr = sizeof(float);
               if(type & T_INT) nbr = sizeof(long long int);
            }
            while(nbr--) *vdata++ = *bufp++;                          // copy the data
        }
        DefaultType = SaveDefaultType;
        return;
    }

     if((p = checkstring(cmdline, "SAVE"))) {
        getargs(&p, (MAX_ARG_COUNT * 2) - 1, ",");                  // getargs macro must be the first executable stmt in a block
        if((argc & 0x01) == 0) error("Invalid syntax");
        
        // befor we start, run through the arguments checking for errors
        for(i = 0; i < argc; i += 2) {
            checkend(skipvar(argv[i], false));
            VarDataList[i/2] = findvar(argv[i], V_NOFIND_ERR | V_EMPTY_OK);
            VarList[i/2] = VarIndex;
            if((vartbl[VarIndex].type & (T_CONST | T_PTR)) || vartbl[VarIndex].level != 0) error("Invalid variable");
            p = &argv[i][strlen(argv[i]) - 1];                      // pointer to the last char
            if(*p == ')') {                                         // strip off any empty brackets which indicate an array
                p--;
                if(*p == ' ') p--;
                if(*p == '(')
                    *p = 0;
                else
                    error("Invalid variable");
            }
        }

        // load the current variable save table into RAM
        // while doing this skip any variables that are in the argument list for this save
        bufp = buf = GetTempMemory(SAVEDVARS_FLASH_SIZE);           // build the saved variable table in RAM
        varp = SavedVarsFlash + sizeof(struct option_s);            // point to where the variables were saved

        while(*varp != 0xff) {                                      // 0xff is the end of the variable list
            type = *varp++;                                         // get the variable type
            array = type & 0x80;  type &= 0x7f;                     // set array to true if it is an array
            vdata = varp;                                           // save a pointer to the name
            while(*varp) varp++;                                    // skip the name
            varp++;                                                 // and the terminating zero byte
            if(array) {                                             // an array has the data size in the next two bytes
                nbr = (varp[0] | (varp[1] << 8)) + 2;
            } else {
                if(type & T_STR) nbr = *varp + 1;
                if(type & T_NBR) nbr = sizeof(float);
                if(type & T_INT) nbr = sizeof(long long int);
            }
            for(i = 0; i < argc; i += 2) {                          // scan the argument list
                p = &argv[i][strlen(argv[i]) - 1];                  // pointer to the last char
                lastc = *p;                                         // get the last char
                if(lastc <= '%') *p = 0;                            // remove the type suffix for the compare
                if(strncasecmp(vdata, argv[i], MAXVARLEN) == 0) {   // does the entry have the same name?
                    while(nbr--) varp++;                            // found matching variable, skip over the entry in flash (ie, do not copy to RAM)
                    i = 9999;                                       // force the termination of the for loop
                }
                *p = lastc;                                         // restore the type suffix
            }
            // finished scanning the argument list, did we find a matching variable?
            // if not, copy this entry to RAM
            if(i < 9999) {
                *bufp++ = type | array;
                while(*vdata) *bufp++ = *vdata++;                   // copy the name
                *bufp++ = *vdata++;                                 // and the terminating zero byte
                while(nbr--) *bufp++ = *varp++;                       // copy the data
            }
        }

        // initialise for writing to the flash
        FlashWriteInit(SavedVarsFlash, 0);

        // before we start, we have to write the options table, the first write
        // will trigger an erase of the flash (and the options table)
        vdata = (char *)&Option;
        for(i = 0; i < sizeof(struct option_s); i++) FlashWriteByteErase(*vdata++);
        
        // now write the variables in RAM recovered from the var save list
        while(buf < bufp) FlashWriteByteErase(*buf++);

        // now save the variables listed in this invocation of VAR SAVE
        for(i = 0; i < argc; i += 2) {
            VarIndex = VarList[i/2];                                // previously saved index to the variable
            vdata = VarDataList[i/2];                               // pointer to the variable's data
            type = TypeMask(vartbl[VarIndex].type);                 // get the variable's type
            type |= (vartbl[VarIndex].type & T_IMPLIED);            // set the implied flag
            array = (vartbl[VarIndex].dims[0] != 0);
            
            nbr = 1;                                                // number of elements to save
            if(array) {                                             // if this is an array calculate the number of elements
                for(j = 0; vartbl[VarIndex].dims[j] != 0 && j < MAXDIM; j++)
                    nbr *= (vartbl[VarIndex].dims[j] + 1 - OptionBase);
                type |= 0x80;                                       // an array has the top bit set
            }
                
            if(type & T_STR) {
                if(array) 
                    nbr *= vartbl[VarIndex].size;
                else
                    nbr = *vdata + 1;                               // for a simple string variable just save the string
            }
            if(type & T_NBR) nbr *= sizeof(float);
            if(type & T_INT) nbr *= sizeof(long long int);
            if(flashptr - SavedVarsFlash + 36 + nbr > SAVEDVARS_FLASH_SIZE) {
                FlashWriteClose();
                error("Not enough memory");
            }
            FlashWriteByteErase(type);                              // save its type
            for(j = 0, p = vartbl[VarIndex].name; *p && j < MAXVARLEN; p++, j++)
                FlashWriteByteErase(*p);                            // save the name
            FlashWriteByteErase(0);                                 // terminate the name
            if(array) {                                             // if it is an array save the number of data bytes
               FlashWriteByteErase(nbr); FlashWriteByteErase(nbr >> 8);
            }
            while(nbr--) FlashWriteByteErase(*vdata++);             // write the data
        }
        FlashWriteClose();
        return;
     }
    error("Unknown command");
}


void ClearSavedVars(void) {
    char *vdata;
    int i;
    FlashWriteInit(SavedVarsFlash, 0);                              // initialise for writing to the flash
    vdata = (char *)&Option;
    for(i = 0; i < sizeof(struct option_s); i++)                    // write the options table (Note: ResetAllOptions() depends on this step)
        FlashWriteByteErase(*vdata++);                              // the first write will trigger an erase of the flash (and the options table)
    FlashWriteByteErase(0xff);                                      // this is the start of the variable table and 0xff means empty
    FlashWriteClose();
}

/*******************************************************************************************************************
 The LIBRARY commands
 The library is an area in the top of program flash that holds code saved with LIBRARY SAVE.  It includes BASIC
 code and CFunctions extracted from the library BASIC code.

 The program flash layout is:
 ===================   << PROG_FLASH_SIZE    (the total size of the flash area in bytes)
 |                 |
 |                 |       this contains the library CFunctions
 |                 |
 ===================   << CFunctionLibrary   (starting address of the library CFunctions)
 |                 |
 |                 |       this contains the library BASIC code
 |                 |
 ===================   << Option.ProgFlashSize   (the maximum size of a BASIC program. Indicates the library start)
 |                 |
 |                 |
 |                 |       empty program flash
 |                 |
 |                 |
 ~~~~~~~~~~~~~~~~~~~
 |                 |
 |                 |       this contains the CFunctions extracted from the main BASIC program
 |                 |
 ===================   << CFunctionFlash   (starting address of the main program CFunctions)
 |                 |
 |                 |       this contains the main program BASIC code
 |                 |
 ===================   << ProgFlash   (starting address of the program flash area)

********************************************************************************************************************/

void cmd_library(void) {
    char *p, *pp, *m, *MemBuff, *TempPtr, rem;
    int i, j, k, InCFun, InQuote, CmdExpected;
    unsigned int CFunDefAddr[100], *CFunHexAddr[100], *CFunHexLibAddr[100];

    if((p = checkstring(cmdline, "SAVE"))) {
        if(CurrentLinePtr) error("Invalid in a program");
        if(*ProgFlash != 0x01) return;
    	checkend(p);
        ClearRuntime();
        TempPtr = m = MemBuff = GetTempMemory(EDIT_BUFFER_SIZE);
        rem = GetCommandValue("Rem");
        InQuote = InCFun = j = 0;
        CmdExpected = true;
        
        // first copy the current program code residing in the Library area to RAM
        if(Option.ProgFlashSize != PROG_FLASH_SIZE) {
            p = ProgFlash + Option.ProgFlashSize;
            while(!(p[0] == 0 && p[1] == 0)) *m++ = *p++;
            *m++ = 0;                                               // terminate the last line
        }

        // then copy the current contents of the program memory to RAM
        p = ProgFlash;
        while(*p != 0xff) {
            if(p[0] == 0 && p[1] == 0) break;                       // end of the program
            if(*p == T_LINENBR) {
                CurrentLinePtr = p;
                TempPtr = m;
                *m++ = *p++; *m++ = *p++; *m++ = *p++;              // copy the line number
                skipspace(p);
                if(*p == 0) {                                       // if this is an empty line we can skip it
                    m = TempPtr;                                    // erase the new line tokens (already copied)
                    p++;
                    if(*p == 0) break;                              // end of the program or module
                    continue;
                }
                CmdExpected = true;                                 // if true we can expect a command next (possibly a CFunction, etc)
            }
            
            if(*p == T_LABEL) {
                for(i = p[1] + 2; i > 0; i--) *m++ = *p++;          // copy the label                        
                TempPtr = m;
                skipspace(p);
            }

            if(CmdExpected && (*p == GetCommandValue("End CFunction") || *p == GetCommandValue("End CSub") || *p == GetCommandValue("End DefineFont"))) {
                InCFun = false;                                     // found an END CFUNCTION, END CSUB or END DEFINEFONT token
            }

            if(InCFun) {
                skipline(p);                                        // skip the body of a CFunction
                m = TempPtr;                                        // don't copy the new line
                continue;
            }

            if(CmdExpected && (*p == cmdCFUN || *p == cmdCSUB || *p == GetCommandValue("DefineFont"))) {    // found a CFUNCTION, CSUB or DEFINEFONT token
                CFunDefAddr[++j] = (unsigned int)m;                 // save its address so that the binary copy in the library can point to it
                while(*p) *m++ = *p++;                              // copy the declaration
                InCFun = true;
            }

            if(CmdExpected && *p == rem) {                          // found a REM token
                skipline(p);
                m = TempPtr;                                        // don't copy the new line tokens
                continue;
            }

            if(*p >= C_BASETOKEN || isnamestart(*p))
                CmdExpected = false;                                // stop looking for a CFunction, etc on this line

            if(*p == '"') InQuote = !InQuote;                       // found the start/end of a string
                    
            if(*p == '\'' && !InQuote) {                            // found a modern remark char
                skipline(p);
                if(*(m-3) == 0x01) {
                    m = TempPtr;                                    // if the comment was the only thing on the line don't copy the line at all
                    continue;
                } else
                    p--;
            }

            if(*p == ' ' && !InQuote) {                             // found a space
                if(*(m-1) == ' ') m--;                              // don't copy the space if the preceeding char was a space
            }

            if(p[0] == 0 && p[1] == 0) break;                       // end of the program
            *m++ = *p++;
        }
        while(*p == 0) *m++ = *p++;                                 // the end of the program can have multiple zeros
        *m++ = *p++;;                                               // copy the terminating 0xff
        while((unsigned int)p & 0b11) p++;
        while((unsigned int)m & 0b11) *m++ = 0xff;                  // step to the next word boundary
        
        // now copy the CFunction/CSub/Font data
        // =====================================
        // the format of a CFunction in flash is:
        //   Unsigned Int - Address of the CFunction/CSub/Font in program memory (points to the token).  For a font it is zero.
        //   Unsigned Int - The length of the CFunction/CSub/Font in bytes including the Offset (see below)
        //   Unsigned Int - The Offset (in words) to the main() function (ie, the entry point to the CFunction/CSub).  The specs for the font if it is a font.
        //   word1..wordN - The CFunction code
        // The next CFunction starts immediately following the last word of the previous CFunction
        
        // first, copy any CFunctions residing in the library area to RAM
        k = 0;                                                      // this is used to index CFunHexLibAddr[] for later adjustment of a CFun's address
        if(CFunctionLibrary != NULL) {
            pp = (char *)CFunctionLibrary;
            while(*(unsigned int *)pp != 0xffffffff) {
                CFunHexLibAddr[++k] = (unsigned int *)m;            // save the address for later adjustment
                j = (*(unsigned int *)(pp + 4)) + 8;                // calculate the total size of the CFunction
                while(j--) *m++ = *pp++;                            // copy it into RAM
            }
        }

        // then, copy any CFunctions in program memory to RAM
        i = 0;                                                      // this is used to index CFunHexAddr[] for later adjustment of a CFun's address
        while(*(unsigned int *)p != 0xffffffff) {
            CFunHexAddr[++i] = (unsigned int *)m;                   // save the address for later adjustment
            j = (*(unsigned int *)(p + 4)) + 8;                     // calculate the total size of the CFunction
            while(j--) *m++ = *p++;                                 // copy it into RAM
        }

        // we have now copied all the CFunctions into RAM
        
        // calculate the starting point of the library code (located in the top of the program space in flash)
        TempPtr = (ProgFlash + PROG_FLASH_SIZE) - (((m - MemBuff) + (FLASH_PAGE_SIZE - 1)) & (~(FLASH_PAGE_SIZE - 1)));
        
        // now adjust the addresses of the declaration in each CFunction header
        // do not adjust a font who's "address" is zero
        
        // first, CFunctions that were already in the library
        for(; k > 0; k--) {
            if(*CFunHexLibAddr[k]  > FONT_TABLE_SIZE) *CFunHexLibAddr[k] -= ((unsigned int)(ProgFlash + Option.ProgFlashSize) - (unsigned int)TempPtr);
        }
        
        // then, CFunctions that are being added to the library
        for(; i > 0; i--) {
            if(*CFunHexAddr[i]  > FONT_TABLE_SIZE) *CFunHexAddr[i] = (CFunDefAddr[i] - (unsigned int)MemBuff) + (unsigned int)TempPtr;
        }
        
        // write the whole lot into its final location
        FlashWriteInit(TempPtr, 0);                                 // initialise for flash write but do not erase any pages
        for(k = 0; k < m - MemBuff; k++)
            FlashWriteByteErase(MemBuff[k]);                        // write to the flash byte by byte
        FlashWriteClose();                                          // this will flush the buffer
        
        // finally update the amount of flash available for ordinary programs
        Option.ProgFlashSize = TempPtr - ProgFlash;
        cmdline = ""; CurrentLinePtr = NULL;                        // keep the NEW command happy
        cmd_new();                                                  // this will save the option, delete the program and return to the command prompt
    }

     if((p = checkstring(cmdline, "DELETE"))) {
        if(Option.ProgFlashSize == PROG_FLASH_SIZE) return;
        FlashWriteInit(ProgFlash + Option.ProgFlashSize, PROG_FLASH_SIZE - Option.ProgFlashSize);
        FlashWriteClose();
        Option.ProgFlashSize = PROG_FLASH_SIZE;
        SaveOptions();
        return;
     }
    
     if((p = checkstring(cmdline, "LIST"))) {
        if(Option.ProgFlashSize == PROG_FLASH_SIZE) return;
        ListProgram(ProgFlash + Option.ProgFlashSize, false);
        return;
     }
    error("Unknown command");
}



/**********************************************************************************************
   These routines are used to load or save the global Option structure from/to flash.
   These options are stored in the beginning of the flash used to save stored variables.
***********************************************************************************************/


void SaveOptions(void) {
    char buf[FLASH_PAGE_SIZE], *p;
    int i;

    p = (char *)&Option;
    for(i = 0; i < sizeof(struct option_s); i++) if(SavedVarsFlash[i] != *p++) goto skipreturn;
    return;                                                         // exit if the option has already been set (ie, nothing to do)
    skipreturn:

    while(!UARTTransmissionHasCompleted(UART1));                    // wait for the console UART to send whatever is in its buffer
    memcpy(buf, SavedVarsFlash, FLASH_PAGE_SIZE);                   // copy the page to RAM
    memcpy(buf, &Option, sizeof(struct option_s));                  // insert our new data into the RAM copy
    FlashWriteInit(SavedVarsFlash, FLASH_PAGE_SIZE);                // erase the page
    for(i = 0; i < FLASH_PAGE_SIZE; i++) FlashWriteByte(buf[i]);    // write the changed page back to flash
    FlashWriteClose();
}


void LoadOptions(void) {
    memcpy(&Option, SavedVarsFlash, sizeof(struct option_s));
#if defined(MX470)    
#if defined(MZEF)
    Option.DEFAULT_DRIVE = FLASHFS;
    Option.PREV_DRIVE = FLASHFS;
#else
    if(Option.SDCARD[0].CS != 0) {
        Option.DEFAULT_DRIVE = SDFS1;
        Option.PREV_DRIVE = SDFS1;  
    }
    else if(Option.SDCARD[1].CS != 0) {
        Option.DEFAULT_DRIVE = SDFS2;
        Option.PREV_DRIVE = SDFS2;  
    }
    else if(Option.SDCARD[2].CS != 0) {
        Option.DEFAULT_DRIVE = SDFS3;
        Option.PREV_DRIVE = SDFS3;  
    }
    else if(Option.SDCARD[3].CS != 0) {
        Option.DEFAULT_DRIVE = SDFS4;
        Option.PREV_DRIVE = SDFS4;  
    }
    else {
        Option.DEFAULT_DRIVE = NOPRESRDIVE;
        Option.PREV_DRIVE = NOPRESRDIVE;        
    }
#endif
#endif    
}



// erase all flash memory and reset the options to their defaults
// used on initial firmware run
void ResetAllOptions(void) {
    Option.Height = SCREENHEIGHT;                                   // reset the options to their defaults
    Option.Width = SCREENWIDTH;
    Option.PIN = 0;
    Option.Baudrate = CONSOLE_BAUDRATE;
    Option.Autorun = false;
    Option.Listcase = CONFIG_TITLE;
    Option.Tab = 2;
    Option.Invert = false;
    Option.ColourCode = false;
    Option.DISPLAY_TYPE = 0;
    Option.DISPLAY_ORIENTATION = 0;
    Option.TOUCH_XSCALE = 0;
    Option.TOUCH_CS = 0;
    Option.TOUCH_IRQ = 0;
   	Option.LCD_CD = 0;
   	Option.LCD_Reset = 0;
   	Option.LCD_CS = 0;
    Option.DISPLAY_CONSOLE = 0;
    Option.DefaultFont = 0x01;
    Option.DefaultFC = WHITE;
    Option.DefaultBC = BLACK;
    Option.RTC_Clock = Option.RTC_Data = 0;
    Option.DriveASet = 0;
    
#if defined(MX470)
    Option.SerialCon = true;
    Option.KeyboardConfig = NO_KEYBOARD;
#if defined(MZEF)    
    Option.MSDStatus = true;    
#endif
    unsigned char i;
    for(i=0; i<SDCARD_MAX_NUM; i++) {
        Option.SDCARD[i].CS = 0;
        Option.SDCARD[i].CD = 0;
        Option.SDCARD[i].WP = 0;
        Option.SDCARD[i].MUX_ENABLE  = FALSE;
        Option.SDCARD[i].MUXn        = 0;
        Option.SDCARD[i].DRV0        = 0;
        Option.SDCARD[i].DRV1        = 0;
    }
    
#if defined(MZEF)
    Option.DEFAULT_DRIVE = FLASHFS;
    Option.PREV_DRIVE = FLASHFS;
#else
#ifdef ELLO_2M 
    Option.DEFAULT_DRIVE = SDFS1;
    Option.PREV_DRIVE = SDFS1;
#else
    Option.DEFAULT_DRIVE = NOPRESRDIVE;
    Option.PREV_DRIVE = NOPRESRDIVE;    
#endif    
#endif
    Option.DISPLAY_BL = 0;
    Option.TOUCH_Click = 0;
    Option.TOUCH_XZERO = 0; //-999999;
    Option.DefaultBrightness = 100;
    Option.LCD_RD = 0;
    Option.MaxCtrls = 101;                                          // if you change this you must also change OPTION LIST
    #if defined(DEBUG_DISPLAY_7_INCH)
        Option.SDCARD[0].CS = 52;
        Option.DISPLAY_TYPE = SSD1963_7;
        Option.DISPLAY_ORIENTATION = LANDSCAPE;
//        Option.DISPLAY_ORIENTATION = PORTRAIT;
        Option.DISPLAY_BL = 0;
        Option.DISPLAY_CONSOLE = 1;
        Option.KeyboardConfig = 1;
        Option.DefaultFont = 0x11;
        Option.TOUCH_CS = 51;
        Option.TOUCH_IRQ = 33;
        Option.TOUCH_Click = 50;
        Option.TOUCH_XZERO = 110;
        Option.TOUCH_YZERO = 318;
        Option.TOUCH_XSCALE = 0.206877;
        Option.TOUCH_YSCALE = 0.131661;
//        #warning "Set Option.TOUCH_SWAPXY"
        Option.TOUCH_SWAPXY = 1;
        Option.ColourCode = true;
    #elif defined(DEBUG_DISPLAY_5_INCH)  // this is on the Explore 100 board
        Option.SDCARD[0].CS = 47;
        Option.DISPLAY_TYPE = SSD1963_5;
        Option.DISPLAY_ORIENTATION = LANDSCAPE;
        Option.DISPLAY_BL = 48;
        Option.DISPLAY_CONSOLE = 1;
        Option.KeyboardConfig = 1;
        Option.DefaultFont = 0x11;
        Option.TOUCH_CS = 1;
        Option.TOUCH_IRQ = 40;
        Option.TOUCH_Click = 39;
        Option.TOUCH_XZERO = 124;
        Option.TOUCH_YZERO = 3822;
        Option.TOUCH_XSCALE = 0.204082;
        Option.TOUCH_YSCALE = -0.129231;
        Option.TOUCH_SWAPXY = 1;
        Option.ColourCode = true;
    #elif defined(DEBUG_DISPLAY_4_INCH)
        Option.SDCARD[0].CS = 52;
        Option.DISPLAY_TYPE = SSD1963_4;
        Option.DISPLAY_ORIENTATION = LANDSCAPE;
        Option.DISPLAY_BL = 18;
        Option.DISPLAY_CONSOLE = 1;
        Option.KeyboardConfig = 1;
        Option.DefaultFont = 0x01;
        Option.TOUCH_CS = 51;
        Option.TOUCH_IRQ = 33;
        Option.TOUCH_Click = 50;
        Option.TOUCH_XZERO = 0; //-999999;
        Option.TOUCH_YZERO = 3513;
        Option.TOUCH_XSCALE = -8.421429;
        Option.TOUCH_YSCALE = -13.325472;
        #warning "Set Option.TOUCH_SWAPXY"
        Option.TOUCH_SWAPXY = 1;
        Option.ColourCode = true;
    #elif defined(DEBUG_DISPLAY_ILI9341)
        Option.DISPLAY_TYPE = ILI9341;
        Option.DISPLAY_ORIENTATION = LANDSCAPE;
        Option.LCD_CD = 27;
        Option.LCD_Reset = 28;
        Option.LCD_CS = 24;
        Option.TOUCH_CS = 51;
        Option.TOUCH_IRQ = 33;
        Option.TOUCH_XZERO = 636;
        Option.TOUCH_YZERO = 888;
        Option.TOUCH_XSCALE = 11.365386;
        Option.TOUCH_YSCALE = 15.427779;
        #warning "Set Option.TOUCH_SWAPXY"
        Option.TOUCH_SWAPXY = 1;
    #endif
#endif

	
#if defined(DEBUG_DISPLAY_ILI9341)
  	Option.DISPLAY_TYPE = ILI9341;
   	Option.DISPLAY_ORIENTATION = LANDSCAPE;
   	Option.LCD_CD = 2;
   	Option.LCD_Reset = 23;
   	Option.LCD_CS = 6;
   	Option.TOUCH_CS = 7;
   	Option.TOUCH_IRQ = 15;
   	Option.TOUCH_XZERO = 636;
   	Option.TOUCH_YZERO = 888;
   	Option.TOUCH_XSCALE = 11.365386;
//    #warning "Set Option.TOUCH_SWAPXY"
    Option.TOUCH_SWAPXY = 1;
   	Option.TOUCH_YSCALE = 15.427779;
#endif

#if defined(MX170) && (defined(DEBUG_DISPLAY_4_INCH) || defined(DEBUG_DISPLAY_4_INCH) || defined(DEBUG_DISPLAY_7_INCH))
	#error "Display not supported"
#endif

#ifdef ELLO_2M
    
    Option.RTC_Data = 43;
    Option.RTC_Clock = 44;
    
    Option.TOUCH_CS = 23;
    Option.TOUCH_IRQ = 21;
    Option.TOUCH_Click = 48;
    Option.TOUCH_XZERO = 0; //TOUCH_NOT_CALIBRATED;
    
    Option.SDCARD[0].MUX_ENABLE = TRUE;
    Option.SDCARD[0].MUXn = 0;
    Option.SDCARD[0].DRV0 = 51;
    Option.SDCARD[0].DRV1 = 46;
    Option.SDCARD[0].CS = 12;
    #ifndef MZEF
    Option.SDCARD[0].CD = 0;
    #else
    Option.SDCARD[0].CD = 0;  
    #endif    
    Option.SDCARD[0].WP = 0;
    
    Option.SDCARD[1].MUX_ENABLE = TRUE;
    Option.SDCARD[1].MUXn = 1;
    Option.SDCARD[1].DRV0 = 51;
    Option.SDCARD[1].DRV1 = 46;
    Option.SDCARD[1].CS = 12;
    #ifndef MZEF
    Option.SDCARD[1].CD = 0;
    #else
    Option.SDCARD[1].CD = 0;  
    #endif
    Option.SDCARD[1].WP = 0;
    
    Option.SDCARD[2].MUX_ENABLE = TRUE;
    Option.SDCARD[2].MUXn = 2;
    Option.SDCARD[2].DRV0 = 51;
    Option.SDCARD[2].DRV1 = 46;
    Option.SDCARD[2].CS = 12;
    #ifndef MZEF
    Option.SDCARD[2].CD = 0;
    #else
    Option.SDCARD[2].CD = 0;  
    #endif
    Option.SDCARD[2].WP = 0;

    Option.DISPLAY_TYPE = SSD1963_7W;
    Option.DISPLAY_ORIENTATION = LANDSCAPE;
    Option.LCD_RD = 53;
    SetFont((Option.DefaultFont = 0x61));
    Option.DefaultFC = WHITE;
    Option.DefaultBC = BLACK;
    Option.DefaultBrightness = 100;
    Option.DISPLAY_CONSOLE = 1;
    Option.ColourCode = true;
    PromptFont = Option.DefaultFont;
    PromptFC = Option.DefaultFC;
    PromptBC = Option.DefaultBC;

#endif
    while(!UARTTransmissionHasCompleted(UART1));                    // wait for the console UART to send whatever is in its buffer
    ClearSavedVars();                                               // this also writes the option table
}


// erase all flash memory and reset the options to their defaults
// used on initial firmware run
void ResetAllFlash(void) {
    FlashWriteInit(SavedVarsFlash, SAVEDVARS_FLASH_SIZE);           // erase saved vars + options
    Option.ProgFlashSize = PROG_FLASH_SIZE;
    ResetAllOptions();                                              // reset all options
    FlashWriteInit(ProgFlash, PROG_FLASH_SIZE);                     // erase program memory
    FlashWriteByte(0); FlashWriteByte(0);                           // terminate the program in flash
    FlashWriteClose();
}