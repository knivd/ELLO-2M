/***********************************************************************************************************************
MMBasic

timers.h

Include file that contains the globals and defines for memory allocation for MMBasic running on the Maximite.
  
Copyright 2011 - 2017 Geoff Graham.  All Rights Reserved.

This file and modified versions of this file are supplied to specific individuals or organisations under the following 
provisions:

- This file, or any files that comprise the MMBasic source (modified or not), may not be distributed or copied to any other
  person or organisation without written permission.

- Object files (.o and .hex files) generated using this file (modified or not) may not be distributed or copied to any other
  person or organisation without written permission.

- This file is provided in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of 
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

************************************************************************************************************************/



/**********************************************************************************
 the C language function associated with commands, functions or operators should be
 declared here
**********************************************************************************/
#if !defined(INCLUDE_COMMAND_TABLE) && !defined(INCLUDE_TOKEN_TABLE)
// format:
//      void cmd_???(void)
//      void fun_???(void)
//      void op_???(void)

void __attribute__((microinstr)) cmd_memory(void);

#endif




/**********************************************************************************
 All command tokens tokens (eg, PRINT, FOR, etc) should be inserted in this table
**********************************************************************************/
#ifdef INCLUDE_COMMAND_TABLE
// the format is:
//    TEXT      	TYPE                P  FUNCTION TO CALL
// where type is always T_CMD
// and P is the precedence (which is only used for operators and not commands)

	{ "Memory",		T_CMD,				0, cmd_memory	},

#endif


/**********************************************************************************
 All other tokens (keywords, functions, operators) should be inserted in this table
**********************************************************************************/
#ifdef INCLUDE_TOKEN_TABLE
// the format is:
//    TEXT      	TYPE                P  FUNCTION TO CALL
// where type is T_NA, T_FUN, T_FNA or T_OPER argumented by the types T_STR and/or T_NBR
// and P is the precedence (which is only used for operators)

#endif


#if !defined(INCLUDE_COMMAND_TABLE) && !defined(INCLUDE_TOKEN_TABLE)
// General definitions used by other modules

#ifndef MEMORY_HEADER
#define MEMORY_HEADER

extern char *StrTmp[];                                              // used to track temporary string space on the heap
extern int TempMemoryTop;                                           // this is the last index used for allocating temp memory

typedef enum _M_Req {M_PROG, M_VAR} M_Req;

extern void m_alloc(int size);
extern void *GetMemory(size_t msize);
extern void *GetTempMemory(int NbrBytes);
extern void *GetTempStrMemory(void);
extern void ClearTempMemory(void);
extern void ClearSpecificTempMemory(void *addr);
extern inline void TestStackOverflow(void);
extern void FreeMemory(void *addr);
extern void InitHeap(void);
extern char *HeapBottom(void);
extern int FreeSpaceOnHeap(void);

extern unsigned int _stack;
extern unsigned int _splim;
extern unsigned int _heap;
extern unsigned int _min_stack_size;
extern unsigned int _text_begin;


// RAM parameters
// ==============
// The following settings will allow MMBasic to use all the free memory on the PIC32.  If you need some RAM for
// other purposes you can declare the space needed as a static variable -or- allocate space to the heap (which
// will reduce the memory available to MMBasic) -or- change the definition of RAMEND.
// NOTE: MMBasic does not use the heap.  It has its own heap which is allocated out of its own memory space.

// The virtual address that MMBasic can start using memory.  This must be rounded up to PAGESIZE.
// MMBasic uses just over 5K for static variables so, in the simple case, RAMBase could be set to 0xA001800.
// However, the PIC32 C compiler provides us with a convenient marker (see diagram above).
extern void *RAMBase;

// The virtual address that marks the end of the RAM allocated to MMBasic.  This must be rounded up to PAGESIZE.
// This determines maximum amount of RAM that MMBasic can use for program, variables and the heap.
// MMBasic uses just over 5K of RAM for static variables and needs at least 4K for the stack (6K preferably).
// So, using a chip with 32KB, RAMALLOC could be set to RAMBASE + (22 * 1024).
// However, the PIC32 C compiler provides us with a convenient marker (see diagram above).
#define RAMEND          ((unsigned int)&_stack - (unsigned int)&_min_stack_size)

// The total amount of memory (in KB) that MMBasic might use.  This must be a constant (ie, not defined in terms of _splim)
// Used only to declare a static array to track memory use.  It does not consume much RAM so we set it to the largest possible size for the PIC32
#if defined(MX170) || defined(MX470) && !defined(MZEF)
    #define MEMSIZE        126  //MX470
#elif defined(MZEF)
    #define MEMSIZE        500  //MZ2048EF
#endif

// other (minor) memory management parameters
#define PAGESIZE        256                                         // the allocation granuality
#define PAGEBITS        2                                           // nbr of status bits per page of allocated memory, must be a power of 2

#define PUSED           0b01                                        // flag that indicates that the page is in use
#define PLAST           0b10                                        // flag to show that this is the last page in a single allocation

#define PAGESPERWORD    ((sizeof(unsigned int) * 8)/PAGEBITS)
#define MRoundUp(a)     (((a) + (PAGESIZE - 1)) & (~(PAGESIZE - 1)))// round up to the nearest page size


#endif
#endif

