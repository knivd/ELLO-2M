/***********************************************************************************************************************
MMBasic

Draw.c

Does the basic LCD display commands and drawing in MMBasic.

Copyright 2011 - 2017 Geoff Graham.  All Rights Reserved.

This file and modified versions of this file are supplied to specific individuals or organisations under the following
provisions:

- This file, or any files that comprise the MMBasic source (modified or not), may not be distributed or copied to any other
  person or organisation without written permission.

- Object files (.o and .hex files) generated using this file (modified or not) may not be distributed or copied to any other
  person or organisation without written permission.

- This file is provided in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

************************************************************************************************************************/


#include <float.h>

#include "../MMBasic_Includes.h"
#include "../Hardware_Includes.h"


/***************************************************************************/
// define the fonts

#if defined(MX170)
    #include "../Fonts/X_8x13_LE.h"
    #include "../Fonts/ArialNumFontPlus.h"

    unsigned char *FontTable[FONT_TABLE_SIZE] = {   (unsigned char *)X_8x13_LE
                                                };
#elif defined(MX470)

    #include "../Fonts/X_8x13_LE.h"
    #include "../Fonts/Misc_12x20_LE.h"
    #include "../Fonts/Hom_16x24_LE.h"
    #include "../Fonts/Hom_16x24_BLD.h"
    #include "../Fonts/Inconsola.h"
    #include "../Fonts/ArialNumFontPlus.h"
    #include "../Fonts/Full_10x20_8859_15.h"

    unsigned char *FontTable[FONT_TABLE_SIZE] = {   (unsigned char *)X_8x13_LE,
                                                    (unsigned char *)Misc_12x20_LE,
                                                    (unsigned char *)Hom_16x24_LE,
                                                    (unsigned char *)Hom_16x24_BLD,
                                                    (unsigned char *)Inconsola,
                                                    (unsigned char *)ArialNumFontPlus,
                                                    (unsigned char *)Full_10x20_8859_15,
                                                    NULL,
                                                    NULL,
                                                    NULL,
                                                    NULL,
                                                    NULL,
                                                    NULL,
                                                    NULL,
                                                    NULL,
                                                    NULL,
                                                };

#endif
    
/***************************************************************************/

int gui_font;
int gui_fcolour;
int gui_bcolour;

int CurrentX, CurrentY;                                             // the current default position for the next char to be written
int DisplayHRes, DisplayVRes;                                       // the physical characteristics of the display
#ifdef MX470
   char * blitbuffptr[MAXBLITBUF];											//Buffer pointers for the BLIT command
#endif
// the MMBasic programming characteristics of the display
// note that HRes == 0 is an indication that a display is not configured
int HRes = 0, VRes = 0;

// pointers to the drawing primitives
void (*DrawRectangle)(int x1, int y1, int x2, int y2, int c) = (void (*)(int , int , int , int , int ))DisplayNotSet;
void (*DrawBitmap)(int x1, int y1, int width, int height, int scale, int fc, int bc, unsigned char *bitmap) = (void (*)(int , int , int , int , int , int , int , unsigned char *))DisplayNotSet;
void (*ScrollLCD) (int lines) = (void (*)(int ))DisplayNotSet;
void (*DrawBuffer)(int x1, int y1, int x2, int y2, char *c) = (void (*)(int , int , int , int , char * ))DisplayNotSet;
void (*ReadBuffer)(int x1, int y1, int x2, int y2, char *c) = (void (*)(int , int , int , int , char * ))DisplayNotSet;
void DrawTriangle(int x0, int y0, int x1, int y1, int x2, int y2, int c, int fill);



/****************************************************************************************************

 MMBasic commands and functions

****************************************************************************************************/

// these are the GUI commands that are common to the MX170 and MX470 versions
// in the case of the MX170 this function is called directly by MMBasic when the GUI command is used
// in the case of the MX470 it is called by MX470GUI in GUI.c
void cmd_guiMX170(void) {
    char *p;

	if(HRes == 0) error("Display not configured");

    // display a bitmap stored in an integer or string
    if((p = checkstring(cmdline, "BITMAP"))) {
        int x, y, fc, bc, h, w, scale, t, bytes;
        char *s;
        float f;
        long long int i64;

        getargs(&p, 15, ",");
        if(!(argc & 1) || argc < 5) error("Incorrect argument count");

        // set the defaults
        h = 8; w = 8; scale = 1; bytes = 8; fc = gui_fcolour; bc = gui_bcolour;

        x = getinteger(argv[0]);
        y = getinteger(argv[2]);

        // get the type of argument 3 (the bitmap) and its value (integer or string)
        t = T_NOTYPE;
        evaluate(argv[4], &f, &i64, &s, &t, true);
        if(t & T_NBR)
            error("Invalid argument");
        else if(t & T_INT)
            s = (char *)&i64;
        else if(t & T_STR)
            bytes = *s++;

        if(argc > 5 && *argv[6]) w = getint(argv[6], 1, HRes);
        if(argc > 7 && *argv[8]) h = getint(argv[8], 1, VRes);
        if(argc > 9 && *argv[10]) scale = getint(argv[10], 1, 15);
        if(argc > 11 && *argv[12]) fc = getint(argv[12], 0, WHITE);
        if(argc == 15) bc = getint(argv[14], -1, WHITE);
        if(h * w > bytes * 8) error("Not enough data");
        DrawBitmap(x, y, w, h, scale, fc, bc, (unsigned char *)s);
        return;
    }

    if((p = checkstring(cmdline, "CALIBRATE"))) {
        int tlx, tly, trx, try, blx, bly, brx, bry, midy;
        char *s;
        if(Option.TOUCH_CS == 0) error("Touch not configured");
        
        GetCalibration(TARGET_OFFSET, TARGET_OFFSET, &tlx, &tly);
        GetCalibration(HRes - TARGET_OFFSET, TARGET_OFFSET, &trx, &try);
        if(abs(trx - tlx) < CAL_ERROR_MARGIN && abs(tly - try) < CAL_ERROR_MARGIN) error("Touch hardware failure");

        GetCalibration(TARGET_OFFSET, VRes - TARGET_OFFSET, &blx, &bly);
        GetCalibration(HRes - TARGET_OFFSET, VRes - TARGET_OFFSET, &brx, &bry);
        midy = max(max(tly, try), max(bly, bry)) / 2;
        Option.TOUCH_SWAPXY = ((tly < midy && try > midy) || (tly > midy && try < midy));

        if(Option.TOUCH_SWAPXY) {
            swap(tlx, tly);
            swap(trx, try);
            swap(blx, bly);
            swap(brx, bry);
        }

        Option.TOUCH_XSCALE = (float)(HRes - TARGET_OFFSET * 2) / (float)(trx - tlx);
        Option.TOUCH_YSCALE = (float)(VRes - TARGET_OFFSET * 2) / (float)(bly - tly);
        Option.TOUCH_XZERO = ((float)tlx - ((float)TARGET_OFFSET / Option.TOUCH_XSCALE));
        Option.TOUCH_YZERO = ((float)tly - ((float)TARGET_OFFSET / Option.TOUCH_YSCALE));
        SaveOptions();
        brx = (HRes - TARGET_OFFSET) - ((brx - Option.TOUCH_XZERO) * Option.TOUCH_XSCALE);
        bry = (VRes - TARGET_OFFSET) - ((bry - Option.TOUCH_YZERO)*Option.TOUCH_YSCALE);
        if(abs(brx) > CAL_ERROR_MARGIN || abs(bry) > CAL_ERROR_MARGIN) {
            s = "Warning: Inaccurate calibration\r\n";
        } else
            s = "Done. No errors\r\n";
#if defined(MX470)
        CurrentX = CurrentY = 0;
        MMPrintString(s);
        strcpy(inpbuf, "Deviation X = "); IntToStr(inpbuf + strlen(inpbuf), brx, 10);
        strcat(inpbuf, ", Y = "); IntToStr(inpbuf + strlen(inpbuf), bry, 10); strcat(inpbuf, " (pixels)\r\n");
        MMPrintString(inpbuf);
        if(!Option.DISPLAY_CONSOLE) {
            GUIPrintString(0, 0, 0x01, JUSTIFY_LEFT | JUSTIFY_TOP, WHITE, BLACK, s);
            GUIPrintString(0, 26, 0x01, JUSTIFY_LEFT | JUSTIFY_TOP, WHITE, BLACK, inpbuf);
        }
#else
        MMPrintString(s);
#endif 

#if defined(DEBUGMODE)
    #if !defined(MX470)
        dp("X ERROR = %d, Y ERROR = %d (pixels)", brx, bry);
    #endif
        dp("SWAP XY = %d", Option.TOUCH_SWAPXY);
        dp("X ZERO = %d, Y ZERO = %d", Option.TOUCH_XZERO, Option.TOUCH_YZERO);
        dp("X SCALE = %f, Y SCALE = %f", (double)Option.TOUCH_XSCALE, (double)Option.TOUCH_YSCALE);
#endif
        return;
    }

    if((p = checkstring(cmdline, "TEST"))) {
        if((checkstring(p, "LCDPANEL"))) {
            int t;
            t = ((HRes > VRes) ? HRes : VRes) / 7;
            while(getConsole() < '\r') {
                DrawCircle(rand() % HRes, rand() % VRes, (rand() % t) + t/5, 1, 1, rgb((rand() % 8)*256/8, (rand() % 8)*256/8, (rand() % 8)*256/8), 1);
            }
            ClearScreen(gui_bcolour);
            return;
        }
        if((checkstring(p, "TOUCH"))) {
            int x, y;
            ClearScreen(gui_bcolour);
            while(getConsole() < '\r') {
                x = GetTouch(GET_X_AXIS);
                y = GetTouch(GET_Y_AXIS);
                if(x != TOUCH_ERROR && y != TOUCH_ERROR) DrawBox(x - 1, y - 1, x + 1, y + 1, 0, WHITE, WHITE);
            }
            ClearScreen(gui_bcolour);
            return;
        }
    }

    
    if((p = checkstring(cmdline, "RESET"))) {
        if((checkstring(p, "LCDPANEL"))) {
            InitDisplaySPI(true);
            #if defined(MX470)
                if(Option.DISPLAY_TYPE >= SSD1963_4 && Option.DISPLAY_TYPE <= SSD_PANEL) InitSSD1963();
            #endif
            if(Option.TOUCH_CS) {
                GetTouchValue(CMD_PENIRQ_ON);                                      // send the controller the command to turn on PenIRQ
                GetTouchAxis(CMD_MEASURE_X);
            }
            return;
        }
    }
    
    
    error("Invalid command");
}



void cmd_text(void) {
    int x, y, justify, font, scale, fc, bc;
    char *s, *p;

    getargs(&cmdline, 15, ",");                                     // this is a macro and must be the first executable stmt
    if(!(argc & 1) || argc < 5) error("Incorrect argument count");
    x = getinteger(argv[0]);
    y = getinteger(argv[2]);
    s = getCstring(argv[4]);
    justify = 0;
    if(argc > 5) {
        for(p = argv[6]; *p; p++) {
            switch(toupper(*p)) {
                case 'L':   justify |= JUSTIFY_LEFT; break;
                case 'C':   justify |= JUSTIFY_CENTER; break;
                case 'R':   justify |= JUSTIFY_RIGHT; break;
                case 'T':   justify |= JUSTIFY_TOP; break;
                case 'M':   justify |= JUSTIFY_MIDDLE; break;
                case 'B':   justify |= JUSTIFY_BOTTOM; break;
                default:    error("Invalid justification");
            }
        }
    }

    font = (gui_font >> 4) + 1; scale = (gui_font & 0b1111); fc = gui_fcolour; bc = gui_bcolour;        // the defaults
	if(argc > 7 && *argv[8]) font = getint(argv[8], 1, FONT_TABLE_SIZE);
    if(FontTable[font - 1] == NULL) error("Invalid font #%", font);
	if(argc > 9 && *argv[10]) scale = getint(argv[10], 1, 15);
	if(argc > 11 && *argv[12]) fc = getint(argv[12], 0, WHITE);
	if(argc == 15) bc = getint(argv[14], -1, WHITE);
    GUIPrintString(x, y, ((font - 1) << 4) | scale, justify, fc, bc, s);
}



void cmd_pixel(void) {
    int c;
    getargs(&cmdline, 5, ",");
    if(!(argc == 3 || argc == 5)) error("Incorrect argument count");
    if(argc == 5)
        c = getint(argv[4], 0, WHITE);
    else
        c = gui_fcolour;
    DrawPixel(getinteger(argv[0]), getinteger(argv[2]), c);
}


void cmd_circle(void) {
    int x, y, r, w, c, f;
    float a;
    
    getargs(&cmdline, 13, ",");
    if(!(argc & 1) || argc < 5) error("Incorrect argument count");

    w = 1; c = gui_fcolour; f = -1; a = 1;                          // setup the defaults
    x = getinteger(argv[0]);
    y = getinteger(argv[2]);
    r = getinteger(argv[4]);
    if(argc > 5 && *argv[6]) w = getint(argv[6], 0, 100);
    if(argc > 7 && *argv[8]) a = getnumber(argv[8]);
    if(argc > 9 && *argv[10]) c = getint(argv[10], 0, WHITE);
    if(argc > 11) f = getint(argv[12], -1, WHITE);
    DrawCircle(x, y, r, w, c, f, a);
}


void cmd_line(void) {
    int x1, y1, x2, y2, w, c;

    getargs(&cmdline, 11, ",");
    if(!(argc & 1) || argc < 7) error("Incorrect argument count");

    c = gui_fcolour;  w = 1;                                        // setup the defaults
    x1 = getinteger(argv[0]);
    y1 = getinteger(argv[2]);
    x2 = getinteger(argv[4]);
    y2 = getinteger(argv[6]);
    if(argc > 7 && *argv[8]) w = getint(argv[8], 1, 100);
    if(argc == 11) c = getint(argv[10], 0, WHITE);
    DrawLine(x1, y1, x2, y2, w, c);
}


void cmd_box(void) {
    int x1, y1, w, h, c, width, f;

    getargs(&cmdline, 13, ",");
    if(!(argc & 1) || argc < 7) error("Incorrect argument count");

    c = gui_fcolour; width = 1; f = -1;                                 // setup the defaults
    x1 = getinteger(argv[0]);
    y1 = getinteger(argv[2]);
    w = getinteger(argv[4]) - 1;
    h = getinteger(argv[6]) - 1;
    if(argc > 7 && *argv[8]) width = getint(argv[8], 0, 100);
    if(argc > 9 && *argv[10]) c = getint(argv[10], 0, WHITE);
    if(argc == 13) f = getint(argv[12], -1, WHITE);
    if(w >= 0 && h >= 0) DrawBox(x1, y1, x1 + w, y1 + h, width, c, f);
}



void cmd_rbox(void) {
    int x1, y1, w, h, r, c, f;

    getargs(&cmdline, 13, ",");
    if(!(argc & 1) || argc < 7) error("Incorrect argument count");

    c = gui_fcolour; w = 1; f = -1; r = 10;                         // setup the defaults
    x1 = getinteger(argv[0]);
    y1 = getinteger(argv[2]);
    w = getinteger(argv[4]) - 1;
    h = getinteger(argv[6]) - 1;
    if(argc > 7 && *argv[8]) r = getint(argv[8], 0, 100);
    if(argc > 9 && *argv[10]) c = getint(argv[10], 0, WHITE);
    if(argc == 13) f = getint(argv[12], -1, WHITE);
    if(w >= 0 && h >= 0) DrawRBox(x1, y1, x1 + w, y1 + h, r, c, f);
}


#if defined(MX470)
// these three functions were written by Peter Mather (matherp on the Back Shed forum)

// read the contents of a PIXEL out of screen memory
void fun_pixel(void) {
    if((void *)ReadBuffer == (void *)DisplayNotSet) error("Invalid on this display");
    int p;
    int x, y;
	getargs(&ep, 3, ",");
	if(argc != 3) error("Incorrect argument count");
    x = getinteger(argv[0]);
    y = getinteger(argv[2]);
    ReadBuffer(x, y, x, y, (char *)&p);
    iret = p & 0xFFFFFF;
    targ = T_INT;
}

void cmd_triangle(void) {
    int x0, y0, x1, y1, x2, y2, c, f;

    getargs(&cmdline, 15, ",");
    if(!(argc & 1) || argc < 11) error("Incorrect argument count");

    c = gui_fcolour; f = -1;
    x0 = getinteger(argv[0]);
    y0 = getinteger(argv[2]);
    x1 = getinteger(argv[4]);
    y1 = getinteger(argv[6]);
    x2 = getinteger(argv[8]);
    y2 = getinteger(argv[10]);
    if(argc >= 13 && *argv[12]) c = getint(argv[12], BLACK, WHITE);
    if(argc == 15) f = getint(argv[14], -1, WHITE);
    DrawTriangle(x0, y0, x1, y1, x2, y2, c, f);
}

void cmd_blit(void) {
    int x1, y1, x2, y2, w, h, bnbr;
    char *buff = NULL;
    char *p;
    if((void *)ReadBuffer == (void *)DisplayNotSet) error("Invalid on this display");
    if((p = checkstring(cmdline, "READ"))) {
        getargs(&p, 9, ",");
        if(argc !=9) error("Invalid syntax");
        if(*argv[0] == '#') argv[0]++;						        // check if the first arg is prefixed with a #
        bnbr = getint(argv[0], 1, MAXBLITBUF) - 1;				    // get the buffer number
        x1 = getinteger(argv[2]);
        y1 = getinteger(argv[4]);
        w = getinteger(argv[6]);
        h = getinteger(argv[8]);
        if(w < 1 || h < 1) return;
        if(x1 < 0) { x2 -= x1; w += x1; x1 = 0; }
        if(y1 < 0) { y2 -= y1; h += y1; y1 = 0; }
        if(x1 + w > HRes) w = HRes - x1;
        if(y1 + h > VRes) h = VRes - y1;
        if(w < 1 || h < 1 || x1 < 0 || x1 + w > HRes || y1 < 0 || y1 + h > VRes ) return;
        if(blitbuffptr[bnbr] == NULL){
            blitbuffptr[bnbr] = GetMemory(w * h * 3);
            ReadBuffer(x1, y1, x1 + w - 1, y1 + h - 1, blitbuffptr[bnbr]);
        } else error("Buffer in use");
    } else if((p = checkstring(cmdline, "WRITE"))) {
        getargs(&p, 9, ",");
        if(argc != 9) error("Invalid syntax");
        if(*argv[0] == '#') argv[0]++;						        // check if the first arg is prefixed with a #
        bnbr = getint(argv[0], 1, MAXBLITBUF) - 1;				    // get the buffer number
        x1 = getinteger(argv[2]);
        y1 = getinteger(argv[4]);
        w = getinteger(argv[6]);
        h = getinteger(argv[8]);
        if(w < 1 || h < 1) return;
        if(x1 < 0) { x2 -= x1; w += x1; x1 = 0; }
        if(y1 < 0) { y2 -= y1; h += y1; y1 = 0; }
        if(x1 + w > HRes) w = HRes - x1;
        if(y1 + h > VRes) h = VRes - y1;
        if(w < 1 || h < 1 || x1 < 0 || x1 + w > HRes || y1 < 0 || y1 + h > VRes ) return;
        if(blitbuffptr[bnbr] != NULL){
            DrawBuffer(x1, y1, x1 + w - 1, y1 + h - 1, blitbuffptr[bnbr]);
        } else error("Buffer not in use");
    } else if((p = checkstring(cmdline, "CLOSE"))) {
        getargs(&p, 1, ",");
        if(*argv[0] == '#') argv[0]++;						        // check if the first arg is prefixed with a #
        bnbr = getint(argv[0], 1, MAXBLITBUF) - 1;				    // get the buffer number
        if(blitbuffptr[bnbr] != NULL){
            FreeMemory(blitbuffptr[bnbr]);
            blitbuffptr[bnbr] = NULL;
        } else error("Buffer not in use");
        // get the number
     } else {
        int memory, max_x;
        getargs(&cmdline, 11, ",");
        if(argc != 11) error("Invalid syntax");
        x1 = getinteger(argv[0]);
        y1 = getinteger(argv[2]);
        x2 = getinteger(argv[4]);
        y2 = getinteger(argv[6]);
        w = getinteger(argv[8]);
        h = getinteger(argv[10]);
        memory = FreeSpaceOnHeap(); 
        if(w < 1 || h < 1) return;
        if(x1 < 0) { x2 -= x1; w += x1; x1 = 0; }
        if(x2 < 0) { x1 -= x2; w += x2; x2 = 0; }
        if(y1 < 0) { y2 -= y1; h += y1; y1 = 0; }
        if(y2 < 0) { y1 -= y2; h += y2; y2 = 0; }
        if(x1 + w > HRes) w = HRes - x1;
        if(x2 + w > HRes) w = HRes - x2;
        if(y1 + h > VRes) h = VRes - y1;
        if(y2 + h > VRes) h = VRes - y2;
        if(w < 1 || h < 1 || x1 < 0 || x1 + w > HRes || x2 < 0 || x2 + w > HRes || y1 < 0 || y1 + h > VRes || y2 < 0 || y2 + h > VRes) return;
        if((w * h * 3) > memory - PAGESIZE) {                       //need to use alternative copy
            if(x1 >= x2) {
                max_x = (memory - PAGESIZE) / h / 3;
                buff = GetMemory(max_x * h * 3);
                while(w > max_x){
                    ReadBuffer(x1, y1, x1 + max_x - 1, y1 + h - 1, buff);
                    DrawBuffer(x2, y2, x2 + max_x - 1, y2 + h - 1, buff);
                    x1 += max_x;
                    x2 += max_x;
                    w -= max_x;
                }
                ReadBuffer(x1, y1, x1 + w - 1, y1 + h - 1, buff);
                DrawBuffer(x2, y2, x2 + w - 1, y2 + h - 1, buff);
                FreeMemory(buff);
                return;
            }
            if(x1 < x2) {
                int start_x1, start_x2;
                max_x = (memory - PAGESIZE) / h / 3;
                buff = GetMemory(max_x * h * 3);
                start_x1 = x1 + w - 1  -max_x;
                start_x2 = x2 + w - 1 - max_x;
                while(w > max_x){
                    ReadBuffer(start_x1, y1, start_x1 + max_x - 1, y1 + h - 1, buff);
                    DrawBuffer(start_x2, y2, start_x2 + max_x - 1, y2 + h - 1, buff);
                    w -= max_x;
                    start_x1 -= max_x;
                    start_x2 -= max_x;
                }
                ReadBuffer(x1, y1, x1 + w - 1, y1 + h - 1, buff);
                DrawBuffer(x2, y2, x2 + w - 1, y2 + h - 1, buff);
                FreeMemory(buff);
                return;

            }
         } else { //simple copy
            buff = GetMemory(w * h * 3);
            ReadBuffer(x1, y1, x1 + w - 1, y1 + h - 1, buff);
            DrawBuffer(x2, y2, x2 + w - 1, y2 + h - 1, buff);
            FreeMemory(buff);
        }
    }
}
#endif


void cmd_cls(void) {
#if defined(MX470)
    HideAllControls();
#endif
    skipspace(cmdline);
    if(!(*cmdline == 0 || *cmdline == '\''))
        ClearScreen(getint(cmdline, 0, WHITE));
    else
        ClearScreen(gui_bcolour);
    CurrentX = CurrentY = 0;
}



void fun_rgb(void) {
    getargs(&ep, 5, ",");
    if(argc == 5)
        iret = rgb(getint(argv[0], 0, 255), getint(argv[2], 0, 255), getint(argv[4], 0, 255));
    else if(argc == 1) {
            if(checkstring(argv[0], "WHITE"))        iret = WHITE;
            else if(checkstring(argv[0], "BLACK"))   iret = BLACK;
            else if(checkstring(argv[0], "BLUE"))    iret = BLUE;
            else if(checkstring(argv[0], "GREEN"))   iret = GREEN;
            else if(checkstring(argv[0], "CYAN"))    iret = CYAN;
            else if(checkstring(argv[0], "RED"))     iret = RED;
            else if(checkstring(argv[0], "MAGENTA")) iret = MAGENTA;
            else if(checkstring(argv[0], "YELLOW"))  iret = YELLOW;
            else if(checkstring(argv[0], "BROWN"))   iret = BROWN;
            else if(checkstring(argv[0], "GRAY"))    iret = GRAY;
            else error("Invalid colour: $", argv[0]);
    } else
        error("Invalid syntax");
    targ = T_INT;
}



void fun_mmhres(void) {
    iret = HRes;
    targ = T_INT;
}



void fun_mmvres(void) {
    iret = VRes;
    targ = T_INT;
}



void cmd_font(void) {
    getargs(&cmdline, 3, ",");
    if(argc < 1) error("Incorrect argument count");
    if(*argv[0] == '#') ++argv[0];
    if(argc == 3)
            SetFont(((getint(argv[0], 1, FONT_TABLE_SIZE) - 1) << 4) | getint(argv[2], 1, 15));
        else
            SetFont(((getint(argv[0], 1, FONT_TABLE_SIZE) - 1) << 4) | 1);
#if defined(MX470)
    if(Option.DISPLAY_CONSOLE && !CurrentLinePtr) {                 // if we are at the command prompt on the LCD
        PromptFont = gui_font;
        if(CurrentY + gui_font_height >= VRes) {             
            ScrollLCD(CurrentY + gui_font_height - VRes);           // scroll up if the font change split the line over the bottom
            CurrentY -= (CurrentY + gui_font_height - VRes);
        }
    }
#endif
}



void cmd_colour(void) {
    getargs(&cmdline, 3, ",");
    if(argc < 1) error("Incorrect argument count");
    gui_fcolour = getint(argv[0], 0, WHITE);
    if(argc == 3)
        gui_bcolour = getint(argv[2], 0, WHITE);
    
#if defined(MX470)
    last_fcolour = gui_fcolour;
    last_bcolour = gui_bcolour;
    if(!CurrentLinePtr) {
        PromptFC = gui_fcolour;
        PromptBC = gui_bcolour;
    }
#endif
}


void fun_mmcharwidth(void) {
    if(HRes == 0) error("Display not configured");
    iret = FontTable[gui_font >> 4][0] * (gui_font & 0b1111);
    targ = T_INT;
}


void fun_mmcharheight(void) {
    if(HRes == 0) error("Display not configured");
    iret = FontTable[gui_font >> 4][1] * (gui_font & 0b1111);
    targ = T_INT;
}






/****************************************************************************************************

 General purpose drawing routines

****************************************************************************************************/


void DrawPixel(int x, int y, int c) {
    DrawRectangle(x, y, x, y, c);
}


void ClearScreen(int c) {
    DrawRectangle(0, 0, HRes, VRes, c);
}


/**************************************************************************************************
Draw a line on a the video output
	x1, y1 - the start coordinate
	x2, y2 - the end coordinate
    w - the width of the line (ignored for diagional lines)
	c - the colour to use
***************************************************************************************************/
#define abs( a)     (((a)> 0) ? (a) : -(a))

void DrawLine(int x1, int y1, int x2, int y2, int w, int c) {
    int  dx, dy, sx, sy, err, e2;

    if(y1 == y2) {
        DrawRectangle(x1, y1, x2, y2 + w - 1, c);                   // horiz line
        return;
    }
    if(x1 == x2) {
        DrawRectangle(x1, y1, x2 + w - 1, y2, c);                   // vert line
        return;
    }

    dx = abs(x2 - x1); sx = x1 < x2 ? 1 : -1;
    dy = -abs(y2 - y1); sy = y1 < y2 ? 1 : -1;
    err = dx + dy;
    while(1) {
        DrawPixel(x1, y1, c);
        e2 = 2 * err;
        if (e2 >= dy) {
            if (x1 == x2) break;
            err += dy; x1 += sx;
        }
        if (e2 <= dx) {
            if (y1 == y2) break;
            err += dx; y1 += sy;
        }
    }
}



/**********************************************************************************************
Draw a box
     x1, y1 - the start coordinate
     x2, y2 - the end coordinate
     w      - the width of the sides of the box (can be zero)
     c      - the colour to use for sides of the box
     fill   - the colour to fill the box (-1 for no fill)
***********************************************************************************************/
void DrawBox(int x1, int y1, int x2, int y2, int w, int c, int fill) {
    int t;

    // make sure the coordinates are in the right sequence
    if(x2 <= x1) { t = x1; x1 = x2; x2 = t; }
    if(y2 <= y1) { t = y1; y1 = y2; y2 = t; }
    if(w > x2 - x1) w = x2 - x1;
    if(w > y2 - y1) w = y2 - y1;

    if(w > 0) {
        w--;
        DrawRectangle(x1, y1, x2, y1 + w, c);                       // Draw the top horiz line
        DrawRectangle(x1, y2 - w, x2, y2, c);                       // Draw the bottom horiz line
        DrawRectangle(x1, y1, x1 + w, y2, c);                       // Draw the left vert line
        DrawRectangle(x2 - w, y1, x2, y2, c);                       // Draw the right vert line
        w++;
    }

    if(fill >= 0)
        DrawRectangle(x1 + w, y1 + w, x2 - w, y2 - w, fill);
}



/**********************************************************************************************
Draw a box with rounded corners
     x1, y1 - the start coordinate
     x2, y2 - the end coordinate
     radius - the radius (in pixels) of the arc forming the corners
     c      - the colour to use for sides
     fill   - the colour to fill the box (-1 for no fill)
***********************************************************************************************/
void DrawRBox(int x1, int y1, int x2, int y2, int radius, int c, int fill) {
    int f, ddF_x, ddF_y, xx, yy;

    f = 1 - radius;
    ddF_x = 1;
    ddF_y = -2 * radius;
    xx = 0;
    yy = radius;
   
    while(xx < yy) {
        if(f >= 0) {
            yy-=1;
            ddF_y += 2;
            f += ddF_y;
        }        
        xx+=1;
        ddF_x += 2;
        f += ddF_x  ;
        DrawPixel(x2 + xx - radius, y2 + yy - radius, c);              // Bottom Right Corner
        DrawPixel(x2 + yy - radius, y2 + xx - radius, c);              // ^^^
        DrawPixel(x1 - xx + radius, y2 + yy - radius, c);              // Bottom Left Corner
        DrawPixel(x1 - yy + radius, y2 + xx - radius, c);              // ^^^

        DrawPixel(x2 + xx - radius, y1 - yy + radius, c);              // Top Right Corner
        DrawPixel(x2 + yy - radius, y1 - xx + radius, c);              // ^^^
        DrawPixel(x1 - xx + radius, y1 - yy + radius, c);              // Top Left Corner
        DrawPixel(x1 - yy + radius, y1 - xx + radius, c);              // ^^^
        if(fill >= 0) {
            DrawLine(x2 + xx - radius - 1, y2 + yy - radius, x1 - xx + radius + 1, y2 + yy - radius, 1, fill);
            DrawLine(x2 + yy - radius - 1, y2 + xx - radius, x1 - yy + radius + 1, y2 + xx - radius, 1, fill);
            DrawLine(x2 + xx - radius - 1, y1 - yy + radius, x1 - xx + radius + 1, y1 - yy + radius, 1, fill);
            DrawLine(x2 + yy - radius - 1, y1 - xx + radius, x1 - yy + radius + 1, y1 - xx + radius, 1, fill);
        }
    }
    if(fill >= 0) DrawRectangle(x1 + 1, y1 + radius, x2 - 1, y2 - radius, fill);
    DrawRectangle(x1 + radius - 1, y1, x2 - radius + 1, y1, c);         // top side
    DrawRectangle(x1 + radius - 1, y2,  x2 - radius + 1, y2, c);        // botom side
    DrawRectangle(x1, y1 + radius, x1, y2 - radius, c);                 // left side
    DrawRectangle(x2, y1 + radius, x2, y2 - radius, c);                 // right side

}




/***********************************************************************************************
Draw a circle on the video output
	x, y - the center of the circle
	radius - the radius of the circle
    w - width of the line drawing the circle
	c - the colour to use for the circle
	fill - the colour to use for the fill or -1 if no fill
	aspect - the ration of the x and y axis (a float).  1.0 gives a prefect circle
***********************************************************************************************/
void DrawCircle(int x, int y, int radius, int w, int c, int fill, float aspect) {
   int a, b, P;
   int A, B;
   int asp;

   while(w >= 0 && radius > 0) {
       a = 0;
       b = radius;
       P = 1 - radius;
       asp = aspect * (float)(1 << 10);

       do {
         A = (a * asp) >> 10;
         B = (b * asp) >> 10;
         if(w) {
             DrawPixel(A+x, b+y, c);
             DrawPixel(B+x, a+y, c);
             DrawPixel(x-A, b+y, c);
             DrawPixel(x-B, a+y, c);
             DrawPixel(B+x, y-a, c);
             DrawPixel(A+x, y-b, c);
             DrawPixel(x-A, y-b, c);
             DrawPixel(x-B, y-a, c);
         }
         if(fill >= 0 && w == 0) {
             DrawRectangle(x-A, y+b, x+A, y+b, fill);
             DrawRectangle(x-A, y-b, x+A, y-b, fill);
             DrawRectangle(x-B, y+a, x+B, y+a, fill);
             DrawRectangle(x-B, y-a, x+B, y-a, fill);
         }
          if(P < 0)
             P+= 3 + 2*a++;
          else
             P+= 5 + 2*(a++ - b--);

        } while(a <= b);
        w--;
        radius--;
   }
}


#if defined(MX470)
/**********************************************************************************************
Draw a triangle
    Thanks to Peter Mather (matherp on the Back Shed forum)
     x0, y0 - the first corner
     x1, y1 - the second corner
     x2, y2 - the third corner
     c      - the colour to use for sides of the triangle
     fill   - the colour to fill the triangle (-1 for no fill)
***********************************************************************************************/
void DrawTriangle(int x0, int y0, int x1, int y1, int x2, int y2, int c, int fill) {

    if(fill == -1){
        // draw only the outline
        DrawLine(x0, y0, x1, y1, 1, c);
        DrawLine(x1, y1, x2, y2, 1, c);
        DrawLine(x2, y2, x0, y0, 1, c);
    } else {
        //we are drawing a filled triangle which may also have an outline
        long a, b, y, last;
        long  dx01,  dy01,  dx02,  dy02, dx12,  dy12,  sa, sb;

        if (y0 > y1) {
            swap(y0, y1);
            swap(x0, x1);
        }
        if (y1 > y2) {
            swap(y2, y1);
            swap(x2, x1);
        }
        if (y0 > y1) {
            swap(y0, y1);
            swap(x0, x1);
        }

        // Handle awkward all-on-same-line case as its own thing
        if(y0 == y2) {
            a = x0;
            b = x0;
            if(x1 < a) {
                a = x1;
            } else {
            if(x1 > b) b = x1;
            }
            if(x2 < a) {
                a = x2;
            } else {
                if(x2 > b)  b = x2;
            }
            DrawRectangle(a, y0, a, b-a+y0, fill);
        } else {
            dx01 = x1 - x0;  dy01 = y1 - y0;  dx02 = x2 - x0;
            dy02 = y2 - y0; dx12 = x2 - x1;  dy12 = y2 - y1;
            sa = 0; sb = 0;
            if(y1 == y2) {
                last = y1;                                          //Include y1 scanline
            } else {
                last = y1 - 1;                                      // Skip it
            }
            for (y = y0; y <= last; y++){
                a = x0 + sa / dy01;
                b = x0 + sb / dy02;
                sa = sa + dx01;
                sb = sb + dx02;
                a = x0 + (x1 - x0) * (y - y0) / (y1 - y0);
                b = x0 + (x2 - x0) * (y - y0) / (y2 - y0);
                if(a > b)swap(a, b);
                DrawRectangle(a, y, b, y, fill);
            }
            sa = dx12 * (y - y1);
            sb = dx02 * ( y- y0);
            while (y <= y2){
                a = x1 + sa / dy12;
                b = x0 + sb / dy02;
                sa = sa + dx12;
                sb = sb + dx02;
                a = x1 + (x2 - x1) * (y - y1) / (y2 - y1);
                b = x0 + (x2 - x0) * (y - y0) / (y2 - y0);
                if(a > b) swap(a, b);
                DrawRectangle(a, y, b, y, fill);
                y = y + 1;
            }
            // we also need an outline but we do this last to overwrite the edge of the fill area
            DrawLine(x0, y0, x1, y1, 1, c);
            DrawLine(x1, y1, x2, y2, 1, c);
            DrawLine(x2, y2, x0, y0, 1, c);
        }
    }
}
#endif



/******************************************************************************************
 Print a char on the LCD display
 Any characters not in the font will print as a space.
 The char is printed at the current location defined by CurrentX and CurrentY
*****************************************************************************************/
void GUIPrintChar(int fnt, int fc, int bc, char c) {
    unsigned char *p, *fp;
    int scale = fnt & 0b1111, height;
    fp = (unsigned char *)FontTable[fnt >> 4];
    height = fp[1];

#if defined(MX470)
    // to get the +, - and = chars for font 6 we fudge them by scaling up font 1
    if((fnt & 0xf0) == 0x50 && (c == '-' || c == '+' || c == '=')) {
        fp = (unsigned char *)FontTable[0];
        scale = scale * 4;
    }
#endif
    if(c >= fp[2] && c < fp[2] + fp[3]) {
        p = fp + 4 + (int)(((c - fp[2]) * fp[1] * fp[0]) / 8);
        DrawBitmap(CurrentX, CurrentY, fp[0], fp[1], scale, fc, bc, p);
    } else {
        DrawRectangle(CurrentX, CurrentY, CurrentX + (fp[0] * scale), CurrentY + (fp[1] * scale), bc);
    }

#if defined(MX470)
    // to get the . and degree symbols for font 6 we draw a small circle
    if((fnt & 0xf0) == 0x50) {
        if(c == '.') DrawCircle(CurrentX + (fp[0] * scale)/2, CurrentY + (fp[1] * scale) - 7 * scale, 4 * scale, 0, fc, fc, 1.0);
        if(c == 0x60) DrawCircle(CurrentX + (fp[0] * scale)/2, CurrentY + 9 * scale, 6 * scale, 2 * scale, fc, -1, 1.0);
    }
#endif

    CurrentX += fp[0] * scale;
}


/******************************************************************************************
 Print a string on the LCD display
 The string must be a C string (not an MMBasic string)
 Any characters not in the font will print as a space.
*****************************************************************************************/
void GUIPrintString(int x, int y, int fnt, int justify, int fc, int bc, char *str) {
    CurrentX = x;  CurrentY = y;
    if(justify & JUSTIFY_CENTER) CurrentX -= (strlen(str) * GetFontWidth(fnt)) / 2;
    if(justify & JUSTIFY_RIGHT)  CurrentX -= (strlen(str) * GetFontWidth(fnt));
    if(justify & JUSTIFY_MIDDLE) CurrentY -= GetFontHeight(fnt) / 2;
    if(justify & JUSTIFY_BOTTOM) CurrentY -= GetFontHeight(fnt);
    while(*str) GUIPrintChar(fnt, fc, bc, *str++);
}



/****************************************************************************************************

 General purpose routines

****************************************************************************************************/



int rgb(int r, int g, int b) {
    return RGB(r, g, b);
}


inline int GetFontWidth(int fnt) {
    return FontTable[fnt >> 4][0] * (fnt & 0b1111);
}


inline int GetFontHeight(int fnt) {
    return FontTable[fnt >> 4][1] * (fnt & 0b1111);
}


void SetFont(int fnt) {
    if(FontTable[fnt >> 4] == NULL) error("Invalid font number #%", (fnt >> 4)+1);
#if defined(MX470)
    gui_font_width = FontTable[fnt >> 4][0] * (fnt & 0b1111);
    gui_font_height = FontTable[fnt >> 4][1] * (fnt & 0b1111);
    if(Option.DISPLAY_CONSOLE) {
        Option.Height = VRes/gui_font_height;
        Option.Width = HRes/gui_font_width;
    }
#endif
    gui_font = fnt;
}


void ResetDisplay(void) {
    if(!Option.DISPLAY_CONSOLE) {
        SetFont(Option.DefaultFont);
        gui_fcolour = Option.DefaultFC;
        gui_bcolour = Option.DefaultBC;
    }
#if defined(MX470)
    ResetGUI();
#endif
}