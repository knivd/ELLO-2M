/***********************************************************************************************************************
MMBasic

Touch.c

Does all the touch screen related I/O in MMBasic.

Copyright 2011 - 2017 Geoff Graham.  All Rights Reserved.

This file and modified versions of this file are supplied to specific individuals or organisations under the following
provisions:

- This file, or any files that comprise the MMBasic source (modified or not), may not be distributed or copied to any other
  person or organisation without written permission.

- Object files (.o and .hex files) generated using this file (modified or not) may not be distributed or copied to any other
  person or organisation without written permission.

- This file is provided in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

************************************************************************************************************************/



#include "../MMBasic_Includes.h"
#include "../Hardware_Includes.h"

#if defined(MX470)
    int GetTouchAxis2046(int cmd);
    int (*GetTouchAxis)(int a) = (int (*)(int ))GetTouchAxis2046;
#endif
int GetTouchValue(int cmd);
void TDelay(void);

// these are defined so that the state of the touch PEN IRQ can be determined with the minimum of CPU cycles
volatile unsigned int *TouchIrqPortAddr = NULL;
int TouchIrqPortBit;

#define TOUCH_SPI_SPEED     200000                                  // we run at 200KHz to minimise noise


////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// configure the touch parameters (chip select pin and the IRQ pin)
// this is called by the OPTION TOUCH command
void __attribute__((microinstr)) ConfigTouch(char *p) {
    getargs(&p, 5, ",");
    if(!(argc == 3 || argc == 5)) error("Incorrect argument count");

    CheckPin(getinteger(argv[0]), CP_IGNORE_INUSE); // | CP_IGNORE_BOOTRES | CP_IGNORE_RESERVED);
    CheckPin(getinteger(argv[2]), CP_IGNORE_INUSE); // | CP_IGNORE_BOOTRES | CP_IGNORE_RESERVED);
    
#if defined(MX470)
    if(argc == 5) {
        CheckPin(getinteger(argv[4]), CP_IGNORE_INUSE); // | CP_IGNORE_BOOTRES | CP_IGNORE_RESERVED);
        Option.TOUCH_Click = getinteger(argv[4]);
    }
#endif

    Option.TOUCH_CS = getinteger(argv[0]);
    Option.TOUCH_IRQ = getinteger(argv[2]);

    Option.TOUCH_XZERO = 0; //TOUCH_NOT_CALIBRATED;                      // record the touch feature as not calibrated
}


////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// setup touch based on the settings saved in flash
void __attribute__((microinstr)) InitTouch(void) {
    if(!Option.TOUCH_CS) return;
    SetAndReserve(Option.TOUCH_CS, P_OUTPUT, 1, EXT_BOOT_RESERVED);    // config CS as an output
    SetAndReserve(Option.TOUCH_IRQ, P_INPUT, 0, EXT_BOOT_RESERVED);    // config IRQ as an input
    PinSetBit(Option.TOUCH_IRQ, CNPUSET);
    PinSetBit(Option.TOUCH_CS, CNPUSET);
#if defined(MX470)
    SetAndReserve(Option.TOUCH_Click, P_OUTPUT, 0, EXT_BOOT_RESERVED); // config the click pin as an output
#endif
    OpenSpiChannel();

    GetTouchValue(CMD_PENIRQ_ON);                                      // send the controller the command to turn on PenIRQ
    
    // these are defined so that the state of the touch PEN IRQ can be determined with the minimum of CPU cycles
    TouchIrqPortBit = GetPinBit(Option.TOUCH_IRQ);
    TouchIrqPortAddr = GetPortAddr(Option.TOUCH_IRQ, PORT);

    GetTouchAxis(CMD_MEASURE_X);
}


////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// this function is only used in calibration
// it draws the target, waits for the touch to stabilise and returns the x and y in raw touch controller numbers (ie, not scaled)
void __attribute__((microinstr)) GetCalibration(int x, int y, int *xval, int *yval) {
    int i, j;
    #define TCAL_FONT    0x02

	if(HRes == 0) error("Display not configured");
    ClearScreen(BLACK);
    GUIPrintString(HRes/2, VRes/2 - GetFontHeight(TCAL_FONT)/2, TCAL_FONT, JUSTIFY_CENTER | JUSTIFY_MIDDLE, WHITE, BLACK, "Touch Target");
    GUIPrintString(HRes/2, VRes/2 + GetFontHeight(TCAL_FONT)/2, TCAL_FONT, JUSTIFY_CENTER | JUSTIFY_MIDDLE, WHITE, BLACK, "and Hold");
    DrawLine(x - (TARGET_OFFSET * 3)/4, y, x + (TARGET_OFFSET * 3)/4, y, 1, WHITE);
    DrawLine(x, y - (TARGET_OFFSET * 3)/4, x, y + (TARGET_OFFSET * 3)/4, 1, WHITE);
    DrawCircle(x, y, TARGET_OFFSET/2, 1, WHITE, -1, 1);

    while(!TOUCH_DOWN) CheckAbort();                                // wait for the touch
    for(i = j = 0; i < 50; i++) {                                   // throw away the first 50 reads as rubbish
        GetTouchAxis(CMD_MEASURE_X); GetTouchAxis(CMD_MEASURE_Y);
    }

    // make a lot of readings and average them
    for(i = j = 0; i < 50; i++) j += GetTouchAxis(CMD_MEASURE_X);
    *xval = j/50;
    for(i = j = 0; i < 50; i++) j += GetTouchAxis(CMD_MEASURE_Y);
    *yval = j/50;

    ClearScreen(BLACK);
    while(TOUCH_DOWN) CheckAbort();                                 // wait for the touch to be lifted
    uSec(25000);
}


////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// this is the main function to call to get a touch reading
// if y is true the y reading will be returned, otherwise the x reading
// this function does noise reduction and scales the reading to pixels
// a return of TOUCH_ERROR means that the pen is not down
int GetTouch(int y) {
    int i;
    static int lastx, lasty;
    
    if(Option.TOUCH_CS == 0) error("Touch option not set");
    if(Option.TOUCH_XZERO == TOUCH_NOT_CALIBRATED) error("Touch not calibrated");
    do {
        if(PinRead(Option.TOUCH_IRQ)) return TOUCH_ERROR;
        if(y) {
            i = ((float)(GetTouchAxis(Option.TOUCH_SWAPXY? CMD_MEASURE_X:CMD_MEASURE_Y) - Option.TOUCH_YZERO) * Option.TOUCH_YSCALE);
            if(i < lasty - CAL_ERROR_MARGIN || i > lasty + CAL_ERROR_MARGIN) { lasty = i; i = -1; }
        } else {
            i = ((float)(GetTouchAxis(Option.TOUCH_SWAPXY? CMD_MEASURE_Y:CMD_MEASURE_X) - Option.TOUCH_XZERO) * Option.TOUCH_XSCALE);
            if(i < lastx - CAL_ERROR_MARGIN || i > lastx + CAL_ERROR_MARGIN) { lastx = i; i = -1; }
        }
    } while(i < 0 || i >= (y ? VRes : HRes));
    return i;
}


////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// this will get a reading from a single axis
// the returned value is not scaled, it is the raw number produced by the touch controller
// it takes multiple readings, discards the outliers and returns the average of the medium values
#if defined(MX470)
int GetTouchAxis2046(int cmd) {
#else
int GetTouchAxis(int cmd) {
#endif
    int i, j, t, b[TOUCH_SAMPLES];

    PinSetBit(Option.TOUCH_IRQ, TRISCLR);                           // Set the PenIRQ to an output
    PinSetBit(Option.TOUCH_IRQ, LATCLR);                            // Drive the PenIRQ low so the diode is not forward biased

    GetTouchValue(cmd);
    // we take TOUCH_SAMPLES readings and sort them into descending order in buffer b[].
    for(i = 0; i < TOUCH_SAMPLES; i++) {
        b[i] = GetTouchValue(cmd);									// get the value
        for(j = i; j > 0; j--) {							        // and sort into position
            if(b[j - 1] < b[j]) {
                t = b[j - 1];
                b[j - 1] = b[j];
                b[j] = t;
            }
            else
                break;
        }
    }

    // we then discard the top TOUCH_DISCARD samples and the bottom TOUCH_DISCARD samples and add up the remainder
    for(j = 0, i = TOUCH_DISCARD; i < TOUCH_SAMPLES - TOUCH_DISCARD; i++) j += b[i];

    // and return the average
    i = j / (TOUCH_SAMPLES - (TOUCH_DISCARD * 2));
    GetTouchValue(CMD_PENIRQ_ON);                                   // send the command to turn PenIRQ on
    PinSetBit(Option.TOUCH_IRQ, TRISSET);                           // Set the PenIRQ to an input
    return i;
}



////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// this will get a single reading from the touch controller
//
// it assumes that PenIRQ line has been pulled low and that the SPI baudrate is correct
// this takes 260uS at 120MHz
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
int GetTouchValue(int cmd) {
    int val;
    
#if defined(MX170)
    if(SPIOpen) error("SPI is open");
#endif
    SpiCsLow(Option.TOUCH_CS, SPI_OPEN_MSTEN | SPI_OPEN_CKE_REV | SPI_OPEN_MODE8 | SPI_OPEN_ON, TOUCH_SPI_SPEED);
    TDelay();
    
    SpiChnPutC(TOUCH_SPI_CHANNEL, cmd);                             // send the read command (also selects the axis)
    SpiChnGetC(TOUCH_SPI_CHANNEL);                                  // Read the dummy data to clear the receive buffer
    while(SpiChnIsBusy(TOUCH_SPI_CHANNEL));
    SpiChnPutC(TOUCH_SPI_CHANNEL, 0x00);                            // Send a dummy byte in order to clock the data out
    val = (SpiChnGetC(TOUCH_SPI_CHANNEL) & 0b1111111) << 5;         // the top 7 bits
    while(SpiChnIsBusy(TOUCH_SPI_CHANNEL));
    SpiChnPutC(TOUCH_SPI_CHANNEL, 0x00);                            // Send a dummy byte in order to clock the data out
    val |= (SpiChnGetC(TOUCH_SPI_CHANNEL) >> 3) & 0b11111;          // the bottom 5 bits
    while(SpiChnIsBusy(TOUCH_SPI_CHANNEL));
    SpiCsHigh(Option.TOUCH_CS);                                     // Deassert the CS line
    return val;
}


void TDelay(void)		// provides a small (~200ns) delay for the touch screen controller.
{
	Nop();	Nop();	Nop();	Nop();	Nop();	Nop();	Nop();	Nop();	Nop();
}


// the MMBasic TOUCH() function
void fun_touch(void) {
    if(checkstring(ep, "X"))
        iret = GetTouch(GET_X_AXIS);
    else if(checkstring(ep, "Y"))
        iret = GetTouch(GET_Y_AXIS);
#if defined(MX470)
    else if(checkstring(ep, "REF"))
        iret = CurrentRef;
    else if(checkstring(ep, "LASTREF"))
        iret = LastRef;
    else if(checkstring(ep, "LASTX"))
        iret = LastX;
    else if(checkstring(ep, "LASTY"))
        iret = LastY;
    else if(checkstring(ep, "DOWN"))
        iret = TOUCH_DOWN;
    else if(checkstring(ep, "UP"))
        iret = !TOUCH_DOWN;
#endif
    else
        error("Invalid argument");

    targ = T_INT;
}

