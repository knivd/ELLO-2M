/***********************************************************************************************************************
MMBasic

Hardware_Includes.h

Defines the hardware aspects for PIC32-Generic MMBasic.

Copyright 2011 - 2017 Geoff Graham.  All Rights Reserved.

This file and modified versions of this file are supplied to specific individuals or organisations under the following
provisions:

- This file, or any files that comprise the MMBasic source (modified or not), may not be distributed or copied to any other
  person or organisation without written permission.

- Object files (.o and .hex files) generated using this file (modified or not) may not be distributed or copied to any other
  person or organisation without written permission.

- This file is provided in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

************************************************************************************************************************/



#if !defined(INCLUDE_COMMAND_TABLE) && !defined(INCLUDE_TOKEN_TABLE)

    #if defined(__32MX170F256B__) || defined(__32MX270F256B__) || defined(__32MX170F256D__) || defined(__32MX270F256D__)
        #define MX170
        #if defined(__32MX270F256D__)
            #define MX270D
        #endif
    #elif defined(__32MX470F512L__) || defined(__32MX470F512H__)
        #define MX470
    #elif defined(__32MZ2048EFG064__) || defined(__32MZ2048EFH064__) || defined(__32MZ2048EFM064__) ||  defined(__32MZ2048EFG100__) || defined(__32MZ2048EFH100__) || defined(__32MZ2048EFM100__)
        #define MX470
        #define MZEF
        #ifndef  __PIC32MZ__
//            #define __PIC32MZ__ 1
        #endif
    #else
        #error This device is not supported
    #endif

    #include "plib.h"                                   // the pre Harmony peripheral libraries

    #define LCDCMD                      // this can be commented out to remove the LCD command (saves 1060 bytes)

    #include "Version.h"

    #if defined(MX170) && !defined(MX270D)
        #include "MX170/IOPorts.h"
        #include "MX170/Configuration.h"
        #include "MX170/Console.h"
        #include "MX170/Serial.h"
    #elif defined(MX270D)
        #include "MX270D/IOPorts.h"
        #include "MX270D/Configuration.h"
        #include "MX270D/Console.h"
        #include "MX270D/Serial.h"
    #elif defined(MX470) && !defined(MZEF)
        #include "MX470/IOPorts.h"
        #include "MX470/Configuration.h"
        #include "MX470/Console.h"
        #include "MX470/Serial.h"
        #include "MX470/Keyboard.h"
        #include "MX470/SSD1963.h"
#elif defined(MZEF)
        #include "MZEF/IOPorts.h"
        #include "MZEF/Configuration.h"
        #include "MZEF/MiscMZEF.h"
        #include "MZEF/Console.h"
        #include "MZEF/Serial.h"
        #include "MZEF/Keyboard.h"
        #include "MZEF/SSD1963.h"
#endif

    #include "Main.h"
    #include "General/Timers.h"
    #include "General/SPI-LCD.h"

    // various debug macros
    #if defined(DEBUGMODE)
        void dump(char *p, int nbr);                                // defined in Main.c,  dump an area of memory in hex and ascii
        void DumpVarTbl(void);                                      // defined in MMBasic.c,  dump the variable table

        #define dp(...) {char s[140];sprintf(s,  __VA_ARGS__); MMPrintString(s); MMPrintString("\r\n");}

        #define db(i) {IntToStr(inpbuf, i, 10); MMPrintString(inpbuf); MMPrintString("\r\n");}
        #define db2(i1, i2) {IntToStr(inpbuf, i1, 10); MMPrintString(inpbuf); MMPrintString("  "); IntToStr(inpbuf, i2, 10); MMPrintString(inpbuf); MMPrintString("\r\n");}
        #define db3(i1, i2, i3) {IntToStr(inpbuf, i1, 10); MMPrintString(inpbuf); MMPrintString("  "); IntToStr(inpbuf, i2, 10); MMPrintString(inpbuf); MMPrintString("  "); IntToStr(inpbuf, i3, 10); MMPrintString(inpbuf); MMPrintString("\r\n");}

        #define ds(s) {MMPrintString(s); MMPrintString("\r\n");}
        #define ds2(s1, s2) {MMPrintString(s1); MMPrintString(s2); MMPrintString("\r\n");}
        #define ds3(s1, s2, s3) {MMPrintString(s1); MMPrintString(s2); MMPrintString(s3); MMPrintString("\r\n");}

        #define pp1(i) { PinSetBit(i, TRISCLR); PinSetBit(i, ODCCLR); PinSetBit(i, LATCLR); PinSetBit(i, LATSET); uSec(10); PinSetBit(i, LATCLR); uSec(10); }
        #define pp2(i) { PinSetBit(i, TRISCLR); PinSetBit(i, ODCCLR); PinSetBit(i, LATCLR); PinSetBit(i, LATSET); uSec(10); PinSetBit(i, LATCLR); uSec(10); PinSetBit(i, LATSET); uSec(10); PinSetBit(i, LATCLR); uSec(10); }
        #define pp3(i) { PinSetBit(i, TRISCLR); PinSetBit(i, ODCCLR); PinSetBit(i, LATCLR); PinSetBit(i, LATSET); uSec(10); PinSetBit(i, LATCLR); uSec(10); PinSetBit(i, LATSET); uSec(10); PinSetBit(i, LATCLR); uSec(10); PinSetBit(i, LATSET); uSec(10); PinSetBit(i, LATCLR); uSec(10); }

#endif


    #define SSD1963_4       1
    #define SSD1963_5       2
    #define SSD1963_5A      3
    #define SSD1963_7       4
    #define SSD1963_7A      5
    #define SSD1963_7W      6
    #define SSD1963_8       7

    #define SSD_PANEL       7    // anything less than or equal to SSD_PANEL is handled by the SSD driver, anything more by the SPI driver

    #define ILI9341         8
    #define ILI9163         9
    #define ST7735          10

    #define LANDSCAPE       1
    #define PORTRAIT        2
    #define RLANDSCAPE      3
    #define RPORTRAIT       4
    #define DISPLAY_LANDSCAPE   (Option.DISPLAY_ORIENTATION & 1)

#endif

#include "General/Memory.h"
#include "General/External.h"
#include "General/MM_Misc.h"
#include "General/MM_Custom.h"
#include "General/Onewire.h"
#include "General/I2C.h"
#include "General/SerialFileIO.h"
#include "General/PWM.h"
#include "General/SPI.h"
#include "General/Flash.h"
#include "General/Editor.h"
#include "General/XModem.h"
#include "General/Touch.h"
#include "General/Draw.h"

#if defined(MX470) && !defined(MZEF)
    #include "MX470/FileIO.h"
    #include "MX470/GUI.h"
    #include "MX470/audio.h"
    #include "MX470/FWUpdate.h"
#elif defined(MZEF)
    #include "MZEF/AdiskImage.h"
    #include "MZEF/FileIO.h"
    #include "MZEF/GUI.h"
    #include "MZEF/audio.h"
    #include "MZEF/FWUpdate.h"
#endif


