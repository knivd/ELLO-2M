﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MMZHELP
{
	public partial class FormFind : Form
	{
		public string FindWhat { get; private set; }

		public FormFind()
		{
			InitializeComponent();
		}

		private void buttonGo_Click(object sender, EventArgs e)
		{
			FindWhat = textBoxFind.Text;
		}

		private void textBoxFind_KeyDown(object sender, KeyEventArgs e)
		{
			if (e.KeyCode == Keys.Enter)
			{
				FindWhat = textBoxFind.Text;
				DialogResult = DialogResult.OK;
				Close();
			}
		}
	}
}
