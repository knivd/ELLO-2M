﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Windows.Forms;

namespace MMZHELP
{
	public partial class MMZHELP : Form
	{
		/// <summary>
		/// Local class Entry - represents topic in the help file.
		/// </summary>
		private class Entry
		{
			private bool _changed;
			public bool Changed
			{
				get { return _changed; }
				private set { _changed = value; }
			}

			private string _oldTopicName;
			private string _topicName;
			public string TopicName
			{
				get
				{
					return _topicName;
				}
				set
				{
					_oldTopicName = _topicName;
					_topicName = value;
					_changed = true;
				}
			}

			private string _oldDescription;
			private string _description;
			public string Description
			{
				get
				{
					return _description;
				}
				set
				{
					_oldDescription = _description;
					_description = value;
					_changed = true;
				}
			}

			public void ResetChanges()
			{
				_topicName = _oldTopicName;
				_description = _oldDescription;
				_changed = false;
			}

			public void ChangesSaved()
			{
				_changed = false;
			}
		}

		/// <summary>
		/// List of help topics.
		/// </summary>
		private List<Entry> topics;

		/// <summary>
		/// Help file name.
		/// </summary>
		private const string fileName = "MMZHELP.TXT";

		/// <summary>
		/// Index of the current help topic entry.
		/// </summary>
		private int index = 0;

		/// <summary>
		/// String containing two single quotas (char 96) - MMZ HELP topic marker
		/// </summary>
		private string topicMarker;

		/// <summary>
		/// Flag indicating programm invoked change in action.
		/// </summary>
		private bool internalChange = false;

		/// <summary>
		/// Flag indicating list changes (add / remove).
		/// </summary>
		private bool listChanged = false;

		/// <summary>
		/// C'tor
		/// </summary>
		public MMZHELP()
		{
			InitializeComponent();
			topics = new List<Entry>();

			StringBuilder sb = new StringBuilder();
			sb.Append((char)96);
			sb.Append((char)96);
			topicMarker = sb.ToString();
			string description = string.Empty;
			topics = new List<Entry>();

			if (File.Exists(fileName))
			{
				string[] lines = File.ReadAllLines(fileName);
				for (int i = lines.Count() - 1; i >= 0; i--)
				{
					if (lines[i].StartsWith(topicMarker))
					{
						Entry ne = new Entry { TopicName = lines[i].Substring(2), Description = description };
						ne.ChangesSaved();
						topics.Add(ne);
						description = string.Empty;
					}
					else
					{
						description = lines[i] + System.Environment.NewLine + description;
					}
				}
				topics = topics.OrderBy(t => t.TopicName).ToList();
			}
			else
			{
				// Create new empty HELP.
				Entry ne = new Entry { TopicName = "NEW", Description = "NEW" };
				topics.Add(ne);
			}

			ShowTopic(index);
		}

		/// <summary>
		/// Show help topic by given index
		/// </summary>
		/// <param name="idx">Index of help topic to be shown</param>
		private void ShowTopic(int idx)
		{
			internalChange = true;
			textBoxDescription.Text = topics[idx].Description;
			textBoxTopic.Text = topics[idx].TopicName;
			internalChange = false;
		}

		private void buttonQuit_Click(object sender, EventArgs e)
		{
			if (topics.Any(t => t.Changed) || listChanged)
			{
				if (MessageBox.Show("Changes are not saved. Continue anyway?", "Question", MessageBoxButtons.YesNo) == DialogResult.Yes)
					Close();
			}
			else
			{
				Close();
			}
		}

		private void buttonPrevious_Click(object sender, EventArgs e)
		{
			index--;
			if (index < 0)
				index = topics.Count - 1;

			ShowTopic(index);
		}

		private void buttonNext_Click(object sender, EventArgs e)
		{
			index++;
			if (index > topics.Count - 1)
				index = 0;

			ShowTopic(index);
		}

		private void buttonFind_Click(object sender, EventArgs e)
		{
			var frm = new FormFind();
			frm.ShowDialog();
			if (frm.DialogResult == DialogResult.Cancel) return;

			var qry = topics.FirstOrDefault(t => t.TopicName.ToUpper() == frm.FindWhat.ToUpper());

			if (qry == null)
			{
				MessageBox.Show($"{frm.FindWhat} was not Found!");
			}
			else
			{
				index = topics.IndexOf(qry);
				ShowTopic(index);
			}
		}

		private void buttonSave_Click(object sender, EventArgs e)
		{
			string content = string.Empty;
			string newLine = string.Empty;

			topics = topics.OrderBy(t => t.TopicName).ToList();

			foreach (var entry in topics)
			{
				content += Environment.NewLine+topicMarker + entry.TopicName + Environment.NewLine;

				// Reorganize description to fit in 80 columns
				string[] descriptionLines = entry.Description.Split(new string[] {Environment.NewLine}, StringSplitOptions.None);
				foreach(var line in descriptionLines)
				{
					string[] words = line.Split(new char[] {' '}, StringSplitOptions.RemoveEmptyEntries);

					newLine = string.Empty;
					foreach (var word in words)
					{
						if (newLine.Length + word.Length > 80)
						{
							content += newLine + Environment.NewLine;
							newLine = string.Empty;
						}
						newLine += word + " ";
					}
					content += newLine + Environment.NewLine;
				}
				entry.ChangesSaved();
			}

			StringBuilder sb = new StringBuilder(content);
			// Replace any occurrence of 3 following CRLF with single CRLF.
			sb.Replace(Environment.NewLine + Environment.NewLine + Environment.NewLine, Environment.NewLine);
			File.WriteAllText(fileName, sb.ToString());
			index = 0;
			ShowTopic(index);
			listChanged = false;
		}

		private void buttonAdd_Click(object sender, EventArgs e)
		{
			Entry ne = new Entry { TopicName = $"NEW_TOPIC_{DateTime.Now.ToString("yyyyMMddHHssfffff")}", Description = string.Empty };
			topics.Add(ne);
			index = topics.IndexOf(ne);
			ShowTopic(index);
			listChanged = true;
		}

		private void textBoxDescription_TextChanged(object sender, EventArgs e)
		{
			if (!internalChange)
				topics[index].Description = textBoxDescription.Text;
		}

		private void textBoxTopic_TextChanged(object sender, EventArgs e)
		{
			if (!internalChange)
				topics[index].TopicName = textBoxTopic.Text;
		}

		private void buttonDelete_Click(object sender, EventArgs e)
		{
			if (MessageBox.Show($"Are you sure to delete topic {topics[index].TopicName}?", "Question", MessageBoxButtons.YesNo) == DialogResult.Yes)
			{
				topics.RemoveAt(index);
				index = 0;
				ShowTopic(0);
				listChanged = true;
			}
		}

		private void buttonUndo_Click(object sender, EventArgs e)
		{
			topics[index].ResetChanges();
		}

		private void buttonLast_Click(object sender, EventArgs e)
		{
			index = topics.Count - 1;
			ShowTopic(index);
		}
	}
}
