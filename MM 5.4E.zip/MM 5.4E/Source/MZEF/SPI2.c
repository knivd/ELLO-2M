/***********************************************************************************************************************
MMBasic

SPI2.c

Handles the all SPI2 functions for the MX470 version.

Copyright 2011 - 2015 Geoff Graham.  All Rights Reserved.

This file and modified versions of this file are supplied to specific individuals or organisations under the following
provisions:

- This file, or any files that comprise the MMBasic source (modified or not), may not be distributed or copied to any other
  person or organisation without written permission.

- Object files (.o and .hex files) generated using this file (modified or not) may not be distributed or copied to any other
  person or organisation without written permission.

- This file is provided in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

************************************************************************************************************************/


#include "../MMBasic_Includes.h"
#include "../Hardware_Includes.h"

extern unsigned int *GetSendDataList(char *p, unsigned int *nbr);
extern long long int *GetReceiveDataBuffer(char *p, unsigned int *nbr);

void cmd_spi2(void) {
    int speed, mode;
    char *p;
    unsigned int junk,nbr, *d;
    long long int *dd;

    if(ExtCurrentConfig[SPI2_OUT_PIN] == EXT_BOOT_RESERVED) error("SPI2 is reserved on startup");

    if((p = checkstring(cmdline, "OPEN")) != NULL) {
        if(ExtCurrentConfig[SPI2_OUT_PIN] == EXT_COM_RESERVED) error("SPI2 is in use");
        CheckPin(SPI2_OUT_PIN, CP_CHECKALL);
        CheckPin(SPI2_INP_PIN, CP_CHECKALL);
        CheckPin(SPI2_CLK_PIN, CP_CHECKALL);

        { // start a new block for getargs()
            getargs(&p, 5, ",");
            if(argc != 5) error("Incorrect argument count");

            speed = getinteger(argv[0]);
            if(speed > BusSpeed/2) error("CPU speed too low");

            mode = SPI_OPEN_MSTEN;// | SPI_OPEN_SMP_END;
            switch(getinteger(argv[2])) {
                case 0:  mode |= SPI_OPEN_CKE_REV;      break;
                case 1:                                 break;
                case 2:  mode |= SPI_OPEN_CKP_HIGH | SPI_OPEN_CKE_REV; break;
                case 3:  mode |= SPI_OPEN_CKP_HIGH;     break;
                default: error("Invalid mode");
            }
            switch(getinteger(argv[4])) {
                case 8:  mode |= SPI_OPEN_MODE8;        break;
                case 16: mode |= SPI_OPEN_MODE16;       break;
                case 32: mode |= SPI_OPEN_MODE32;       break;
                default: error("Invalid size");
            }
            ExtCfg(SPI2_OUT_PIN, EXT_DIG_OUT, 0); ExtCfg(SPI2_OUT_PIN, EXT_COM_RESERVED, 0);
            ExtCfg(SPI2_INP_PIN, EXT_DIG_IN, 0); ExtCfg(SPI2_INP_PIN, EXT_COM_RESERVED, 0);
            ExtCfg(SPI2_CLK_PIN, EXT_DIG_OUT, 0); ExtCfg(SPI2_CLK_PIN, EXT_COM_RESERVED, 0);
            SPI2_PPS_OPEN;                                                  // this is defined in IOPorts.h
            SpiChnOpen(SPI_CHANNEL2, mode, BusSpeed/speed);
        }
        return;
    }

    if(ExtCurrentConfig[SPI2_OUT_PIN] != EXT_COM_RESERVED) error("Not open");
    
    if(checkstring(cmdline, "CLOSE")) {
        SPI2Close();
        return;
    }

    if((p = checkstring(cmdline, "WRITE")) != NULL) {
        d = GetSendDataList(p, &nbr);
        SpiChnGetRov(SPI_CHANNEL2, true);
        while(nbr--) {
            while(!SpiChnTxBuffEmpty(SPI_CHANNEL2));                // wait for the buffer to empty
            INTDisableInterrupts();                                 // see Errata #10
            SpiChnPutC(SPI_CHANNEL2, *d++);
            INTEnableInterrupts();
            junk = SpiChnGetC(SPI_CHANNEL2);
        }
        return;
    }

    if((p = checkstring(cmdline, "READ")) != NULL) {
        dd = GetReceiveDataBuffer(p, &nbr);
        SpiChnGetRov(SPI_CHANNEL2, true);
        while(nbr--) {
            while(!SpiChnTxBuffEmpty(SPI_CHANNEL2));                // wait for the buffer to empty
            INTDisableInterrupts();                                 // see Errata #10
            SpiChnPutC(SPI_CHANNEL2, 0);
            INTEnableInterrupts();
            *dd++ = SpiChnGetC(SPI_CHANNEL2);
        }
        return;
    }
    error("Invalid syntax");
}



// output and get a byte via SPI
void fun_spi2(void) {
    int c;
    if(ExtCurrentConfig[SPI2_OUT_PIN] == EXT_BOOT_RESERVED) error("SPI2 reserved at startup");
    if(ExtCurrentConfig[SPI2_OUT_PIN] != EXT_COM_RESERVED) error("Not open");
    c = getinteger(ep);
    SpiChnGetRov(SPI_CHANNEL2, true);                               // clear any receive buffer overrun
    while(!SpiChnTxBuffEmpty(SPI_CHANNEL2));                        // wait for the buffer to empty
    INTDisableInterrupts();                                         // see Errata #10
    SpiChnPutC(SPI_CHANNEL2, c);
    INTEnableInterrupts();
    iret = SpiChnGetC(SPI_CHANNEL2);
    targ = T_INT;
}



void SPI2Close(void) {
    if(ExtCurrentConfig[SPI2_OUT_PIN] == EXT_BOOT_RESERVED) return;
    SpiChnClose(SPI_CHANNEL2);
    SPI2_PPS_CLOSE;                                                 // this is defined in IOPorts.h
    ExtCfg(SPI2_OUT_PIN, EXT_NOT_CONFIG, 0); ExtCfg(SPI2_INP_PIN, EXT_NOT_CONFIG, 0);      // reset to not in use
    ExtCfg(SPI2_CLK_PIN, EXT_NOT_CONFIG, 0);
}
