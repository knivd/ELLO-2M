/***********************************************************************************************************************
MMBasic

MiscMZEF.h

Header file defining the public functions and variables in Console.c

Copyright 2011 - 2017 Geoff Graham.  All Rights Reserved.

This file and modified versions of this file are supplied to specific individuals or organisations under the following
provisions:

- This file, or any files that comprise the MMBasic source (modified or not), may not be distributed or copied to any other
  person or organisation without written permission.

- Object files (.o and .hex files) generated using this file (modified or not) may not be distributed or copied to any other
  person or organisation without written permission.

- This file is provided in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

************************************************************************************************************************/

#ifndef MISCMZEF_H
#define	MISCMZEF_H

#ifdef	__cplusplus
extern "C" {
#endif

/* Enable this definition if you do no used the osc. auto detect functionality. */    
//#define SET_LOCAL_OSC_CLOCK       12000000ul

void InitProcessor(void);
void MiscSetSpeed(unsigned int newspeed);
unsigned int MiscClkSystemFrequencyGet(void);
uint32_t get_fattime(void);

#ifdef	__cplusplus
}
#endif

#endif	/* MISCMZEF_H */

