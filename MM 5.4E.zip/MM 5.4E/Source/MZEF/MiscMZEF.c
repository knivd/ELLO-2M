/***********************************************************************************************************************
MMBasic

MiscMZEF.c

Handles the a few miscellaneous functions for the MX470 version.

Copyright 2011 - 2017 Geoff Graham.  All Rights Reserved.

This file and modified versions of this file are supplied to specific individuals or organisations under the following
provisions:

- This file, or any files that comprise the MMBasic source (modified or not), may not be distributed or copied to any other
  person or organisation without written permission.

- Object files (.o and .hex files) generated using this file (modified or not) may not be distributed or copied to any other
  person or organisation without written permission.

- This file is provided in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

************************************************************************************************************************/

#include "../MMBasic_Includes.h"
#include "../Hardware_Includes.h"


static unsigned int sys_clk_freq                        = DEFAULT_CLK_FREQ;
static unsigned int sys_clk_bus_peripherial_1           = DEFAULT_CLK_BUS_PERIPHERAL_1;
static unsigned int sys_clk_bus_peripherial_2           = DEFAULT_CLK_BUS_PERIPHERAL_2;
static unsigned int sys_clk_bus_peripherial_3           = DEFAULT_CLK_BUS_PERIPHERAL_3;
static unsigned int sys_clk_bus_peripherial_4           = DEFAULT_CLK_BUS_PERIPHERAL_4;
static unsigned int sys_clk_bus_peripherial_5           = DEFAULT_CLK_BUS_PERIPHERAL_5;
static unsigned int sys_clk_bus_peripherial_7           = DEFAULT_CLK_BUS_PERIPHERAL_7;
static unsigned int sys_clk_bus_peripherial_8           = DEFAULT_CLK_BUS_PERIPHERAL_8;
static unsigned int sys_default_clk_config_primary_xtal = DEFAULT_CLK_CONFIG_PRIMARY_XTAL;
static unsigned int sys_default_clk_secondary_xtal      = DEFAULT_CLK_CONFIG_SECONDARY_XTAL;

extern void CallCFuncT5(void);                                    // this is implemented in CFunction.c
extern unsigned int CFuncT5;                                      // we should call the CFunction T5 interrupt function if this is non zero

static void MiscPBClkInitialize(unsigned int cpuspeed);
static void MiscClkSystemFrequencySet(unsigned int setsysfreq);

// function (which looks like a pre defined variable) to return the type of platform
void fun_device(void){
	sret = GetTempStrMemory();									    // this will last for the life of the command
    strcpy(sret, "Micromite Plus");
    CtoM(sret);
    targ = T_STR;
}


///////////////////////////////////////////////////////////////////////////////////////////////
// constants and functions used in the OPTION LIST command
char *LCDList[] = {"SSD1963_4", "SSD1963_5", "SSD1963_5A", "SSD1963_7", "SSD1963_7A", "SSD1963_7W", "SSD1963_8", "ILI9341", "ILI9163", "ST7735"};
char *OrientList[] = {"LANDSCAPE", "PORTRAIT", "RLANDSCAPE", "RPORTRAIT"};
char *CaseList[] = {"", "LOWER", "UPPER"};
char *KBrdList[] = {"", "US", "FR", "GR", "IT", "BE", "UK", "ES" };


void __ISR( _TIMER_5_VECTOR, IPL1SRS) T5Interrupt(void) {
    if(CFuncT5) CallCFuncT5();                                  // T5 interrupt CFunctions (see CFunction.c)
    mT5ClearIntFlag();
}


void PO(char *s) {
    MMPrintString("OPTION "); MMPrintString(s); MMPrintString(" ");
}

void PInt(int n) {
    char s[20];
    IntToStr(s, n, 10);
    MMPrintString(s);
}

void PIntComma(int n) {
    MMPrintString(", "); PInt(n);
}

void PO2Str(char *s1, char *s2) {
    PO(s1); MMPrintString(s2); MMPrintString("\r\n");
}


void PO2Int(char *s1, int n) {
    PO(s1); PInt(n); MMPrintString("\r\n");
}

void PO3Int(char *s1, int n1, int n2) {
    PO(s1); PInt(n1); PIntComma(n2); MMPrintString("\r\n");
}
///////////////////////////////////////////////////////////////////////////////////////////////
void __attribute__((microinstr)) OtherOptions(void) {
	char *tp, *ttp;

	tp = checkstring(cmdline, "RESET");
	if(tp) {
        FlashWriteInit(SavedVarsFlash, SAVEDVARS_FLASH_SIZE);           // erase saved vars + options
        Option.ProgFlashSize = PROG_FLASH_SIZE;
        ResetAllOptions();
		goto saveandreset;
	}

#ifndef ELLO_2M

    tp = checkstring(cmdline, "KEYBOARD");
	if(tp) {
    	if(CurrentLinePtr) error("Invalid in a program");
		if(checkstring(tp, "DISABLE"))	Option.KeyboardConfig = NO_KEYBOARD;
        else if(checkstring(tp, "US"))	Option.KeyboardConfig = CONFIG_US;
		else if(checkstring(tp, "FR"))	Option.KeyboardConfig = CONFIG_FR;
		else if(checkstring(tp, "GR"))	Option.KeyboardConfig = CONFIG_GR;
		else if(checkstring(tp, "IT"))	Option.KeyboardConfig = CONFIG_IT;
		else if(checkstring(tp, "BE"))	Option.KeyboardConfig = CONFIG_BE;
		else if(checkstring(tp, "UK"))	Option.KeyboardConfig = CONFIG_UK;
		else if(checkstring(tp, "ES"))	Option.KeyboardConfig = CONFIG_ES;
        goto saveandreset;
	}

    tp = checkstring(cmdline, "SDCARD");
    if(tp) {
    	if(CurrentLinePtr) error("Invalid in a program");
        if(checkstring(tp, "DISABLE"))   
            DisableSDCard(DEFAULT_SDCARD);    
        else
            ConfigSDCard(tp, DEFAULT_SDCARD);

        goto saveandreset;
    }
    
    tp = checkstring(cmdline, "SDCARD1");
    if(tp) {
    	if(CurrentLinePtr) error("Invalid in a program");
        if(checkstring(tp, "DISABLE"))  
            DisableSDCard(SDCARD_1); 
        else
            ConfigSDCard(tp, SDCARD_1);

        goto saveandreset;
    }

    tp = checkstring(cmdline, "SDCARD2");
    if(tp) {
    	if(CurrentLinePtr) error("Invalid in a program");
        if(checkstring(tp, "DISABLE"))
            DisableSDCard(SDCARD_2);             
        else
            ConfigSDCard(tp, SDCARD_2);

        goto saveandreset;
    }

    tp = checkstring(cmdline, "SDCARD3");
    if(tp) {
    	if(CurrentLinePtr) error("Invalid in a program");
        if(checkstring(tp, "DISABLE"))
            DisableSDCard(SDCARD_3);             
        else
            ConfigSDCard(tp, SDCARD_3);

        goto saveandreset;
    }

#endif

    tp = checkstring(cmdline, "SDCARD4");
    if(tp) {
    	if(CurrentLinePtr) error("Invalid in a program");
        if(checkstring(tp, "DISABLE"))
            DisableSDCard(SDCARD_4);  
        else
            ConfigSDCard(tp, SDCARD_4);

        goto saveandreset;
    }    

#ifndef ELLO_2M
    
    tp = checkstring(cmdline, "LCDPANEL");
    if(tp) {
    	if(CurrentLinePtr) error("Invalid in a program");
        if((ttp = checkstring(tp, "CONSOLE"))) {
            if(HRes == 0) error("LCD Panel not configured");
            if(ScrollLCD == (void (*)(int ))DisplayNotSet) error("SSD1963 display required");
            if(!DISPLAY_LANDSCAPE) error("Landscape only");
            Option.Height = VRes/gui_font_height; Option.Width = HRes/gui_font_width;
            skipspace(ttp);
            Option.DefaultFC = WHITE;
            Option.DefaultBC = BLACK;
            Option.DefaultBrightness = 100;
            if(!(*ttp == 0 || *ttp == '\'')) {
                getargs(&ttp, 7, ",");                              // this is a macro and must be the first executable stmt in a block
                if(argc > 0) {
                    if(*argv[0] == '#') argv[0]++;                  // skip the hash if used
                    SetFont(((getint(argv[0], 1, FONT_BUILTIN_NBR) - 1) << 4) | 1);
                    Option.DefaultFont = gui_font;
                }
                if(argc > 2) Option.DefaultFC = getint(argv[2], BLACK, WHITE);
                if(argc > 4) Option.DefaultBC = getint(argv[4], BLACK, WHITE);
                if(Option.DefaultFC == Option.DefaultBC) error("Same colours");
                if(argc > 6) Option.DefaultBrightness = getint(argv[6], 2, 100);
                SetBacklightSSD1963(Option.DefaultBrightness);
            } else
                SetFont((Option.DefaultFont = 0x61));
            Option.DISPLAY_CONSOLE = 1;
            Option.ColourCode = true;
            SaveOptions();
            PromptFont = Option.DefaultFont;
            PromptFC = Option.DefaultFC;
            PromptBC = Option.DefaultBC;
            ClearScreen(Option.DefaultBC);
            return;
        }
        else if(checkstring(tp, "NOCONSOLE")) {
            Option.Height = SCREENHEIGHT; Option.Width = SCREENWIDTH;
            Option.DISPLAY_CONSOLE = 0;
            Option.ColourCode = false;
            Option.DefaultFC = WHITE;
            Option.DefaultBC = BLACK;
            SetFont((Option.DefaultFont = 0x01));
            Option.DefaultBrightness = 100;
            SaveOptions();
            ClearScreen(Option.DefaultBC);
            return;
        }
        else if(checkstring(tp, "DISABLE")) {
            Option.Height = SCREENHEIGHT; Option.Width = SCREENWIDTH;
            Option.DISPLAY_CONSOLE = Option.DISPLAY_TYPE = Option.DISPLAY_ORIENTATION = Option.DISPLAY_BL = HRes = 0;
            Option.DefaultFC = WHITE; Option.DefaultBC = BLACK; Option.DefaultFont = 0x01; Option.DefaultBrightness = 100;
            DrawRectangle = (void (*)(int , int , int , int , int )) DisplayNotSet;
            DrawBitmap =  (void (*)(int , int , int , int , int , int , int , unsigned char *)) DisplayNotSet;
            ScrollLCD = (void (*)(int ))DisplayNotSet;
            DrawBuffer = (void (*)(int , int , int , int , char * )) DisplayNotSet;
            ReadBuffer = (void (*)(int , int , int , int , char * )) DisplayNotSet;
        }
        else {
            ConfigDisplaySSD(tp);
            if(!Option.DISPLAY_TYPE) ConfigDisplaySPI(tp);          // if it is not an SSD1963 then try for a SPI type
        }

        goto saveandreset;
    }

    tp = checkstring(cmdline, "TOUCH");
	if(tp) {
    	if(CurrentLinePtr) error("Invalid in a program");
		if(checkstring(tp, "DISABLE")) {
            TouchIrqPortAddr = NULL;
            Option.TOUCH_Click = Option.TOUCH_CS = Option.TOUCH_IRQ = false;
        } else
            ConfigTouch(tp);

        goto saveandreset;
	}

    tp = checkstring(cmdline, "CONSOLE");
	if(tp) {
		if(checkstring(tp, "OFF"))		    { Option.SerialCon = false;  SaveOptions(); CloseSerialConsole(); return; }
		if(checkstring(tp, "ON"))           { if(ExtCurrentConfig[CONSOLE_RX_PIN] != EXT_NOT_CONFIG || ExtCurrentConfig[CONSOLE_TX_PIN] != EXT_NOT_CONFIG)
                                                  error("Console pins are in use");
                                              Option.SerialCon = true;
                                              SaveOptions(); initSerialConsole(); return; }
		if(checkstring(tp, "INVERT"))		{ Option.Invert = true;  SaveOptions(); initSerialConsole(); return; }
		if(checkstring(tp, "NOINVERT"))		{ Option.Invert = false; SaveOptions(); initSerialConsole(); return; }
		if(checkstring(tp, "AUTO"))		    { Option.Invert = 2; SaveOptions(); initSerialConsole(); return; }
		if(checkstring(tp, "ECHO"))		    { EchoOption = true; return; }
		if(checkstring(tp, "NOECHO"))		{ EchoOption = false; return; }
	}

#endif  
    tp = checkstring(cmdline, "RTC");
	if(tp) {
    	if(CurrentLinePtr) error("Invalid in a program");
		if(checkstring(tp, "DISABLE")) {
            Option.RTC_Clock = Option.RTC_Data = 0;
        } else {
            getargs(&tp, 3, ",");                                   // this is a macro and must be the first executable stmt in a block
            if(argc != 3) error("Invalid Syntax");
            Option.RTC_Data = getinteger(argv[0]);
            CheckPin(Option.RTC_Data, CP_IGNORE_INUSE);
            Option.RTC_Clock = getinteger(argv[2]);
            CheckPin(Option.RTC_Clock, CP_IGNORE_INUSE);
        }
        goto saveandreset;
	}

    tp = checkstring(cmdline, "LIST");
    if(tp) {
        if(Option.Autorun == true) PO2Str("AUTORUN", "ON");
        if(Option.SerialCon == false)
            PO2Str("CONSOLE", "OFF");
        else {
            if(Option.Baudrate != CONSOLE_BAUDRATE) PO2Int("BAUDRATE", Option.Baudrate);
            if(Option.Invert == true) PO2Str("CONSOLE", "INVERT");
            if(Option.Invert == 2) PO2Str("CONSOLE", "AUTO");
        }
        if(Option.ColourCode == true) PO2Str("COLOURCODE", "ON");
        if(Option.Listcase != CONFIG_TITLE) PO2Str("CASE", CaseList[(int)Option.Listcase]);
        if(Option.Tab != 2) PO2Int("TAB", Option.Tab);
        if(Option.Height != 24 || Option.Width != 80) PO3Int("DISPLAY", Option.Height, Option.Width);
        if(Option.DISPLAY_TYPE > SSD_PANEL) {
            PO("LCDPANEL"); MMPrintString(LCDList[Option.DISPLAY_TYPE - 1]); MMPrintString(", "); MMPrintString(OrientList[(int)Option.DISPLAY_ORIENTATION - 1]);
            PIntComma(Option.LCD_CD); PIntComma(Option.LCD_Reset); PIntComma(Option.LCD_CS); MMPrintString("\r\n");
        }
        if(Option.DISPLAY_TYPE > 0 && Option.DISPLAY_TYPE <= SSD_PANEL) {
            PO("LCDPANEL"); MMPrintString(LCDList[Option.DISPLAY_TYPE - 1]); MMPrintString(", "); MMPrintString(OrientList[(int)Option.DISPLAY_ORIENTATION - 1]);
            if(Option.DISPLAY_BL) PIntComma(Option.DISPLAY_BL);
            if(Option.LCD_RD && Option.DISPLAY_BL) PIntComma(Option.LCD_RD);
            if(Option.LCD_RD && !Option.DISPLAY_BL) { putConsole(',');PIntComma(Option.LCD_RD);}
            MMPrintString("\r\n");
        }
        if(Option.TOUCH_CS) {
            PO("TOUCH"); PInt(Option.TOUCH_CS); PIntComma(Option.TOUCH_IRQ);
            if(Option.TOUCH_Click) PIntComma(Option.TOUCH_Click);
            MMPrintString("\r\n");
        }
        if(Option.KeyboardConfig != NO_KEYBOARD) PO2Str("KEYBOARD", KBrdList[(int)Option.KeyboardConfig]);
        if(Option.SDCARD[0].CS) {
            PO("SDCARD1"); 
            if(Option.SDCARD[0].MUX_ENABLE)
            {
                MMPrintString("MUX");
                PInt(Option.SDCARD[0].MUXn);
                PIntComma(Option.SDCARD[0].DRV0);
                PIntComma(Option.SDCARD[0].DRV1);
                PIntComma(Option.SDCARD[0].CS);
            }
            else
            {
                PInt(Option.SDCARD[0].CS);
            }
            if(Option.SDCARD[0].CD) PIntComma(Option.SDCARD[0].CD);
            if(Option.SDCARD[0].WP) PIntComma(Option.SDCARD[0].WP);
            MMPrintString("\r\n");
        }
        if(Option.SDCARD[1].CS) {
            PO("SDCARD2");
            if(Option.SDCARD[1].MUX_ENABLE)
            {
                MMPrintString("MUX");
                PInt(Option.SDCARD[1].MUXn);
                PIntComma(Option.SDCARD[1].DRV0);
                PIntComma(Option.SDCARD[1].DRV1);
                PIntComma(Option.SDCARD[1].CS);
            }
            else
            {
                PInt(Option.SDCARD[1].CS);
            }                        
            if(Option.SDCARD[1].CD) PIntComma(Option.SDCARD[1].CD);
            if(Option.SDCARD[1].WP) PIntComma(Option.SDCARD[1].WP);
            MMPrintString("\r\n");
        }
        if(Option.SDCARD[2].CS) {
            PO("SDCARD3"); 
            if(Option.SDCARD[2].MUX_ENABLE)
            {
                MMPrintString("MUX");
                PInt(Option.SDCARD[2].MUXn);
                PIntComma(Option.SDCARD[2].DRV0);
                PIntComma(Option.SDCARD[2].DRV1);
                PIntComma(Option.SDCARD[2].CS);
            }
            else
            {
                PInt(Option.SDCARD[2].CS);
            }
            if(Option.SDCARD[2].CD) PIntComma(Option.SDCARD[2].CD);
            if(Option.SDCARD[2].WP) PIntComma(Option.SDCARD[2].WP);
            MMPrintString("\r\n");
        }        
        if(Option.SDCARD[3].CS) {
            PO("SDCARD4"); 
            if(Option.SDCARD[3].MUX_ENABLE)
            {
                MMPrintString("MUX");
                PInt(Option.SDCARD[3].MUXn);
                PIntComma(Option.SDCARD[3].DRV0);
                PIntComma(Option.SDCARD[3].DRV1);
                PIntComma(Option.SDCARD[3].CS);
            }
            else
            {
                PInt(Option.SDCARD[3].CS);
            }
            if(Option.SDCARD[3].CD) PIntComma(Option.SDCARD[3].CD);
            if(Option.SDCARD[3].WP) PIntComma(Option.SDCARD[3].WP);
            MMPrintString("\r\n");
        }                       
        if(Option.DISPLAY_CONSOLE == true) PO2Str("LCDPANEL", "CONSOLE");
        if(Option.RTC_Data != 0) PO3Int("RTC", Option.RTC_Data, Option.RTC_Clock);
        if(Option.MaxCtrls != 101) PO2Int("CONTROLS", Option.MaxCtrls - 1);
        if(Option.MSDStatus == false) PO2Str("MSD", "OFF");
        return;
    }

    tp = checkstring(cmdline, "MSD");
    if(tp) {
        if(checkstring(tp, "OFF"))		    { Option.MSDStatus = false;  SaveOptions(); MSD_NVM_Attach(false); return; }
        if(checkstring(tp, "ON"))		    { Option.MSDStatus = true;  SaveOptions(); MSD_NVM_Attach(true); return; }
    }    
    
	error("Unrecognised option");

saveandreset:
    // used for options that require the cpu to be reset
    uSec(200000);
    SaveOptions();
    if(U1OTGSTAT & 1)                                               // if the USB is connected
        MMPrintString("Restart the Micromite+");                    // the user must do the reset
    else {
        _excep_code = RESTART_NOAUTORUN;                            // otherwise do an automatic reset
        SoftReset();                                                // this will restart the processor
    }

}





// Do not use console debugging here - the console is not set up
void InitProcessor(void) {
    int i;
    INTDisableInterrupts();
    
    // initial setup of the I/O ports
    // Default all pins to digital input
#if !defined(__32MZ2048EFG064__) && !defined(__32MZ2048EFH064__) && !defined(__32MZ2048EFM064__)
    if(!HAS_64PINS){
        ANSELACLR = ANSELCCLR = ANSELFCLR = 0xffffffff;
        LATACLR = CNPUACLR = CNPDACLR = 0xffffffff;
        TRISASET = 0xffffffff;
    }
#endif
    TRISBSET = TRISCSET = TRISDSET = TRISESET = TRISFSET = TRISGSET = 0xffffffff;
    ANSELBCLR = ANSELECLR = ANSELGCLR =  0xffffffff; 
    LATBCLR = LATCCLR = LATDCLR = LATECLR = LATFCLR = LATGCLR = 0xffffffff;
    CNENBCLR = CNENCCLR = CNENDCLR = CNENECLR = CNENFCLR = CNENGCLR = 0xffffffff;
    CNCONBCLR = CNCONCCLR = CNCONDCLR = CNCONECLR = CNCONFCLR = CNCONGCLR = 0xffffffff;
    CNPUBCLR = CNPUCCLR = CNPUDCLR = CNPUECLR = CNPUFCLR = CNPUGCLR = 0xffffffff;
    CNPDBCLR  = CNPDCCLR = CNPDDCLR = CNPDECLR = CNPDFCLR = CNPDGCLR = 0xffffffff;
    mJTAGPortEnable(0);
    
    SysPerformanceConfig(MiscClkSystemFrequencyGet(), PCACHE_PREFETCH_ENABLE_ALL);
    MiscSetSpeed(MiscClkSystemFrequencyGet());

    PRISS = 0x76543210;                /* assign shadow set #7-#1 to priority level #7-#1 ISRs */
       
    mU1UnifiedIntVector();
    mU5UnifiedIntVector();
    mU3UnifiedIntVector();    
    mU4UnifiedIntVector();            
    mI2C1UnifiedIntVector();     
    INTConfigureSystem(INT_SYSTEM_CONFIG_MULT_VECTOR);
    
    SpiChnClose(SPI_CHANNEL1); SPI_PPS_CLOSE;                       // SPI is not reset by the watchdog
    SpiChnClose(SPI_CHANNEL2); SPI2_PPS_CLOSE;                      // SPI is not reset by the watchdog
    CloseOC1(); PWM_CH1_CLOSE; PWM_CH2_CLOSE; PWM_CH3_CLOSE;        // nor the output compare (PWM)
    CloseOC4(); PWM_CH4_CLOSE; PWM_CH5_CLOSE;

    // clear all UARTs (again not reset by the watchdog)
    UARTEnable(UART1, UART_ENABLE_FLAGS(UART_DISABLE | UART_PERIPHERAL));
    COM4_TX_PPS_CLOSE;
    UARTEnable(UART5, UART_ENABLE_FLAGS(UART_DISABLE | UART_PERIPHERAL));
    COM1_TX_PPS_CLOSE;
    COM1_EN_PPS_CLOSE;
    UARTEnable(UART3, UART_ENABLE_FLAGS(UART_DISABLE | UART_PERIPHERAL));
    COM2_TX_PPS_CLOSE;
    UARTEnable(UART4, UART_ENABLE_FLAGS(UART_DISABLE | UART_PERIPHERAL));
    COM3_TX_PPS_CLOSE;

    LoadOptions();   
    
    // populate the Option struct from flash
    if(Option.Baudrate == 0xffffffff) ResetAllFlash();              // init the options if this is the very first startup

    // set the base of the usable memory
    RAMBase = (void *)MRoundUp((unsigned int)&_splim + (Option.MaxCtrls * sizeof(struct s_ctrl)));
    
    // setup a pointer to the base of the GUI controls table
    Ctrl = (struct s_ctrl *)&_splim;
    for(i = 1; i < Option.MaxCtrls; i++) {
        Ctrl[i].state = Ctrl[i].type = 0;
        Ctrl[i].s = NULL;
    }
    
    if(HAS_100PINS)                                                 // setup the I/O pin table
        PinDef = (struct s_PinDef *)PinDef100;
    else
        PinDef = (struct s_PinDef *)PinDef64;
    
    initTimers();                                                   // initialise and startup the timers
    InitHeap();                                                     // initialise memory allocation
    initExtIO();
    initConsole();                                                  // initialise the USB or UART used for the console
    INTEnableInterrupts();
    uSec(1000000);
}

/*
 *
 */
unsigned int MiscGetOscSysClock( void )
{
unsigned int retfreq = 0;    
    
#ifndef SET_LOCAL_OSC_CLOCK
    if((*((unsigned int *)0xbfc0fff0)) == 0xFFFE0001)
    {
        retfreq = 12000000ul;
    }
    else if((*((unsigned int *)0xbfc0fff0)) == 0xFFFD0002)
    {
        retfreq = 24000000ul;    
    }
#else
    retfreq = SET_LOCAL_OSC_CLOCK;
#endif
    if( (retfreq != 12000000ul) && (retfreq != 24000000ul)) {
        retfreq = 12000000ul;
    }
    return retfreq;
}


/*
 *
 */
void MiscSetSpeed( unsigned int newspeed ) //__attribute__((optimize("-O0"))) 
{
OSC_SYS_TYPE clockSource = OSC_PRIMARY_WITH_PLL;
OSC_SYSPLL_FREQ_RANGE PLLFrequencyRange = OSC_SYSPLL_FREQ_RANGE_5M_TO_10M;
OSC_SYSPLL_IN_DIV PLLInDiv;
unsigned int PLLMULT;
OSC_SYSPLL_OUT_DIV PLLODIV;
unsigned int in_sysfreq;

    in_sysfreq = MiscGetOscSysClock();
    if(in_sysfreq == 12000000ul)
    {
        PLLInDiv = OSC_SYSPLL_IN_DIV_2;
    }
    else
    {
        PLLInDiv = OSC_SYSPLL_IN_DIV_4;
    }

    // get the new value for the PLL multiplier and output dividers
    switch( newspeed ) { 
        case 258000000: PLLMULT = 86; PLLODIV = OSC_SYSPLL_OUT_DIV_2; break;
        case 252000000: PLLMULT = 84; PLLODIV = OSC_SYSPLL_OUT_DIV_2; break;
        case 228000000: PLLMULT = 76; PLLODIV = OSC_SYSPLL_OUT_DIV_2; break;
        case 204000000: PLLMULT = 68; PLLODIV = OSC_SYSPLL_OUT_DIV_2; break;
        case 198000000: PLLMULT = 66; PLLODIV = OSC_SYSPLL_OUT_DIV_2; break;
        case 156000000: PLLMULT = 52; PLLODIV = OSC_SYSPLL_OUT_DIV_2; break;
        case 120000000: PLLMULT = 40; PLLODIV = OSC_SYSPLL_OUT_DIV_2; break;
        case 99000000:  PLLMULT = 33; PLLODIV = OSC_SYSPLL_OUT_DIV_2; break;
        case 60000000:  PLLMULT = 20; PLLODIV = OSC_SYSPLL_OUT_DIV_2; break;
        default: return; break;
    }    
    
    MiscPBClkInitialize(newspeed);
    SystemUnlock();
    OSCSysClockSelect(OSC_FRC);
    while(!OSCIsClockSwitchingComplete());
    SysWaitStateConfig(newspeed);
    SystemLock();

    MiscClkSystemFrequencySet(newspeed);
    
    mSysUnlockOpLock((OSCPLLClockUnlock()));
    while(-1 == OSCClockSourceSwitch(   clockSource,
                            PLLFrequencyRange,
                            PLLInDiv,
                            PLLMULT,
                            PLLODIV,
                            TRUE ));    

    PR4 = 500 * (BusSpeed/2/1000000) - 1;                       // Main timer ticks at 500 uSec
    TMR4 = (TMR4 * (newspeed >> 11)) / (ClockSpeed >> 11);      // and adjust its current count
    if(Option.SerialCon) UARTSetDataRate(UART1,  BusSpeed, Option.Baudrate);         // reset the console baud rate   
    if(com2_baud) UARTSetDataRate(UART3, BusSpeed, com2_baud);  // reset COM2 baud rate
    if(com3_baud) UARTSetDataRate(UART4, BusSpeed, com3_baud);  // reset COM3 baud rate
    if(com4_baud) UARTSetDataRate(UART1, BusSpeed, com4_baud);  // reset COM4 baud rate
    if(com1_baud) UARTSetDataRate(UART2, BusSpeed, com1_baud);  // reset COM1 baud rate    
}



/*******************************************************************************
 * Function:
 *  void Misc_ClkInitializeDefault( void )
 *
 *Summary:
 *  Initializes hardware and internal data structure of the System Clock.
 *
 *Description:
 *  This function initializes the hardware and internal data structure of System
 *  Clock Service.
 ******************************************************************************/
static void MiscPBClkInitialize( unsigned int cpuspeed )
{
OSC_PB_CLOCK_DIV_TYPE PB1ClockDivisor;
OSC_PB_CLOCK_DIV_TYPE PB2ClockDivisor;
OSC_PB_CLOCK_DIV_TYPE PB3ClockDivisor;
OSC_PB_CLOCK_DIV_TYPE PB4ClockDivisor;
OSC_PB_CLOCK_DIV_TYPE PB5ClockDivisor;
OSC_PB_CLOCK_DIV_TYPE PB7ClockDivisor = OSC_PB_CLOCK_DIV_1;
OSC_PB_CLOCK_DIV_TYPE PB8ClockDivisor;
unsigned int tmp_pbspeed;

    if( cpuspeed <= 100000000 ) {
        PB1ClockDivisor = OSC_PB_CLOCK_DIV_1;
        PB2ClockDivisor = OSC_PB_CLOCK_DIV_1;
        PB3ClockDivisor = OSC_PB_CLOCK_DIV_1;
        PB4ClockDivisor = OSC_PB_CLOCK_DIV_1;
        PB5ClockDivisor = OSC_PB_CLOCK_DIV_1;
        PB8ClockDivisor = OSC_PB_CLOCK_DIV_1; 
        tmp_pbspeed = cpuspeed;
    }
    else if(cpuspeed <= 200000000){
        PB1ClockDivisor = OSC_PB_CLOCK_DIV_2;
        PB2ClockDivisor = OSC_PB_CLOCK_DIV_2;
        PB3ClockDivisor = OSC_PB_CLOCK_DIV_2;
        PB4ClockDivisor = OSC_PB_CLOCK_DIV_2;
        PB5ClockDivisor = OSC_PB_CLOCK_DIV_2;
        PB8ClockDivisor = OSC_PB_CLOCK_DIV_2; 
        tmp_pbspeed = cpuspeed/2;        
    }
    else {
        PB1ClockDivisor = OSC_PB_CLOCK_DIV_3;
        PB2ClockDivisor = OSC_PB_CLOCK_DIV_3;
        PB3ClockDivisor = OSC_PB_CLOCK_DIV_3;
        PB4ClockDivisor = OSC_PB_CLOCK_DIV_3;
        PB5ClockDivisor = OSC_PB_CLOCK_DIV_3;
        PB8ClockDivisor = OSC_PB_CLOCK_DIV_3; 
        tmp_pbspeed = cpuspeed/3;        
    }

    SystemUnlock();
    
    OscFRCDivisorSelect(OSC_FRC_DIV_1);
    
    /* Enable Peripheral Bus 1 */
    OscPBClockDivisorSet(OSC_PERIPHERAL_BUS_1, PB1ClockDivisor);   
    /* Enable Peripheral Bus 2 */
    OscPBClockDivisorSet(OSC_PERIPHERAL_BUS_2, PB2ClockDivisor);
    OscPBOutputClockEnable(OSC_PERIPHERAL_BUS_2);
    /* Enable Peripheral Bus 3 */
    OscPBClockDivisorSet(OSC_PERIPHERAL_BUS_3, PB3ClockDivisor);
    OscPBOutputClockEnable(OSC_PERIPHERAL_BUS_3);
    /* Enable Peripheral Bus 4 */
    OscPBClockDivisorSet(OSC_PERIPHERAL_BUS_4, PB4ClockDivisor);
    OscPBOutputClockEnable(OSC_PERIPHERAL_BUS_4);
    /* Enable Peripheral Bus 5 */
    OscPBClockDivisorSet(OSC_PERIPHERAL_BUS_5, PB5ClockDivisor);
    OscPBOutputClockEnable(OSC_PERIPHERAL_BUS_5);
    /* Enable Peripheral Bus 7 */
    OscPBClockDivisorSet(OSC_PERIPHERAL_BUS_7, PB7ClockDivisor);
    OscPBOutputClockEnable(OSC_PERIPHERAL_BUS_7);
    /* Enable Peripheral Bus 8 */
    OscPBClockDivisorSet(OSC_PERIPHERAL_BUS_8, PB8ClockDivisor);
    OscPBOutputClockEnable(OSC_PERIPHERAL_BUS_8);    
  
    /* Disable REFCLKO1*/
    OscReferenceOscDisable(OSC_REFERENCE_1);
    /* Disable REFCLK1_OE*/
    OscReferenceOutputDisable(OSC_REFERENCE_1);   
    /* Disable REFCLKO2*/
    OscReferenceOscDisable(OSC_REFERENCE_2);
    /* Disable REFCLK2_OE*/
    OscReferenceOutputDisable(OSC_REFERENCE_2);
    /* Disable REFCLKO3*/
    OscReferenceOscDisable(OSC_REFERENCE_3);
    /* Disable REFCLK3_OE*/
    OscReferenceOutputDisable(OSC_REFERENCE_3);
    /* Disable REFCLKO4*/
    OscReferenceOscDisable(OSC_REFERENCE_4);
    /* Disable REFCLK4_OE*/
    OscReferenceOutputDisable(OSC_REFERENCE_4);
 
    SystemLock();
    
    BusSpeed = tmp_pbspeed;
}


/*******************************************************************************
 * Function:
 *  inline uint32_t Misc_ClkSystemFrequencyGet(void)
 *
 *Summary:
 *  Gets the system clock frequency in Hertz.
 *
 *Description:
 *  This function gets the System clock frequency in Hertz.
 *
 *Parameters:
 *  None.
 *
 *Returns:
 *  System clock frequency in Hertz.
 ******************************************************************************/
unsigned int MiscClkSystemFrequencyGet( void )
{
    return sys_clk_freq;
}


/*
 *
 */
static void MiscClkSystemFrequencySet( unsigned int setsysfreq )
{
    sys_clk_freq = setsysfreq;
}


uint32_t get_fattime(void)
{
    /* RTC should return time here */
    /* For now, just a value */
    SYS_FS_TIME time;
    time.packedTime = 0;

    if(year > 2010) {
        time.discreteTime.year = (year - 1980); // year is 2016
        time.discreteTime.month = month;    // Dec
        time.discreteTime.day = day;     // 10th date
        time.discreteTime.hour = hour;    // 3pm afternoon
        time.discreteTime.minute = minute;  // 06 min
        time.discreteTime.second = second;  // 00 sec        
    }
    else {
        // All FAT FS times are calculated based on 0 = 1980
        time.discreteTime.year = (2016 - 1980); // year is 2016
        time.discreteTime.month = 12;    // Dec
        time.discreteTime.day = 13;     // 10th date
        time.discreteTime.hour = 01;    // 1am
        time.discreteTime.minute = 00;  // 00 min
        time.discreteTime.second = 00;  // 00 sec
    }
    return (time.packedTime);
}

