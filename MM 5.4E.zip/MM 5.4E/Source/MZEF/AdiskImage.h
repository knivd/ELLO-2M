/* 
 * File:   AdiskImage.h
 * Author: Spas
 *
 * Created on 04 ???????? 2016, 21:10
 */

#ifndef ADISKIMAGE_H
#define	ADISKIMAGE_H

#ifdef	__cplusplus
extern "C" {
#endif
    
#define A_DISK_BYTE_PAGE_SIZE           16384
#define A_DISK_MEDIA_SIZE               DRV_NVM_BLOCK_MEMORY_SIZE                          //in KBytes
#define A_DISK_BYTE_SIZE                (A_DISK_MEDIA_SIZE*1024) 
#define A_DISK_START_ADDRESS            DRV_NVM_MEDIA_START_ADDRESS

extern const unsigned char __attribute__((space(prog),aligned(A_DISK_BYTE_PAGE_SIZE))) AdiskImage[A_DISK_BYTE_SIZE];

#ifdef	__cplusplus
}
#endif

#endif	/* ADISKIMAGE_H */

