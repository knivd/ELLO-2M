/***********************************************************************************************************************
MMBasic

Console.h

Header file defining the public functions and variables in Console.c

Copyright 2011 - 2016 Geoff Graham.  All Rights Reserved.

This file and modified versions of this file are supplied to specific individuals or organisations under the following
provisions:

- This file, or any files that comprise the MMBasic source (modified or not), may not be distributed or copied to any other
  person or organisation without written permission.

- Object files (.o and .hex files) generated using this file (modified or not) may not be distributed or copied to any other
  person or organisation without written permission.

- This file is provided in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

************************************************************************************************************************/

#ifndef _CONSOLE_H
#define _CONSOLE_H

//** USB INCLUDES ***********************************************************
#include "usb/driver/usb/usbhs/drv_usbhs.h"
#include "usb/usb/usb_device.h"
#include "usb/usb/usb_device_cdc.h"

// *****************************************************************************
/* System Objects

  Summary:
    Structure holding the system's object handles

  Description:
    This structure contains the object handles for all objects in the
    MPLAB Harmony project's system configuration.

  Remarks:
    These handles are returned from the "Initialize" functions for each module
    and must be passed into the "Tasks" function for each module.
*/
typedef struct
{
    SYS_MODULE_OBJ  sysDevcon;
    SYS_MODULE_OBJ  sysTmr;
    SYS_MODULE_OBJ  drvTmr0;
    SYS_MODULE_OBJ  drvUSBObject;
    
    SYS_MODULE_OBJ  usbDevObject0;



} SYSTEM_OBJECTS;


// *****************************************************************************
/* Application States

  Summary:
    Application states enumeration

  Description:
    This enumeration defines the valid application states.  These states
    determine the behavior of the application at various times.
*/

typedef enum
{
  /* Application opens and attaches the device here */
    APP_STATE_INIT = 0,

    /* Application waits for device configuration*/
    APP_STATE_WAIT_FOR_CONFIGURATION,

    /* Check if we got data from CDC */
    APP_STATE_CHECK_CDC_READ_WRITE,

    /* Application Error state*/
    APP_STATE_ERROR

} APP_STATES;


// *****************************************************************************
/* Application Data

  Summary:
    Holds application data

  Description:
    This structure holds the application's data.

  Remarks:
    Application strings and buffers are be defined outside this structure.
 */

typedef struct
{
    /* Device layer handle returned by device layer open function */
    USB_DEVICE_HANDLE deviceHandle;

    /* Application CDC Instance */
    USB_DEVICE_CDC_INDEX cdcInstance;

    /* Application USART Driver handle */
    DRV_HANDLE usartHandle;

    /* Application's current state*/
    APP_STATES state;

    /* Device configured state */
    bool isConfigured;

    /* Read Data Buffer */
    uint8_t * readBuffer;

    /* Set Line Coding Data */
    USB_CDC_LINE_CODING setLineCodingData;

    /* Get Line Coding Data */
    USB_CDC_LINE_CODING getLineCodingData;

    /* Control Line State */
    USB_CDC_CONTROL_LINE_STATE controlLineStateData;

    /* Break data */
    uint16_t breakData;

    /* Read transfer handle */
    USB_DEVICE_CDC_TRANSFER_HANDLE readTransferHandle;

    /* Write transfer handle */
    USB_DEVICE_CDC_TRANSFER_HANDLE writeTransferHandle;

    /* True if a character was read */
    bool isReadComplete;

    /* True if a character was written*/
    bool isWriteComplete;

    /* UART2 received data */
    uint8_t * uartReceivedData;

    /* Read Buffer Length*/
    size_t readLength;

    /* Current UART TX Count*/
    size_t uartTxCount;


} APP_DATA;


#define CONSOLE_RX_BUF_SIZE 2048
extern char ConsoleRxBuf[CONSOLE_RX_BUF_SIZE];
extern volatile int ConsoleRxBufHead;
extern volatile int ConsoleRxBufTail;

#define CONSOLE_TX_BUF_SIZE 4096                    // this is made a large size so that the serial console does not slow down the USB and LCD consoles
extern char ConsoleTxBuf[CONSOLE_TX_BUF_SIZE];
extern volatile int ConsoleTxBufHead;
extern volatile int ConsoleTxBufTail;

// declare the console I/O functions
extern void initConsole(void);
extern int MMgetchar(void);
extern int kbhitConsole(void);
extern void putConsole(int c);
extern int getConsole(void);

extern inline void CheckAbort(void);

extern void putConsole(int c);
extern int kbhitConsole(void);

extern void initSerialConsole(void);
extern void CloseSerialConsole(void);
extern void initUSBConsole(void);
extern void CloseUSBConsole(void);
extern void SerialConsolePutC(int c);

extern void USBPutC(int c);
extern void SerUSBPutC(char c);
extern void SerUSBPutS(char *s);

/*****************************************************************************************************************************
USB specific defines
******************************************************************************************************************************/
// declare the USB I/O functions
extern void CheckUSB(void);

// PIC32MX U1OTGSTAT emulation (only for VBUSVD bit).
#define U1OTGSTAT                       ((USBOTGbits.VBUS == 3) ? 1 : 0)

/* Application USB Device CDC Read Buffer Size. This should be a multiple of
 * the CDC Bulk Endpoint size */
#define APP_READ_BUFFER_SIZE            1024

#define USB_RX_BUFFER_SIZE	APP_READ_BUFFER_SIZE
#define USB_TX_BUFFER_SIZE              4096

extern volatile unsigned int USBTimer;

#define USBTIMEOUT  30                  // timeout for USB transmit data

#endif /* _CONSOLE_H */