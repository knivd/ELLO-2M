/* 
 * File:   usb_system_config.h
 * Author: Spas Spasov
 *
 * Created on November 2016
 */

#ifndef USB_SYSTEM_CONFIG_H
#define	USB_SYSTEM_CONFIG_H

#include "osal/osal.h"
#include "system/system.h"

#ifdef	__cplusplus
extern "C" {
#endif

    
/*** USB Driver Configuration ***/
/* Enables Device Support */
#define DRV_USBHS_DEVICE_SUPPORT                    true

/* Disable Device Support */
#define DRV_USBHS_HOST_SUPPORT                      false

/* Maximum USB driver instances */
#define DRV_USBHS_INSTANCES_NUMBER                  1

/* Interrupt mode enabled */
#define DRV_USBHS_INTERRUPT_MODE                    true

/* Number of Endpoints used */
#define DRV_USBHS_ENDPOINTS_NUMBER                  4         // cdc + msd

/*** USB Device Stack Configuration ***/
/* The USB Device Layer will not initialize the USB Driver */
#define USB_DEVICE_DRIVER_INITIALIZE_EXPLICIT

/* Maximum device layer instances */
#define USB_DEVICE_INSTANCES_NUMBER                 1

/* EP0 size in bytes */
#define USB_DEVICE_EP0_BUFFER_SIZE                  64

/* Enable SOF Events */ 
//#define USB_DEVICE_SOF_EVENT_ENABLE

/* Maximum instances of CDC function driver */
#define USB_DEVICE_CDC_INSTANCES_NUMBER             1
    
/* CDC Transfer Queue Size for both read and
   write. Applicable to all instances of the
   function driver */
#define USB_DEVICE_CDC_QUEUE_DEPTH_COMBINED         3
    
/**/
#define USE_UTIMER_USBDEVICE_SYS_TASK    
    
#ifdef  USE_UTIMER_USBDEVICE_SYS_TASK
/* USB peripherial Timer instances used for USB DRV */
#define USB_DEVICE_UTIMER_NUMBER                    8    
#define USB_DEVICE_UTIMER_INT_PRIORITY              3
    
/**/    
#define USB_DEVICE_UTIMER_PB_FREQ                   MiscClkSystemFrequencyGet()
#define USB_DEVICE_UTIMER_PRESCALE                  256
#define USB_DEVICE_UTIMER_TOGGLES_PER_SEC           500
#define USB_DEVICE_UTIMER_TICK                      (USB_DEVICE_UTIMER_PB_FREQ/USB_DEVICE_UTIMER_PRESCALE/USB_DEVICE_UTIMER_TOGGLES_PER_SEC)    
    
#define USB_SYS_DEBUG_MESSAGE(message)
#define USB_SYS_DEBUG(message) 
#endif    

/*** USB MSD Device Stack Configuration ***/

#define USB_DEVICE_MSD_NUM_SECTOR_BUFFERS           1

/* Enable SOF Events */ 
#define USB_DEVICE_SOF_EVENT_ENABLE     

/* Number of MSD Function driver instances in the application */
#define USB_DEVICE_MSD_INSTANCES_NUMBER             1

/* Number of Logical Units */
#define USB_DEVICE_MSD_LUNS_NUMBER                  1

    
/*** NVM Driver Configuration ***/   
    
/* Size of disk image (in KB) in Program Flash Memory */
#define DRV_NVM_BLOCK_MEMORY_SIZE                   864  
#define DRV_NVM_INSTANCES_NUMBER                    1
#define DRV_NVM_CLIENTS_NUMBER                      5
#define DRV_NVM_BUFFER_OBJECT_NUMBER                5

#define DRV_NVM_INTERRUPT_MODE                      true
#define DRV_NVM_INTERRUPT_SOURCE                    INT_SOURCE_FLASH_CONTROL

#define DRV_NVM_MEDIA_SIZE                          DRV_NVM_BLOCK_MEMORY_SIZE
#define DRV_NVM_MEDIA_START_ADDRESS                 0x9D128000

#define DRV_NVM_ERASE_WRITE_ENABLE
  
#define DRV_NVM_SYS_FS_REGISTER    
    
    
/*** File System Service Configuration ***/

#define SYS_FS_MEDIA_NUMBER                         1

#define SYS_FS_VOLUME_NUMBER                        1

#define SYS_FS_AUTOMOUNT_ENABLE                     false
#define SYS_FS_MAX_FILES                            1
#define SYS_FS_MAX_FILE_SYSTEM_TYPE                 1
#define SYS_FS_MEDIA_MAX_BLOCK_SIZE                 512
#define SYS_FS_MEDIA_MANAGER_BUFFER_SIZE            2048

#define SYS_FS_MEDIA_TYPE_IDX0 				
#define SYS_FS_TYPE_IDX0 	    
    
    
#ifdef	__cplusplus
}
#endif

#endif	/* USB_SYSTEM_CONFIG_H */

