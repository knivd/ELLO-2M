/***********************************************************************************************************************
Configuration_Bits.h

Include file that contains the configuration details for the Micromite using MMBasic.

Copyright 2011 - 2017 Geoff Graham.  All Rights Reserved.

This file and modified versions of this file are supplied to specific individuals or organisations under the following
provisions:

- This file, or any files that comprise the MMBasic source (modified or not), may not be distributed or copied to any other
  person or organisation without written permission.

- Object files (.o and .hex files) generated using this file (modified or not) may not be distributed or copied to any other
  person or organisation without written permission.

- This file is provided in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

************************************************************************************************************************/

#ifndef CONFIGURATION_BITS_H
#define	CONFIGURATION_BITS_H

#ifdef	__cplusplus
extern "C" {
#endif

// ****************************************************************************
// Section: Configuration Bits
// ****************************************************************************

/*** DEVCFG0 ***/
#pragma config DEBUG =      OFF
#pragma config JTAGEN =     OFF
#pragma config ICESEL =     ICS_PGx1
#pragma config TRCEN =      OFF
#pragma config BOOTISA =    MIPS32
#pragma config FECCCON =    OFF_UNLOCKED
#pragma config FSLEEP =     VREGS
#pragma config DBGPER =     PG_ALL
#pragma config SMCLR =      MCLR_NORM
#pragma config SOSCGAIN =   GAIN_2X
#pragma config SOSCBOOST =  ON
#pragma config POSCGAIN =   GAIN_2X
#pragma config POSCBOOST =  OFF
#pragma config EJTAGBEN =   NORMAL
#pragma config CP =         OFF

/*** DEVCFG1 ***/
#pragma config FNOSC =      POSC
#pragma config DMTINTV =    WIN_127_128
#pragma config FSOSCEN =    OFF
#pragma config IESO =       ON
#pragma config POSCMOD =    EC
#pragma config OSCIOFNC =   OFF
#pragma config FCKSM =      CSECME
#pragma config WDTPS =      PS1024
#pragma config WDTSPGM =    STOP
#pragma config FWDTEN =     OFF
#pragma config WINDIS =     NORMAL
#pragma config FWDTWINSZ =  WINSZ_25
#pragma config DMTCNT =     DMT31
#pragma config FDMTEN =     OFF
    
/*** DEVCFG2 ***/
#pragma config FPLLIDIV =   DIV_2
#pragma config FPLLRNG =    RANGE_5_10_MHZ
#pragma config FPLLICLK =   PLL_POSC
#pragma config FPLLMULT =   MUL_66
#pragma config FPLLODIV =   DIV_2
#pragma config UPLLFSEL =   FREQ_12MHZ
    
/*** DEVCFG3 ***/
#pragma config USERID =     0xFFFF
#pragma config FMIIEN =     OFF
#pragma config FETHIO =     OFF
#pragma config PGL1WAY =    OFF
#pragma config PMDL1WAY =   OFF
#pragma config IOL1WAY =    OFF
#pragma config FUSBIDIO =   OFF

/*** BF1SEQ3 ***/
#pragma config TSEQ =       0x0001
#pragma config CSEQ =       0xFFFE

  
/*** ADEVCFG0 ***/
#pragma config_alt DEBUG =      OFF
#pragma config_alt JTAGEN =     OFF
#pragma config_alt ICESEL =     ICS_PGx1
#pragma config_alt TRCEN =      OFF
#pragma config_alt BOOTISA =    MIPS32
#pragma config_alt FECCCON =    OFF_UNLOCKED
#pragma config_alt FSLEEP =     VREGS
#pragma config_alt DBGPER =     PG_ALL
#pragma config_alt SMCLR =      MCLR_NORM
#pragma config_alt SOSCGAIN =   GAIN_2X
#pragma config_alt SOSCBOOST =  ON
#pragma config_alt POSCGAIN =   GAIN_2X
#pragma config_alt POSCBOOST =  OFF
#pragma config_alt EJTAGBEN =   NORMAL
#pragma config_alt CP =         OFF

/*** ADEVCFG1 ***/
#pragma config_alt FNOSC =      POSC
#pragma config_alt DMTINTV =    WIN_127_128
#pragma config_alt FSOSCEN =    OFF
#pragma config_alt IESO =       ON
#pragma config_alt POSCMOD =    EC
#pragma config_alt OSCIOFNC =   OFF
#pragma config_alt FCKSM =      CSECME
#pragma config_alt WDTPS =      PS1024
#pragma config_alt WDTSPGM =    STOP
#pragma config_alt FWDTEN =     OFF
#pragma config_alt WINDIS =     NORMAL
#pragma config_alt FWDTWINSZ =  WINSZ_25
#pragma config_alt DMTCNT =     DMT31
#pragma config_alt FDMTEN =     OFF
    
/*** ADEVCFG2 ***/
#pragma config_alt FPLLIDIV =   DIV_2
#pragma config_alt FPLLRNG =    RANGE_5_10_MHZ
#pragma config_alt FPLLICLK =   PLL_POSC
#pragma config_alt FPLLMULT =   MUL_66
#pragma config_alt FPLLODIV =   DIV_2
#pragma config_alt UPLLFSEL =   FREQ_12MHZ
    
/*** ADEVCFG3 ***/
#pragma config_alt USERID =     0xFFFF
#pragma config_alt FMIIEN =     OFF
#pragma config_alt FETHIO =     OFF
#pragma config_alt PGL1WAY =    OFF
#pragma config_alt PMDL1WAY =   OFF
#pragma config_alt IOL1WAY =    OFF
#pragma config_alt FUSBIDIO =   OFF   

/*** ABF1SEQ3 ***/
#pragma config_alt TSEQ =       0x0001
#pragma config_alt CSEQ =       0xFFFE
    
    
    
    
/*** BF2DEVCFG0 ***/
#pragma config_bf2 DEBUG =      OFF
#pragma config_bf2 JTAGEN =     ON
#pragma config_bf2 ICESEL =     ICS_PGx1
#pragma config_bf2 TRCEN =      OFF
#pragma config_bf2 BOOTISA =    MIPS32
#pragma config_bf2 FECCCON =    OFF_UNLOCKED
#pragma config_bf2 FSLEEP =     VREGS
#pragma config_bf2 DBGPER =     PG_ALL
#pragma config_bf2 SMCLR =      MCLR_NORM
#pragma config_bf2 SOSCGAIN =   GAIN_2X
#pragma config_bf2 SOSCBOOST =  ON
#pragma config_bf2 POSCGAIN =   GAIN_2X
#pragma config_bf2 POSCBOOST =  OFF
#pragma config_bf2 EJTAGBEN =   REDUCED
#pragma config_bf2 CP =         OFF

/*** BF2DEVCFG1 ***/
#pragma config_bf2 FNOSC =      POSC
#pragma config_bf2 DMTINTV =    WIN_127_128
#pragma config_bf2 FSOSCEN =    OFF
#pragma config_bf2 IESO =       ON
#pragma config_bf2 POSCMOD =    EC
#pragma config_bf2 OSCIOFNC =   OFF
#pragma config_bf2 FCKSM =      CSECME
#pragma config_bf2 WDTPS =      PS1024
#pragma config_bf2 WDTSPGM =    STOP
#pragma config_bf2 FWDTEN =     OFF
#pragma config_bf2 WINDIS =     NORMAL
#pragma config_bf2 FWDTWINSZ =  WINSZ_25
#pragma config_bf2 DMTCNT =     DMT31
#pragma config_bf2 FDMTEN =     OFF
    
/*** BF2DEVCFG2 ***/
#pragma config_bf2 FPLLIDIV =   DIV_4
#pragma config_bf2 FPLLRNG =    RANGE_5_10_MHZ
#pragma config_bf2 FPLLICLK =   PLL_POSC
#pragma config_bf2 FPLLMULT =   MUL_66
#pragma config_bf2 FPLLODIV =   DIV_2
#pragma config_bf2 UPLLFSEL =   FREQ_24MHZ
    
/*** BF2DEVCFG3 ***/
#pragma config_bf2 USERID =     0xFFFF
#pragma config_bf2 FMIIEN =     OFF
#pragma config_bf2 FETHIO =     OFF
#pragma config_bf2 PGL1WAY =    OFF
#pragma config_bf2 PMDL1WAY =   OFF
#pragma config_bf2 IOL1WAY =    OFF
#pragma config_bf2 FUSBIDIO =   OFF   
    
/*** BF2SEQ3 ***/
#pragma config_bf2 TSEQ =       0xFFFF
#pragma config_bf2 CSEQ =       0xFFFF    
    
    
/*** ABF2DEVCFG0 ***/
#pragma config_abf2 DEBUG =      OFF
#pragma config_abf2 JTAGEN =     ON
#pragma config_abf2 ICESEL =     ICS_PGx1
#pragma config_abf2 TRCEN =      OFF
#pragma config_abf2 BOOTISA =    MIPS32
#pragma config_abf2 FECCCON =    OFF_UNLOCKED
#pragma config_abf2 FSLEEP =     VREGS
#pragma config_abf2 DBGPER =     PG_ALL
#pragma config_abf2 SMCLR =      MCLR_NORM
#pragma config_abf2 SOSCGAIN =   GAIN_2X
#pragma config_abf2 SOSCBOOST =  ON
#pragma config_abf2 POSCGAIN =   GAIN_2X
#pragma config_abf2 POSCBOOST =  OFF
#pragma config_abf2 EJTAGBEN =   REDUCED
#pragma config_abf2 CP =         OFF

/*** ABF2DEVCFG1 ***/
#pragma config_abf2 FNOSC =      POSC
#pragma config_abf2 DMTINTV =    WIN_127_128
#pragma config_abf2 FSOSCEN =    OFF
#pragma config_abf2 IESO =       ON
#pragma config_abf2 POSCMOD =    EC
#pragma config_abf2 OSCIOFNC =   OFF
#pragma config_abf2 FCKSM =      CSECME
#pragma config_abf2 WDTPS =      PS1024
#pragma config_abf2 WDTSPGM =    STOP
#pragma config_abf2 FWDTEN =     OFF
#pragma config_abf2 WINDIS =     NORMAL
#pragma config_abf2 FWDTWINSZ =  WINSZ_25
#pragma config_abf2 DMTCNT =     DMT31
#pragma config_abf2 FDMTEN =     OFF
    
/*** ABF2DEVCFG2 ***/
#pragma config_abf2 FPLLIDIV =   DIV_4
#pragma config_abf2 FPLLRNG =    RANGE_5_10_MHZ
#pragma config_abf2 FPLLICLK =   PLL_POSC
#pragma config_abf2 FPLLMULT =   MUL_66
#pragma config_abf2 FPLLODIV =   DIV_2
#pragma config_abf2 UPLLFSEL =   FREQ_24MHZ
    
/*** ABF2DEVCFG3 ***/
#pragma config_abf2 USERID =     0xFFFF
#pragma config_abf2 FMIIEN =     OFF
#pragma config_abf2 FETHIO =     OFF
#pragma config_abf2 PGL1WAY =    OFF
#pragma config_abf2 PMDL1WAY =   OFF
#pragma config_abf2 IOL1WAY =    OFF
#pragma config_abf2 FUSBIDIO =   OFF   
    
/*** ABF2SEQ3 ***/
#pragma config_abf2 TSEQ =       0xFFFF
#pragma config_abf2 CSEQ =       0xFFFF       


#ifdef	__cplusplus
}
#endif

#endif	/* CONFIGURATION_BITS_H */
