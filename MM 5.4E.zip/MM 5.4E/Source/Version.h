/***********************************************************************************************************************
MMBasic

Version.h

Copyright 2011 - 2017 Geoff Graham.  All Rights Reserved.

This file and modified versions of this file are supplied to specific individuals or organisations under the following
provisions:

- This file, or any files that comprise the MMBasic source (modified or not), may not be distributed or copied to any other
  person or organisation without written permission.

- Object files (.o and .hex files) generated using this file (modified or not) may not be distributed or copied to any other
  person or organisation without written permission.

- This file is provided in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

 ************************************************************************************************************************/

// Uncomment the following line if you want the "Lite" version of the MX170 code
//#define LITE

#define ELLO_2M

#if defined(MX170)
    #define VERSION         "5.04.04"
#if !defined(LITE)
    #define MES_SIGNON  "Micromite MKII MMBasic Ver " VERSION "\r\n"
#else
    #define MES_SIGNON  "Micromite Lite MMBasic Ver " VERSION "\r\n"
#endif
#elif defined(MX470) && !defined(MZEF)
    #define VERSION         "5.04.04"
    #define MES_SIGNON  "Micromite Plus MMBasic Ver " VERSION "\r\n"
#elif defined(MZEF)
    #define VERSION         "5.04.04"
    #define MES_SIGNON  "Micromite MZ MMBasic Ver " VERSION "\r\n"
#endif

#define YEAR	       "2011-2017"
#if defined(MX270D)
    #define COPYRIGHT  "Copyright " YEAR " Geoff Graham\r\n" "Copyright " "2017" " Spas Spasov & KnivD\r\n"
#elif defined(MX170)
    #define COPYRIGHT  "Copyright " YEAR " Geoff Graham\r\n"
#elif defined(MX470)
#ifndef ELLO_2M
    #define COPYRIGHT  "Copyright " YEAR " Geoff Graham\r\n" "Copyright " "2017" " Spas Spasov & KnivD\r\n"
#else
    #define COPYRIGHT  "Copyright " YEAR " Geoff Graham\r\nLicensed to use with ELLO Computer\r\n"  "Copyright " "2017" " Spas Spasov & KnivD\r\n"
#endif
#endif


// debugging options
//#define DEBUG_DISPLAY_ILI9341
//#define DEBUG_DISPLAY_4_INCH
//#define DEBUG_DISPLAY_5_INCH_64PIN
//#define DEBUG_DISPLAY_5_INCH_100PIN
//#define DEBUG_DISPLAY_7_INCH
//#define DEBUGMODE                     // no display specified


#if defined(DEBUG_DISPLAY_5_INCH_64PIN) || defined(DEBUG_DISPLAY_5_INCH_100PIN)
#define DEBUG_DISPLAY_5_INCH
#endif

#if defined(DEBUG_DISPLAY_ILI9341) || defined(DEBUG_DISPLAY_4_INCH) || defined(DEBUG_DISPLAY_5_INCH) || defined(DEBUG_DISPLAY_7_INCH)
#define DEBUGMODE
#endif

#if defined(__DEBUG) && !defined(DEBUGMODE)
    #define DEBUGMODE
#endif

#if defined(MX470)
    #if defined(LITE)
        #error "Lite version not valid for the MX470"
    #endif
#endif

