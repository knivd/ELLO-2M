/***********************************************************************************************************************
MMBasic

plib.h

Defines the hardware aspects for PIC32-Generic MMBasic.

Copyright 2011 - 2017 Geoff Graham.  All Rights Reserved.

This file and modified versions of this file are supplied to specific individuals or organisations under the following
provisions:

- This file, or any files that comprise the MMBasic source (modified or not), may not be distributed or copied to any other
  person or organisation without written permission.

- Object files (.o and .hex files) generated using this file (modified or not) may not be distributed or copied to any other
  person or organisation without written permission.

- This file is provided in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

************************************************************************************************************************/

#ifndef PLIB_MMB_H
#define	PLIB_MMB_H

#include <xc.h>

#if defined(__PIC32MX__)
    #define microinstr  mips16
    #define _SUPPRESS_PLIB_WARNING                      // required for XC1.33  Later compiler versions will need PLIB to be installed
    #include <plib.h>  
#elif defined(__PIC32MZ__)
    #define microinstr  nomicromips
    #include <errno.h>
    #define NVM_USE_ADDITIONAL_SYNCHRO
    #include "MZEF/mz_libs/include/plib_mz.h"           // MZ peripheral libraries
#else

#endif

#endif	/* PLIB_MMB_H */

