/***********************************************************************************************************************
MMBasic

IOPorts.h

Include file that defines the IOPins for the PIC32 chip in MMBasic.
  
Copyright 2011 - 2017 Geoff Graham.  All Rights Reserved.

This file and modified versions of this file are supplied to specific individuals or organisations under the following 
provisions:

- This file, or any files that comprise the MMBasic source (modified or not), may not be distributed or copied to any other
  person or organisation without written permission.

- Object files (.o and .hex files) generated using this file (modified or not) may not be distributed or copied to any other
  person or organisation without written permission.

- This file is provided in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of 
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

************************************************************************************************************************/

#include "../General/Flash.h"

#if !defined(__32MX270F256D__)
       #error Processor not supported
#endif


#define _DEVID_ (*(volatile unsigned int *)0xBF80F220)
#define PIC32MX170F256B_DEVID  0x06610053
#define PIC32MX270F256B_DEVID  0x06600053
#define PIC32MX170F256D_DEVID  0x0661A053
#define PIC32MX270F256D_DEVID  0x0660A053
#define HAS_USB                ((_DEVID_ & 0xfffffff) == PIC32MX270F256B_DEVID || (_DEVID_ & 0xfffffff) == PIC32MX270F256D_DEVID)
#define HAS_28PINS             ((_DEVID_ & 0xfffffff) == PIC32MX170F256B_DEVID || (_DEVID_ & 0xfffffff) == PIC32MX270F256B_DEVID)
#define HAS_44PINS             (!HAS_28PINS)

// these are the valid peek/poke memory ranges for the MX170/MX270
#define PEEKRANGE(a) ((a >= 0xA0000000 && a <= 0xA000FFFF) || (a >= 0x9D000000 && a <= 0x9D03FFFF) || (a >= 0x9FC00000 && a <= 0x9FC00BFF) || (a >= 0xBF800000 && a <= 0xBF8FFFFF))
#define POKERANGE(a) ((a >= 0xA0000000 && a <= 0xA000FFFF) || (a >= 0xBF800000 && a <= 0xBF8FFFFF))

// General defines
#define P_INPUT				1						// for setting the TRIS on I/O bits
#define P_OUTPUT			0
#define P_ON				1
#define P_OFF				0

// Constant definitions of the port registers in the 44-pin chips
#define ADDR_PORTA          (volatile unsigned int *)0xbf886020
#define ADDR_PORTB          (volatile unsigned int *)0xbf886120
#define ADDR_PORTC          (volatile unsigned int *)0xbf886220

// Structure that defines the SFR, bit number and mode for each I/O pin
struct s_PinDef {
    volatile unsigned int *sfr;     // this is the port register (defined above), eg ADDR_PORTB for port B
    unsigned char bitnbr;           // this is the bit number of the port, eg the 7 in B7
    unsigned char mode;             // the various modes that an I/O pin can be set to (defined below)
    unsigned char anChan;           // if the input supports analog this is the analog channel number
};
    
// Defines for the various modes that an I/O pin can be set to
#define UNUSED       (1 << 0)
#define ANALOG_IN    (1 << 1)
#define DIGITAL_IN   (1 << 2)
#define COUNTING     (1 << 3)
#define DIGITAL_OUT  (1 << 4)
#define DO_NOT_RESET (1 << 5)

#define NBR_PINS_28CHIP     26					    // number of pins for external i/o on a 28 pin chip
#define NBR_PINS_44CHIP     44					    // number of pins for external i/o on a 44 pin chip
#define NBRPINS             (HAS_28PINS ? NBR_PINS_28CHIP : NBR_PINS_44CHIP)	// number of pins for external i/o
#define MAXNBRPINS          44
    

// Define the structure for the I/O pins
// the first element of the structure contains a pointer to the SFR for the port to be used
// the second element is the bit number within that port to use
// the third is a set of flags that defines what that I/O pin can do
#if defined(DEFINE_PINDEF_TABLE)
#ifdef __DEBUG
const struct s_PinDef PinDef28[NBR_PINS_28CHIP + 1] = {                                               // debug cannot work with the table in boot flash
#else
const struct s_PinDef __attribute__((address(0x9FC00500))) PinDef28[NBR_PINS_28CHIP + 1] = {  // place the table in boot flash
#endif

};

#ifdef __DEBUG
const struct s_PinDef PinDef44[NBR_PINS_44CHIP + 1] = {                                                                // debug cannot work with the table in boot flash
#else
const struct s_PinDef __attribute__((address(0x9FC00500 + sizeof(PinDef28)))) PinDef44[NBR_PINS_44CHIP + 1] = {  // place the table in boot flash
#endif
    { NULL,  0, UNUSED },                                                       // pin 0
    { ADDR_PORTB,  9, DIGITAL_IN | DIGITAL_OUT },                               // pin 1    I2C_SDA
    { ADDR_PORTC,  6, DIGITAL_IN | DIGITAL_OUT },                               // pin 2
    { ADDR_PORTC,  7, DIGITAL_IN | DIGITAL_OUT },                               // pin 3
    { ADDR_PORTC,  8, DIGITAL_IN | DIGITAL_OUT },                               // pin 4
    { ADDR_PORTC,  9, DIGITAL_IN | DIGITAL_OUT },                               // pin 5
    { NULL,  0, UNUSED },                                                       // pin 6
    { NULL,  0, UNUSED },                                                       // pin 7
    { NULL,  0, UNUSED | DO_NOT_RESET },                                        // pin 8    USBP
    { NULL,  0, UNUSED | DO_NOT_RESET },                                        // pin 9    USBM
    { NULL,  0, UNUSED },                                                       // pin 10
    { ADDR_PORTB,  13, ANALOG_IN | DIGITAL_IN | DIGITAL_OUT, 11 },              // pin 11
//
    { ADDR_PORTA,  10, DIGITAL_IN | DIGITAL_OUT },                              // pin 12
    { ADDR_PORTA,  7, DIGITAL_IN | DIGITAL_OUT },                               // pin 13
    { ADDR_PORTB,  14, ANALOG_IN | DIGITAL_IN | DIGITAL_OUT, 10 },              // pin 14   SPI_CLK_CLOCK
    { ADDR_PORTB,  15, ANALOG_IN | DIGITAL_IN | DIGITAL_OUT, 9 },               // pin 15
    { NULL,  0, UNUSED },                                                       // pin 16
    { NULL,  0, UNUSED },                                                       // pin 17
    { NULL,  0, UNUSED },                                                       // pin 18
#if defined(DEBUGMODE)
    { NULL,  0, UNUSED | DO_NOT_RESET },                                        // pin 19  ICSP PGD
    { NULL,  0, UNUSED | DO_NOT_RESET },                                        // pin 20  ICSP PGC
#else    
    { ADDR_PORTA,  0, ANALOG_IN | DIGITAL_IN | DIGITAL_OUT, 0 },                // pin 19  ICSP PGD
    { ADDR_PORTA,  1, ANALOG_IN | DIGITAL_IN | DIGITAL_OUT, 1 },                // pin 20  ICSP PGC, SPI_OUT_MOSI
#endif
    { ADDR_PORTB,  0, ANALOG_IN | DIGITAL_IN | DIGITAL_OUT, 2 },                // pin 21
    { ADDR_PORTB,  1, ANALOG_IN | DIGITAL_IN | DIGITAL_OUT, 3 },                // pin 22
    { ADDR_PORTB,  2, ANALOG_IN | DIGITAL_IN | DIGITAL_OUT, 4 },                // pin 23   COM4_RX
    { ADDR_PORTB,  3, ANALOG_IN | DIGITAL_IN | DIGITAL_OUT, 5 },                // pin 24   COM4_TX
    { ADDR_PORTC,  0, ANALOG_IN | DIGITAL_IN | DIGITAL_OUT, 6 },                // pin 25
    { ADDR_PORTC,  1, ANALOG_IN | DIGITAL_IN | DIGITAL_OUT, 7 },                // pin 26
    { ADDR_PORTC,  2, ANALOG_IN | DIGITAL_IN | DIGITAL_OUT, 8 },                // pin 27   COM1_TX
    { NULL,  0, UNUSED },                                                       // pin 28
    { NULL,  0, UNUSED },                                                       // pin 29
    { NULL,  0, UNUSED },                                                       // pin 30   OSC1
    { NULL,  0, UNUSED },                                                       // pin 31   OSC2
    { ADDR_PORTA,  8, DIGITAL_IN | DIGITAL_OUT },                               // pin 32   COM1_RX
    { NULL,  0, UNUSED },                                                       // pin 33   CONSOLE Tx (DATA OUT)
//
    { NULL,  0, UNUSED },                                                       // pin 34   CONSOLE Rx (DATA IN)
    { ADDR_PORTA,  9, DIGITAL_IN | DIGITAL_OUT },                               // pin 35
    { ADDR_PORTC,  3, ANALOG_IN | DIGITAL_IN | DIGITAL_OUT, 12 },               // pin 36
    { ADDR_PORTC,  4, DIGITAL_IN | DIGITAL_OUT },                               // pin 37
    { ADDR_PORTC,  5, DIGITAL_IN | DIGITAL_OUT },                               // pin 38
    { NULL,  0, UNUSED },                                                       // pin 39
    { NULL,  0, UNUSED },                                                       // pin 40
    { ADDR_PORTB,  5, DIGITAL_IN | DIGITAL_OUT },                               // pin 41   SPI_INP_MISO
    { NULL,  0, UNUSED },                                                       // pin 42
    { ADDR_PORTB,  7, DIGITAL_IN | DIGITAL_OUT },                               // pin 43
    { ADDR_PORTB,  8, DIGITAL_IN | DIGITAL_OUT },                               // pin 44   I2C_SCL
};

#else
    const extern struct s_PinDef PinDef28[];
    const extern struct s_PinDef PinDef44[];
#endif      // DEFINE_PINDEF_TABLE

extern struct s_PinDef *PinDef;


// Define the counting pin numbers.  INT1PIN refers to the PIC32 external interrupt #1, an so on for the others
#define INT1PIN                 (37)
#define INT1PIN_OPEN            PPSInput(4, INT1, RPC4)
#define INT1PIN_CLOSE           PPSInput(4, INT1, NULL)

#define INT2PIN                 (36)
#define INT2PIN_OPEN            PPSInput(3, INT2, RPC3)
#define INT2PIN_CLOSE           PPSInput(3, INT2, NULL)

#define INT3PIN                 (35)
#define INT3PIN_OPEN            PPSInput(2, INT3, RPA9)
#define INT3PIN_CLOSE           PPSInput(2, INT3, NULL)

#define INT4PIN                 (3)
#define INT4PIN_OPEN            PPSInput(1, INT4, RPC7)
#define INT4PIN_CLOSE           PPSInput(1, INT4, NULL)


// I2C pin numbers
#define P_I2C_SDA               (1)
#define P_I2C_SCL               (44)


// Define the serial console pin numbers
#define CONSOLE_RX_PIN          (34)     // this is UART1
#define CONSOLE_TX_PIN          (33)
#define CONSOLE_RX_PPS_OPEN     PPSInput(3, U1RX, RPA4)
#define CONSOLE_TX_PPS_OPEN     PPSOutput(1, RPB4, U1TX)
#define CONSOLE_TX_PPS_CLOSE    PPSOutput(1, RPB4, NULL)

// COM1: port pin numbers, this is UART2, UART1 is used by the console or COM4
#define COM1_RX_PIN             (32)
#define COM1_TX_PIN             (27)
#define COM1_EN_PIN             (38)
#define COM1_RX_PPS_OPEN        PPSInput(2, U2RX, RPA8)
#define COM1_TX_PPS_OPEN        PPSOutput(4, RPC2, U2TX);
#define COM1_TX_PPS_CLOSE       PPSOutput(4, RPC2, NULL)
#define COM1_DE_PPS_OPEN        PPSOutput(1, RPC5, U2RTS)
#define COM1_DE_PPS_CLOSE       PPSOutput(1, RPC5, NULL)

// COM2: port pin numbers (Software UART)
#define COM2_RX_PIN             (11)
#define COM2_TX_PIN             (12)
    
// COM4: port pin numbers, this is UART1
#define COM4_RX_PIN             (23)     
#define COM4_TX_PIN             (24)
#define COM4_RX_PPS_OPEN        PPSInput(3, U1RX, RPB2)
#define COM4_TX_PPS_OPEN        PPSOutput(1, RPB3, U1TX)
#define COM4_TX_PPS_CLOSE       PPSOutput(1, RPB3, NULL)

// SPI pin numbers
#define SPI_INP_PIN             (41)
#define SPI_OUT_PIN             (20)
#define SPI_CLK_PIN             (14)
#define SPI_PPS_OPEN            PPSInput(2, SDI1, RPB5); PPSOutput(2, RPA1, SDO1)
#define SPI_PPS_CLOSE           PPSOutput(2, RPA1, NULL)

// touch controller interface
#define TOUCH_SPI_CHANNEL       SPI_CHANNEL1

// SPI LCD controller interface
#define SPI_LCD_SPI_CHANNEL     SPI_CHANNEL1

// PWM CH1
#define PWM_CH1_PIN             (21)
#define PWM_CH1_OPEN            PPSOutput(4, RPB0, OC3)
#define PWM_CH1_CLOSE           PPSOutput(4, RPB0, NULL)

// PWM CH2
#define PWM_CH2_PIN             (22)
#define PWM_CH2_OPEN            PPSOutput(2, RPB1, OC2)
#define PWM_CH2_CLOSE           PPSOutput(2, RPB1, NULL)

// PWM CH3
#define PWM_CH3_PIN             (26)
#define PWM_CH3_OPEN            PPSOutput(3, RPC1, OC5)
#define PWM_CH3_CLOSE           PPSOutput(3, RPC1, NULL)

// PWM CH4
#define PWM_CH4_PIN             (15)
#define PWM_CH4_OPEN            PPSOutput(1, RPB15, OC1)
#define PWM_CH4_CLOSE           PPSOutput(1, RPB15, NULL)

// PWM CH5
#define PWM_CH5_PIN             (2)
#define PWM_CH5_OPEN            PPSOutput(3, RPC6, OC4)
#define PWM_CH5_CLOSE           PPSOutput(3, RPC6, NULL)


// pin used for wakeup from sleep and receiving IR messages
#define WAKEUP_PIN              (43)

// pins used by USB
#define USB_1_PIN               (10)
#define USB_2_PIN               (42)

