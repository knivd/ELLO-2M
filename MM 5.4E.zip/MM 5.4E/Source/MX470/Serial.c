/***********************************************************************************************************************
MMBasic

Serial.c

Handles the serial I/O  commands and functions in MMBasic..

Copyright 2011 - 2017 Geoff Graham.  All Rights Reserved.

This file and modified versions of this file are supplied to specific individuals or organisations under the following
provisions:

- This file, or any files that comprise the MMBasic source (modified or not), may not be distributed or copied to any other
  person or organisation without written permission.

- Object files (.o and .hex files) generated using this file (modified or not) may not be distributed or copied to any other
  person or organisation without written permission.

- This file is provided in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

************************************************************************************************************************/


#define _SUPPRESS_PLIB_WARNING                      // required for XC1.33  Later compiler versions will need PLIB to be installed
#include <plib.h>									// the pre Harmony peripheral libraries

#include "../MMBasic_Includes.h"
#include "../Hardware_Includes.h"

// variables for com1
int com1 = 0;														// true if COM1 is enabled
int com1_buf_size;													// size of the buffer used to receive chars
int com1_baud = 0;													// determines the baud rate
char *com1_interrupt;												// pointer to the interrupt routine
int com1_ilevel;													// number nbr of chars in the buffer for an interrupt
unsigned char *com1Rx_buf;											// pointer to the buffer for received characters
volatile int com1Rx_head, com1Rx_tail;								// head and tail of the ring buffer for com1
unsigned char *com1Tx_buf;											// pointer to the buffer for transmitted characters
volatile int com1Tx_head, com1Tx_tail;								// head and tail of the ring buffer for com1

#define COM1_9B       0b001                                         // 9 bit data enabled
#define COM1_DE       0b010                                         // RS485 enable flag in use
char com1_mode;                                                     // keeps track of the settings for com1
unsigned char com1_bit9 = 0;                                        // used to track the 9th bit

// variables for com2
int com2 = 0;														// true if COM2 is enabled
int com2_buf_size;													// size of the buffer used to receive chars
int com2_baud = 0;													// determines the baud rate
char *com2_interrupt;												// pointer to the interrupt routine
int com2_ilevel;													// number nbr of chars in the buffer for an interrupt
unsigned char *com2Rx_buf;											// pointer to the buffer for received characters
volatile int com2Rx_head, com2Rx_tail;								// head and tail of the ring buffer for com2 Rx
unsigned char *com2Tx_buf;											// pointer to the buffer for transmitted characters
volatile int com2Tx_head, com2Tx_tail;								// head and tail of the ring buffer for com2 Tx

// variables for com3
int com3 = 0;														// true if COM3 is enabled
int com3_buf_size;													// size of the buffer used to receive chars
int com3_baud = 0;													// determines the baud rate
char *com3_interrupt;												// pointer to the interrupt routine
int com3_ilevel;													// number nbr of chars in the buffer for an interrupt
unsigned char *com3Rx_buf;											// pointer to the buffer for received characters
volatile int com3Rx_head, com3Rx_tail;								// head and tail of the ring buffer for com3 Rx
unsigned char *com3Tx_buf;											// pointer to the buffer for transmitted characters
volatile int com3Tx_head, com3Tx_tail;								// head and tail of the ring buffer for com3 Tx

// variables for com4
int com4 = 0;														// true if com4 is enabled
int com4_buf_size;													// size of the buffer used to receive chars
int com4_baud = 0;													// determines the baud rate
char *com4_interrupt;												// pointer to the interrupt routine
int com4_ilevel;													// number nbr of chars in the buffer for an interrupt
unsigned char *com4Rx_buf;											// pointer to the buffer for received characters
volatile int com4Rx_head, com4Rx_tail;								// head and tail of the ring buffer for com4 Rx
unsigned char *com4Tx_buf;											// pointer to the buffer for transmitted characters
volatile int com4Tx_head, com4Tx_tail;								// head and tail of the ring buffer for com4 Tx


/***************************************************************************************************
Initialise the serial function including the timer and interrupts.
****************************************************************************************************/
void SerialOpen(char *spec) {
	int baud, i, inv, oc, s2, de, b9, bufsize, ilevel;
	char *interrupt;
	
	getargs(&spec, 13, ":,");										// this is a macro and must be the first executable stmt
	if(argc != 2 && (argc & 0x01) == 0) error("COM specification");

    de = b9 = inv = oc = s2 = false;
    for(i = 0; i < 4; i++) {
    	if(str_equal(argv[argc - 1], "OC")) { oc = true; argc -= 2; }	// get the open collector option
    	if(str_equal(argv[argc - 1], "DE")) { de = true; argc -= 2; }	// get the data enable option
    	if(str_equal(argv[argc - 1], "9BIT")) { b9 = true; argc -= 2; }	// get the 9 bit byte option
    	if(str_equal(argv[argc - 1], "S2")) { s2 = true; argc -= 2; }	// get the two stop bit option
    	if(str_equal(argv[argc - 1], "INV")) { inv = true; argc -= 2; }	// get the invert option
    }
    
	if(argc < 1 || argc > 9) error("COM specification");

	if(argc >= 3 && *argv[2]) {
		baud = getinteger(argv[2]);									// get the baud rate as a number
		if(baud > BusSpeed/2) error("Baud rate too high");
	} else
		baud = COM_DEFAULT_BAUD_RATE;

	if(argc >= 5 && *argv[4])
		bufsize = getinteger(argv[4]);								// get the buffer size as a number
	else
		bufsize = COM_DEFAULT_BUF_SIZE;

	if(argc >= 7) {
    	InterruptUsed = true;
		interrupt = GetIntAddress(argv[6]);							// get the interrupt location
	} else
		interrupt = NULL;

	if(argc >= 9) {
		ilevel = getinteger(argv[8]);								// get the buffer level for interrupt as a number
		if(ilevel < 1 || ilevel > bufsize) error("COM specification");
	} else
		ilevel = 1;


	if(spec[3] == '1') {
	///////////////////////////////// this is COM1 ////////////////////////////////////
        int cfg1, cfg2;
        
		if(com1) error("Already open");
        CheckPin(COM1_RX_PIN, CP_CHECKALL);
        CheckPin(COM1_TX_PIN, CP_CHECKALL);

 		com1_buf_size = bufsize;									// extracted from the comspec above
		com1_interrupt = interrupt;
		com1_ilevel	= ilevel;

		// setup for receive
		com1Rx_buf = GetMemory(com1_buf_size);						// setup the buffer
		com1Rx_head = com1Rx_tail = 0;
		ExtCfg(COM1_RX_PIN, EXT_DIG_IN, 0);                         // pin 15 is Rx (an input)
		ExtCfg(COM1_RX_PIN, EXT_COM_RESERVED, 0);                   // reserve the pin for com use
        PinSetBit(COM1_RX_PIN, inv ? CNPDSET:CNPUSET);              // set a pulldown/pullup on Rx so that the input does not float

        COM1_RX_PPS_OPEN;

		// setup for transmit
		com1Tx_buf = GetMemory(TX_BUFFER_SIZE);						// setup the buffer
		com1Tx_head = com1Tx_tail = 0;
		ExtCfg(COM1_TX_PIN, EXT_NOT_CONFIG, 0);
		ExtSet(COM1_TX_PIN, 1);                                     // start with the Tx pin high (ie, idle)
		ExtCfg(COM1_TX_PIN, oc ? EXT_OC_OUT : EXT_DIG_OUT, 0);      // set the Tx pin as an output
		ExtCfg(COM1_TX_PIN, EXT_COM_RESERVED, 0);                   // reserve the pin for com use
        COM1_TX_PPS_OPEN;

        com1_bit9 = com1_mode = 0;
        
        cfg1 = 0;                                                   // default is Tx/Rx only, no invert and no RTS/CTS

        if(de) {
            CheckPin(COM1_EN_PIN, CP_CHECKALL);
    		ExtCfg(COM1_EN_PIN, oc ? EXT_OC_OUT : EXT_DIG_OUT, 0);  // set the RTS pin as an output
            ExtCfg(COM1_EN_PIN, EXT_COM_RESERVED, 0);               // reserve the pin for com use
            COM1_EN_PPS_OPEN;
            com1_mode |= COM1_DE;
            cfg1 |= UART_SUPPORT_IEEE_485;
        }
        if(inv) cfg1 |= (UART_INVERT_RECEIVE_POLARITY | UART_INVERT_TRANSMIT_POLARITY);

        cfg2 = 0;                                                   // default is 8 bits, no parity and 1 stop bit
        if(s2) cfg2 |= UART_STOP_BITS_2;
        if(b9) {
            cfg2 |= UART_DATA_SIZE_9_BITS;
            com1_mode |= COM1_9B;
        }

        // setup the UART
        UARTConfigure(UART2, cfg1);
        UARTSetFifoMode(UART2, UART_INTERRUPT_ON_TX_NOT_FULL | UART_INTERRUPT_ON_RX_NOT_EMPTY);
        UARTSetLineControl(UART2, cfg2);
        UARTSetDataRate(UART2, BusSpeed, (com1_baud = baud));
        UARTEnable(UART2, UART_ENABLE_FLAGS(UART_PERIPHERAL | UART_RX | UART_TX));

        // Configure UART2 RX Interrupt (the Tx Interrupt is enabled in SerialPutchar())
        INTSetVectorPriority(INT_VECTOR_UART(UART2), INT_PRIORITY_LEVEL_4);
        INTSetVectorSubPriority(INT_VECTOR_UART(UART2), INT_SUB_PRIORITY_LEVEL_0);
        INTEnable(INT_SOURCE_UART_RX(UART2), INT_ENABLED);

		com1 = true;
	}

    if (spec[3] == '2') {
	///////////////////////////////// this is COM2 ////////////////////////////////////
        int cfg1, cfg2;

		if(com2) error("Already open");
        CheckPin(COM2_RX_PIN, CP_CHECKALL);
        CheckPin(COM2_TX_PIN, CP_CHECKALL);

 		com2_buf_size = bufsize;									// extracted from the comspec above
		com2_interrupt = interrupt;
		com2_ilevel	= ilevel;

		// setup for receive
		com2Rx_buf = GetMemory(com2_buf_size);						// setup the buffer
		com2Rx_head = com2Rx_tail = 0;
		ExtCfg(COM2_RX_PIN, EXT_DIG_IN, 0);                         // pin 15 is Rx (an input)
		ExtCfg(COM2_RX_PIN, EXT_COM_RESERVED, 0);                   // reserve the pin for com use
        PinSetBit(COM2_RX_PIN, inv ? CNPDSET:CNPUSET);              // set a pulldown/pullup on Rx so that the input does not float

        COM2_RX_PPS_OPEN;

		// setup for transmit
		com2Tx_buf = GetMemory(TX_BUFFER_SIZE);						// setup the buffer
		com2Tx_head = com2Tx_tail = 0;
		ExtCfg(COM2_TX_PIN, EXT_NOT_CONFIG, 0);
		ExtSet(COM2_TX_PIN, 1);                                     // start with the Tx pin high (ie, idle)
		ExtCfg(COM2_TX_PIN, oc ? EXT_OC_OUT : EXT_DIG_OUT, 0);      // set the Tx pin as an output
		ExtCfg(COM2_TX_PIN, EXT_COM_RESERVED, 0);                   // reserve the pin for com use
        COM2_TX_PPS_OPEN;

        cfg1 = 0;                                                   // default is Tx/Rx only, no invert and no RTS/CTS

        if(de || b9) error("COM specification");
        if(inv) cfg1 |= (UART_INVERT_RECEIVE_POLARITY | UART_INVERT_TRANSMIT_POLARITY);

        cfg2 = 0;                                                   // default is 8 bits, no parity and 1 stop bit
        if(s2) cfg2 |= UART_STOP_BITS_2;

        // setup the UART
        UARTConfigure(UART3, cfg1);
        UARTSetFifoMode(UART3, UART_INTERRUPT_ON_TX_NOT_FULL | UART_INTERRUPT_ON_RX_NOT_EMPTY);
        UARTSetLineControl(UART3, cfg2);
        UARTSetDataRate(UART3, BusSpeed, (com2_baud = baud));
        UARTEnable(UART3, UART_ENABLE_FLAGS(UART_PERIPHERAL | UART_RX | UART_TX));

        // Configure UART3 RX Interrupt (the Tx Interrupt is enabled in SerialPutchar())
        INTSetVectorPriority(INT_VECTOR_UART(UART3), INT_PRIORITY_LEVEL_6);
        INTSetVectorSubPriority(INT_VECTOR_UART(UART3), INT_SUB_PRIORITY_LEVEL_0);
        INTEnable(INT_SOURCE_UART_RX(UART3), INT_ENABLED);

		com2 = true;
	}

    if (spec[3] == '3') {
	///////////////////////////////// this is COM3 ////////////////////////////////////
        int cfg1, cfg2;

		if(com3) error("Already open");
        CheckPin(COM3_RX_PIN, CP_CHECKALL);
        CheckPin(COM3_TX_PIN, CP_CHECKALL);

 		com3_buf_size = bufsize;									// extracted from the comspec above
		com3_interrupt = interrupt;
		com3_ilevel	= ilevel;

		// setup for receive
		com3Rx_buf = GetMemory(com3_buf_size);						// setup the buffer
		com3Rx_head = com3Rx_tail = 0;
		ExtCfg(COM3_RX_PIN, EXT_DIG_IN, 0);                         // pin 15 is Rx (an input)
		ExtCfg(COM3_RX_PIN, EXT_COM_RESERVED, 0);                   // reserve the pin for com use
        PinSetBit(COM3_RX_PIN, inv ? CNPDSET:CNPUSET);              // set a pulldown/pullup on Rx so that the input does not float
        COM3_RX_PPS_OPEN;

		// setup for transmit
		com3Tx_buf = GetMemory(TX_BUFFER_SIZE);						// setup the buffer
		com3Tx_head = com3Tx_tail = 0;
		ExtCfg(COM3_TX_PIN, EXT_NOT_CONFIG, 0);
		ExtSet(COM3_TX_PIN, 1);                                     // start with the Tx pin high (ie, idle)
		ExtCfg(COM3_TX_PIN, oc ? EXT_OC_OUT : EXT_DIG_OUT, 0);      // set the Tx pin as an output
		ExtCfg(COM3_TX_PIN, EXT_COM_RESERVED, 0);                   // reserve the pin for com use
        COM3_TX_PPS_OPEN;

        cfg1 = 0;                                                   // default is Tx/Rx only, no invert and no RTS/CTS

        if(de || b9) error("COM specification");
        if(inv) cfg1 |= (UART_INVERT_RECEIVE_POLARITY | UART_INVERT_TRANSMIT_POLARITY);

        cfg2 = 0;                                                   // default is 8 bits, no parity and 1 stop bit
        if(s2) cfg2 |= UART_STOP_BITS_2;

        // setup the UART
        UARTConfigure(UART4, cfg1);
        UARTSetFifoMode(UART4, UART_INTERRUPT_ON_TX_NOT_FULL | UART_INTERRUPT_ON_RX_NOT_EMPTY);
        UARTSetLineControl(UART4, cfg2);
        UARTSetDataRate(UART4, BusSpeed, (com3_baud = baud));
        UARTEnable(UART4, UART_ENABLE_FLAGS(UART_PERIPHERAL | UART_RX | UART_TX));

        // Configure UART4 RX Interrupt (the Tx Interrupt is enabled in SerialPutchar())
        INTSetVectorPriority(INT_VECTOR_UART(UART4), INT_PRIORITY_LEVEL_7);
        INTSetVectorSubPriority(INT_VECTOR_UART(UART4), INT_SUB_PRIORITY_LEVEL_0);
        INTEnable(INT_SOURCE_UART_RX(UART4), INT_ENABLED);

		com3 = true;
	}

    if (spec[3] == '4') {
	///////////////////////////////// this is COM4 ////////////////////////////////////
        int cfg1, cfg2;

        if(Option.SerialCon) error("In use by the console");
		if(com4) error("Already open");
        CheckPin(COM4_RX_PIN, CP_CHECKALL);
        CheckPin(COM4_TX_PIN, CP_CHECKALL);

 		com4_buf_size = bufsize;									// extracted from the comspec above
		com4_interrupt = interrupt;
		com4_ilevel	= ilevel;

		// setup for receive
		com4Rx_buf = GetMemory(com4_buf_size);						// setup the buffer
		com4Rx_head = com4Rx_tail = 0;
		ExtCfg(COM4_RX_PIN, EXT_DIG_IN, 0);                         // pin 15 is Rx (an input)
		ExtCfg(COM4_RX_PIN, EXT_COM_RESERVED, 0);                   // reserve the pin for com use
        PinSetBit(COM4_RX_PIN, inv ? CNPDSET:CNPUSET);              // set a pulldown/pullup on Rx so that the input does not float

        COM4_RX_PPS_OPEN;

		// setup for transmit
		com4Tx_buf = GetMemory(TX_BUFFER_SIZE);						// setup the buffer
		com4Tx_head = com4Tx_tail = 0;
		ExtCfg(COM4_TX_PIN, EXT_NOT_CONFIG, 0);
		ExtSet(COM4_TX_PIN, 1);                                     // start with the Tx pin high (ie, idle)
		ExtCfg(COM4_TX_PIN, oc ? EXT_OC_OUT : EXT_DIG_OUT, 0);      // set the Tx pin as an output
		ExtCfg(COM4_TX_PIN, EXT_COM_RESERVED, 0);                   // reserve the pin for com use
        COM4_TX_PPS_OPEN;

        cfg1 = 0;                                                   // default is Tx/Rx only, no invert and no RTS/CTS

        if(de || b9) error("COM specification");
        if(inv) cfg1 |= (UART_INVERT_RECEIVE_POLARITY | UART_INVERT_TRANSMIT_POLARITY);

        cfg2 = 0;                                                   // default is 8 bits, no parity and 1 stop bit
        if(s2) cfg2 |= UART_STOP_BITS_2;

        // setup the UART
        UARTConfigure(UART1, cfg1);
        UARTSetFifoMode(UART1, UART_INTERRUPT_ON_TX_NOT_FULL | UART_INTERRUPT_ON_RX_NOT_EMPTY);
        UARTSetLineControl(UART1, cfg2);
        UARTSetDataRate(UART1, BusSpeed, (com4_baud = baud));
        UARTEnable(UART1, UART_ENABLE_FLAGS(UART_PERIPHERAL | UART_RX | UART_TX));

        // Configure UART1 RX Interrupt (the Tx Interrupt is enabled in SerialPutchar())
        INTSetVectorPriority(INT_VECTOR_UART(UART1), INT_PRIORITY_LEVEL_3);
        INTSetVectorSubPriority(INT_VECTOR_UART(UART1), INT_SUB_PRIORITY_LEVEL_0);
        INTEnable(INT_SOURCE_UART_RX(UART1), INT_ENABLED);

		com4 = true;
	}
}




/***************************************************************************************************
Close a serial port.
****************************************************************************************************/
void SerialClose(int comnbr) {

	if(comnbr == 1 && com1) {
        INTEnable(INT_SOURCE_UART_RX(UART2), INT_DISABLED);
        INTEnable(INT_SOURCE_UART_TX(UART2), INT_DISABLED);
        UARTEnable(UART2, UART_ENABLE_FLAGS(UART_DISABLE | UART_PERIPHERAL));
        COM1_TX_PPS_CLOSE;
        if(com1_mode & COM1_DE) {
            COM1_EN_PPS_CLOSE;
            ExtCfg(COM1_EN_PIN, EXT_NOT_CONFIG, 0);
        }
		com1 = false;
		com1_interrupt = NULL;
        PinSetBit(COM1_RX_PIN, CNPUCLR);                            // clear the pullup or pulldown on Rx
        PinSetBit(COM1_RX_PIN, CNPDCLR);
		ExtCfg(COM1_RX_PIN, EXT_NOT_CONFIG, 0);
		ExtCfg(COM1_TX_PIN, EXT_NOT_CONFIG, 0);
		FreeMemory(com1Rx_buf);
		FreeMemory(com1Tx_buf);
	}

    else if(comnbr == 2 && com2) {
        INTEnable(INT_SOURCE_UART_RX(UART3), INT_DISABLED);
        INTEnable(INT_SOURCE_UART_TX(UART3), INT_DISABLED);
        UARTEnable(UART3, UART_ENABLE_FLAGS(UART_DISABLE | UART_PERIPHERAL));
        COM2_TX_PPS_CLOSE;
		com2 = false;
		com2_interrupt = NULL;
        PinSetBit(COM2_RX_PIN, CNPUCLR);                            // clear the pullup or pulldown on Rx
        PinSetBit(COM2_RX_PIN, CNPDCLR);
		ExtCfg(COM2_RX_PIN, EXT_NOT_CONFIG, 0);
		ExtCfg(COM2_TX_PIN, EXT_NOT_CONFIG, 0);
		FreeMemory(com2Rx_buf);
		FreeMemory(com2Tx_buf);
	}

    else if(comnbr == 3 && com3) {
        INTEnable(INT_SOURCE_UART_RX(UART4), INT_DISABLED);
        INTEnable(INT_SOURCE_UART_TX(UART4), INT_DISABLED);
        UARTEnable(UART4, UART_ENABLE_FLAGS(UART_DISABLE | UART_PERIPHERAL));
        COM3_TX_PPS_CLOSE;
		com3 = false;
		com3_interrupt = NULL;
        PinSetBit(COM3_RX_PIN, CNPUCLR);                            // clear the pullup or pulldown on Rx
        PinSetBit(COM3_RX_PIN, CNPDCLR);
		ExtCfg(COM3_RX_PIN, EXT_NOT_CONFIG, 0);
		ExtCfg(COM3_TX_PIN, EXT_NOT_CONFIG, 0);
		FreeMemory(com3Rx_buf);
		FreeMemory(com3Tx_buf);
	}

    else if(comnbr == 4 && com4) {
        INTEnable(INT_SOURCE_UART_RX(UART1), INT_DISABLED);
        INTEnable(INT_SOURCE_UART_TX(UART1), INT_DISABLED);
        UARTEnable(UART1, UART_ENABLE_FLAGS(UART_DISABLE | UART_PERIPHERAL));
        COM4_TX_PPS_CLOSE;
		com4 = false;
		com4_interrupt = NULL;
        PinSetBit(COM4_RX_PIN, CNPUCLR);                            // clear the pullup or pulldown on Rx
        PinSetBit(COM4_RX_PIN, CNPDCLR);
		ExtCfg(COM4_RX_PIN, EXT_NOT_CONFIG, 0);
		ExtCfg(COM4_TX_PIN, EXT_NOT_CONFIG, 0);
		FreeMemory(com4Rx_buf);
		FreeMemory(com4Tx_buf);
	}

}



/***************************************************************************************************
Add a character to the serial output buffer.
****************************************************************************************************/
unsigned char SerialPutchar(int comnbr, unsigned char c) {
	if(comnbr == 1) {
		while(com1Tx_tail == ((com1Tx_head + 1) % TX_BUFFER_SIZE)) 	// wait if the buffer is full
			if(MMAbort) {											// allow the user to abort a hung serial port
				com1Tx_tail = com1Tx_head = 0;						// clear the buffer
				longjmp(mark, 1);									// and abort
			}
		com1Tx_buf[com1Tx_head] = c;								// add the char
		com1Tx_head = (com1Tx_head + 1) % TX_BUFFER_SIZE;			// advance the head of the queue
        INTEnable(INT_SOURCE_UART_TX(UART2), INT_ENABLED);          // enable Tx interrupt in case it was off
	}
    else if(comnbr == 2) {
		while(com2Tx_tail == ((com2Tx_head + 1) % TX_BUFFER_SIZE))  // wait if the buffer is full
			if(MMAbort) {											// allow the user to abort a hung serial port
				com2Tx_tail = com2Tx_head = 0;						// clear the buffer
				longjmp(mark, 1);									// and abort
			}
		com2Tx_buf[com2Tx_head] = c;								// add the char
		com2Tx_head = (com2Tx_head + 1) % TX_BUFFER_SIZE;			// advance the head of the queue
        INTEnable(INT_SOURCE_UART_TX(UART3), INT_ENABLED);          // enable Tx interrupt in case it was off
	}
    else if(comnbr == 3) {
		while(com3Tx_tail == ((com3Tx_head + 1) % TX_BUFFER_SIZE))  // wait if the buffer is full
			if(MMAbort) {											// allow the user to abort a hung serial port
				com3Tx_tail = com3Tx_head = 0;						// clear the buffer
				longjmp(mark, 1);									// and abort
			}
		com3Tx_buf[com3Tx_head] = c;								// add the char
		com3Tx_head = (com3Tx_head + 1) % TX_BUFFER_SIZE;			// advance the head of the queue
        INTEnable(INT_SOURCE_UART_TX(UART4), INT_ENABLED);          // enable Tx interrupt in case it was off
	}
    else if(comnbr == 4) {
		while(com4Tx_tail == ((com4Tx_head + 1) % TX_BUFFER_SIZE))  // wait if the buffer is full
			if(MMAbort) {											// allow the user to abort a hung serial port
				com4Tx_tail = com4Tx_head = 0;						// clear the buffer
				longjmp(mark, 1);									// and abort
			}
		com4Tx_buf[com4Tx_head] = c;								// add the char
		com4Tx_head = (com4Tx_head + 1) % TX_BUFFER_SIZE;			// advance the head of the queue
        INTEnable(INT_SOURCE_UART_TX(UART1), INT_ENABLED);          // enable Tx interrupt in case it was off
	}
	return c;
}



/***************************************************************************************************
Get the status the serial receive buffer.
Returns the number of characters waiting in the buffer
****************************************************************************************************/
int SerialRxStatus(int comnbr) {
	int i = 0;
	if(comnbr == 1) {
        INTEnable(INT_SOURCE_UART_RX(UART2), INT_DISABLED);
		i = com1Rx_head - com1Rx_tail;
        INTEnable(INT_SOURCE_UART_RX(UART2), INT_ENABLED);
		if(i < 0) i += com1_buf_size;
	}
    else if(comnbr == 2) {
        INTEnable(INT_SOURCE_UART_RX(UART3), INT_DISABLED);
		i = com2Rx_head - com2Rx_tail;
        INTEnable(INT_SOURCE_UART_RX(UART3), INT_ENABLED);
		if(i < 0) i += com2_buf_size;
	}
    else if(comnbr == 3) {
        INTEnable(INT_SOURCE_UART_RX(UART4), INT_DISABLED);
		i = com3Rx_head - com3Rx_tail;
        INTEnable(INT_SOURCE_UART_RX(UART4), INT_ENABLED);
		if(i < 0) i += com3_buf_size;
	}
    else if(comnbr == 4) {
        INTEnable(INT_SOURCE_UART_RX(UART1), INT_DISABLED);
		i = com4Rx_head - com4Rx_tail;
        INTEnable(INT_SOURCE_UART_RX(UART1), INT_ENABLED);
		if(i < 0) i += com4_buf_size;
	}

	return i;
}



/***************************************************************************************************
Get the status the serial transmit buffer.
Returns the number of characters waiting in the buffer
****************************************************************************************************/
int SerialTxStatus(int comnbr) {
	int i = 0;
	if(comnbr == 1) {
		i = com1Tx_head - com1Tx_tail;
		if(i < 0) i += TX_BUFFER_SIZE;
	}
    else if(comnbr == 2) {
		i = com2Tx_head - com2Tx_tail;
		if(i < 0) i += TX_BUFFER_SIZE;
	}
    else if(comnbr == 3) {
		i = com3Tx_head - com3Tx_tail;
		if(i < 0) i += TX_BUFFER_SIZE;
	}
    else if(comnbr == 4) {
		i = com4Tx_head - com4Tx_tail;
		if(i < 0) i += TX_BUFFER_SIZE;
	}
	return i;
}



/***************************************************************************************************
Get a character from the serial receive buffer.
Note that this is returned as an integer and -1 means that there are no characters available
****************************************************************************************************/
int SerialGetchar(int comnbr) {
	int c;
    c = -1;                                                         // -1 is no data
	if(comnbr == 1) {
        INTEnable(INT_SOURCE_UART_RX(UART2), INT_DISABLED);
		if(com1Rx_head != com1Rx_tail) {                            // if the queue has something in it
			c = com1Rx_buf[com1Rx_tail];                            // get the char
 			com1Rx_tail = (com1Rx_tail + 1) % com1_buf_size;        // and remove from the buffer
		}
        INTEnable(INT_SOURCE_UART_RX(UART2), INT_ENABLED);
	}
    else if(comnbr == 2) {
        INTEnable(INT_SOURCE_UART_RX(UART3), INT_DISABLED);
		if(com2Rx_head != com2Rx_tail) {                            // if the queue has something in it
			c = com2Rx_buf[com2Rx_tail];                            // get the char
 			com2Rx_tail = (com2Rx_tail + 1) % com2_buf_size;        // and remove from the buffer
		}
        INTEnable(INT_SOURCE_UART_RX(UART3), INT_ENABLED);
	}
    else if(comnbr == 3) {
        INTEnable(INT_SOURCE_UART_RX(UART4), INT_DISABLED);
		if(com3Rx_head != com3Rx_tail) {                            // if the queue has something in it
			c = com3Rx_buf[com3Rx_tail];                            // get the char
 			com3Rx_tail = (com3Rx_tail + 1) % com3_buf_size;        // and remove from the buffer
		}
        INTEnable(INT_SOURCE_UART_RX(UART4), INT_ENABLED);
	}
    else if(comnbr == 4) {
        INTEnable(INT_SOURCE_UART_RX(UART1), INT_DISABLED);
		if(com4Rx_head != com4Rx_tail) {                            // if the queue has something in it
			c = com4Rx_buf[com4Rx_tail];                            // get the char
 			com4Rx_tail = (com4Rx_tail + 1) % com4_buf_size;        // and remove from the buffer
		}
        INTEnable(INT_SOURCE_UART_RX(UART1), INT_ENABLED);
	}
	return c;
}



// UART 2 interrupt handler for COM1:
void __ISR(_UART_2_VECTOR, IPL4AUTO) IntUART2Handler(void) {
//void __ISR(INT_VECTOR_UART(UART2), ipl4AUTO) IntUART2Handler(void) {
    unsigned short cc;

    if(INTGetFlag(INT_SOURCE_UART_RX(UART2))) {                     // Is this an RX interrupt?
        while(UARTReceivedDataIsAvailable(UART2)) {                 // while there is data to read
            if(UARTGetLineStatus(UART2) & 0b1110) {                 // first check for errors
                UARTGetDataByte(UART2);                             // and if there was an error throw away the char
                U2STACLR = 0b1110;                                  // clear the error on the UART
                continue;                                           // and try the next char
            }
            cc = UARTGetData(UART2).__data;
            if(com1_mode & COM1_9B) {                               // if we are using 9 bits
                com1Rx_buf[com1Rx_head] = (cc >> 8) + '0';          // store the 9th bit in the ring buffer
                com1Rx_head = (com1Rx_head + 1) % com1_buf_size;    // advance the head of the queue
                if(com1Rx_head == com1Rx_tail) {                    // if the buffer has overflowed
                    com1Rx_tail = (com1Rx_tail + 1) % com1_buf_size;// throw away the oldest char
                }
            }
            com1Rx_buf[com1Rx_head] = cc;                           // store the data byte in the ring buffer
            com1Rx_head = (com1Rx_head + 1) % com1_buf_size;        // advance the head of the queue
            if(com1Rx_head == com1Rx_tail) {                        // if the buffer has overflowed
                com1Rx_tail = (com1Rx_tail + 1) % com1_buf_size;    // throw away the oldest char
            }
        }
        INTClearFlag(INT_SOURCE_UART_RX(UART2));                    // Clear the RX interrupt Flag
    }

    if(INTGetFlag(INT_SOURCE_UART_TX(UART2))) {                     // Is this an Tx interrupt?
        while(UARTTransmitterIsReady(UART2) && com1Tx_tail != com1Tx_head) { // while Tx is free and there is data to send
            cc = com1Tx_buf[com1Tx_tail];
            com1Tx_tail = (com1Tx_tail + 1) % TX_BUFFER_SIZE;       // advance the tail of the queue
            if(com1_mode & COM1_9B) {                               // if we are using 9 bits
                if(com1_bit9 == 0) {
                    com1_bit9 = cc;
                    continue;
                } else {
                    cc |= (com1_bit9 == '1') << 8;
                    com1_bit9 = 0;
                }
            }
            INTDisableInterrupts();                                 // see Errata #10
            UARTSendData(UART2, (UART_DATA)cc);                     // send the byte
            INTEnableInterrupts();
        }
        if(com1Tx_tail == com1Tx_head)                              // if there is nothing left to send
            INTEnable(INT_SOURCE_UART_TX(UART2), INT_DISABLED);     // disable the interrupt
        INTClearFlag(INT_SOURCE_UART_TX(UART2));                    // Clear the Tx interrupt Flag
    }
}


// UART 3 interrupt handler for COM2:
void __ISR(_UART_3_VECTOR, IPL6AUTO) IntUART3Handler(void) {
//void __ISR(INT_VECTOR_UART(UART3), ipl6AUTO) IntUART3Handler(void) {
    unsigned short cc;

    if(INTGetFlag(INT_SOURCE_UART_RX(UART3))) {                     // Is this an RX interrupt?
        while(UARTReceivedDataIsAvailable(UART3)) {                 // while there is data to read
            if(UARTGetLineStatus(UART3) & 0b1110) {                 // first check for errors
                UARTGetDataByte(UART3);                             // and if there was an error throw away the char
                U3STACLR = 0b1110;                                  // clear the error on the UART
                continue;                                           // and try the next char
            }
            cc = UARTGetData(UART3).__data;
            com2Rx_buf[com2Rx_head] = cc;                           // store the data byte in the ring buffer
            com2Rx_head = (com2Rx_head + 1) % com2_buf_size;        // advance the head of the queue
            if(com2Rx_head == com2Rx_tail) {                        // if the buffer has overflowed
                com2Rx_tail = (com2Rx_tail + 1) % com2_buf_size;    // throw away the oldest char
            }
        }
        INTClearFlag(INT_SOURCE_UART_RX(UART3));                    // Clear the RX interrupt Flag
    }

    if(INTGetFlag(INT_SOURCE_UART_TX(UART3))) {                     // Is this an Tx interrupt?
        while(UARTTransmitterIsReady(UART3) && com2Tx_tail != com2Tx_head) { // while Tx is free and there is data to send
            cc = com2Tx_buf[com2Tx_tail];
            com2Tx_tail = (com2Tx_tail + 1) % TX_BUFFER_SIZE;       // advance the tail of the queue
            INTDisableInterrupts();                                 // see Errata #10
            UARTSendData(UART3, (UART_DATA)cc);                     // send the byte
            INTEnableInterrupts();
        }
        if(com2Tx_tail == com2Tx_head)                              // if there is nothing left to send
            INTEnable(INT_SOURCE_UART_TX(UART3), INT_DISABLED);     // disable the interrupt
        INTClearFlag(INT_SOURCE_UART_TX(UART3));                    // Clear the Tx interrupt Flag
    }
}



// UART 4 interrupt handler for COM3:
void __ISR(_UART_4_VECTOR, IPL7AUTO) IntUART4Handler(void) {
    unsigned short cc;

    if(INTGetFlag(INT_SOURCE_UART_RX(UART4))) {                     // Is this an RX interrupt?
        while(UARTReceivedDataIsAvailable(UART4)) {                 // while there is data to read
            if(UARTGetLineStatus(UART4) & 0b1110) {                 // first check for errors
                UARTGetDataByte(UART4);                             // and if there was an error throw away the char
                U4STACLR = 0b1110;                                  // clear the error on the UART
                continue;                                           // and try the next char
            }
            cc = UARTGetData(UART4).__data;
            com3Rx_buf[com3Rx_head] = cc;                           // store the data byte in the ring buffer
            com3Rx_head = (com3Rx_head + 1) % com3_buf_size;        // advance the head of the queue
            if(com3Rx_head == com3Rx_tail) {                        // if the buffer has overflowed
                com3Rx_tail = (com3Rx_tail + 1) % com3_buf_size;    // throw away the oldest char
            }
        }
        INTClearFlag(INT_SOURCE_UART_RX(UART4));                    // Clear the RX interrupt Flag
    }

    if(INTGetFlag(INT_SOURCE_UART_TX(UART4))) {                     // Is this an Tx interrupt?
        while(UARTTransmitterIsReady(UART4) && com3Tx_tail != com3Tx_head) { // while Tx is free and there is data to send
            cc = com3Tx_buf[com3Tx_tail];
            com3Tx_tail = (com3Tx_tail + 1) % TX_BUFFER_SIZE;       // advance the tail of the queue
            INTDisableInterrupts();                                 // see Errata #10
            UARTSendData(UART4, (UART_DATA)cc);                     // send the byte
            INTEnableInterrupts();
        }
        if(com3Tx_tail == com3Tx_head)                              // if there is nothing left to send
            INTEnable(INT_SOURCE_UART_TX(UART4), INT_DISABLED);     // disable the interrupt
        INTClearFlag(INT_SOURCE_UART_TX(UART4));                    // Clear the Tx interrupt Flag
    }
}



// UART 1 interrupt handler for COM4:
// this is implemented in Console.c because UART1 is also used for the console


