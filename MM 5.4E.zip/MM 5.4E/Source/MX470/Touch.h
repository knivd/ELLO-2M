/***********************************************************************************************************************
MMBasic

Touch.h

Supporting header file for Touch.c which does all the touch screen related I/O in MMBasic.

Copyright 2011 - 2015 Geoff Graham.  All Rights Reserved.

This file and modified versions of this file are supplied to specific individuals or organisations under the following
provisions:

- This file, or any files that comprise the MMBasic source (modified or not), may not be distributed or copied to any other
  person or organisation without written permission.

- Object files (.o and .hex files) generated using this file (modified or not) may not be distributed or copied to any other
  person or organisation without written permission.

- This file is provided in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

************************************************************************************************************************/



/**********************************************************************************
 the C language function associated with commands, functions or operators should be
 declared here
**********************************************************************************/
#if !defined(INCLUDE_COMMAND_TABLE) && !defined(INCLUDE_TOKEN_TABLE)


#endif




/**********************************************************************************
 All command tokens tokens (eg, PRINT, FOR, etc) should be inserted in this table
**********************************************************************************/
#ifdef INCLUDE_COMMAND_TABLE


#endif


/**********************************************************************************
 All other tokens (keywords, functions, operators) should be inserted in this table
**********************************************************************************/
#ifdef INCLUDE_TOKEN_TABLE


#endif


#if !defined(INCLUDE_COMMAND_TABLE) && !defined(INCLUDE_TOKEN_TABLE)

    #define CAL_ERROR_MARGIN    8
    #define TARGET_OFFSET       30
    #define TOUCH_SAMPLES       16
    #define TOUCH_DISCARD       6

    extern volatile int TouchX, TouchY;
    extern volatile int TouchDown, TouchUp;
    
    extern void InitTouch(void);
    extern void GetTouch(void);
    extern int GetTouchAxis(int cmd);
    extern int GetTouchValue(int cmd);
    extern void GetCalibration(int x, int y, int *xval, int *yval);

    #define TOUCH_NOT_CALIBRATED    -999999
    #define TOUCH_ERROR             -1
        
#endif
