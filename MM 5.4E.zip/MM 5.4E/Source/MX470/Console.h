/***********************************************************************************************************************
MMBasic

Console.h

Header file defining the public functions and variables in Console.c

Copyright 2011 - 2017 Geoff Graham.  All Rights Reserved.

This file and modified versions of this file are supplied to specific individuals or organisations under the following
provisions:

- This file, or any files that comprise the MMBasic source (modified or not), may not be distributed or copied to any other
  person or organisation without written permission.

- Object files (.o and .hex files) generated using this file (modified or not) may not be distributed or copied to any other
  person or organisation without written permission.

- This file is provided in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

************************************************************************************************************************/

#define CONSOLE_RX_BUF_SIZE 256
extern char ConsoleRxBuf[CONSOLE_RX_BUF_SIZE];
extern int ConsoleRxBufHead;
extern int ConsoleRxBufTail;

#define CONSOLE_TX_BUF_SIZE 2048                    // this is made a large size so that the serial console does not slow down the USB and LCD consoles
extern char ConsoleTxBuf[CONSOLE_TX_BUF_SIZE];
extern int ConsoleTxBufHead;
extern int ConsoleTxBufTail;

// declare the console I/O functions
extern void initConsole(void);
extern int MMgetchar(void);
extern int kbhitConsole(void);
extern void putConsole(int c);
extern int getConsole(void);

extern inline void CheckAbort(void);

extern void putConsole(int c);
extern int kbhitConsole(void);

extern void initSerialConsole(void);
extern void CloseSerialConsole(void);
extern void initUSBConsole(void);
extern void CloseUSBConsole(void);
extern void SerialConsolePutC(int c);

extern void USBPutC(int c);
extern void SerUSBPutC(char c);
extern void SerUSBPutS(char *s);


/*****************************************************************************************************************************
USB specific defines
******************************************************************************************************************************/

extern void CheckUSB(void);

#define USB_RX_BUFFER_SIZE	128
#define USB_TX_BUFFER_SIZE	128

extern char USB_RxBuf[USB_RX_BUFFER_SIZE];
extern char USB_TxBuf[2][USB_TX_BUFFER_SIZE];
extern volatile int USB_NbrCharsInTxBuf;
extern volatile int USB_Current_TxBuf;

extern volatile unsigned int USBTimer;
#define USBTIMEOUT  30                  // timeout for USB transmit data

