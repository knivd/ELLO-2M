/***********************************************************************************************************************
MMBasic

Audio.h

Include file that contains the globals and defines for Music.c in the Maximite version of MMBasic.
  
Copyright 2011 - 2014 Geoff Graham.  All Rights Reserved.

This file and modified versions of this file are supplied to specific individuals or organisations under the following 
provisions:

- This file, or any files that comprise the MMBasic source (modified or not), may not be distributed or copied to any other
  person or organisation without written permission.

- Object files (.o and .hex files) generated using this file (modified or not) may not be distributed or copied to any other
  person or organisation without written permission.

- This file is provided in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of 
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

************************************************************************************************************************/



/**********************************************************************************
 the C language function associated with commands, functions or operators should be
 declared here
**********************************************************************************/
#if !defined(INCLUDE_COMMAND_TABLE) && !defined(INCLUDE_TOKEN_TABLE)
    void cmd_play(void);
    void CloseAudio(void);
    void StopAudio(void);
    void audioInterrupt(void);
    extern volatile int vol_left, vol_right;
#endif




/**********************************************************************************
 All command tokens tokens (eg, PRINT, FOR, etc) should be inserted in this table
**********************************************************************************/
#ifdef INCLUDE_COMMAND_TABLE
	{ "Play",        	T_CMD,				0, cmd_play	    },
#endif


/**********************************************************************************
 All other tokens (keywords, functions, operators) should be inserted in this table
**********************************************************************************/
#ifdef INCLUDE_TOKEN_TABLE
// the format is:
//    TEXT      	TYPE                P  FUNCTION TO CALL
// where type is T_NA, T_FUN, T_FNA or T_OPER argumented by the types T_STR and/or T_NBR
// and P is the precedence (which is only used for operators)

#endif
#if !defined(INCLUDE_COMMAND_TABLE) && !defined(INCLUDE_TOKEN_TABLE)
    // General definitions used by other modules
    #ifdef MX470
        #ifndef AUDIO_HEADER
            #define AUDIO_HEADER
            typedef enum { P_NOTHING, P_PAUSE_TONE, P_TONE, P_WAV, P_PAUSE_WAV, P_STOPPED} e_CurrentlyPlaying;
            extern e_CurrentlyPlaying CurrentlyPlaying; 
            #define PWM_FREQ 80000
            extern char *sbuff1, *sbuff2;
            extern const int SineTable50[256];
            extern const int SineTable60[256];
            extern const int SineTable80[256];
        #endif
    #endif
#endif