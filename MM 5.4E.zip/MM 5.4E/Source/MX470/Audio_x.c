/***********************************************************************************************************************
MMBasic

Audio.c

Handles the PLAY command.

Copyright 2011 - 2017 Geoff Graham
Copyright 2017 Peter Mather
All Rights Reserved.

This file and modified versions of this file are supplied to specific individuals or organisations under the following
provisions:

- This file, or any files that comprise the MMBasic source (modified or not), may not be distributed or copied to any other
  person or organisation without written permission.

- Object files (.o and .hex files) generated using this file (modified or not) may not be distributed or copied to any other
  person or organisation without written permission.

- This file is provided in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

************************************************************************************************************************/
#define _SUPPRESS_PLIB_WARNING                      // required for XC1.33  Later compiler versions will need PLIB to be installed
#include <plib.h>									// the pre Harmony peripheral libraries

//#include <p32xxxx.h>								// device specific defines
#include <stdio.h>
#include <stdbool.h>                                // Pascal
#include <stdint.h>                                 // Pascal

#include "../MMBasic_Includes.h"
#include "../Hardware_Includes.h"

//** SD CARD INCLUDES ***********************************************************
#include "SDCard/SDCard.h"
#include "SDCard/FSconfig.h"
extern int InitSDCard(void);
extern int FindFreeFileNbr(void);
extern const int ErrorMap[20];

// define the PWM output frequency for making a tone
volatile unsigned char PWM_count = 0;
volatile unsigned int PhaseM_left, PhaseM_right;

e_CurrentlyPlaying CurrentlyPlaying = P_NOTHING;
volatile int v_left, v_right, vol_left = 100, vol_right = 100;
char *wav_buf;                                                      // pointer to the buffer for received wav data
int wav_filesize;                                                   // head and tail of the ring buffer for com1
int tickspersample;
char *WAVInterrupt = NULL;
int WAVcomplete;
int WAV_fnbr;
int *SineTable;
volatile int swingbuf = 0,nextbuf = 0;
char *sbuff1, *sbuff2;
char *pbuffp;
int *flacbuff;
int ppos = 0;                                                       // playing position for PLAY WAV
int sinemin, sinemax, sineavg, nchannels;
volatile unsigned int bcount[3] = {0, 0, 0};
volatile int last_left, last_right, current_left, current_right;


union map {
    unsigned char sinebytes[4];
    unsigned int sine;
} PhaseAC_left, PhaseAC_right;

const int SineTable50[256] = {
313,319,325,332,338,345,351,357,364,370,376,383,389,395,401,407,413,419,425,431,436,442,447,453,458,464,469,
474,479,484,489,494,498,503,507,511,515,519,523,527,531,534,538,541,544,547,550,552,555,557,560,562,564,565,
567,569,570,571,572,573,574,574,575,575,575,575,575,574,574,573,572,571,570,569,567,565,564,562,560,557,555,
552,550,547,544,541,538,534,531,527,523,519,515,511,507,503,498,494,489,484,479,474,469,464,458,453,447,442,
436,431,425,419,413,407,401,395,389,383,376,370,364,357,351,345,338,332,325,319,313,306,300,293,287,280,274,
268,261,255,249,242,236,230,224,218,212,206,200,194,189,183,178,172,167,161,156,151,146,141,136,131,127,122,
118,114,110,106,102,98,94,91,87,84,81,78,75,73,70,68,65,63,61,60,58,56,55,54,53,52,51,51,50,50,50,50,50,51,
51,52,53,54,55,56,58,60,61,63,65,68,70,73,75,78,81,84,87,91,94,98,102,106,110,114,118,122,127,131,136,141,146,
151,156,161,167,172,178,183,189,194,200,206,212,218,224,230,236,242,249,255,261,268,274,280,287,293,300,306
};
const int SineTable60[256] = {
375,383,390,398,406,414,421,429,436,444,452,459,466,474,481,488,496,503,510,517,523,530,537,544,550,556,563,
569,575,581,587,592,598,603,608,614,618,623,628,633,637,641,645,649,653,656,660,663,666,669,672,674,676,679,
681,682,684,685,687,688,688,689,690,690,690,690,690,689,688,688,687,685,684,682,681,679,676,674,672,669,666,
663,660,656,653,649,645,641,637,633,628,623,618,614,608,603,598,592,587,581,575,569,563,556,550,544,537,530,
523,517,510,503,496,488,481,474,466,459,452,444,436,429,421,414,406,398,390,383,375,367,360,352,344,336,329,
321,314,306,298,291,284,276,269,262,254,247,240,233,227,220,213,206,200,194,187,181,175,169,163,158,152,147,
142,136,132,127,122,117,113,109,105,101,97,94,90,87,84,81,78,76,74,71,69,68,66,65,63,62,62,61,60,60,60,60,60,
61,62,62,63,65,66,68,69,71,74,76,78,81,84,87,90,94,97,101,105,109,113,117,122,127,132,136,142,147,152,158,163,
169,175,181,187,194,200,206,213,220,227,233,240,247,254,262,269,276,284,291,298,306,314,321,329,336,344,352,
360,367
};
const int SineTable80[256] = {
500,510,521,531,541,551,562,572,582,592,602,612,622,632,641,651,661,670,680,689,698,707,716,725,733,742,750,
758,766,774,782,790,797,804,811,818,825,831,837,843,849,855,860,865,870,875,880,884,888,892,895,899,902,905,
907,910,912,914,915,917,918,919,919,920,920,920,919,919,918,917,915,914,912,910,907,905,902,899,895,892,888,
884,880,875,870,865,860,855,849,843,837,831,825,818,811,804,797,790,782,774,766,758,750,742,733,725,716,707,
698,689,680,670,661,651,641,632,622,612,602,592,582,572,562,551,541,531,521,510,500,490,479,469,459,449,438,
428,418,408,398,388,378,368,359,349,339,330,320,311,302,293,284,275,267,258,250,242,234,226,218,210,203,196,
189,182,175,169,163,157,151,145,140,135,130,125,120,116,112,108,105,101,98,95,93,90,88,86,85,83,82,81,81,80,
80,80,81,81,82,83,85,86,88,90,93,95,98,101,105,108,112,116,120,125,130,135,140,145,151,157,163,169,175,182,
189,196,203,210,218,226,234,242,250,258,267,275,284,293,302,311,320,330,339,349,359,368,378,388,398,408,418,
428,438,449,459,469,479,490
};


// setup the sound outputs
void ConfigSoundOutputs(void) {
    ExtCfg(PWM_PLAY_L_PIN, EXT_DIG_OUT, 0); ExtCfg(PWM_PLAY_L_PIN, EXT_COM_RESERVED, 0);
    ExtCfg(PWM_PLAY_R_PIN, EXT_DIG_OUT, 0); ExtCfg(PWM_PLAY_R_PIN, EXT_COM_RESERVED, 0);
    PWM_PLAY_L_OPEN;
    PWM_PLAY_R_OPEN;
    OpenOC4( OC_ON | OC_TIMER_MODE16 | OC_TIMER3_SRC | OC_PWM_FAULT_PIN_DISABLE , (BusSpeed/PWM_FREQ)/2, 0x0000 );
    OpenOC1( OC_ON | OC_TIMER_MODE16 | OC_TIMER3_SRC | OC_PWM_FAULT_PIN_DISABLE , (BusSpeed/PWM_FREQ)/2, 0x0000 );
    OpenTimer3(T3_ON | T2_PS_1_1, BusSpeed/PWM_FREQ);
    ConfigIntTimer3(T3_INT_ON | T3_INT_PRIOR_4);
    if(BusSpeed == 50000000) SineTable = (int *)SineTable50;
    if(BusSpeed == 60000000) SineTable = (int *)SineTable60;
    if(BusSpeed == 80000000) SineTable = (int *)SineTable80;
    sinemin = SineTable[191];
    sinemax = SineTable[63];
    sineavg = SineTable[0];
}


void CloseAudio(void){
    if(CurrentlyPlaying == P_TONE || CurrentlyPlaying == P_PAUSE_TONE) StopAudio();
    else if(CurrentlyPlaying == P_WAV || CurrentlyPlaying == P_PAUSE_WAV) {
        bcount[1] = bcount[2] = wav_filesize = 0;
        StopAudio();
        ForceFileClose(WAV_fnbr);
        FreeMemory(sbuff1); 
        FreeMemory(sbuff2); 
        WAVcomplete = true;
        FSerror = 0;
    }
    return;
}


// The MMBasic command:  PLAY
void cmd_play(void) {
    char *tp;
    unsigned int temp;
    if(checkstring(cmdline, "STOP")) {
        CloseAudio();
        return;
    }
    
    if(checkstring(cmdline, "PAUSE")) {
        if(CurrentlyPlaying == P_TONE)
            CurrentlyPlaying = P_PAUSE_TONE;
        else
        if(CurrentlyPlaying == P_WAV)
            CurrentlyPlaying = P_PAUSE_WAV;
        else
            error("Nothing playing");
        return;
    }

    if(checkstring(cmdline, "RESUME")) {
        if(CurrentlyPlaying == P_PAUSE_TONE)
            CurrentlyPlaying = P_TONE;
        else
        if(CurrentlyPlaying == P_PAUSE_WAV)
            CurrentlyPlaying = P_WAV;
        else
            error("Nothing to resume");  
        return;
    }

    if(checkstring(cmdline, "CLOSE")) {
        CloseAudio();
        PWMClose(1);
        return;
    }

    if((tp = checkstring(cmdline, "VOLUME"))) {
        getargs(&tp, 3, ",");
        if(argc < 1) error("Argument count");
        if(*argv[0]) vol_left = getint(argv[0], 0, 100);
        if(argc == 3) vol_right = getint(argv[2], 0, 100);
        return;
    }

    if(BusSpeed < 50000000) error("CPU speed too low");

    if((tp = checkstring(cmdline, "TONE"))) {
        int f_left, f_right;
        unsigned int PlayDuration = 0xffffffff;                     // default is to play forever
        
        // get the command line arguments
        getargs(&tp, 5, ",");                                       // this MUST be the first executable line in the function
        if(!(argc == 3 || argc == 5)) error("Argument count");

        if(CurrentlyPlaying == P_WAV || CurrentlyPlaying == P_PAUSE_WAV) error("Sound output in use");
        if(CurrentlyPlaying == P_TONE || CurrentlyPlaying == P_PAUSE_TONE) StopAudio();                 // stop the current tone
        
        f_left = getint(argv[0], 1, 20000);                         // get the arguments
        f_right = f_left;
        if(argc > 2 && *argv[2]) f_right = getint(argv[2], 1, 20000);
        if(argc > 4) PlayDuration = getint(argv[4], 0, INT_MAX);
        if(PlayDuration == 0) return;
        
        ConfigSoundOutputs();
        PhaseM_left =  (unsigned int)(((unsigned long long)0xffffffff * (unsigned long long)f_left)  / (unsigned long long)PWM_FREQ);
        PhaseM_right = (unsigned int)(((unsigned long long)0xffffffff * (unsigned long long)f_right) / (unsigned long long)PWM_FREQ);
        CurrentlyPlaying = P_TONE;
        SoundPlay = PlayDuration;
        return;
    }
    
    if((tp = checkstring(cmdline, "WAV"))) {
        char *p;
        unsigned int nbr;
        char sbuff[5];
        short format, samplesize;
        int formatlength, samplerate, dummy, chunksize, nextchunk, sectoroffset;
        
        // get the command line arguments
        getargs(&tp, 3, ",");                                  // this MUST be the first executable line in the function
        if(!(argc == 1 || argc == 3)) error("Argument count");
        
        if(!(CurrentlyPlaying == P_NOTHING || CurrentlyPlaying == P_STOPPED)) error("Sound output in use");

        if(!InitSDCard()) return;
        p = getCstring(argv[0]);                                    // get the file name
        WAVInterrupt = NULL;
        WAVcomplete = 0;
        if(argc == 3) {
            WAVInterrupt = GetIntAddress(argv[2]);					// get the interrupt location
            InterruptUsed = true;
        }

        // open the file
        if(strchr(p, '.') == NULL) strcat(p, ".WAV");
        WAV_fnbr = FindFreeFileNbr();
        if(!BasicFileOpen(p, WAV_fnbr, FA_READ)) return;
        FSerror = f_read(FileTable[WAV_fnbr].fptr, sbuff, 4, &nbr);
        sbuff[4] = 0;
        if(strcmp(sbuff,"RIFF")){
            FileClose(WAV_fnbr);
            error("File format");
        }
        f_read(FileTable[WAV_fnbr].fptr,&wav_filesize, 4, &nbr);
        f_read(FileTable[WAV_fnbr].fptr,sbuff, 4, &nbr);
        sbuff[4] = 0;
        if(strcmp(sbuff,"WAVE")) {
            FileClose(WAV_fnbr);
            error("File format");
        }
        f_read(FileTable[WAV_fnbr].fptr,sbuff, 4, &nbr);
        sbuff[4] = 0;
        f_read(FileTable[WAV_fnbr].fptr,&formatlength, 4, &nbr);
        nextchunk = (*(FileTable[WAV_fnbr].fptr)).fptr + formatlength;
        f_read(FileTable[WAV_fnbr].fptr,&format, 2, &nbr);
        if(format != 1){
            FileClose(WAV_fnbr);
            error("Only 8-bit, 1 or 2-channel, 8 or 16KHz, .WAV files allowed");
        }
        f_read(FileTable[WAV_fnbr].fptr,&nchannels, 2, &nbr);
        if(nchannels != 1 && nchannels != 2 ){
            FileClose(WAV_fnbr);
            error("Only 8-bit, 1 or 2-channel, 8 or 16KHz, .WAV files allowed");
        }
        f_read(FileTable[WAV_fnbr].fptr,&samplerate, 4, &nbr);
        if(!(samplerate==16000 || samplerate==8000)){
            FileClose(WAV_fnbr);
            error("Only 8 or 16KHz, .WAV files allowed");
        }
        tickspersample = PWM_FREQ / samplerate;
        f_read(FileTable[WAV_fnbr].fptr,&dummy, 4, &nbr);
        f_read(FileTable[WAV_fnbr].fptr,&dummy, 2, &nbr);
        f_read(FileTable[WAV_fnbr].fptr,&samplesize, 2, &nbr);
        if(samplesize != 8){
            FileClose(WAV_fnbr);
            error("Only 8-bit, 1 or 2-channel, 8 or 16KHz, .WAV files allowed");
        }
        do{
            f_lseek(FileTable[WAV_fnbr].fptr,nextchunk);
            f_read(FileTable[WAV_fnbr].fptr,sbuff, 4, &nbr);
            sbuff[4] = 0;
            f_read(FileTable[WAV_fnbr].fptr,&chunksize, 4, &nbr);
            nextchunk = chunksize + (*(FileTable[WAV_fnbr].fptr)).fptr;
        } while (strcmp(sbuff,"data"));
        wav_filesize = chunksize;
        sectoroffset = (*(FileTable[WAV_fnbr].fptr)).fptr;
        sbuff1 = GetMemory(WAV_BUFFER_SIZE);                     
        sbuff2 = GetMemory(WAV_BUFFER_SIZE);                     
        wav_filesize -= 32;    
        FSerror=f_read(FileTable[WAV_fnbr].fptr,sbuff1, WAV_BUFFER_SIZE - sectoroffset, &temp);
        bcount[1] = temp;
        wav_filesize -= bcount[1];
        if(bcount[1]==WAV_BUFFER_SIZE-sectoroffset){
            FSerror=f_read(FileTable[WAV_fnbr].fptr,sbuff2, WAV_BUFFER_SIZE, &temp);
            bcount[2] = temp;
        }
        else bcount[2] = 0;
        wav_filesize -= bcount[2];
        last_left = current_left = last_right = current_right = sineavg;
        ppos = 0;
        ConfigSoundOutputs();
        swingbuf = 1;
        nextbuf = 1;
        CurrentlyPlaying = P_WAV;
        return;
    } 
    error("Unknown command");
}



/******************************************************************************************
Timer 1 interrupt.
Used to send data to the PWM for playing a WAV or TONE
*******************************************************************************************/
void audioInterrupt(void) {
    int a,b;
    // play a tone
    if(CurrentlyPlaying == P_TONE){
        PhaseAC_left.sine += PhaseM_left;
        PhaseAC_right.sine += PhaseM_right;
        OC1RS = (sineavg + (((SineTable[PhaseAC_left.sinebytes[3]] - sineavg)  * vol_left) / 100));
        OC4RS = (sineavg + (((SineTable[PhaseAC_right.sinebytes[3]] - sineavg)  * vol_right) / 100));
    } else if(CurrentlyPlaying == P_WAV) {
        if(bcount[1] == 0 && bcount[2] == 0){
            mT3IntEnable(0);     									// disable interrupt 3 (which calls this function from PWM.c)
            OC1RS = sineavg;
            OC4RS = sineavg;
        } else {
            if(PWM_count == 0){
                if(swingbuf){ //buffer is primed
                    last_left = current_left;
                    last_right = current_right;
                    if(swingbuf == 1)pbuffp = sbuff1;
                    else pbuffp = sbuff2;
                    a = pbuffp[ppos++];
                    if(nchannels == 2)b = pbuffp[ppos++];
                    else b = a;
                    a = (a * (sinemax - sinemin) )/ 256;
                    a = (a * vol_left) / 100 + sinemin;
                    b = (b * (sinemax-sinemin))/256;
                    b = (b * vol_right) / 100 + sinemin;
                    if(ppos == bcount[swingbuf]){
                        bcount[swingbuf] = 0;                       //buffer used up
                        if(swingbuf == 1)swingbuf = 2;
                        else swingbuf = 1;
                        ppos = 0;
                    }
                    current_left = a;
                    current_right = a;
                    OC1RS = last_left;
                    OC4RS = last_right;
                }
            }
            OC1RS = (last_left + ((current_left - last_left) * PWM_count) / tickspersample);
            OC4RS = (last_right + ((current_right-last_right)*PWM_count) / tickspersample);
            PWM_count++; if(PWM_count == tickspersample) PWM_count = 0;
        }
    } else {
        // play must be stopped or paused
                OC1RS = sineavg;
                OC4RS = sineavg;
    }
}


/******************************************************************************************
Stop playing the WAV or tone
*******************************************************************************************/
void StopAudio(void) {
    if(CurrentlyPlaying != P_NOTHING) {
        if(CurrentlyPlaying == P_WAV) {
            while(bcount[1] || bcount[2]);                          //wait for playback to complete
        }
        SoundPlay = 0;
        mT3IntEnable(0);     										// disable interrupt
        OC1RS = sineavg;
        OC4RS = sineavg;
        ppos = 0;
        CurrentlyPlaying = P_STOPPED;
    }
}


/******************************************************************************************
 * Maintain the WAV sample buffer
*******************************************************************************************/
void checkWAVinput(void){
    unsigned int temp;
    if(swingbuf != nextbuf) {                                       // audioInterrupt() has moved to next buffer
        if(CurrentlyPlaying == P_WAV) {
            if(swingbuf == 2){
                    FSerror = f_read(FileTable[WAV_fnbr].fptr,sbuff1, WAV_BUFFER_SIZE, &temp);
                    bcount[1] = temp;
                    wav_filesize -= temp;
                    if(FSerror){
                        bcount[1] = 0;
                        bcount[2] = 0;
                        wav_filesize = 0;
                    }

            } else {
                    FSerror = f_read(FileTable[WAV_fnbr].fptr,sbuff2, WAV_BUFFER_SIZE, &temp);
                    bcount[2] = temp;
                    wav_filesize -= temp;
                    if(FSerror){
                        bcount[1] = 0;
                        bcount[2] = 0;
                        wav_filesize = 0;
                    }
            }
        nextbuf = swingbuf;    
        }
    }
    if(wav_filesize <= 0 && (CurrentlyPlaying == P_WAV)) {
        StopAudio();
        FreeMemory(sbuff1); 
        FreeMemory(sbuff2); 
        FileClose(WAV_fnbr);
        WAVcomplete = true;
    }
}

