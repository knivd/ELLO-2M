/***********************************************************************************************************************
MMBasic

xmodem.c

Implements the xmodem command and protocol for the MX470.
 This includes the ability to send and receive a file directly from the SD card.

Copyright 2011 - 2017 Geoff Graham.  All Rights Reserved.

This file and modified versions of this file are supplied to specific individuals or organisations under the following 
provisions:

- This file, or any files that comprise the MMBasic source (modified or not), may not be distributed or copied to any other
  person or organisation without written permission.

- Object files (.o and .hex files) generated using this file (modified or not) may not be distributed or copied to any other
  person or organisation without written permission.

- This file is provided in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of 
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

************************************************************************************************************************/

#include <stdio.h>

#include "../MMBasic_Includes.h"
#include "../Hardware_Includes.h"

void xmodemTransmit(char *p, int fnbr);
void xmodemReceive(char *sp, int maxbytes, int fnbr);
int FindFreeFileNbr(void);


void cmd_xmodem(void) {
	char *buf, BreakKeySave, *p, *fromp;
    int rcv = 0, fnbr;
	char *fname;

    if(toupper(*cmdline) == 'R')
        rcv = true;
    else if(toupper(*cmdline) == 'S')
        rcv = false;
    else
        error("Syntax");
    while(isalpha(*cmdline)) cmdline++ ;                           // find the filename (if it is there)
    skipspace(cmdline);

    BreakKeySave = BreakKey;
    BreakKey = 0;
        
    if(*cmdline == 0 || *cmdline == '\'') {
        // no file name, so this is a transfer to/from program memory
        if(CurrentLinePtr) error("Invalid in a program");
        ClearProgram();                                             // we need all the RAM
        buf = GetTempMemory(EDIT_BUFFER_SIZE);
        if(rcv) {
            xmodemReceive(buf, EDIT_BUFFER_SIZE, 0);
            SaveProgramToFlash(buf, true);
        } else {
            // we must copy program memory into RAM expanding tokens as we go
            fromp  = ProgFlash;
            p = buf;                                                // the RAM buffer
            while(1) {
                if(*fromp == T_LINENBR) {
                    fromp = llist(p, fromp);                        // expand the line into the buffer
                    p += strlen(p);
                    if(p - buf + 40 > EDIT_BUFFER_SIZE) error("Not enough memory");
                    *p++ = '\n'; *p = 0;                            // terminate that line
                }
                if(fromp[0] == 0 || fromp[0] == 0xff) break;        // finally, is it the end of the program?
            }
            --p; *p = 0;                                            // erase the last line terminator
            xmodemTransmit(buf, 0);                                 // send it off
        }
    } else {
        // this is a transfer to/from the SD card
        fnbr = FindFreeFileNbr();
        fname = getCstring(cmdline);                               // get the file name
        
        if(rcv) {
            if(!BasicFileOpen(fname, fnbr, FSA_WRITE_CREATE_ALWAYS)) return;
            xmodemReceive(NULL, 0, fnbr);
        } else {
            if(!BasicFileOpen(fname, fnbr, FSA_READ)) return;
            xmodemTransmit(NULL, fnbr);
        }
        FileClose(fnbr);
    }
    BreakKey = BreakKeySave;
}


int _inbyte(int timeout) {
	int c;
	
	PauseTimer = 0;
	while(PauseTimer < timeout) {
		c = getConsole();
		if(c != -1) {
			return c;
		}	
	}
	return -1;	
}


// for the MX470 we don't want any XModem data echoed to the LCD panel
#if defined(MX470)
#define putConsole(c) SerUSBPutC(c)
#endif


/***********************************************************************************************
the xmodem protocol
************************************************************************************************/

/* derived from the work of Georges Menie (www.menie.org) Copyright 2001-2010 Georges Menie
 * very much debugged and changed
 *
 * this is just the basic XModem protocol (no 1K blocks, crc, etc).  It has been tested on
 * Terra Term and is intended for use with that software.
 */


#define SOH  0x01
#define STX  0x02
#define EOT  0x04
#define ACK  0x06
#define NAK  0x15
#define CAN  0x18
#define PAD  0x1a

#define DLY_1S 1000
#define MAXRETRANS 25

#define X_BLOCK_SIZE	128
#define X_BUF_SIZE	X_BLOCK_SIZE + 6								// 128 for XModem + 3 head chars + 2 crc + nul


static int check(const unsigned char *buf, int sz)
{
	int i;
	unsigned char cks = 0;
	for (i = 0; i < sz; ++i) {
		cks += buf[i];
	}
	if (cks == buf[sz])
		return 1;

	return 0;
}


static void flushinput(void)
{
	while (_inbyte(((DLY_1S)*3)>>1) >= 0);
}


// receive data
// if sp == NULL we are saving to a file on the SD card (fnbr is the file number)
// otherwise we are saving to RAM which will later be written to program memory
void xmodemReceive(char *sp, int maxbytes, int fnbr) {
	unsigned char xbuff[X_BUF_SIZE];
	unsigned char *p;
	unsigned char trychar = NAK; //'C';
	unsigned char packetno = 1;
	int i, c;
	int retry, retrans = MAXRETRANS;

	// first establish communication with the remote
	while(1) {
		for( retry = 0; retry < 32; ++retry) {
			if(trychar) putConsole(trychar);
			if ((c = _inbyte((DLY_1S)<<1)) >= 0) {
				switch (c) {
				case SOH:
					goto start_recv;
				case EOT:
					flushinput();
					putConsole(ACK);
                    if(sp != NULL) {
                        if(maxbytes <= 0) error("Not enough memory");
                        *sp++ = 0;                                  // terminate the data
                    }
					return; 										// no more data
				case CAN:
					flushinput();
					putConsole(ACK);
					error("Cancelled by remote");
					break;
				default:
					break;
				}
			}
		}
		flushinput();
		putConsole(CAN);
		putConsole(CAN);
		putConsole(CAN);
		error("Remote did not respond");                            // no sync

	start_recv:
		trychar = 0;
		p = xbuff;
		*p++ = SOH;
		for (i = 0;  i < (X_BLOCK_SIZE+3); ++i) {
			if ((c = _inbyte(DLY_1S)) < 0) goto reject;
			*p++ = c;
		}

		if (xbuff[1] == (unsigned char)(~xbuff[2]) && (xbuff[1] == packetno || xbuff[1] == (unsigned char)packetno-1) && check(&xbuff[3], X_BLOCK_SIZE)) {
			if (xbuff[1] == packetno)	{
				for(i = 0 ; i < X_BLOCK_SIZE ; i++) {
                    if(sp != NULL) {
                        // save the data to the RAM buffer
                        if(--maxbytes > 0) {
                            if(xbuff[i + 3] == PAD)
                                *sp++ = 0;                          // replace any EOF's (used to pad out a block) with NUL
                            else
                                *sp++ = xbuff[i + 3];               // saving to a memory buffer
                        }
                    } else {
                        // we are saving to a file
                        FilePutChar(xbuff[i + 3], fnbr);            
                    }
                }
				++packetno;
				retrans = MAXRETRANS+1;
			}
			if (--retrans <= 0) {
				flushinput();
				putConsole(CAN);
				putConsole(CAN);
				putConsole(CAN);
				error("Too many errors");
			}
			putConsole(ACK);
			continue;
		}
	reject:
		flushinput();
		putConsole(NAK);
	}
}


// transmit data
// if p == NULL we are reading the data to be sent from a file on the SD card (fnbr is the file number)
// otherwise we are reading from RAM and p points to the start of the data (which is terminated by a zero char)
void xmodemTransmit(char *p, int fnbr) {
	unsigned char xbuff[X_BUF_SIZE]; 
	unsigned char packetno = 1;
    char prevchar = 0;
	int i, c, len;
	int retry;

	// first establish communication with the remote
	while(1) {
		for( retry = 0; retry < 32; ++retry) {
			if ((c = _inbyte((DLY_1S)<<1)) >= 0) {
				switch (c) {
				case NAK:											// start sending
					goto start_trans;
				case CAN:
					if ((c = _inbyte(DLY_1S)) == CAN) {
						putConsole(ACK);
						flushinput();
						error("Cancelled by remote");
					}
					break;
				default:
					break;
				}
			}
		}
		putConsole(CAN);
		putConsole(CAN);
		putConsole(CAN);
		flushinput();
		error("Remote did not respond");							// no sync

		// send a packet
		while(1) {
		start_trans:
			memset (xbuff, 0, X_BUF_SIZE);							// start with an empty buffer
			
			xbuff[0] = SOH;											// copy the header
			xbuff[1] = packetno;
			xbuff[2] = ~packetno;
			
            if(p != NULL) {
                // our data is in RAM
                for(len = 0; len < 128 && *p; len++) {
                    if(*p == '\n' && prevchar != '\r')
                        prevchar = xbuff[len + 3] = '\r';
                    else
                        prevchar = xbuff[len + 3] = *p++;			// copy the data from memory into the packet
                }
            } else {
                // we get the data from a file
                for(len = 0; len < 128 && !FileEOF(fnbr); len++) {
                    xbuff[len + 3] = FileGetChar(fnbr);				// copy the data from the file into the packet
                }
            }
			if (len > 0) {
				unsigned char ccks = 0;
				for (i = 3; i < X_BLOCK_SIZE+3; ++i) {
					ccks += xbuff[i];
				}
				xbuff[X_BLOCK_SIZE+3] = ccks;
				
				// now send the block
				for (retry = 0; retry < MAXRETRANS && !MMAbort; ++retry) {
					// send the block
					for (i = 0; i < X_BLOCK_SIZE+4 && !MMAbort; ++i) {
						putConsole(xbuff[i]);
					}
					// check the response
					if ((c = _inbyte(DLY_1S)) >= 0 ) {
						switch (c) {
						case ACK:
							++packetno;
							goto start_trans;
						case CAN:									// cancelled by remote
							putConsole(ACK);
							flushinput();
							error("Cancelled by remote");
							break;
						case NAK:									// receiver got a corrupt block
						default:
							break;
						}
					}
				}
				// too many retrys... give up
				putConsole(CAN);
				putConsole(CAN);
				putConsole(CAN);
				flushinput();
				error("Too many errors");
			}
			
			// finished sending - send end of text
			else {
				for (retry = 0; retry < 10; ++retry) {
					putConsole(EOT);
					if ((c = _inbyte((DLY_1S)<<1)) == ACK) break;
				}
				flushinput();
				if(c == ACK) return;
				error("Error closing");
			}
		}
	}
}

