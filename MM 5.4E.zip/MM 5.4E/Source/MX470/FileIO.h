/***********************************************************************************************************************
MMBasic

FileIO.h

Supporting header file for FileIO.c which does all the SD Card related file I/O in MMBasic.

Copyright 2011 - 2017 Geoff Graham.  All Rights Reserved.

This file and modified versions of this file are supplied to specific individuals or organisations under the following
provisions:

- This file, or any files that comprise the MMBasic source (modified or not), may not be distributed or copied to any other
  person or organisation without written permission.

- Object files (.o and .hex files) generated using this file (modified or not) may not be distributed or copied to any other
  person or organisation without written permission.

- This file is provided in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

************************************************************************************************************************/



/**********************************************************************************
 the C language function associated with commands, functions or operators should be
 declared here
**********************************************************************************/
#if !defined(INCLUDE_COMMAND_TABLE) && !defined(INCLUDE_TOKEN_TABLE)

void cmd_save(void);
void cmd_load(void);
void cmd_mkdir(void);
void cmd_rmdir(void);
void cmd_chdir(void);
void cmd_kill(void);
void cmd_drive(void);
void cmd_a_drive(void);
void cmd_b_drive(void);
void cmd_c_drive(void);
void cmd_d_drive(void);
void cmd_e_drive(void);
void cmd_name(void);
void cmd_seek(void);
void cmd_files(void);

void fun_cwd(void);
void fun_dir(void);
void fun_drive(void);
void cmd_fwupdate(void);
void cmd_verinfo(void);
#endif




/**********************************************************************************
 All command tokens tokens (eg, PRINT, FOR, etc) should be inserted in this table
**********************************************************************************/
#ifdef INCLUDE_COMMAND_TABLE

	{ "Save",		T_CMD,				0, cmd_save	},
	{ "Load",		T_CMD,				0, cmd_load	},
	{ "Mkdir",		T_CMD,				0, cmd_mkdir	},
	{ "Rmdir",		T_CMD,				0, cmd_rmdir	},
	{ "Chdir",		T_CMD,				0, cmd_chdir	},
	{ "Kill",		T_CMD,				0, cmd_kill	},
    { "Drive",		T_CMD,				0, cmd_drive	},            
	{ "Name",		T_CMD,				0, cmd_name	},
	{ "Seek",		T_CMD,				0, cmd_seek     },
	{ "Files",		T_CMD,				0, cmd_files    },
    { "Dir",		T_CMD,				0, cmd_files    },
    { "A:",         T_CMD,				0, cmd_a_drive	}, 
    { "B:",         T_CMD,				0, cmd_b_drive	},
    { "C:",         T_CMD,				0, cmd_c_drive	},
    { "D:",         T_CMD,				0, cmd_d_drive	},
    { "E:",         T_CMD,				0, cmd_e_drive	},
    { "FWUpdate",   T_CMD,				0, cmd_fwupdate	},
    { "VerInfo",    T_CMD,				0, cmd_verinfo	},
#endif


/**********************************************************************************
 All other tokens (keywords, functions, operators) should be inserted in this table
**********************************************************************************/
#ifdef INCLUDE_TOKEN_TABLE

	{ "Cwd$",		T_FNA | T_STR,		0, fun_cwd		},
	{ "Dir$(",		T_FUN | T_STR,		0, fun_dir		},
    { "MM.Drive",	T_FNA | T_INT,		0, fun_drive	},
#endif


#if !defined(INCLUDE_COMMAND_TABLE) && !defined(INCLUDE_TOKEN_TABLE)

    #ifndef _FILEIO_HEADER_
    #define _FILEIO_HEADER_
        /* File access mode and open method flags (3rd argument of f_open) */
        #define	FSA_READ                         ("r")
        #define	FSA_WRITE_CREATE_ALWAYS			("w")
    #endif
    extern void FileOpen(char *fname, char *fmode, char *ffnbr);
    extern int BasicFileOpen(char *fname, int fnbr, char *mode);
    extern void File_fopen(char *fname, char *mode, int fnbr);
    extern void FileClose(int fnbr);
    extern char FileGetChar(int fnbr);
    extern char FilePutChar(char c, int fnbr);
    extern int  FileEOF(int fnbr);
    extern unsigned long FileLOC(int fnbr);
    extern unsigned long FileLOF(int fnbr);
    extern char *ChangeToDir(char *p);
    extern void SDCardClose(void);
    extern void ConfigSDCard(char *p, unsigned char sd_number);
    extern void InitFileIO(void);
    extern int InitSDCard(void);
    extern char* GetPrompt(void);
    extern void DisableSDCard(unsigned char sd_number);
    extern int SDCardPresent[];
    extern char *wav_buf;											// pointer to the buffer for received wav data
    extern volatile int wav_head, wav_tail, wav_filesize;           // head and tail of the ring buffer for com1
    extern int WAV_tickspersample;
    extern void checkWAVinput(void);
    extern char *WAVInterrupt;
    extern int WAVcomplete;
    extern int WAV_fnbr;
    #define WAV_BUFFER_SIZE (8000 * 1 * 2)                          // 1 second at 8KHz
    extern int OptionFileErrorAbort;
    
#endif
