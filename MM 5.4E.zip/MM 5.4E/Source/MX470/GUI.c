/***********************************************************************************************************************
MMBasic

Display.c

Does all the LCD display commands and I/O in MMBasic.

Copyright 2011 - 2017 Geoff Graham.  All Rights Reserved.

This file and modified versions of this file are supplied to specific individuals or organisations under the following
provisions:

- This file, or any files that comprise the MMBasic source (modified or not), may not be distributed or copied to any other
  person or organisation without written permission.

- Object files (.o and .hex files) generated using this file (modified or not) may not be distributed or copied to any other
  person or organisation without written permission.

- This file is provided in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

************************************************************************************************************************/


#define _SUPPRESS_PLIB_WARNING                      // required for XC1.33  Later compiler versions will need PLIB to be installed
#include <plib.h>									// the pre Harmony peripheral libraries
#include <float.h>

#include "../MMBasic_Includes.h"
#include "../Hardware_Includes.h"

#include "SSD1963.h"


#define BTN_SIDE_BRIGHT     -25
#define BTN_SIDE_DULL       -50
#define BTN_SIDE_WIDTH      4
#define BTN_CAPTION_SHIFT   2

#define CLICK_DURATION      3           // the duration of a "click" in mSec

#define CTRL_NORMAL         0b0000000   // the control should be displayed as normal
#define CTRL_DISABLED       0b0000001   // the control is disabled and displayed in dull colours
#define CTRL_DISABLED2      0b0000010   // as above but only used when a keyboard is active
#define CTRL_HIDDEN         0b0000100   // the control is hidden
#define CTRL_HIDDEN2        0b0001000   // only used when setting a control to hidden
#define CTRL_SPINUP         0b0010000   // the spinbox up arrow is touched
#define CTRL_SPINDOWN       0b0100000   // ditto down
#define CTRL_SELECTED       0b1000000   // for a textbox or numberbox indicated that the box is selected

#define BTN_DISABLED        -55

// define what the function DrawKeyboard() will do
#define KEY_OPEN            1
#define KEY_DRAW_ALL        2
#define KEY_KEY_DWN         3
#define KEY_KEY_UP          4
#define KEY_CANCEL           5

#define CTRL_BUTTON         1
#define CTRL_SWITCH         2
#define CTRL_RADIOBTN       3
#define CTRL_CHECKBOX       4
#define CTRL_LED            5
#define CTRL_SPINNER        6
#define CTRL_FRAME          7
#define CTRL_NBRBOX         8
#define CTRL_TEXTBOX        9
#define CTRL_DISPLAYBOX     10
#define CTRL_CAPTION        11
#define CTRL_GRAPH          12
#define CTRL_AREA           13

#define MAX_PAGES           32          // the number of pages that can be specifies (this must not exceed 32)
#if defined(MX470)
    extern void cmd_guiMX170(void);
#endif
int SetupPage;
unsigned int CurrentPages;

int gui_font_width, gui_font_height;

int display_backlight;                  // the brightness of the backlight (1 to 100)

int gui_click_pin = 0;                  // the sound pin

volatile int CursorTimer;               // used to time the flashing cursor
volatile int ClickTimer = 0;            // used to time the click when touch occurs
volatile int TouchTimer;                // used to time the response to touch
int CheckGuiFlag = 0;                   // used to tell the mSec timer to call CheckGui()

int CurrentRef;                         // if the pen is down this is the control (or zero if not on a control)
int LastRef;                            // this is the last control touched
int LastX;                              // this is the x coord when the pen was lifted
int LastY;                              // ditto for y

float CtrlSavedVal;                     // a temporary place to save a control's value

int TouchX, TouchY;
volatile int TouchDown = false;
volatile int TouchUp = false;


int last_x2, last_y2;                   // defaults used when creating controls
float last_inc, last_min, last_max;
int last_fcolour, last_bcolour;

int KeyDown = 0;
int KeyAltShift = 0;
int InvokingCtrl = 0;

int gui_int_down;                       // true if the touch has triggered an interrupt
char *GuiIntDownVector = NULL;          // address of the interrupt routine or NULL if no interrupt
int gui_int_up;                         // true if the release of the touch has triggered an interrupt
char *GuiIntUpVector = NULL;            // address of the interrupt routine or NULL if no interrupt
int DelayedDrawKeyboard = false;        // a flag to indicate that the pop-up keyboard should be drawn AFTER the pen down interrupt

struct s_ctrl *Ctrl;                    // list of the controls


int ChangeBright(int c, int pct);
void SpecialWritePixel(int x, int y, unsigned int tc, int status);
void SpecialDrawLine(int x1, int y1, int x2, int y2, int w, int tc, int status);
void SpecialDrawBox(int x1, int y1, int x2, int y2, int w, int c, int fill, int status);
void SpecialDrawRBox(int x1, int y1, int x2, int y2, int radius, int c, int fill, int status);
void SpecialPrintString(int x, int y, int jh, int jv, int jo, int fc, int bc, char *str, int status);
void SpecialDrawCircle(int x, int y, int radius, int w, int c, int fill, float aspect, int status);
void SpecialDrawTriangle(int x0, int y0, int x1, int y1, int x2, int y2, int c, int fill, int status);
void DrawBorder(int x1, int y1, int x2, int y2, int w, int tc, int bc, int status);
void DrawBasicButton(int x1, int y1, int x2, int y2, int w, int up, int c, int status);
void DrawButton(int r);
void DrawSwitch(int r);
void DrawCheckBox(int r);
void DrawRadioBtn(int r);
void DrawLED(int r);
void DrawSpinner(int r);
void DrawFrame(int r);
void DrawCaption(int r);
char *GetCaption(int k, int is_alpha, int alt);
void GetSingleKeyCoord(int k, int is_alpha, int *x1, int *y1, int *x2, int *y2);
void DrawTextBox(int r);
void PopUpRedrawAll(int r, int disabled);
void KeyPadErase(int is_alpha);
void DrawSingleKey(int is_alpha, int x1, int y1, int x2, int y2, char *s, int fc, int bc);
void DrawKeyboard(int mode);
void DrawControl(int r);
void UpdateControl(int r);
void SetCtrlState(int r, int state, int err);
void DoCallback(int InvokingCtrl, char *key);



////////////////////////////////////////////////////////////////////////////////////////////////////////
//
// The GUI command is the base of all the sophisticated GUI drawing features in the Micromite Plus
//
////////////////////////////////////////////////////////////////////////////////////////////////////////



/*********************************************************************************************
 Most controls have similar argument lists, so this function is a "universal" argument
 collector for all controls.
 It returns with the control's reference number in case the caller wants to make some
 more adjustments.
 ********************************************************************************************/
int GetCtrlParams(int type, char *p) {
    int r, a;

    getargs(&p, 19, ",");
    if((argc & 1) != 1) error("Argument count");
    if(*argv[0] == '#') argv[0]++;
    r = getint(argv[0], 1, Option.MaxCtrls - 1);
    if(Ctrl[r].type) error("GUI reference number #% is in use", r);
    if(argc < 5) error("Argument count");
    a = 0;

    // setup the defaults
    Ctrl[r].x2 = last_x2; Ctrl[r].y2 = last_y2;
    if(type == CTRL_CAPTION) {
        Ctrl[r].fc = gui_fcolour;                                   // a caption defaults to the system colours set by the COLOUR command
        Ctrl[r].bc = gui_bcolour;
    } else {
        Ctrl[r].fc = last_fcolour;                                  // the others take the last colours used in the last command
        Ctrl[r].bc = last_bcolour;
    }
    Ctrl[r].inc = last_inc; Ctrl[r].min = last_min; Ctrl[r].max = last_max;

    // save the current font, needed if we redraw the control
    Ctrl[r].font = gui_font;

    // get string space
    Ctrl[r].s = GetMemory(MAXSTRLEN);

    // and the caption if the control needs it
    switch(type) {                  // these need a caption
        case CTRL_CAPTION:
        case CTRL_BUTTON:
        case CTRL_LED:
        case CTRL_SWITCH:
        case CTRL_FRAME:
        case CTRL_RADIOBTN:
        case CTRL_CHECKBOX:         strcpy(Ctrl[r].s, getCstring(argv[a += 2]));
}

    // get x1 and y1 - all controls require these
    Ctrl[r].x1 = getint(argv[a += 2], 0, HRes);
    if(argc < a) error("Argument count");
    Ctrl[r].y1 = getint(argv[a += 2], 0, VRes);

    // the fourth argument in GUI CAPTION is the justification
    if(type == CTRL_CAPTION) {
        a += 2;
        if(!(argc < a || *argv[a] == 0)) {                          // if justification is specified
            int jh = 0, jv = 0, jo = 0;
            if(!GetJustification(argv[a], &jh, &jv, &jo))
                if(!GetJustification(getCstring(argv[a]), &jh, &jv, &jo)) 
                    error("Justification");;
            Ctrl[r].x2 = jh | jv << 2 | jo << 4;                    // stuff the justification parameters into the short int
        }
        else
            Ctrl[r].x2 = 0;
    } else {
        // get the width - all controls except CAPTION need this
        if(argc > a + 2) if(*argv[a += 2] != 0) last_x2 = Ctrl[r].x2 = getint(argv[a], BTN_SIDE_WIDTH, HRes);

        // now get or set the height
        switch(type) {
            case CTRL_NBRBOX:          *Ctrl[r].s = '0';            // this needs to be set, then fall thru
            case CTRL_BUTTON:
            case CTRL_SWITCH:
            case CTRL_FRAME:
            case CTRL_TEXTBOX:
            case CTRL_DISPLAYBOX:
            case CTRL_SPINNER:
            case CTRL_AREA:
            case CTRL_GRAPH:            // these all need the height in addition to the width
                                        if(argc > a + 2) if(*argv[a += 2] != 0) last_y2 = Ctrl[r].y2 = getint(argv[a], BTN_SIDE_WIDTH, VRes);
                                        Ctrl[r].x2 +=  Ctrl[r].x1; Ctrl[r].y2 +=  Ctrl[r].y1;
                                        break;

            case CTRL_CHECKBOX:         // the radio button does not need the height and is a special case
                                        // its touch sensitive area is different from its drawing parameters
                                        // we have the width/height in x2 and it is saved in Ctrl[r].inc
                                        Ctrl[r].inc = Ctrl[r].x2; 
                                        Ctrl[r].y2 =  Ctrl[r].y1 + Ctrl[r].x2;  // calculate the touch sensitive area
                                        Ctrl[r].x2 = Ctrl[r].x1 + Ctrl[r].x2 + (gui_font_width * (strlen(Ctrl[r].s) + 1));  // calculate the touch sensitive area
                                        break;

            case CTRL_RADIOBTN:         // the radio button also does not need the height and is a special case
                                        // its touch sensitive area is different from its drawing parameters
                                        // the button's X centre is saved in Ctrl[r].min, Y centre in Ctrl[r].min and radius in Ctrl[r].inc
                                        Ctrl[r].min = Ctrl[r].x1;
                                        Ctrl[r].max = Ctrl[r].y1;
                                        Ctrl[r].inc = Ctrl[r].x2;
                                        Ctrl[r].x2 = Ctrl[r].x1 + Ctrl[r].inc + (gui_font_width * (strlen(Ctrl[r].s) + 1));  // calculate the touch sensitive area
                                        Ctrl[r].x1 -= Ctrl[r].inc;
                                        Ctrl[r].y2 = Ctrl[r].y1 + Ctrl[r].inc;
                                        Ctrl[r].y1 -= Ctrl[r].inc;
                                        break;

        }
    }

    // get the foreground colour - all controls except the area control need this
    if(type != CTRL_AREA && argc > a + 2) if(*argv[a += 2] != 0) last_fcolour = Ctrl[r].fc = getint(argv[a], BLACK, WHITE);

    switch(type) {                  // these all need the background colour
        case CTRL_SPINNER:
        case CTRL_BUTTON:
        case CTRL_SWITCH:
        case CTRL_TEXTBOX:
        case CTRL_NBRBOX:
        case CTRL_DISPLAYBOX:
        case CTRL_GRAPH:            if(argc > a + 2) if(*argv[a += 2] != 0) last_bcolour = Ctrl[r].bc = getint(argv[a], 0, WHITE);
                                    break;
        case CTRL_CAPTION:          if(argc > a + 2) if(*argv[a += 2] != 0) last_bcolour = Ctrl[r].bc = getint(argv[a], -1, WHITE);
                                    break;
    }

    if(Ctrl[r].type != CTRL_SPINNER) {
        if(argc > a + 2) if(*argv[a += 2] != 0) last_inc = Ctrl[r].inc = getnumber(argv[a]);
        if(argc > a + 2) if(*argv[a += 2] != 0) last_min = Ctrl[r].min = getnumber(argv[a]);
        if(argc > a + 2) last_max = Ctrl[r].max = getnumber(argv[a += 2]);
    }

    if(argc > a + 1) error("Argument count");
    Ctrl[r].type = type;
    Ctrl[r].value = 0;
    Ctrl[r].page = SetupPage;
    Ctrl[r].fcc = gui_fcolour;
    SetCtrlState(r, CTRL_NORMAL, false);
    return r;
}


void cmd_gui(void) {
    int r;
    char *p;

    if(HRes == 0) error("LCD Panel not configured");

    if((p = checkstring(cmdline, "BUTTON"))) {
        r = GetCtrlParams(CTRL_BUTTON, p);
        return;
    }


    if((p = checkstring(cmdline, "SWITCH"))) {
        r = GetCtrlParams(CTRL_SWITCH, p);
        return;
    }


    if((p = checkstring(cmdline, "CHECKBOX"))) {
        r = GetCtrlParams(CTRL_CHECKBOX, p);
        return;
    }


    if((p = checkstring(cmdline, "RADIO"))) {
        r = GetCtrlParams(CTRL_RADIOBTN, p);

        return;
    }


    if((p = checkstring(cmdline, "LED"))) {
        r = GetCtrlParams(CTRL_LED, p);
        Ctrl[r].inc = 0;
        return;
    }


    if((p = checkstring(cmdline, "FRAME"))) {
        r = GetCtrlParams(CTRL_FRAME, p);
        return;
    }


    if((p = checkstring(cmdline, "NUMBERBOX"))) {
        char *pp;
        if((pp = checkstring(p, "CANCEL"))) {
            if(!InvokingCtrl) return;
            DrawKeyboard(KEY_CANCEL);
        } else
            r = GetCtrlParams(CTRL_NBRBOX, p);
        return;
    }

    
    if((p = checkstring(cmdline, "TEXTBOX"))) {
        char *pp;
        if((pp = checkstring(p, "CANCEL"))) {
            if(!InvokingCtrl) return;
            DrawKeyboard(KEY_CANCEL);
        } else
            r = GetCtrlParams(CTRL_TEXTBOX, p);
        return;
    }


    if((p = checkstring(cmdline, "SPINBOX"))) {
        r = GetCtrlParams(CTRL_SPINNER, p);
        Ctrl[r].value = 0;
        if(Ctrl[r].value < Ctrl[r].min) Ctrl[r].value = Ctrl[r].min;
        if(Ctrl[r].value > Ctrl[r].max) Ctrl[r].value = Ctrl[r].max;
        FloatToStr(Ctrl[r].s, Ctrl[r].value, 0, -1, ' ');
        UpdateControl(r);                                             // update the displayed string
        return;
    }


    if((p = checkstring(cmdline, "DISPLAYBOX"))) {
        r = GetCtrlParams(CTRL_DISPLAYBOX, p);
        return;
    }


    if((p = checkstring(cmdline, "CAPTION"))) {
        r = GetCtrlParams(CTRL_CAPTION, p);
        return;
    }


    if((p = checkstring(cmdline, "GRAPH"))) {
        r = GetCtrlParams(CTRL_GRAPH, p);
        return;
    }


    if((p = checkstring(cmdline, "AREA"))) {
        r = GetCtrlParams(CTRL_AREA, p);
        return;
    }


    if((p = checkstring(cmdline, "DELETE"))) {
        int i, r;
        getargs(&p, MAX_ARG_COUNT, ",");
        if(!(argc & 1)) error("Argument count");
        if(checkstring(argv[0], "ALL")) {
            for(r = 1; r < Option.MaxCtrls; r++)
                if(Ctrl[r].type != 0) {
                    SetCtrlState(r, CTRL_HIDDEN, true);
                    FreeMemory(Ctrl[r].s);
                    Ctrl[r].state = Ctrl[r].type = 0;
                }
            return;
        } else {
            for(i = 0; i < argc; i += 2) {
                if(*argv[i] == '#') argv[i]++;
                r = getint(argv[i], 1, Option.MaxCtrls - 1);
                SetCtrlState(r, CTRL_HIDDEN, true);
                FreeMemory(Ctrl[r].s);
                Ctrl[r].state = Ctrl[r].type = 0;
            }
        }
        return;
    }


    if((p = checkstring(cmdline, "DISABLE"))) {
        int i, r;
        getargs(&p, MAX_ARG_COUNT, ",");
        if(!(argc & 1)) error("Argument count");
        if(checkstring(argv[0], "ALL")) {
            for(r = 1; r < Option.MaxCtrls; r++)
                SetCtrlState(r, CTRL_DISABLED, false);
            return;
        }
        for(i = 0; i < argc; i += 2) {
            if(*argv[i] == '#') argv[i]++;
            r = getint(argv[i], 1, Option.MaxCtrls - 1);
            SetCtrlState(r, CTRL_DISABLED, true);
        }
        return;
    }


    if((p = checkstring(cmdline, "HIDE"))) {
        int i, r;
        getargs(&p, MAX_ARG_COUNT, ",");
        if(!(argc & 1)) error("Argument count");
        if(checkstring(argv[0], "ALL")) {
            for(r = 1; r < Option.MaxCtrls; r++)
                if(CurrentPages & (1 << Ctrl[r].page)) 
                    SetCtrlState(r, CTRL_HIDDEN, false);
            return;
        }
        for(i = 0; i < argc; i += 2) {
            if(*argv[i] == '#') argv[i]++;
            r = getint(argv[i], 1, Option.MaxCtrls - 1);
            if(CurrentPages & (1 << Ctrl[r].page)) 
                SetCtrlState(r, CTRL_HIDDEN, true);
        }
        return;
    }


    if((p = checkstring(cmdline, "ENABLE"))) {
        int i, r;
        getargs(&p, MAX_ARG_COUNT, ",");
        if(!(argc & 1)) error("Argument count");
        if(checkstring(argv[0], "ALL")) {
            for(r = 1; r < Option.MaxCtrls; r++) {
                Ctrl[r].state &= ~(CTRL_DISABLED | CTRL_DISABLED2);
                SetCtrlState(r, CTRL_NORMAL, false);
            }
            return;
        }
        for(i = 0; i < argc; i += 2) {
            if(*argv[i] == '#') argv[i]++;
            r = getint(argv[i], 1, Option.MaxCtrls - 1);
            Ctrl[r].state &= ~(CTRL_DISABLED | CTRL_DISABLED2);
            SetCtrlState(r, CTRL_NORMAL, true);
        }
        return;
    }


    if((p = checkstring(cmdline, "SHOW"))) {
        int i, r;
        getargs(&p, MAX_ARG_COUNT, ",");
        if(!(argc & 1)) error("Argument count");
        if(checkstring(argv[0], "ALL")) {
            for(r = 1; r < Option.MaxCtrls; r++) {
                Ctrl[r].state &= ~CTRL_HIDDEN;
                SetCtrlState(r, CTRL_NORMAL, false);
            }
            return;
        }
        for(i = 0; i < argc; i += 2) {
            if(*argv[i] == '#') argv[i]++;
            r = getint(argv[i], 1, Option.MaxCtrls - 1);
            Ctrl[r].state &= ~CTRL_HIDDEN;
            SetCtrlState(r, CTRL_NORMAL, true);
        }
        return;
    }


    if((p = checkstring(cmdline, "RESTORE"))) {
        int i, r;
        getargs(&p, MAX_ARG_COUNT, ",");
        if(!(argc & 1)) error("Argument count");
        if(checkstring(argv[0], "ALL")) {
            for(r = 1; r < Option.MaxCtrls; r++) {
                Ctrl[r].state &= ~(CTRL_DISABLED | CTRL_DISABLED2 | CTRL_HIDDEN);
                SetCtrlState(r, CTRL_NORMAL, false);
            }
            return;
        }
        for(i = 0; i < argc; i += 2) {
            if(*argv[i] == '#') argv[i]++;
            r = getint(argv[i], 1, Option.MaxCtrls - 1);
            Ctrl[r].state &= ~(CTRL_DISABLED | CTRL_DISABLED2 | CTRL_HIDDEN);
            SetCtrlState(r, CTRL_NORMAL, true);
        }
        return;
    }


    if((p = checkstring(cmdline, "REDRAW"))) {
        int i, r;
        getargs(&p, MAX_ARG_COUNT, ",");
        if(!(argc & 1)) error("Argument count");
        if(checkstring(argv[0], "ALL")) {
            for(r = 1; r < Option.MaxCtrls; r++)
                UpdateControl(r);
            return;
        }
        for(i = 0; i < argc; i += 2) {
            if(*argv[i] == '#') argv[i]++;
            r = getint(argv[i], 1, Option.MaxCtrls - 1);
            UpdateControl(r);
        }
        return;
    }


    if((p = checkstring(cmdline, "FCOLOUR")) || (p = checkstring(cmdline, "BCOLOUR"))) {
        int i, r, c;
        getargs(&p, MAX_ARG_COUNT, ",");
        if(!(argc & 1) || argc < 3) error("Argument count");
        c = getint(argv[0], BLACK, WHITE);
        for(i = 2; i < argc; i += 2) {
            if(*argv[i] == '#') argv[i]++;
            r = getint(argv[i], 1, Option.MaxCtrls - 1);
            if(Ctrl[r].type == 0) error("Control #% does not exist", r);
            if(checkstring(cmdline, "FCOLOUR"))
                Ctrl[r].fc = c;
            else
                Ctrl[r].bc = c;
            UpdateControl(r);
        }
        return;
    }


    if((p = checkstring(cmdline, "REDRAW"))) {
        int i, r;
        getargs(&p, MAX_ARG_COUNT, ",");
        if(!(argc & 1)) error("Argument count");
        if(checkstring(argv[0], "ALL")) {
            for(r = 1; r < Option.MaxCtrls; r++)
                UpdateControl(r);
            return;
        }
        for(i = 0; i < argc; i += 2) {
            if(*argv[i] == '#') argv[i]++;
            r = getint(argv[i], 1, Option.MaxCtrls - 1);
            UpdateControl(r);
        }
        return;
    }


    if((p = checkstring(cmdline, "BEEP"))) {
        if(Option.TOUCH_Click == 0) error("Click option not set");
        ClickTimer = getint(p, 0, INT_MAX) + 1;
		return;
	}


    if((p = checkstring(cmdline, "INTERRUPT"))) {
        getargs(&p, 3, ",");
        if(Option.TOUCH_CS == 0) error("Touch option not set");
        if(Option.TOUCH_XZERO == TOUCH_NOT_CALIBRATED) error("Touch not calibrated");
		if(*argv[0] == '0' && !isdigit(*(argv[0]+1)))
            GuiIntDownVector = GuiIntUpVector = NULL;
        else {
            GuiIntDownVector = GetIntAddress(argv[0]);				// get a pointer to the down interrupt routine
            if(argc == 3)
                GuiIntUpVector = GetIntAddress(argv[2]);            // and for the up routine
            else
                GuiIntUpVector = NULL;
            InterruptUsed = true;
        }
        gui_int_down = gui_int_up = false;
		return;
	}


    if((p = checkstring(cmdline, "SETUP"))) {
        SetupPage = getint(p, 1, MAX_PAGES) - 1;
		return;
	}

    // the final few commands are common to the MX170 and MX470 so execute them in Draw.c
    cmd_guiMX170();
}




void cmd_page(void) {
    int i, r, OldPages;
    getargs(&cmdline, MAX_ARG_COUNT, ",");
    if(!(argc & 1)) error("Argument count");
    OldPages = CurrentPages;
    CurrentPages = 0;
    for(i = 0; i < argc; i += 2) {                                  // get the new set of pages
        if(*argv[i] == '#') argv[i]++;
        CurrentPages |= (1 << (getint(argv[i], 1, MAX_PAGES) - 1));
    }

    // hide any that are showing but not on the new pages
    for(r = 0; r < Option.MaxCtrls; r++) {                          // step thru the controls
        if(Ctrl[r].type != 0) {                                     // if the control is active
            if((!(CurrentPages & (1 << Ctrl[r].page))) && (OldPages & (1 << Ctrl[r].page)) && (!(Ctrl[r].state & CTRL_HIDDEN))) {
                Ctrl[r].state |= CTRL_HIDDEN;
                if(r == CurrentRef) {
                    if(Ctrl[r].type == CTRL_BUTTON) Ctrl[r].value = 0;
                    if(Ctrl[r].type == CTRL_SPINNER) Ctrl[r].state &= ~(CTRL_SPINUP | CTRL_SPINDOWN);
                    LastRef = CurrentRef = 0;
                    gui_int_down = gui_int_up = false;
                }
                DrawControl(r);
                Ctrl[r].state &= ~CTRL_HIDDEN;
            }
        }
    }

    // show any that are on the new pages but not currently showing and are not hidden
    for(r = 0; r < Option.MaxCtrls; r++) {                                 // step thru the controls
        if(Ctrl[r].type != 0) {                                     // if the control is active
            if((!(OldPages & (1 << Ctrl[r].page))) && (CurrentPages & (1 << Ctrl[r].page)) && (!(Ctrl[r].state & CTRL_HIDDEN))) {
                DrawControl(r);
            }
        }
    }
}



////////////////////////////////////////////////////////////////////////////////////////////////////////
//
// This is the detailed implementation of the GUI controls in the Micromite Plus
//
////////////////////////////////////////////////////////////////////////////////////////////////////////




int ChangeBright(int c, int pct) {
    int r, g, b;
    if(pct == 0 || c <= 0) return c;
    r = (c >> 16) & 0xff;
    g = (c >> 8) & 0xff;
    b = c & 0xff;
    r += (r * pct) / 100; if(r > 255) r = 255; if(r < 0) r = 0;
    g += (g * pct) / 100; if(g > 255) g = 255; if(g < 0) g = 0;
    b += (b * pct) / 100; if(b > 255) b = 255; if(b < 0) b = 0;
    return RGB(r, g, b);
}


void SpecialWritePixel(int x, int y, unsigned int tc, int status) {
    if(status & CTRL_HIDDEN) {
        tc = gui_bcolour;
    } else if(status & (CTRL_DISABLED | CTRL_DISABLED2)) {
        tc = ChangeBright(tc, BTN_DISABLED);
    }
    DrawPixel(x, y, tc);
}


void SpecialDrawLine(int x1, int y1, int x2, int y2, int w, int tc, int status){
    if(status & CTRL_HIDDEN) {
        tc = gui_bcolour;
    } else if(status & (CTRL_DISABLED | CTRL_DISABLED2)) {
        tc = ChangeBright(tc, BTN_DISABLED);
    }
    DrawLine(x1, y1, x2, y2, w, tc);
}


void SpecialDrawBox(int x1, int y1, int x2, int y2, int w, int c, int fill, int status) {
    if(status & CTRL_HIDDEN) {
        c = gui_bcolour;
        fill = gui_bcolour;
    } else if(status & (CTRL_DISABLED | CTRL_DISABLED2)) {
        c = ChangeBright(c, BTN_DISABLED);
        if(fill != gui_bcolour) fill = ChangeBright(fill, BTN_DISABLED);
    }
    DrawBox(x1, y1, x2, y2, w, c, fill);
}


void SpecialDrawRBox(int x1, int y1, int x2, int y2, int radius, int c, int fill, int status) {
    if(status & CTRL_HIDDEN) {
        c = gui_bcolour;
        fill = gui_bcolour;
    } else if(status & (CTRL_DISABLED | CTRL_DISABLED2)) {
        c = ChangeBright(c, BTN_DISABLED);
        if(fill != gui_bcolour) fill = ChangeBright(fill, BTN_DISABLED);
    }
    DrawRBox(x1, y1, x2, y2, radius, c, fill);
}


void SpecialPrintString(int x, int y, int jh, int jv, int jo, int fc, int bc, char *str, int status) {
    int lines, i, y2;
    char t, *p, *idx[MAX_CAPTION_LINES + 1];

    // first check if the string contains one or more line split chars ('~')
    // while we are doing this save their addresses in idx[]
    idx[0] = p = str;
    lines = 1;
    while((p = strchr(p, '~')) != NULL && lines < MAX_CAPTION_LINES) {
        idx[lines] = p++;
        lines++;
    }

    if(lines > 1) {
        // this is two or more lines
        // recursively call this function to print each line
        idx[lines] = str + strlen(str);
        y2 = y - (gui_font_height / 2) * (lines - 1);
        for(i = 0; i < lines; i++) {
            t = *idx[i + 1];
            *idx[i + 1] = 0;
            SpecialPrintString(x, y2, jh, jv, jo, fc, bc, idx[i], status);
            *idx[i + 1] = t;
            if(t == '~') idx[i + 1]++;
            y2 += gui_font_height;
        }
    } else {
        // this is just a single line, so print it
        if(status & CTRL_HIDDEN) {
            fc = gui_bcolour;
            bc = gui_bcolour;
        } else if(status & (CTRL_DISABLED | CTRL_DISABLED2)) {
            fc = ChangeBright(fc, BTN_DISABLED);
            if(bc != gui_bcolour) bc = ChangeBright(bc, BTN_DISABLED);
        }
        GUIPrintString(x, y, gui_font, jh, jv, jo, fc, bc, str);
    }
}



void SpecialDrawCircle(int x, int y, int radius, int w, int c, int fill, float aspect, int status) {
    if(status & CTRL_HIDDEN) {
        c = gui_bcolour;
        fill = gui_bcolour;
    } else if(status & (CTRL_DISABLED | CTRL_DISABLED2)) {
        c = ChangeBright(c, BTN_DISABLED);
        if(fill != gui_bcolour) fill = ChangeBright(fill, BTN_DISABLED);
    }
    DrawCircle(x, y, radius, w, c, fill, aspect);
}



void SpecialDrawTriangle(int x0, int y0, int x1, int y1, int x2, int y2, int c, int fill, int status) {
    if(status & CTRL_HIDDEN) {
        c = gui_bcolour;
        fill = gui_bcolour;
    } else if(status & (CTRL_DISABLED | CTRL_DISABLED2)) {
        c = ChangeBright(c, BTN_DISABLED);
        if(fill != gui_bcolour) fill = ChangeBright(fill, BTN_DISABLED);
    }
    DrawTriangle(x0, y0, x1, y1, x2, y2, c, fill);
}



void DrawBorder(int x1, int y1, int x2, int y2, int w, int tc, int bc, int status) {
    int i;
    for(i = 0; i < w; i++) {
        SpecialDrawLine(x1 + i, y1 + i, x2 - i, y1 + i, 1, tc, status);     // top border
        SpecialDrawLine(x1 + i, y1 + i, x1 + i, y2 - i, 1, tc, status);     // left border
        SpecialDrawLine(x1 + i, y2 - i, x2 - i, y2 - i, 1, bc, status);     // bottom
        SpecialDrawLine(x2 - i, y1 + i, x2 - i, y2 - i, 1, bc, status);     // and right
    }
}



void DrawBasicButton(int x1, int y1, int x2, int y2, int w, int up, int c, int status) {
    DrawBorder(x1, y1, x2, y2, w, ChangeBright(c, up ? BTN_SIDE_BRIGHT:BTN_SIDE_DULL), ChangeBright(c, BTN_SIDE_DULL), status);
    SpecialDrawBox(x1 + w, y1 + w, x2 - w, y2 - w, 0, 0, c, status);    // fill in the face of the button
}



void DrawButton(int r) {
    char *p, *pp, s[MAXSTRLEN];
    int bs = 0;

    DrawBasicButton(Ctrl[r].x1, Ctrl[r].y1, Ctrl[r].x2, Ctrl[r].y2, BTN_SIDE_WIDTH, (Ctrl[r].value == 0), Ctrl[r].bc, Ctrl[r].state);

    // extract the up/down strings if necessary
    for(p = Ctrl[r].s, pp = s; *p != '|';) {
        if(*p == 0) {
            p = s - 1;
            bs = BTN_CAPTION_SHIFT;
            break;
        }
        *pp++ = *p++;
    }
    p++;
    *pp = 0;

    // draw the caption
    if(Ctrl[r].value == 0)
        SpecialPrintString(Ctrl[r].x1 + (Ctrl[r].x2 - Ctrl[r].x1)/2, Ctrl[r].y1 + (Ctrl[r].y2 - Ctrl[r].y1)/2, JUSTIFY_CENTER, JUSTIFY_MIDDLE, ORIENT_NORMAL, Ctrl[r].fc, Ctrl[r].bc, s, Ctrl[r].state);
    else
        SpecialPrintString(Ctrl[r].x1 + (Ctrl[r].x2 - Ctrl[r].x1)/2 + bs, Ctrl[r].y1 + (Ctrl[r].y2 - Ctrl[r].y1)/2 + bs, JUSTIFY_CENTER, JUSTIFY_MIDDLE, ORIENT_NORMAL, Ctrl[r].fc, Ctrl[r].bc, p, Ctrl[r].state);
}



void DrawSwitch(int r) {
    char *p, *pp, s[MAXSTRLEN];
    int half, on, twobtn, shift;

    // extract the up/down strings if necessary
    twobtn = true;
    for(p = Ctrl[r].s, pp = s; *p != '|';) {
        if(*p == 0) {
            p = s - 1;
            twobtn = false;
            break;
        }
        *pp++ = *p++;
    }
    p++;
    *pp = 0;

    on = (Ctrl[r].value == 0);
    if(on) shift = 0; else shift = BTN_CAPTION_SHIFT;
    if(twobtn)
        half = Ctrl[r].x1 + (Ctrl[r].x2 - Ctrl[r].x1)/2;
    else
        half = Ctrl[r].x2;
    DrawBasicButton(Ctrl[r].x1, Ctrl[r].y1, half, Ctrl[r].y2, BTN_SIDE_WIDTH, on, ChangeBright(Ctrl[r].bc, on ? 0 : -25), Ctrl[r].state);
    if(twobtn) DrawBasicButton(half, Ctrl[r].y1, Ctrl[r].x2, Ctrl[r].y2, BTN_SIDE_WIDTH, !on, ChangeBright(Ctrl[r].bc, on ? -25 : 0), Ctrl[r].state);

    // draw the captions
    if(on) shift = 0; else shift = BTN_CAPTION_SHIFT;
    SpecialPrintString(Ctrl[r].x1 + (half - Ctrl[r].x1)/2 + shift, Ctrl[r].y1 + (Ctrl[r].y2 - Ctrl[r].y1)/2 + shift,      JUSTIFY_CENTER, JUSTIFY_MIDDLE, ORIENT_NORMAL, ChangeBright(Ctrl[r].fc, (on || twobtn) ? 0:-25), ChangeBright(Ctrl[r].bc, on ? 0:-25), s, Ctrl[r].state);
    if(!on) shift = 0; else shift = BTN_CAPTION_SHIFT;
    if(twobtn) SpecialPrintString(half + (Ctrl[r].x2 - half)/2 + shift, Ctrl[r].y1 + (Ctrl[r].y2 - Ctrl[r].y1)/2 + shift, JUSTIFY_CENTER, JUSTIFY_MIDDLE, ORIENT_NORMAL, ChangeBright(Ctrl[r].fc, on ? -25:0),  ChangeBright(Ctrl[r].bc, on ? -25:0),  p, Ctrl[r].state);
}



// for the checkbox the width/height is saved in Ctrl[r].inc
void DrawCheckBox(int r) {
    int i, w;

    SpecialDrawBox(Ctrl[r].x1, Ctrl[r].y1, Ctrl[r].x1 + Ctrl[r].inc, Ctrl[r].y1 + Ctrl[r].inc, BTN_SIDE_WIDTH, ChangeBright(Ctrl[r].fc, -30), gui_bcolour, Ctrl[r].state) ;
    SpecialPrintString(Ctrl[r].x1 + Ctrl[r].inc + Ctrl[r].inc/2, Ctrl[r].y1 + Ctrl[r].inc/2, JUSTIFY_LEFT, JUSTIFY_MIDDLE, ORIENT_NORMAL, Ctrl[r].fcc, gui_bcolour, Ctrl[r].s, Ctrl[r].state);

    // draw the tick
    if(Ctrl[r].value != 0) {
        w = (Ctrl[r].inc / 28) + 1;                                     // vary the tick size according to the box size
        for(i = -w; i <= w; i++) {
            SpecialDrawLine(Ctrl[r].x1 + i + BTN_SIDE_WIDTH*2, Ctrl[r].y1 + BTN_SIDE_WIDTH*2, Ctrl[r].x1 + Ctrl[r].inc + i - BTN_SIDE_WIDTH*2, Ctrl[r].y2 - BTN_SIDE_WIDTH*2, 1, Ctrl[r].fc, Ctrl[r].state);
            SpecialDrawLine(Ctrl[r].x1 + i + BTN_SIDE_WIDTH*2, Ctrl[r].y2 - BTN_SIDE_WIDTH*2, Ctrl[r].x1 + Ctrl[r].inc + i - BTN_SIDE_WIDTH*2, Ctrl[r].y1 + BTN_SIDE_WIDTH*2, 1, Ctrl[r].fc, Ctrl[r].state);
        }
    }
}



// the radio button is a special case, its touch sensitive area is different from its drawing parameters
// the touch sensitive area is stored in x1, y1 to x2, y2
// the buttons X center is saved in Ctrl[r].min, Y center in Ctrl[r].min and radius in Ctrl[r].inc
void DrawRadioBtn(int r) {
    int i, frame;

    SpecialDrawCircle(Ctrl[r].min, Ctrl[r].max, Ctrl[r].inc, BTN_SIDE_WIDTH, ChangeBright(Ctrl[r].fc, -30), gui_bcolour, 1.0, Ctrl[r].state);
    SpecialPrintString(Ctrl[r].min + Ctrl[r].inc + gui_font_width - (gui_font_width/4), Ctrl[r].max, JUSTIFY_LEFT, JUSTIFY_MIDDLE, ORIENT_NORMAL, Ctrl[r].fcc, gui_bcolour, Ctrl[r].s, Ctrl[r].state);

    if(Ctrl[r].value != 0) {
        // draw the button if this control has been selected
        SpecialDrawCircle(Ctrl[r].min, Ctrl[r].max, Ctrl[r].inc - ((BTN_SIDE_WIDTH * 3) / 2), 0, 0, Ctrl[r].fc, 1.0, Ctrl[r].state);

        // make sure that all the other radio buttons are in the up state
        // first find the frame (if any) that the current button is in
        for(frame = 1; frame < Option.MaxCtrls; frame++)
            if(Ctrl[frame].type == CTRL_FRAME && Ctrl[r].page == Ctrl[frame].page && Ctrl[r].min > Ctrl[frame].x1 && Ctrl[r].min < Ctrl[frame].x2 && Ctrl[r].max > Ctrl[frame].y1 && Ctrl[r].max < Ctrl[frame].y2)
                break;
        // next look for any other radio buttons that are not the current one and is down and is in the same frame... and set it up
        for(i = 1; i < Option.MaxCtrls; i++) {
            if(Ctrl[i].type == CTRL_RADIOBTN && Ctrl[i].page == Ctrl[r].page && i != r && Ctrl[r].value != 0) {
                // if frame == MAX_CTRL this means that there is no frame and the whole screen can be considered the frame
                if(frame == Option.MaxCtrls || (Ctrl[i].min > Ctrl[frame].x1 && Ctrl[i].min < Ctrl[frame].x2 && Ctrl[i].max > Ctrl[frame].y1 && Ctrl[i].max < Ctrl[frame].y2)) {
                    Ctrl[i].value = 0;
                    if(Ctrl[r].state != CTRL_HIDDEN) DrawRadioBtn(i);
                }
            }
        }
    }
}



void DrawLED(int r) {
    SpecialDrawCircle(Ctrl[r].x1, Ctrl[r].y1, Ctrl[r].x2, 0, 0, RGB(160,160,160), 1.0, Ctrl[r].state);
    SpecialDrawCircle(Ctrl[r].x1, Ctrl[r].y1, Ctrl[r].x2 - BTN_SIDE_WIDTH/2, 0, 0, ChangeBright(Ctrl[r].fc, (Ctrl[r].value == 0) ? -65:0), 1.0, Ctrl[r].state);
    SpecialPrintString(Ctrl[r].x1 + Ctrl[r].x2 + gui_font_width - (gui_font_width/4), Ctrl[r].y1, JUSTIFY_LEFT, JUSTIFY_MIDDLE, ORIENT_NORMAL, Ctrl[r].fcc, gui_bcolour, Ctrl[r].s, Ctrl[r].state);
}


void DrawSpinner(int r) {
    int x1, x2, y1, y2;
    int h, z;
    h = (Ctrl[r].y2 - Ctrl[r].y1);
    z = h/6;
    x1 = Ctrl[r].x1; x2 = Ctrl[r].x2;
    y1 = Ctrl[r].y1; y2 = Ctrl[r].y2;
    SpecialDrawRBox(x1 + h, y1, x2 - h, y2, 10,  Ctrl[r].fc, Ctrl[r].bc, Ctrl[r].state);
    FloatToStr(Ctrl[r].s, Ctrl[r].value, 0, -1, ' ');               // convert the value to a string for display
    Ctrl[r].s[(x2 - x1 - h * 2) / gui_font_width] = 0;              // truncate to the display width
    SpecialPrintString(x1 + (x2 - x1)/2, y1 + h/2, JUSTIFY_CENTER, JUSTIFY_MIDDLE, ORIENT_NORMAL, Ctrl[r].fc, Ctrl[r].bc, Ctrl[r].s, Ctrl[r].state);
    if(Ctrl[r].state & CTRL_SPINUP)
        SpecialDrawTriangle(x2 - h/2, y1 + z, x2 - z, y1 + h - z, x2 - h + z, y1 + h - z, Ctrl[r].bc, Ctrl[r].fc, Ctrl[r].state);  // touched up pointing spin button
    else
        SpecialDrawTriangle(x2 - h/2, y1 + z, x2 - z, y1 + h - z, x2 - h + z, y1 + h - z, Ctrl[r].fc, Ctrl[r].bc, Ctrl[r].state);  // up pointing spin button
    if(Ctrl[r].state & CTRL_SPINDOWN)
        SpecialDrawTriangle(x1 + h/2, y1 + h - z, x1 + z, y1 + z, x1 + h - z, y1 + z, Ctrl[r].bc, Ctrl[r].fc, Ctrl[r].state);      // touched down pointing spin button
    else
        SpecialDrawTriangle(x1 + h/2, y1 + h - z, x1 + z, y1 + z, x1 + h - z, y1 + z, Ctrl[r].fc, Ctrl[r].bc, Ctrl[r].state);      // down pointing spin button
}



void DrawFrame(int r) {
    SpecialDrawRBox(Ctrl[r].x1, Ctrl[r].y1, Ctrl[r].x2, Ctrl[r].y2, 10, Ctrl[r].fc, -1, Ctrl[r].state);     // the border
    SpecialPrintString(Ctrl[r].x1 + 15, Ctrl[r].y1, JUSTIFY_LEFT, JUSTIFY_MIDDLE, ORIENT_NORMAL, Ctrl[r].fc, gui_bcolour, Ctrl[r].s, Ctrl[r].state);
}


void DrawCaption(int r) {
    SpecialPrintString(Ctrl[r].x1, Ctrl[r].y1, Ctrl[r].x2 & 0b0000011, (Ctrl[r].x2 >> 2) & 0b0000011, (Ctrl[r].x2 >> 4) & 0b0000111, Ctrl[r].fc, Ctrl[r].bc, Ctrl[r].s, Ctrl[r].state);
}


char *KeypadCaption[12][2] = {  {"Alt", "123"},
                                {"0", "Can"},
                                {"Ent", "Ent"},
                                {"1", "."},
                                {"2", ""},
                                {"3", ""},
                                {"4", "+"},
                                {"5", "-"},
                                {"6", "E"},
                                {"7", "Del"},
                                {"8", "CE"},
                                {"9", ""}
                              };

char *KeyboardCaption[30][4] = {{"&12", "ABC", "&12", "ABC"},
                                {"Z", "+" , "z", "["},
                                {"X", "-", "x" , "]"},
                                {"C", "=", "c", "{" },
                                {"V", "?", "v", "}" },
                                {"B", ",", "b", "|" },
                                {"N", ".", "n", "\\" },
                                {"M", "Del", "m", "Del" },
                                {"[ ]", "Can", "[ ]", "Can" },
                                {"Ent", "Ent", "Ent", "Ent" },
                                {"A", "!", "a", "_" },
                                {"S", "@", "s", "/" },
                                {"D", "#", "d", "<" },
                                {"F", "$", "f", ">" },
                                {"G", "%", "g", ":" },
                                {"H", "&", "h", ";" },
                                {"J", "*", "j", "^" },
                                {"K", "(", "k", "'" },
                                {"L", ")", "l", "\"" },
                                {" ", " ", " ", " " },
                                {"Q", "1", "q", "1" },
                                {"W", "2", "w", "2" },
                                {"E", "3", "e", "3" },
                                {"R", "4", "r", "4" },
                                {"T", "5", "t", "5" },
                                {"Y", "6", "y", "6" },
                                {"U", "7", "u", "7" },
                                {"I", "8", "i", "8" },
                                {"O", "9", "o", "9" },
                                {"P", "0", "p", "0" }
                              };


char *GetCaption(int k, int is_alpha, int alt) {
    if(is_alpha)
        return KeyboardCaption[k][alt];
    else
        return KeypadCaption[k][alt];
}


void GetSingleKeyCoord(int k, int is_alpha, int *x1, int *y1, int *x2, int *y2) {
    int horiznbr, width, BaseHoriz, BaseVert;

    if(is_alpha) {                                                  // if this is the keyboard
        horiznbr = 10;                                              // number of horizontal buttons
        width = (HRes/10 < 80) ? HRes/10 : 80;                      // scale the button size to the horiz resolution
        BaseVert = (Ctrl[InvokingCtrl].y2 > VRes/2) ? width * 3 : VRes;  // should it be in the top half of the screen?
        BaseHoriz = HRes;
    } else {                                                        // if this is the number pad
        horiznbr = 3;                                               // number of horizontal buttons
        width = (VRes/4 < 80) ? VRes/4 : 80;                        // scale the button size to the vert resolution
        if(Ctrl[InvokingCtrl].y2 > VRes/2 && Ctrl[InvokingCtrl].x2 > HRes/2) {
            BaseVert = width * 4;                                   // should it be in the top left part of the screen?
            BaseHoriz = width * 3;
        } else {
            BaseVert = VRes;                                        // or in the bottom right
            BaseHoriz = HRes;
        }
    }

    *x1 = BaseHoriz - (horiznbr - (k % horiznbr)) * width + width/10;
    *y1 = BaseVert - ((k / horiznbr) + 1) * width + width/10;
    *x2 = *x1 + width - width/10;
    *y2 = *y1 + width - width/10;
}


void DrawTextBox(int r) {
    int fc, bc;
    if(Ctrl[r].state & CTRL_SELECTED) {
        fc = Ctrl[r].bc;
        bc = Ctrl[r].fc;
    } else {
        fc = Ctrl[r].fc;
        bc = Ctrl[r].bc;
    }
    SpecialDrawRBox(Ctrl[r].x1, Ctrl[r].y1, Ctrl[r].x2, Ctrl[r].y2, 10,  fc, bc, Ctrl[r].state);
    Ctrl[r].s[(Ctrl[r].x2 - Ctrl[r].x1) / gui_font_width] = 0;      // truncate text to the display width
    if(strlen(Ctrl[r].s) > 2 && Ctrl[r].s[0] == '#' && Ctrl[r].s[1] == '#')
        SpecialPrintString(Ctrl[r].x1 + (Ctrl[r].x2 - Ctrl[r].x1)/2, Ctrl[r].y1 + (Ctrl[r].y2 - Ctrl[r].y1)/2, JUSTIFY_CENTER, JUSTIFY_MIDDLE, ORIENT_NORMAL, ChangeBright(fc, BTN_DISABLED), bc, Ctrl[r].s + 2, Ctrl[r].state);
    else
        SpecialPrintString(Ctrl[r].x1 + (Ctrl[r].x2 - Ctrl[r].x1)/2, Ctrl[r].y1 + (Ctrl[r].y2 - Ctrl[r].y1)/2, JUSTIFY_CENTER, JUSTIFY_MIDDLE, ORIENT_NORMAL, fc, bc, Ctrl[r].s , Ctrl[r].state);
}


// this will set all controls (except the control r) to disabled or non disabled
// note: r must always be a reference to the text box (never the keypad)
void PopUpRedrawAll(int r, int disabled) {
    int i;
    for(i = 1; i < Option.MaxCtrls; i++) {                                 // find all the other controls and set to disabled
        if(Ctrl[i].type && i != r) {
            if(disabled)
                Ctrl[i].state |= CTRL_DISABLED2;                    // set it to disable
            else
                Ctrl[i].state &= ~CTRL_DISABLED2;                   // set it to not disabled
            UpdateControl(i);
        }
    }
}


void KeyPadErase(int is_alpha) {
    int width, BaseHoriz, BaseVert;

    if(is_alpha) {                                                  // if this is the keyboard
        width = (HRes/10 < 80) ? HRes/10 : 80;                      // scale the button size to the horiz resolution
        BaseVert = (Ctrl[InvokingCtrl].y2 > VRes/2) ? width * 3 : VRes;  // should it be in the top half of the screen?
        DrawBox(HRes - width*10, BaseVert - width * 3, HRes, BaseVert, 0, 0, gui_bcolour);  // erase the background
    } else {                                                        // if this is the number pad
        width = (VRes/4 < 80) ? VRes/4 : 80;                        // scale the button size to the vert resolution
        if(Ctrl[InvokingCtrl].y2 > VRes/2 && Ctrl[InvokingCtrl].x2 > HRes/2) {
            BaseVert = width * 4;                                   // should it be in the top left part of the screen?
            BaseHoriz = width * 3;
        } else {
            BaseVert = VRes;                                        // or in the bottom right
            BaseHoriz = HRes;
        }
        DrawBox(BaseHoriz - width*3, BaseVert - width * 4, BaseHoriz, BaseVert, 0, 0, gui_bcolour);  // erase the background
    }
    KeyDown = -1;
}


void DrawSingleKey(int is_alpha, int x1, int y1, int x2, int y2, char *s, int fc, int bc) {
    int fnt, i;
    fnt = gui_font;
    if(is_alpha) {
        if(HRes > 600)
            SetFont(0x31);                                          // set a readable font
        else if(HRes > 400)
            SetFont(0x11);
        else
             SetFont(0x01);
    } else {
        if(VRes > 240)
            SetFont(0x31);                                          // set a readable font
        else if(VRes > 160)
            SetFont(0x11);
        else
             SetFont(0x01);
    }
    SpecialDrawRBox(x1, y1, x2, y2, 10,  fc, bc, 0);     // the border
    SpecialPrintString(x1 + (x2 - x1)/2, y1 + (y2 - y1)/2, JUSTIFY_CENTER, JUSTIFY_MIDDLE, ORIENT_NORMAL, fc, bc, s, 0);
    if(*s == ' ') {
        for(i = 0; i < ((x2 - x1) / 3); i++)
            SpecialDrawLine(x1 + (x2 - x1)/2 - i/2, y1 + i + (y2 - y1)/3, x1 + (x2 - x1)/2 + i/2, y1 + i + (y2 - y1)/3, 1, fc, 0);
    }
    SetFont(fnt);
}


// invoke the callback routine so that the programmer has the option of manipulating the result
void DoCallback(int InvokingCtrl, char *key) {
    char callstr[32];
    char *nextstmtSaved = nextstmt;
    if(FindSubFun("MM.KEYPRESS", 0) >= 0) {
        strcpy(callstr, "MM.KEYPRESS"); IntToStrPad(callstr + strlen(callstr), InvokingCtrl, ' ', 4, 10);
        strcat(callstr, ", \""); strcat(callstr, key); strcat(callstr, "\"");
        callstr[strlen(callstr)+1] = 0;
        ExecuteProgram(callstr);
        nextstmt = nextstmtSaved;
    }
}


void DrawKeyboard(int mode) {
    int x1, y1, x2, y2;
    int is_alpha, nbr_buttons;
    int i;
    char *p;

    if(Ctrl[InvokingCtrl].type == CTRL_TEXTBOX) {
        nbr_buttons = 30;
        is_alpha = true;
    } else {
        nbr_buttons = 12;
        is_alpha = false;
    }
    
    if(mode == KEY_OPEN) {
        DoCallback(InvokingCtrl, "Open");
        KeyPadErase(Ctrl[InvokingCtrl].type == CTRL_TEXTBOX);       // erase the background
        mode = KEY_DRAW_ALL;
    }

    // special processing for KEY_KEY_UP when the numeric keypad is in alt mode
    // this switches back to number mode for everything except for backspace when there are still chars in the buffer
    if(mode == KEY_KEY_UP && !is_alpha && KeyAltShift && KeyDown > 0 && (KeyDown != 9 || *Ctrl[InvokingCtrl].s == 0)) {
        KeyAltShift = false;                                        // redraw all keys in number mode
        mode = KEY_DRAW_ALL;                                        // drop thru to redraw all
    }

    if(mode == KEY_DRAW_ALL) {
        // just draw all the buttons
        for(i = 0; i < nbr_buttons; i++) {
            GetSingleKeyCoord(i, is_alpha, &x1, &y1, &x2, &y2);
            DrawSingleKey(is_alpha, x1, y1, x2, y2, GetCaption(i, is_alpha, KeyAltShift), Ctrl[InvokingCtrl].fc, Ctrl[InvokingCtrl].bc);
        }
        KeyDown = -1;                                               // no key to be down
        return;
    }

    if(mode == KEY_KEY_UP) {
        if(KeyDown >= 0) {
            GetSingleKeyCoord(KeyDown, is_alpha, &x1, &y1, &x2, &y2);
            DrawSingleKey(is_alpha, x1, y1, x2, y2, GetCaption(KeyDown, is_alpha, KeyAltShift), Ctrl[InvokingCtrl].fc, Ctrl[InvokingCtrl].bc);
        }
        KeyDown = -1;
        return;
    }

    if(mode != KEY_CANCEL) {
        for(i = 0; i < nbr_buttons; i++) {
            GetSingleKeyCoord(i, is_alpha, &x1, &y1, &x2, &y2);
            if(TouchX > x1 && TouchX < x2 && TouchY > y1 && TouchY < y2) {
                if(!is_alpha && KeyAltShift) {
                    // this ignores the invalid keys on the number pad when in the alt mode
                    switch(i) {
                        case 4:
                        case 5:
                        case 11: return;
                        case 3:  if(*Ctrl[InvokingCtrl].s == 0) break; else if(strchr(Ctrl[InvokingCtrl].s, '.') != NULL) return; break;
                        case 8:  if(*Ctrl[InvokingCtrl].s == 0) break; else if(strchr(Ctrl[InvokingCtrl].s, 'E') != NULL) return; break;
                        case 9:
                        case 10: if(*Ctrl[InvokingCtrl].s == 0) return;
                    }
                }
                KeyDown = i;
                ClickTimer += CLICK_DURATION;
                DrawSingleKey(is_alpha, x1, y1, x2, y2, GetCaption(i, is_alpha, KeyAltShift), Ctrl[InvokingCtrl].bc, Ctrl[InvokingCtrl].fc);
            }
        }

        if(KeyDown == -1) return;

        if(KeyDown == 0) {                                              // this is the alt key
            KeyAltShift = !(KeyAltShift & 1);                           // toggle alt/text bit, also resets shift to no shift
            DrawKeyboard(KEY_DRAW_ALL);                                 // redraw the keyboard/keypad
            return;
        }

        if(KeyDown == 19) {                                                         // this is the shift key
            KeyAltShift = ((!(KeyAltShift & 0b10) << 1) | (KeyAltShift & 0b01));    // toggle the shift key
            DrawKeyboard(KEY_DRAW_ALL);                                             // redraw the keyboard/keypad
            return;
        }
    }

    if(mode == KEY_CANCEL || ((KeyAltShift & 1) && KeyDown == (is_alpha ? 8 : 1))) {        // the user has hit the cancle key
        strcpy(Ctrl[InvokingCtrl].s, inpbuf);                       // restore the current value
        KeyDown = (is_alpha ? 9 : 2);                               // fake the Enter key
    }
    
    if(KeyDown == (is_alpha ? 9 : 2)) {                             // this is the enter key
        DoCallback(InvokingCtrl, GetCaption(KeyDown, is_alpha, KeyAltShift));
        if(!is_alpha) FloatToStr(Ctrl[InvokingCtrl].s, Ctrl[InvokingCtrl].value = atof(Ctrl[InvokingCtrl].s), 0, -1, ' ');     // convert to a float and put back on the display
        KeyPadErase(is_alpha);                                      // hide the keypad
        Ctrl[InvokingCtrl].state &= ~CTRL_SELECTED;                 // deselect the text box
        PopUpRedrawAll(0, false);                                   // redraw all the controls
        LastRef = InvokingCtrl;
        InvokingCtrl = 0;
        return;
    }

    p = Ctrl[InvokingCtrl].s + strlen(Ctrl[InvokingCtrl].s);
    if(!is_alpha && KeyAltShift) {
        // the keypad is in the alt mode
        // process the special keys
        switch(KeyDown) {
            case 3:  *p++ = '.'; break;
            case 6:  *p++ = '+'; break;
            case 7:  *p++ = '-'; break;
            case 8:  *p++ = 'E'; break;
            case 9:  *(--p) = 0; break;
            case 10: *Ctrl[InvokingCtrl].s = 0; break;
            default: return;
        }
    } else if(is_alpha && (KeyAltShift & 1)) {
        if(KeyDown == 7) {
            if(strlen(Ctrl[InvokingCtrl].s)) *(--p) = 0;
        } else
            *p++ = *GetCaption(KeyDown, is_alpha, KeyAltShift);
    } else {
        // the keyboard is in normal mode
        if(is_alpha && KeyDown == 8)
            *p++ = ' ';                                             // the space key
        else
            *p++ = *GetCaption(KeyDown, is_alpha, KeyAltShift);
    }
    *p = 0;

    DoCallback(InvokingCtrl, GetCaption(KeyDown, is_alpha, KeyAltShift));
    DrawControl(InvokingCtrl);
}


// draw a control on the screen
void DrawControl(int r) {
    int fnt;
    fnt = gui_font;
    SetFont(Ctrl[r].font);
    switch(Ctrl[r].type) {
        case CTRL_BUTTON:       DrawButton(r);   break;
        case CTRL_SWITCH:       DrawSwitch(r);   break;
        case CTRL_CHECKBOX:     DrawCheckBox(r); break;
        case CTRL_RADIOBTN:     DrawRadioBtn(r); break;
        case CTRL_LED:          DrawLED(r);      break;
        case CTRL_SPINNER:      DrawSpinner(r);  break;
        case CTRL_FRAME:        DrawFrame(r);    break;
        case CTRL_TEXTBOX:
        case CTRL_NBRBOX:
        case CTRL_DISPLAYBOX:   DrawTextBox(r);  break;
        case CTRL_CAPTION:      DrawCaption(r);  break;
        default:                break;
    }
    SetFont(fnt);
}


// similar to DrawControl() but it will only redraw the control if it is in the current
// set of pages for display and if it is not hidden
void UpdateControl(int r) {
    if((CurrentPages & (1 << Ctrl[r].page)) && !(Ctrl[r].state & CTRL_HIDDEN)) DrawControl(r);
}


// check if the pen has touched or been lifted and animate the GUI elements as required
// this is called after every command (from check_interrupt()), in the getchar() loop and repeatedly in a pause
// TouchDown and TouchUp are set in the Timer 4 interrupt
void ProcessTouch(void) {
    static int repeat = 0;
    static int waiting = false;
    int r, spinup;

    if(repeat) {
        if(TOUCH_DOWN)
            if(TouchTimer < repeat)
                return;
            else
                TouchDown = true;
        else
            repeat = 0;
    } else {
        if(waiting) {
            if(TouchTimer < 50)                                     // wait 50mS before a processing touch (allows the touch to settle)
                return;
            else
                waiting = false;
        } else {
            waiting = true;
            TouchTimer = 0;                                         // TouchTimer is incremented every mS in the Timer 4 interrupt
        }
    }

    if(!(TouchUp || TouchDown)) return;                             // quick exit if there is nothing to do
    if(TouchDown) {
        // touch has just occured
        TouchX = GetTouch(GET_X_AXIS);
        TouchY = GetTouch(GET_Y_AXIS);
        LastRef = CurrentRef = 0;
        TouchUp = TouchDown = false;
        if(TouchX == TOUCH_ERROR) return;                           // abort if the pen was lifted
        if(InvokingCtrl) {                                          // the keyboard/keypad takes complete control when activated
            DrawKeyboard(KEY_KEY_DWN);
            gui_int_down = false;
            return;
        }

        gui_int_down = true;                                        // signal that a MMBasic interrupt is valid
        for(r = 1; r < Option.MaxCtrls; r++) {
            if(Ctrl[r].type && TouchX >= Ctrl[r].x1 && TouchY >= Ctrl[r].y1 && TouchX <= Ctrl[r].x2 && TouchY <= Ctrl[r].y2) {
                if(!(CurrentPages & (1 << Ctrl[r].page))) continue;                            // ignore if the page is not displayed
                if(Ctrl[r].state & (CTRL_DISABLED | CTRL_DISABLED2 | CTRL_HIDDEN)) continue;   // ignore if control is disabled
                switch(Ctrl[r].type) {
                    case CTRL_BUTTON:
                    case CTRL_RADIOBTN:;
                    case CTRL_AREA:     Ctrl[r].value = 1;
                                        break;

                    case CTRL_FRAME:    continue;                   // a frame does not respond to touch but it might contain controls that do

                    case CTRL_CAPTION:
                    case CTRL_DISPLAYBOX:
                    case CTRL_LED:      return;                     // these controls do not respond to touch

                    case CTRL_SPINNER:  if(TouchX < (Ctrl[r].x1 + (Ctrl[r].y2 - Ctrl[r].y1)))               // if it is in the left side
                                                spinup = false;                                             // it is spin down
                                         else if(TouchX > (Ctrl[r].x2 - (Ctrl[r].y2 - Ctrl[r].y1)))         // if it is in the right side
                                                spinup = true;                                              // it is spin up
                                        else
                                            return;
                                        if(spinup) {
                                            if(Ctrl[r].state & CTRL_SPINDOWN) return;
                                            if(Ctrl[r].value + Ctrl[r].inc > Ctrl[r].max) { repeat = 0; break; }
                                            Ctrl[r].state |= CTRL_SPINUP;
                                            Ctrl[r].value += Ctrl[r].inc;
                                        } else {
                                            if(Ctrl[r].state & CTRL_SPINUP) return;
                                            if(Ctrl[r].value - Ctrl[r].inc < Ctrl[r].min) { repeat = 0; break; }
                                            Ctrl[r].state |= CTRL_SPINDOWN;
                                            Ctrl[r].value -= Ctrl[r].inc;
                                        }
                                        if(Ctrl[r].value < Ctrl[r].inc &&  Ctrl[r].value > -Ctrl[r].inc) Ctrl[r].value = 0;
                                        if(repeat == 0)
                                            repeat = 500;
                                        else
                                            repeat = 100;
                                        TouchTimer = 0;
                                        break;

                    case CTRL_NBRBOX:
                                        FloatToStr(Ctrl[r].s, Ctrl[r].value, 0, -1, ' ');                   // set the string value to be saved
                                        // fall thru
                                        
                    case CTRL_TEXTBOX:  strcpy(inpbuf, Ctrl[r].s);                                          // save the current value in case the user cancels
                                        *Ctrl[r].s = 0;                                                     // set it to an empty string
                                        Ctrl[r].state |= CTRL_SELECTED;                                     // select the number text/box
                                        PopUpRedrawAll(r, true);
                                        CurrentRef = InvokingCtrl = r;                                      // tell the keypad what text/number box it is servicing
                                        KeyAltShift = 0;
                                        DrawControl(r);
                                        ClickTimer += CLICK_DURATION;
                                        if(GuiIntDownVector == NULL)
                                            DrawKeyboard(KEY_OPEN);                                          // initial draw of the keypad
                                        else
                                            DelayedDrawKeyboard = true;                                      // leave it until after the keyboard interrupt
                                        return;

                    default:            Ctrl[r].value = !Ctrl[r].value;
                                        break;
                }
                CurrentRef = r;
                DrawControl(r);
                ClickTimer += CLICK_DURATION;                       // sound a "click"
                return;
            }
        }
    }

    if(TouchUp) {
        // the touch has just been released
        TouchUp = TouchDown = false;
        if(InvokingCtrl) {                                          // the keyboard/keypad takes complete control when activated
            DrawKeyboard(KEY_KEY_UP);
            gui_int_down = false;
            return;
        }

        gui_int_up = true;
        if(CurrentRef) {
            if(Ctrl[CurrentRef].type) {
                if((CurrentPages & (1 << Ctrl[CurrentRef].page)) && !(Ctrl[CurrentRef].state & (CTRL_DISABLED | CTRL_DISABLED2 | CTRL_HIDDEN))) {   // ignore if control is disabled or the page is not displayed
                    if(CurrentRef) LastRef = CurrentRef;
                    switch(Ctrl[CurrentRef].type) {
                        case CTRL_AREA:
                        case CTRL_BUTTON:   Ctrl[CurrentRef].value = 0;
                                            DrawControl(CurrentRef);
                                            break;

                        case CTRL_SPINNER:  Ctrl[CurrentRef].state &= ~(CTRL_SPINUP | CTRL_SPINDOWN);
                                            DrawControl(CurrentRef);
                                            break;

                        default:            break;
                    }
                }
            }
        }
        CurrentRef = 0;
    }
}



void SetCtrlState(int r, int state, int err) {
    if(Ctrl[r].type == 0) {
        if(err) error("Control #% does not exist", r);
    } else {
        if(r == CurrentRef) {
            if(Ctrl[r].type == CTRL_BUTTON) {
                Ctrl[r].value = 0;
                UpdateControl(r);
            }
            if(Ctrl[r].type == CTRL_SPINNER) {
                Ctrl[r].state &= ~(CTRL_SPINUP | CTRL_SPINDOWN);
                UpdateControl(r);
            }
            LastRef = CurrentRef = 0;
            gui_int_down = gui_int_up = false;
        }
        Ctrl[r].state |= state;
        if(state & CTRL_HIDDEN)
            DrawControl(r);
        else
            UpdateControl(r);
    }
}



// this function is used by the CLS command
void HideAllControls(void) {
    int r;
    for(r = 1; r < Option.MaxCtrls; r++) 
        if((CurrentPages & (1 << Ctrl[r].page)) && !(Ctrl[r].state & CTRL_HIDDEN)) 
            SetCtrlState(r, CTRL_HIDDEN, false);
}


// This will check if an interrupt is pending and will service if yes.
// Essentially this runs a short program which does nothing but it gives the
// interrupt checking routines in ExecuteProgram() a chance to do their job.
// This routine should be called repeatedly during long delays.
void ServiceInterrupts(void) {
    char *ttp, *s, tcmdtoken;
    char p[3];

    LocalIndex++;                                                   // preserve the current temporary string memory allocations
    ttp = nextstmt;                                                 // save the globals used by commands
    tcmdtoken = cmdtoken;
    s = cmdline;

    p[0] = cmdENDIF;                                                // setup a short program that does nothing
    p[1] = p[2] = 0;
    ExecuteProgram(p);                                              // execute the program's code

    cmdline = s;                                                    // restore the globals
    cmdtoken = tcmdtoken;
    nextstmt = ttp;
    LocalIndex--;
}



void fun_msgbox(void) {
    int i, j, k;
    int x, y, x1, y1, x2, y2, msgnbr, btnnbr, btnwidth;
    char *p, msg[MAX_CAPTION_LINES][MAXSTRLEN];
    char btn[4][MAXSTRLEN];
    int btnx1[4], btny1, btnx2[4], btny2;

	getargs(&ep, 9, ",");
    if(argc < 3) error("Argument count");
    p = getCstring(argv[0]);
    i = msgnbr = 0;
    while(*p) {
        if(*p == '~') {
            if(msgnbr + 1 >= MAX_CAPTION_LINES) break;
            msg[msgnbr++][i]= 0;
            i = 0; p++;
        } else {
            msg[msgnbr][i++] = *p++;
        }
    }
    msg[msgnbr++][i]= 0;

    btnnbr = ((argc - 2) / 2) + 1;
    for(i = 0; i < btnnbr; i++)
        strcpy(btn[i], getCstring(argv[(i * 2) + 2]));

    for(j = i = 0; i < msgnbr; i++)
        if(strlen(msg[i]) > j) j = strlen(msg[i]);
    j *= gui_font_width;

    for(k = i = 0; i < btnnbr; i++)
        if(strlen(btn[i]) > k) k = strlen(btn[i]);
    btnwidth = (k + 2) * gui_font_width;
    k = (btnwidth * btnnbr) + ((btnnbr - 1) * 2 * gui_font_width);
    if(k > j) j = k;
    j += 4 * gui_font_width;

    i = (((5 + msgnbr) * gui_font_height) / 2) + gui_font_height / 4;
    x1 = HRes/2 - j/2; y1 = VRes/2 - i; x2 = HRes/2 + j/2; y2 = VRes/2 + i;
    PopUpRedrawAll(0, true);
    SpecialDrawRBox(x1, y1, x2, y2, 25, gui_fcolour, gui_bcolour, CTRL_NORMAL);

    for(i = 0; i < msgnbr; i++)
      SpecialPrintString(HRes/2, y1 + gui_font_height + (gui_font_height * i), JUSTIFY_CENTER, JUSTIFY_TOP, ORIENT_NORMAL, gui_fcolour, gui_bcolour, msg[i], CTRL_NORMAL);
    
    btny1 = y2 - (gui_font_height * 3);
    btny2 = y2 - gui_font_height;
    for(i = 0; i < btnnbr; i++) {
        btnx1[i] = HRes/2 - (k/2) + (btnwidth * i) + (i * 2 * gui_font_width);  btnx2[i] = btnx1[i] + btnwidth;
        DrawBasicButton(btnx1[i], btny1, btnx2[i], btny2, BTN_SIDE_WIDTH, 1, gui_fcolour, CTRL_NORMAL);
        SpecialPrintString(btnx1[i] + btnwidth/2, btny1 + gui_font_height, JUSTIFY_CENTER, JUSTIFY_MIDDLE, ORIENT_NORMAL, gui_bcolour, gui_fcolour, btn[i], CTRL_NORMAL);
    }

    while(1) {
        ServiceInterrupts();
        x = GetTouch(GET_X_AXIS);  y = GetTouch(GET_Y_AXIS);
        for(i = 0; i < btnnbr; i++)
            if(x >= btnx1[i] && x <= btnx2[i] && y >= btny1 && y <= btny2)
                break;
        if(i < btnnbr) {
            DrawBasicButton(btnx1[i], btny1, btnx2[i], btny2, BTN_SIDE_WIDTH, 0, gui_fcolour, CTRL_NORMAL);
            SpecialPrintString(btnx1[i] + btnwidth/2 + BTN_CAPTION_SHIFT, btny1 + gui_font_height + BTN_CAPTION_SHIFT, JUSTIFY_CENTER, JUSTIFY_MIDDLE, ORIENT_NORMAL, gui_bcolour, gui_fcolour, btn[i], CTRL_NORMAL);
            ClickTimer += CLICK_DURATION;                        // sound a "click"
            while(GetTouch(GET_X_AXIS) != TOUCH_ERROR) ServiceInterrupts();
            SpecialDrawRBox(x1, y1, x2, y2, 25, gui_bcolour, gui_bcolour, CTRL_NORMAL);
            PopUpRedrawAll(0, false);
            iret = i + 1;
            targ = T_INT;
            return;
        }
    }
}


void fun_ctrlval(void) {
    int r;
    if(HRes == 0) error("LCD Panel not configured");
    if(*ep == '#') ep++;
	r = getint(ep, 1, Option.MaxCtrls);
    if(Ctrl[r].type == 0) error("Control #% does not exist", r);
    if(InvokingCtrl || Ctrl[r].type == CTRL_TEXTBOX || Ctrl[r].type == CTRL_DISPLAYBOX || Ctrl[r].type == CTRL_CAPTION) {
        sret = GetTempStrMemory();                                  // this will last for the life of the command
        if(Ctrl[r].type != CTRL_TEXTBOX || strlen(Ctrl[r].s) < 3 || Ctrl[r].s[0] != '#' || Ctrl[r].s[1] != '#')
            strcpy(sret, Ctrl[r].s);                                // copy the string (if it is NOT "ghost text")
        CtoM(sret);                                                 // convert to an MMBasic string
        targ = T_STR;
    } else {
        fret = Ctrl[r].value;
        targ = T_NBR;
    }
}



void cmd_ctrlval(void) {
    int r;
    float v;
    if(HRes == 0) error("LCD Panel not configured");
    if(*cmdline == '#') cmdline++;
	r = getint(cmdline, 1, Option.MaxCtrls);
    if(Ctrl[r].type == 0) error("Control #% does not exist", r);
	while(*cmdline && tokenfunction(*cmdline) != op_equal) cmdline++;   // search for the = symbol
	if(!*cmdline) error("Syntax");
	++cmdline;                                                      // step over the = symbol
    skipspace(cmdline);
	if(!*cmdline || *cmdline == '\'') error("Syntax");
    switch(Ctrl[r].type) {
        case CTRL_BUTTON:
        case CTRL_SWITCH:
        case CTRL_CHECKBOX:
        case CTRL_RADIOBTN: v = (getnumber(cmdline) != 0);
                            if(Ctrl[r].value == v) return;          // don't update if no change
                            Ctrl[r].value = v;
                            break;

        case CTRL_LED:      v = getnumber(cmdline);
//                            if(Ctrl[r].value == v) return;        // don't update if no change
                            if(v > 1) {
                                Ctrl[r].inc = v;
                                Ctrl[r].value = 1;
                                CheckGuiFlag = true;
                            } else {
                                int i;
                                CheckGuiFlag = false;
                                Ctrl[r].inc = 0;
                                Ctrl[r].value = v;
                                for(i = 1; i < Option.MaxCtrls; i++) {
                                    if(Ctrl[i].type == CTRL_LED && Ctrl[i].inc != 0) {
                                        CheckGuiFlag = true;
                                        break;
                                    }
                                }
                            }
                            break;

        case CTRL_SPINNER:  v = getnumber(cmdline);
                            if(v < Ctrl[r].min) v = Ctrl[r].min;
                            if(v > Ctrl[r].max) v = Ctrl[r].max;
                            if(Ctrl[r].value == v) return;          // don't update if no change
                            Ctrl[r].value = v;
                            FloatToStr(Ctrl[r].s, v, 0, -1, ' ');   // update the displayed string
                            break;

        case CTRL_NBRBOX:   if(InvokingCtrl) { strcpy(Ctrl[r].s, getCstring(cmdline));  break; }  // user updating from within MM.KEYPRESS
                            if(strlen(cmdline) > 3 && cmdline[0] == '"' && cmdline[1] == '#' && cmdline[2] == '#') {
                                // the user wants ghost text
                                strcpy(Ctrl[r].s, getCstring(cmdline));
                                Ctrl[r].value = 0;
                            } else {
                                // a normal number
                                v = getnumber(cmdline);
                                if(Ctrl[r].value == v) return;          // don't update if no change
                                Ctrl[r].value = v;
                                FloatToStr(Ctrl[r].s, v, 0, -1, ' ');   // update the displayed string
                            }
                            break;

        case CTRL_FRAME:
        case CTRL_CAPTION:  
                            memset(Ctrl[r].s, ' ', strlen(Ctrl[r].s));  // set the caption to spaces
                            UpdateControl(r);                           // erase the existing text
                            // fall through

        case CTRL_DISPLAYBOX:
        case CTRL_TEXTBOX: strcpy(Ctrl[r].s, getCstring(cmdline));  break;
        }
    UpdateControl(r);
}


void fun_mmhpos(void) {
    if(HRes == 0) error("LCD Panel not configured");
    iret = CurrentX;
    targ = T_INT;
}


void fun_mmvpos(void) {
    if(HRes == 0) error("LCD Panel not configured");
    iret = CurrentY;
    targ = T_INT;
}



void cmd_backlight(void) {
    if(HRes != 0 && Option.DISPLAY_TYPE > SSD_PANEL) error("SSD1963 display only");
    SetBacklightSSD1963(getint(cmdline, 0, 100));
}

void ResetGUI(void) {
    int i;
    InvokingCtrl = CurrentRef = LastRef = 0;
    LastX = LastY = TOUCH_ERROR;
    gui_int_down = gui_int_up = false;
    GuiIntDownVector = GuiIntUpVector = NULL;
    KeyDown = 0;
    KeyAltShift = 0;
    last_x2 = 100;
    last_y2 = 100;
    last_fcolour = gui_fcolour;
    last_bcolour = gui_bcolour;
    last_inc = 1;
    last_min = -FLT_MAX;
    last_max = FLT_MAX;

    SetupPage = 0;
    CurrentPages = 1;
    for(i = 1; i < Option.MaxCtrls; i++) {
        Ctrl[i].state = Ctrl[i].type = 0;
        if(Ctrl[i].s) FreeMemory(Ctrl[i].s);
    }
}


// This is called by Timer.c every mSec
// it scans through all controls looking for a LED with a timeout set (in Ctrl[r].inc) and decrements it
void CheckGuiTimeouts(void) {
    int r;
    for(r = 1; r < Option.MaxCtrls; r++) {
        if(Ctrl[r].type == CTRL_LED && Ctrl[r].inc > 1) {
            Ctrl[r].inc--;                                          // decrement the timeout
        }
    }
}


// This implements a LED flash
// it is called by check_interrupt() 
// it scans through all controls looking for a LED with a timeout set (in Ctrl[r].inc)
void CheckGui(void) {
    int r;
    CheckGuiFlag = false;
    for(r = 1; r < Option.MaxCtrls; r++) {
        if(Ctrl[r].type == CTRL_LED) {
            if(Ctrl[r].inc > 1)
                CheckGuiFlag = true;                                // keep calling this function while LEDs have timeouts
            if(Ctrl[r].inc == 1) {                                  // if this one has timed out
                Ctrl[r].inc = 0;
                Ctrl[r].value = 0;                                  // turn off the LED
                UpdateControl(r);
            }
        }
    }
}

