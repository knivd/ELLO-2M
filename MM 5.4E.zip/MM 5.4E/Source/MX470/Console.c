/***********************************************************************************************************************
MMBasic

Console.c

Implements the routines to handle all console communications.

Copyright 2011 - 2017 Geoff Graham.  All Rights Reserved.

This file and modified versions of this file are supplied to specific individuals or organisations under the following
provisions:

- This file, or any files that comprise the MMBasic source (modified or not), may not be distributed or copied to any other
  person or organisation without written permission.

- Object files (.o and .hex files) generated using this file (modified or not) may not be distributed or copied to any other
  person or organisation without written permission.

- This file is provided in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

************************************************************************************************************************/

#define _SUPPRESS_PLIB_WARNING                      // required for XC1.33  Later compiler versions will need PLIB to be installed
#include <plib.h>									// the pre Harmony peripheral libraries

#include "../MMBasic_Includes.h"
#include "../Hardware_Includes.h"


//** USB INCLUDES ***********************************************************
#include "../MX470/USB/Microchip/Include/USB/usb.h"
#include "../MX470/USB/Microchip/Include/USB/usb_function_cdc.h"
#include "../MX470/USB/HardwareProfile.h"

#include "../MX470/USB/Microchip/Include/GenericTypeDefs.h"
#include "../MX470/USB/Microchip/Include/Compiler.h"
#include "../MX470/USB/usb_config.h"
#include "../MX470/USB/Microchip/Include/USB/usb_device.h"


// declare the USB I/O functions
void CheckUSB(void);

// COM4 buffers
extern unsigned char *com4Rx_buf;                                   // pointer to the buffer for received characters
extern volatile int com4Rx_head, com4Rx_tail;                       // head and tail of the ring buffer for com4 Rx
extern unsigned char *com4Tx_buf;                                   // pointer to the buffer for transmitted characters
extern volatile int com4Tx_head, com4Tx_tail;                       // head and tail of the ring buffer for com4 Tx

// USB buffers
char USB_RxBuf[USB_RX_BUFFER_SIZE];
char USB_TxBuf[2][USB_TX_BUFFER_SIZE];
volatile int USB_NbrCharsInTxBuf;
volatile int USB_Current_TxBuf;

volatile unsigned int USBTimer;                                     // used to timeout a stalled USB transmit queue

// Because the USB copies data direct to the serial Tx buf and sends data direct from the serial Rx queue
// it does not need its own I/O buffers (except for the hardware device buffers declared above).
// The only pointer that we need is this one which keep track of where we are while reading the serial Rx buffer
//volatile int USBSerialRxBufTail = 0;

char ConsoleRxBuf[CONSOLE_RX_BUF_SIZE];
int ConsoleRxBufHead = 0;
int ConsoleRxBufTail = 0;

char ConsoleTxBuf[CONSOLE_TX_BUF_SIZE];
int ConsoleTxBufHead = 0;
int ConsoleTxBufTail = 0;

// declare the console I/O functions in this file
void initConsole(void);
void putConsole(int c);
int kbhitConsole(void);
void initSerialConsole(void);
void initUSBConsole(void);
void CloseUSBConsole(void);


void initConsole(void) {
    initUSBConsole();
    initSerialConsole();
}

/*********************************************************************************************
* USB Serial I/O functions for the console
**********************************************************************************************/

// initialize the USB serial console and USB
void initUSBConsole(void) {
    ConsoleRxBufHead = ConsoleRxBufTail = 0;
    USB_NbrCharsInTxBuf = 0;
    USB_Current_TxBuf = 0;
    USBDeviceInit();                                                // Initialise USB module SFRs and firmware
    CheckUSB();
}

// close the USB serial console and USB
void CloseUSBConsole(void) {
		USBDisableInterrupts();
		USBModuleDisable();
}

/*********************************************************************************************
* Serial I/O functions for the console
**********************************************************************************************/

// initialize the UART1 serial port
void initSerialConsole(void) {
    int ConsoleInvert = 0;

    if(Option.SerialCon == false) return;

    PinSetBit(CONSOLE_RX_PIN, CNPUSET);                             // set the pullup on Rx
    ExtCurrentConfig[CONSOLE_RX_PIN] = EXT_BOOT_RESERVED;
    ExtCurrentConfig[CONSOLE_TX_PIN] = EXT_BOOT_RESERVED;

    COM4_RX_PPS_OPEN; COM4_TX_PPS_OPEN;

    // initially just configure for 38400 baud
    UARTConfigure(UART1, UART_ENABLE_PINS_TX_RX_ONLY);
    UARTSetFifoMode(UART1, UART_INTERRUPT_ON_TX_NOT_FULL | UART_INTERRUPT_ON_RX_NOT_EMPTY);
    UARTSetLineControl(UART1, UART_DATA_SIZE_8_BITS | UART_PARITY_NONE | UART_STOP_BITS_1);
    UARTEnable(UART1, UART_ENABLE_FLAGS(UART_PERIPHERAL | UART_RX | UART_TX));
    UARTSetDataRate(UART1, BusSpeed, 38400);

    // Configure UART1 RX Interrupt (the Tx Interrupt is enabled in SerialConsolePutC())
    INTEnable(INT_SOURCE_UART_RX(UART1), INT_ENABLED);
    INTSetVectorPriority(INT_VECTOR_UART(UART1), INT_PRIORITY_LEVEL_3);
    INTSetVectorSubPriority(INT_VECTOR_UART(UART1), INT_SUB_PRIORITY_LEVEL_0);
   
    INTEnableInterrupts();
    // this implements the emergency reset routine
    uSec(100000);                                                   // wait for 100mS
    if(getConsole() == '!') {                                       // did we get a !
        uSec(150000);                                               // if so, wait a further 150mS and check that we receive at least four more
        if(getConsole() == '!' && getConsole() == '!' && getConsole() == '!' && getConsole() == '!') {
            int i;
            uSec(2000000);                                          // now wait for 2 sec
            for(i = 0; i < 25; i++)
                if(getConsole() != '!')                             // and check that we get at least 25 consecutive !'s
                    goto exit_test;
            ResetAllFlash();                                        // must be a reset request
            MMPrintString("\r\nMMBasic reset completed\r\n");
            // wait for the user to stop sending characters
            do {
                while(getConsole() != -1);
                uSec(100000);
            } while(getConsole() != -1);
        }
    }
    exit_test:
        
   // check if we are to invert the console (for RS232)
   if(Option.Invert == 2) {
        uSec(200000);
        ConsoleInvert = !PinRead(CONSOLE_RX_PIN);

    } else
        ConsoleInvert = Option.Invert;

    // finish setting up the UART including the final baudrate
    ConsoleRxBufHead = ConsoleRxBufTail;
    PinSetBit(CONSOLE_RX_PIN, CNPUCLR);                             // clear the pullup on Rx
    PinSetBit(CONSOLE_RX_PIN, ConsoleInvert ? CNPDSET:CNPUSET);     // set a pulldown/pullup on Rx so that the input does not float
    UARTConfigure(UART1, UART_ENABLE_PINS_TX_RX_ONLY | ((ConsoleInvert) ? (UART_INVERT_RECEIVE_POLARITY | UART_INVERT_TRANSMIT_POLARITY): 0));
    UARTSetDataRate(UART1, BusSpeed, Option.Baudrate);
}


// close the serial console and UART1 serial port
void CloseSerialConsole(void) {
    INTEnable(INT_SOURCE_UART_RX(UART1), INT_DISABLED);
    INTEnable(INT_SOURCE_UART_TX(UART1), INT_DISABLED);
    UARTEnable(UART1, UART_ENABLE_FLAGS(UART_DISABLE | UART_PERIPHERAL));
    COM4_TX_PPS_CLOSE;
    PinSetBit(CONSOLE_RX_PIN, CNPUCLR);                             // clear the pullup or pulldown on Rx
    PinSetBit(CONSOLE_RX_PIN, CNPDCLR);
    ExtCurrentConfig[CONSOLE_RX_PIN] = EXT_COM_RESERVED;            // show that they are not specially reserved
    ExtCurrentConfig[CONSOLE_TX_PIN] = EXT_COM_RESERVED;
    ExtCfg(CONSOLE_RX_PIN, EXT_NOT_CONFIG, 0);
    ExtCfg(CONSOLE_TX_PIN, EXT_NOT_CONFIG, 0);
}


// UART 1 interrupt handler
void __ISR(_UART1_VECTOR, IPL3AUTO) IntConsoleHandler(void) {
    unsigned short cc;
    
    // The UART is being used for the console
    if(Option.SerialCon) {
        if(INTGetFlag(INT_SOURCE_UART_RX(UART1))) {                         // Is this an RX interrupt?
            while(UARTReceivedDataIsAvailable(UART1)) {                     // while there is data to read
                if(UARTGetLineStatus(UART1) & 0b1110) {                     // first check for errors
                    UARTGetDataByte(UART1);                                 // and if there was an error throw away the char
                    U1STACLR = 0b1110;                                      // clear the error on the UART
                    continue;                                               // and try the next char
                }
                ConsoleRxBuf[ConsoleRxBufHead]  = UARTGetDataByte(UART1);   // store the byte in the ring buffer
                if(BreakKey && ConsoleRxBuf[ConsoleRxBufHead] == BreakKey) {// if the user wants to stop the progran
                    MMAbort = true;                                         // set the flag for the interpreter to see
                    ConsoleRxBufHead = ConsoleRxBufTail;                    // empty the buffer
                    break;
                }
                ConsoleRxBufHead = (ConsoleRxBufHead + 1) % CONSOLE_RX_BUF_SIZE;     // advance the head of the queue
                if(ConsoleRxBufHead == ConsoleRxBufTail) {                           // if the buffer has overflowed
                    ConsoleRxBufTail = (ConsoleRxBufTail + 1) % CONSOLE_RX_BUF_SIZE; // throw away the oldest char
                }
            }
            INTClearFlag(INT_SOURCE_UART_RX(UART1));                    // Clear the RX interrupt Flag
        }

        if(INTGetFlag(INT_SOURCE_UART_TX(UART1))) {                     // Is this a Tx interrupt?
            while(UARTTransmitterIsReady(UART1) && ConsoleTxBufTail != ConsoleTxBufHead) { // while Tx is free and there is data to send
                cc = ConsoleTxBuf[ConsoleTxBufTail];
                ConsoleTxBufTail = (ConsoleTxBufTail + 1) % CONSOLE_TX_BUF_SIZE;       // advance the tail of the queue
                INTDisableInterrupts();                                 // see Errata #10
                UARTSendData(UART1, (UART_DATA)cc);                     // send the byte
                INTEnableInterrupts();
            }
            if(ConsoleTxBufTail == ConsoleTxBufHead)                    // if there is nothing left to send
                INTEnable(INT_SOURCE_UART_TX(UART1), INT_DISABLED);     // disable the interrupt
            INTClearFlag(INT_SOURCE_UART_TX(UART1));                    // Clear the Tx interrupt Flag
        }
    } else {
        // The UART is being used for COM4
        if(INTGetFlag(INT_SOURCE_UART_RX(UART1))) {                     // Is this an RX interrupt?
            while(UARTReceivedDataIsAvailable(UART1)) {                 // while there is data to read
                if(UARTGetLineStatus(UART1) & 0b1110) {                 // first check for errors
                    UARTGetDataByte(UART1);                             // and if there was an error throw away the char
                    U2STACLR = 0b1110;                                  // clear the error on the UART
                    continue;                                           // and try the next char
                }
                cc = UARTGetData(UART1).__data;
                com4Rx_buf[com4Rx_head] = cc;                           // store the data byte in the ring buffer
                com4Rx_head = (com4Rx_head + 1) % com4_buf_size;        // advance the head of the queue
                if(com4Rx_head == com4Rx_tail) {                        // if the buffer has overflowed
                    com4Rx_tail = (com4Rx_tail + 1) % com4_buf_size;    // throw away the oldest char
                }
            }
            INTClearFlag(INT_SOURCE_UART_RX(UART1));                    // Clear the RX interrupt Flag
        }

        if(INTGetFlag(INT_SOURCE_UART_TX(UART1))) {                     // Is this a Tx interrupt?
            while(UARTTransmitterIsReady(UART1) && com4Tx_tail != com4Tx_head) { // while Tx is free and there is data to send
                cc = com4Tx_buf[com4Tx_tail];
                com4Tx_tail = (com4Tx_tail + 1) % TX_BUFFER_SIZE;       // advance the tail of the queue
                INTDisableInterrupts();                                 // see Errata #10
                UARTSendData(UART1, (UART_DATA)cc);                     // send the byte
                INTEnableInterrupts();
            }
            if(com4Tx_tail == com4Tx_head)                              // if there is nothing left to send
                INTEnable(INT_SOURCE_UART_TX(UART1), INT_DISABLED);     // disable the interrupt
            INTClearFlag(INT_SOURCE_UART_TX(UART1));                    // Clear the Tx interrupt Flag
        }
    }
}




// get a keystroke from the console.  Will wait forever for input
// if the char is a newline (lf) then replace it with a cr
int MMgetchar(void) {
    int c;
    static char prevchar = 0;

    loopback:
    do {
        ProcessTouch();
        if(CurrentlyPlaying == P_WAV)checkWAVinput();
        ShowCursor(true);
        c = MMInkey();
    } while(c == -1);
    if(c == '\n' && prevchar == '\r') {
        prevchar = 0;
        goto loopback;
    }
    ShowCursor(false);
    prevchar = c;
    if(c == '\n') c = '\r';
    return c;
}



// send a character to the Console serial port
void SerialConsolePutC(int c) {
    if(Option.SerialCon) {
        while(ConsoleTxBufTail == ((ConsoleTxBufHead + 1) % CONSOLE_TX_BUF_SIZE))  // wait if the buffer is full
            INTEnable(INT_SOURCE_UART_TX(UART1), INT_ENABLED);      // enable Tx interrupt in case it was off
			if(MMAbort) {											// allow the user to abort a hung serial port
				ConsoleTxBufTail = ConsoleTxBufHead = 0;			// clear the buffer
				longjmp(mark, 1);									// and abort
			}
		ConsoleTxBuf[ConsoleTxBufHead] = c;							// add the char
		ConsoleTxBufHead = (ConsoleTxBufHead + 1) % CONSOLE_TX_BUF_SIZE;		   // advance the head of the queue
        INTEnable(INT_SOURCE_UART_TX(UART1), INT_ENABLED);          // enable Tx interrupt in case it was off
    }
}

// send a character to the USB serial port
void USBPutC(int c) {
    if(U1OTGSTAT & 1) {                                             // if there is 5V on the USB connector
        while(USB_NbrCharsInTxBuf >= USB_TX_BUFFER_SIZE) {          // if the buffer is full
            if(USBTimer > USBTIMEOUT) return;                       // skip if the buffer is still full (not being drained)
        }
        mT4IntEnable(0);                                            // timer 4 can trigger a USB transfer so disable it
        USB_TxBuf[USB_Current_TxBuf][USB_NbrCharsInTxBuf++] = c;    // Place the char into the buffer
        mT4IntEnable(1);
        USBTimer = 0;
    }
}



// send a character to the USB, TFT LCD or Console serial port
void putConsole(int c) {
    DisplayPutC(c);
    USBPutC(c);
    SerialConsolePutC(c);
}


// print a char on the Serial and USB consoles only (used in the EDIT command and dp() macro)
void SerUSBPutC(char c) {
    SerialConsolePutC(c);
    USBPutC(c);
}

// print a string on the Serial and USB consoles only (used in the EDIT command and dp() macro)
void SerUSBPutS(char *s) {
    while(*s) SerUSBPutC(*s++);
}


// returns the number of character waiting in the console input queue
int kbhitConsole(void) {
    int i;
    INTEnable(INT_SOURCE_UART_RX(UART1), INT_DISABLED);
    i = ConsoleRxBufHead - ConsoleRxBufTail;
    INTEnable(INT_SOURCE_UART_RX(UART1), INT_ENABLED);
    if(i < 0) i += CONSOLE_RX_BUF_SIZE;
    return i;
}



// get a char from the console input queue
// will return immediately with -1 if there is no character waiting
int getConsole(void) {
    int c;
    CheckAbort();
    if(ConsoleRxBufHead == ConsoleRxBufTail) return -1;
    c = ConsoleRxBuf[ConsoleRxBufTail];
    ConsoleRxBufTail = (ConsoleRxBufTail + 1) % CONSOLE_RX_BUF_SIZE;   // advance the head of the queue
    return c;
}


// this is called frequently to check if CTRL-C has been pressed
inline void CheckAbort(void) {
//    CheckUSB();
    if(MMAbort) {
        CloseAudio();
        ShowCursor(false);                                          // turn off cursor in case it was visible
        ConsoleRxBufHead = ConsoleRxBufTail;                        // empty the keyboard input queue
        WDTimer = 0;                                                // turn off the watchdog timer
        longjmp(mark, 1);                                           // jump back to the input prompt
    }
}



/*********************************************************************************************
* USB I/O functions
**********************************************************************************************/



/******************************************************************************************
Check the USB for work to be done.
Used to send and get data to or from the USB interface.
Each call takes typically 6uS but sometimes it can be up to 600uS.
*******************************************************************************************/
void CheckUSB(void) {
	int i, numBytesRead;
    static int USB5V = 0;

	if(U1OTGSTAT & 1) {														    // is there 5V on the USB?
        if(!USB5V) uSec(10000);
        if(!(U1OTGSTAT & 1)) return;
        USB5V = true;
	    USBDeviceTasks();													    // do any USB work

        if(USBGetDeviceState() == CONFIGURED_STATE) {
			numBytesRead = getsUSBUSART(USB_RxBuf,USB_RX_BUFFER_SIZE);		    // check for data to be read
			for(i = 0; i < numBytesRead; i++) {								    // if we have some data, copy it into the keyboard buffer
                ConsoleRxBuf[ConsoleRxBufHead]  = USB_RxBuf[i];                 // store the byte in the ring buffer
                if(BreakKey && ConsoleRxBuf[ConsoleRxBufHead] == BreakKey) {    // if the user wants to stop the progran
                    MMAbort = true;                                             // set the flag for the interpreter to see
                    ConsoleRxBufHead = ConsoleRxBufTail;                        // empty the buffer
                    break;
                }
                ConsoleRxBufHead = (ConsoleRxBufHead + 1) % CONSOLE_RX_BUF_SIZE;    // advance the head of the queue
                if(ConsoleRxBufHead == ConsoleRxBufTail) {                          // if the buffer has overflowed
                    ConsoleRxBufTail = (ConsoleRxBufTail + 1) % CONSOLE_RX_BUF_SIZE;// throw away the oldest char
                }
            }

			if(USB_NbrCharsInTxBuf && mUSBUSARTIsTxTrfReady()) {			    // next, check for data to be sent
				putUSBUSART(USB_TxBuf[USB_Current_TxBuf],USB_NbrCharsInTxBuf);	// and send it
				USB_Current_TxBuf = !USB_Current_TxBuf;
				USB_NbrCharsInTxBuf = 0;
			}
		    CDCTxService();													    // send anything that needed sending
		}
	} else {
        if(USB5V) {
            uSec(100000);
            USBDeviceInit();                                                    // re-initialise USB module SFRs and firmware
        }
        USB5V = false;
//        USBBannerTimer = -5000;
    }
}




/******************************************************************************************
BOOL USER_USB_CALLBACK_EVENT_HANDLER
This function is called from the USB stack to notify a user application that a USB event
occured.  This callback is in interrupt context when the USB_INTERRUPT option is selected.

Args:  event - the type of event
       *pdata - pointer to the event data
       size - size of the event data

This function was derived from the demo CDC program provided by Microchip
*******************************************************************************************/
BOOL USER_USB_CALLBACK_EVENT_HANDLER(USB_EVENT event, void *pdata, WORD size)
{
    switch(event)
    {
        case EVENT_CONFIGURED:
            CDCInitEP();
             break;
//        case EVENT_SET_DESCRIPTOR:
//            break;
        case GRG_EVENT_EP0_REQUEST:
            USBCheckCDCRequest();
//            if(USBBannerTimer <= -5000) USBBannerTimer = 200;			// wait 200mS then send the MMBasic banner
            break;
        case EVENT_SOF:
            break;
        case EVENT_SUSPEND:
            break;
        case EVENT_RESUME:
            break;
        case EVENT_BUS_ERROR:
            break;
        case EVENT_TRANSFER:
            Nop();
            break;
        default:
            break;
    }
    return TRUE;
}



