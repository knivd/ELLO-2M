/***********************************************************************************************************************
MMBasic

Audio.c

Handles the PLAY command.

Copyright 2011 - 2017 Geoff Graham
Copyright 2017 Peter Mather
All Rights Reserved.

This file and modified versions of this file are supplied to specific individuals or organisations under the following
provisions:

- This file, or any files that comprise the MMBasic source (modified or not), may not be distributed or copied to any other
  person or organisation without written permission.

- Object files (.o and .hex files) generated using this file (modified or not) may not be distributed or copied to any other
  person or organisation without written permission.

- This file is provided in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

************************************************************************************************************************/
#define _SUPPRESS_PLIB_WARNING                      // required for XC1.33  Later compiler versions will need PLIB to be installed
#include <plib.h>									// the pre Harmony peripheral libraries

//#include <p32xxxx.h>								// device specific defines
#include <stdio.h>
#include <stdbool.h>                                // Pascal
#include <stdint.h>                                 // Pascal

#include "../MMBasic_Includes.h"
#include "../Hardware_Includes.h"

//** SD CARD INCLUDES ***********************************************************
#include "SDCard/SDCard.h"
#include "SDCard/FSconfig.h"
extern int InitSDCard(void);
extern int FindFreeFileNbr(void);
extern const int ErrorMap[34];

// define the PWM output frequency for making a tone
volatile unsigned char PWM_count = 0;
volatile unsigned int PhaseM_left, PhaseM_right;

e_CurrentlyPlaying CurrentlyPlaying = P_NOTHING;
volatile int v_left, v_right, vol_left = 100, vol_right = 100;
int *sinemap;

char *wav_buf;										// pointer to the buffer for received wav data
volatile int wav_head, wav_tail, wav_filesize;      // head and tail of the ring buffer for com1
int WAV_tickspersample;
FSFILE *pWAVFile;
char *WAVInterrupt = NULL;
int WAVcomplete;
int WAV_fnbr;
volatile unsigned int bcount[3] = {0, 0, 0};

union map {
    unsigned char sinebytes[4];
    unsigned int sine;
} PhaseAC_left, PhaseAC_right;

const int SineTable50[256] = {
313,319,325,332,338,345,351,357,364,370,376,383,389,395,401,407,413,419,425,431,436,442,447,453,458,464,469,
474,479,484,489,494,498,503,507,511,515,519,523,527,531,534,538,541,544,547,550,552,555,557,560,562,564,565,
567,569,570,571,572,573,574,574,575,575,575,575,575,574,574,573,572,571,570,569,567,565,564,562,560,557,555,
552,550,547,544,541,538,534,531,527,523,519,515,511,507,503,498,494,489,484,479,474,469,464,458,453,447,442,
436,431,425,419,413,407,401,395,389,383,376,370,364,357,351,345,338,332,325,319,313,306,300,293,287,280,274,
268,261,255,249,242,236,230,224,218,212,206,200,194,189,183,178,172,167,161,156,151,146,141,136,131,127,122,
118,114,110,106,102,98,94,91,87,84,81,78,75,73,70,68,65,63,61,60,58,56,55,54,53,52,51,51,50,50,50,50,50,51,
51,52,53,54,55,56,58,60,61,63,65,68,70,73,75,78,81,84,87,91,94,98,102,106,110,114,118,122,127,131,136,141,146,
151,156,161,167,172,178,183,189,194,200,206,212,218,224,230,236,242,249,255,261,268,274,280,287,293,300,306
};
const int SineTable60[256] = {
375,383,390,398,406,414,421,429,436,444,452,459,466,474,481,488,496,503,510,517,523,530,537,544,550,556,563,
569,575,581,587,592,598,603,608,614,618,623,628,633,637,641,645,649,653,656,660,663,666,669,672,674,676,679,
681,682,684,685,687,688,688,689,690,690,690,690,690,689,688,688,687,685,684,682,681,679,676,674,672,669,666,
663,660,656,653,649,645,641,637,633,628,623,618,614,608,603,598,592,587,581,575,569,563,556,550,544,537,530,
523,517,510,503,496,488,481,474,466,459,452,444,436,429,421,414,406,398,390,383,375,367,360,352,344,336,329,
321,314,306,298,291,284,276,269,262,254,247,240,233,227,220,213,206,200,194,187,181,175,169,163,158,152,147,
142,136,132,127,122,117,113,109,105,101,97,94,90,87,84,81,78,76,74,71,69,68,66,65,63,62,62,61,60,60,60,60,60,
61,62,62,63,65,66,68,69,71,74,76,78,81,84,87,90,94,97,101,105,109,113,117,122,127,132,136,142,147,152,158,163,
169,175,181,187,194,200,206,213,220,227,233,240,247,254,262,269,276,284,291,298,306,314,321,329,336,344,352,
360,367
};
const int SineTable80[256] = {
500,510,521,531,541,551,562,572,582,592,602,612,622,632,641,651,661,670,680,689,698,707,716,725,733,742,750,
758,766,774,782,790,797,804,811,818,825,831,837,843,849,855,860,865,870,875,880,884,888,892,895,899,902,905,
907,910,912,914,915,917,918,919,919,920,920,920,919,919,918,917,915,914,912,910,907,905,902,899,895,892,888,
884,880,875,870,865,860,855,849,843,837,831,825,818,811,804,797,790,782,774,766,758,750,742,733,725,716,707,
698,689,680,670,661,651,641,632,622,612,602,592,582,572,562,551,541,531,521,510,500,490,479,469,459,449,438,
428,418,408,398,388,378,368,359,349,339,330,320,311,302,293,284,275,267,258,250,242,234,226,218,210,203,196,
189,182,175,169,163,157,151,145,140,135,130,125,120,116,112,108,105,101,98,95,93,90,88,86,85,83,82,81,81,80,
80,80,81,81,82,83,85,86,88,90,93,95,98,101,105,108,112,116,120,125,130,135,140,145,151,157,163,169,175,182,
189,196,203,210,218,226,234,242,250,258,267,275,284,293,302,311,320,330,339,349,359,368,378,388,398,408,418,
428,438,449,459,469,479,490
};


// setup the sound outputs
void ConfigSoundOutputs(void) {
    ExtCfg(PWM_PLAY_L_PIN, EXT_DIG_OUT, 0); ExtCfg(PWM_PLAY_L_PIN, EXT_COM_RESERVED, 0);
    ExtCfg(PWM_PLAY_R_PIN, EXT_DIG_OUT, 0); ExtCfg(PWM_PLAY_R_PIN, EXT_COM_RESERVED, 0);
    PWM_PLAY_L_OPEN;
    PWM_PLAY_R_OPEN;
    OpenOC4( OC_ON | OC_TIMER_MODE16 | OC_TIMER3_SRC | OC_PWM_FAULT_PIN_DISABLE , (BusSpeed/PWM_FREQ)/2, 0x0000 );
    OpenOC1( OC_ON | OC_TIMER_MODE16 | OC_TIMER3_SRC | OC_PWM_FAULT_PIN_DISABLE , (BusSpeed/PWM_FREQ)/2, 0x0000 );
    OpenTimer3(T3_ON | T2_PS_1_1, BusSpeed/PWM_FREQ);
    ConfigIntTimer3(T3_INT_ON | T3_INT_PRIOR_4);
    if(BusSpeed == 50000000) sinemap = (int *)SineTable50;
    if(BusSpeed == 60000000) sinemap = (int *)SineTable60;
    if(BusSpeed == 80000000) sinemap = (int *)SineTable80;
}


void CloseAudio(void){
        if(CurrentlyPlaying == P_TONE || CurrentlyPlaying == P_PAUSE_TONE)
            StopAudio();
        else if(CurrentlyPlaying == P_WAV || CurrentlyPlaying == P_PAUSE_WAV) {
            StopAudio();
            FileClose(WAV_fnbr);
            FreeMemory(wav_buf); 
            WAVcomplete = true;
        }    
    return;
}


// The MMBasic command:  PLAY
void cmd_play(void) {
    char *tp;
    
    if(checkstring(cmdline, "STOP")) {
        CloseAudio();
        return;
    }
    
    if(checkstring(cmdline, "PAUSE")) {
        if(CurrentlyPlaying == P_TONE)
            CurrentlyPlaying = P_PAUSE_TONE;
        else
        if(CurrentlyPlaying == P_WAV)
            CurrentlyPlaying = P_PAUSE_WAV;
        else
            error("Nothing playing");
        return;
    }

    if(checkstring(cmdline, "RESUME")) {
        if(CurrentlyPlaying == P_PAUSE_TONE)
            CurrentlyPlaying = P_TONE;
        else
        if(CurrentlyPlaying == P_PAUSE_WAV)
            CurrentlyPlaying = P_WAV;
        else
            error("Nothing to resume");  
        return;
    }

    if(checkstring(cmdline, "CLOSE")) {
        CloseAudio();
        PWMClose(1);
        return;
    }

    if((tp = checkstring(cmdline, "VOLUME"))) {
        getargs(&tp, 3, ",");
        if(argc < 1) error("Argument count");
        if(*argv[0]) vol_left = getint(argv[0], 0, 100);
        if(argc == 3) vol_right = getint(argv[2], 0, 100);
        return;
    }

    if(BusSpeed < 50000000) error("CPU speed too low");

    if((tp = checkstring(cmdline, "TONE"))) {
        int f_left, f_right;
        unsigned int PlayDuration = 0xffffffff;                     // default is to play forever
        
        // get the command line arguments
        getargs(&tp, 5, ",");                                       // this MUST be the first executable line in the function
        if(!(argc == 3 || argc == 5)) error("Argument count");

        if(CurrentlyPlaying == P_WAV || CurrentlyPlaying == P_PAUSE_WAV) error("Sound output in use");
        if(CurrentlyPlaying == P_TONE || CurrentlyPlaying == P_PAUSE_TONE) StopAudio();                 // stop the current tone
        
        f_left = getint(argv[0], 1, 20000);                         // get the arguments
        f_right = f_left;
        if(argc > 2 && *argv[2]) f_right = getint(argv[2], 1, 20000);
        if(argc > 4) PlayDuration = getint(argv[4], 0, INT_MAX);
        if(PlayDuration == 0) return;
        
        ConfigSoundOutputs();
        PhaseM_left =  (unsigned int)(((unsigned long long)0xffffffff * (unsigned long long)f_left)  / (unsigned long long)PWM_FREQ);
        PhaseM_right = (unsigned int)(((unsigned long long)0xffffffff * (unsigned long long)f_right) / (unsigned long long)PWM_FREQ);
        CurrentlyPlaying = P_TONE;
        SoundPlay = PlayDuration;
        return;
    }
    
    if((tp = checkstring(cmdline, "WAV"))) {
        int i;
        char *p;
        char sbuff[5];
        short format, samplesize, nchannels;
        int formatlength, samplerate, dummy;
        
        // get the command line arguments
        getargs(&tp, 3, ",");                                  // this MUST be the first executable line in the function
        if(!(argc == 1 || argc == 3)) error("Argument count");
        
        if(!(CurrentlyPlaying == P_NOTHING || CurrentlyPlaying == P_STOPPED)) error("Sound output in use");

        if(!InitSDCard()) return;
        p = getCstring(argv[0]);                                    // get the file name
        WAVInterrupt = NULL;
        WAVcomplete = 0;
        if(argc == 3) {
            WAVInterrupt = GetIntAddress(argv[2]);					// get the interrupt location
            InterruptUsed = true;
        }

        // open the file
        if(strchr(p, '.') == NULL) strcat(p, ".WAV");
        WAV_fnbr = FindFreeFileNbr();
        OpenFileTable[WAV_fnbr] = (unsigned int)FSfopen(p, "r");
        if((i = FSerror()) != 0) {
            ErrorThrow(ErrorMap[i]);
            return;
        }
        pWAVFile=(FSFILE *)OpenFileTable[WAV_fnbr];
        FSfread(sbuff, 1, 4, pWAVFile);
        sbuff[4] = 0;
        if(strcmp(sbuff,"RIFF")){
            FileClose(WAV_fnbr);
            error("Invalid file format");
        }
        FSfread((int *)(&wav_filesize), sizeof(int), 1, pWAVFile);
        FSfread(sbuff, 1, 4, pWAVFile);
        sbuff[4] = 0;
        if(strcmp(sbuff,"WAVE")) {
            FileClose(WAV_fnbr);
            error("Invalid file format");
        }
        FSfread(sbuff, 1, 4, pWAVFile);
        sbuff[4] = 0;
        FSfread(&formatlength, sizeof(int), 1, pWAVFile);
        FSfread(&format, sizeof(short), 1, pWAVFile);
        if(format != 1){
            FileClose(WAV_fnbr);
            error("Only 8-bit, 2-channel, 8 or 16KHz, .WAV files allowed");
        }
        FSfread(&nchannels, sizeof(short), 1, pWAVFile);
        if(nchannels != 2){
            FileClose(WAV_fnbr);
            error("Only 8-bit, 2-channel, 8 or 16KHz, .WAV files allowed");
        }
        FSfread(&samplerate, sizeof(int), 1, pWAVFile);
        if(!(samplerate == 16000 || samplerate == 8000)){
            FileClose(WAV_fnbr);
            error("Only 8-bit, 2-channel, 8 or 16KHz, .WAV files allowed");
        }
        WAV_tickspersample = PWM_FREQ / samplerate;
        FSfread(&dummy, sizeof(int), 1, pWAVFile);
        FSfread(&dummy, sizeof(short), 1, pWAVFile);
        FSfread(&samplesize, sizeof(short), 1, pWAVFile);
        if(samplesize != 8){
            FileClose(WAV_fnbr);
            error("Only 8-bit, 2-channel, 8 or 16KHz, .WAV files allowed");
        }
        FSfread(sbuff, 1, 4, pWAVFile);
        sbuff[4] = 0;
        wav_buf = GetMemory(WAV_BUFFER_SIZE);                       //buffer 4 seconds
        wav_head = wav_tail = 0;
        wav_filesize -= 44;                                         //remove the header from the count
        ConfigSoundOutputs();
        CurrentlyPlaying = P_WAV;
        return;
    } 
    error("Unknown command");
}



/******************************************************************************************
Timer 1 interrupt.
Used to send data to the PWM for playing a WAV or TONE
*******************************************************************************************/
void audioInterrupt(void) {
    int a,b;
    // play a tone
    if(CurrentlyPlaying == P_TONE){
        PhaseAC_left.sine += PhaseM_left;
        PhaseAC_right.sine += PhaseM_right;
        a = ((int)sinemap[PhaseAC_left.sinebytes[3]] - (int)sinemap[0]) * vol_left / 100;
        b = ((int)sinemap[PhaseAC_right.sinebytes[3]] - (int)sinemap[0]) * vol_right / 100;
        OC1RS = (sinemap[0]) + a;
        OC4RS = (sinemap[0]) + b;
    } else if(CurrentlyPlaying == P_WAV) {
        // play a WAV
        if(PWM_count == 0){
            if(wav_head != wav_tail) {                              // if the queue has something in it
                a = wav_buf[wav_tail];                              // get the char
                b = wav_buf[wav_tail + 1];                          // get the char
                wav_tail = (wav_tail + 2) % WAV_BUFFER_SIZE;        // and remove from the buffer
                OC1RS = (sinemap[0] + (((sinemap[a] - sinemap[0]) * vol_left) / 100));
                OC4RS = (sinemap[0] + (((sinemap[b] - sinemap[0]) * vol_right) / 100));
            }
        }
        PWM_count++; 
        if(PWM_count == WAV_tickspersample) PWM_count = 0;
    } else {
        // play must be paused
        OC1RS = sinemap[128];
        OC4RS = sinemap[128];
    }
}


/******************************************************************************************
Stop playing the WAV or tone
*******************************************************************************************/
void StopAudio(void) {
    if(CurrentlyPlaying != P_NOTHING) {
        SoundPlay = 0;
        mT3IntEnable(0);     										    // disable interrupt
        CloseTimer3();
        CloseOC1();
        CloseOC4();
        ExtCfg(PWM_PLAY_L_PIN, EXT_NOT_CONFIG, 0);
        ExtCfg(PWM_PLAY_R_PIN, EXT_NOT_CONFIG, 0);
        PWM_PLAY_L_CLOSE;
        PWM_PLAY_R_CLOSE;
        CurrentlyPlaying = P_STOPPED;
    }
}


/******************************************************************************************
 * Maintain the WAV sample buffer
*******************************************************************************************/
void checkWAVinput(void){
    char sbuff[2];
    
    while(wav_tail != ((wav_head + 2) % WAV_BUFFER_SIZE) && wav_filesize) {	// repeat until the buffer is full or EOF
        FSfread(sbuff, sizeof(char), 2, pWAVFile);
        wav_buf[wav_head] = sbuff[0];								// add the char
        wav_buf[wav_head + 1] = sbuff[1];							// add the char
        wav_head = (wav_head + 2) % WAV_BUFFER_SIZE;			    // advance the head of the queue
        wav_filesize -= 2;
    }
    
    if(!wav_filesize){
        while(wav_head != wav_tail);                                //wait for replay to finish
        StopAudio();
        FileClose(WAV_fnbr);
        FreeMemory(wav_buf); 
        WAVcomplete = true;
    }
}

