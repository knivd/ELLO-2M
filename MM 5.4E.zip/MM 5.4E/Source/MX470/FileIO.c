/***********************************************************************************************************************
MMBasic

FileIO.c

Does all the SD Card related file I/O in MMBasic.

Copyright 2011 - 2017 Geoff Graham.  All Rights Reserved.

This file and modified versions of this file are supplied to specific individuals or organisations under the following
provisions:

- This file, or any files that comprise the MMBasic source (modified or not), may not be distributed or copied to any other
  person or organisation without written permission.

- Object files (.o and .hex files) generated using this file (modified or not) may not be distributed or copied to any other
  person or organisation without written permission.

- This file is provided in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

************************************************************************************************************************/


#define _SUPPRESS_PLIB_WARNING                      // required for XC1.33  Later compiler versions will need PLIB to be installed
#include <plib.h>                                   // the pre Harmony peripheral libraries

#include "../MMBasic_Includes.h"
#include "../Hardware_Includes.h"

//** SD CARD INCLUDES ***********************************************************
#include "SDCard/SDCard.h"
#include "SDCard/FSconfig.h"

int OptionFileErrorAbort = true;
static char *pcmdl = NULL;

int SDCardPresent[SDCARD_MAX_NUM];

void File_fopen(char *fname, char *mode, int fnbr);
void FileClose(int fnbr);
char FileGetChar(int fnbr);
char FilePutChar(char c, int fnbr);
int FileEOF(int fnbr);
char *GetCWD(void);
void File_CloseAll(void);
int InitSDCard(void);
int FindFreeFileNbr(void);
char *ChangeToDir(char *p);
int CheckFileName(char *p);
void LoadImage(char *p);
void LoadFont(char *p);


/*****************************************************************************************
Mapping of errors reported by the Microchip FAT 16/32 file system to MMBasic file errors
*****************************************************************************************/
const int ErrorMap[34] = {          0,  // 0  =   No error
                                    11, // 1  =   An erase failed
                                    1,  // 2  =   No SD card found
                                    15, // 3  =   The disk is of an unsupported format
                                    15, // 4  =   The boot record is bad
                                    15, // 5  =   The file system type is unsupported
                                    15, // 6  =   An initialization error has occurred
                                    15, // 7  =   An operation was performed on an uninitialized device
                                    10, // 8  =   A bad read of a sector occurred
                                    11, // 9  =   Could not write to a sector
                                    15, // 10 =  Invalid cluster value
                                    6,  // 11 =  Could not find the file on the device
                                    7,  // 12 =  Could not find the directory
                                    10, // 13 =  File is corrupted
                                    0,  // 14 =  No more files in this directory
                                    15, // 15 =  Could not load/allocate next cluster in file
                                    5,  // 16 =  A specified file name is too long to use
                                    9,  // 17 =  A specified filename already exists on the device
                                    5,  // 18 =  Invalid file name
                                    12, // 19 =  Attempt to delete a directory with KILL
                                    4,  // 20 =  All root directory entries are taken
                                    3,  // 21 =  All clusters in partition are taken
                                    14, // 22 =  This directory is not empty yet, remove files before deleting
                                    15, // 23 =  The disk is too big to format as FAT16
                                    2,  // 24 =  Card is write protected
                                    11, // 25 =  File not opened for the write
                                    11, // 26 =  File location could not be changed successfully
                                    10, // 27 =  Bad cache read
                                    15, // 28 =  FAT 32 - card not supported
                                    8,  // 29 =  The file is read-only
                                    10, // 30 =  The file is write-only
                                    15, // 31 =  Invalid argument
                                    9,  // 32 =  Too many files are already open
                                    15, // 33 =  Unsupported sector size
                            };

/******************************************************************************************
Text for the file related error messages reported by MMBasic
******************************************************************************************/

const char *FErrorMsg[NBRERRMSG] = {    "",                                 // 0
                                        "SD card not found",                      // 1
                                        "SD card is write protected",               // 2
                                        "Not enough space",                        // 3
                                        "All root directory entries are taken",     // 4
                                        "Invalid file or directory name",           // 5
                                        "Cannot find file",                         // 6
                                        "Cannot find file or directory",          // 7
                                        "File is read only",                        // 8
                                        "Cannot open file",                         // 9
                                        "Cannot read from file",                    // 10
                                        "Cannot write to file",                     // 11
                                        "Not a file",                               // 12
                                        "Not a directory",                          // 13
                                        "Directory not empty",                      // 14
                                        "Cannot access the SD card"                 // 15
                                    };


//
//
char* GetPrompt(void) {
char* pPrompt;

    switch(Option.DEFAULT_DRIVE) {
        case SDFS1:
            if(Option.DriveASet)
                pPrompt = "B>";
            else
                pPrompt = "A>";
            break;
        case SDFS2:
            if(Option.DriveASet)
                pPrompt = "C>";
            else
                pPrompt = "B>";
            break;            
        case SDFS3:
            if(Option.DriveASet)
                pPrompt = "D>";
            else
                pPrompt = "C>";
            break;     
        case SDFS4:
            if(Option.DriveASet)
                pPrompt = "E>";
            else
                pPrompt = "D>";
            break;
        default:
            pPrompt = "> ";
            break;
    }
    return pPrompt;
}


//////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////// MMBASIC COMMANDS & FUNCTIONS FOR THE SDCARD /////////////////////////////



////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// configure the SD card parameters (chip select, write protect and card detect pins)
// this is called by the OPTION SDCARD command
void ConfigSDCard(char *p, unsigned char sd_number) {  
unsigned char i;
unsigned char cnt = 0;
unsigned char arg_offset = 0;
sdcard_t tmp_sdc;

    getargs(&p, 11, ",");
    if(!(argc & 1)) error("Incorrect argument count");
    if(sd_number >= SDCARD_MAX_NUM) error("Incorrect argument count");
    
    tmp_sdc.CS = tmp_sdc.CD = tmp_sdc.WP = 0;
    tmp_sdc.MUX_ENABLE = FALSE; tmp_sdc.MUXn = 0;
    tmp_sdc.DRV0 = tmp_sdc.DRV1 = 0;
    
    if(checkstring(argv[0], "MUX0")) {
       tmp_sdc.MUX_ENABLE = TRUE; 
       tmp_sdc.MUXn = 0;
    }
    else if(checkstring(argv[0], "MUX1")) {
        tmp_sdc.MUX_ENABLE = TRUE;
        tmp_sdc.MUXn = 1;
    }    
    else if(checkstring(argv[0], "MUX2")) {
        tmp_sdc.MUX_ENABLE = TRUE;
        tmp_sdc.MUXn = 2;        
    }  
    else if(checkstring(argv[0], "MUX3")) {
        tmp_sdc.MUX_ENABLE = TRUE;
        tmp_sdc.MUXn = 3;        
    }      
    
    if(tmp_sdc.MUX_ENABLE) {
        if( argc < 7 ) error("Incorrect argument count");
        arg_offset = 6;        
    }
    
    if(FALSE == tmp_sdc.MUX_ENABLE) {
        CheckPin(getinteger(argv[arg_offset+0]), CP_IGNORE_INUSE); // | CP_IGNORE_BOOTRES | CP_IGNORE_RESERVED);
        if(argc > arg_offset+2) {
            CheckPin(abs(getinteger(argv[arg_offset+2])), CP_IGNORE_INUSE); // | CP_IGNORE_BOOTRES | CP_IGNORE_RESERVED);
            tmp_sdc.CD = getinteger(argv[arg_offset+2]);
        }
        tmp_sdc.CS = getinteger(argv[arg_offset+0]);
    }
    if(argc == arg_offset+5) {
        CheckPin(abs(getinteger(argv[arg_offset+4])), CP_IGNORE_INUSE); // | CP_IGNORE_BOOTRES | CP_IGNORE_RESERVED);
        tmp_sdc.WP = getinteger(argv[arg_offset+4]);
    }    
  
    Option.SDCARD[sd_number].WP          = tmp_sdc.WP;
    Option.SDCARD[sd_number].MUX_ENABLE  = tmp_sdc.MUX_ENABLE;
    Option.SDCARD[sd_number].MUXn        = tmp_sdc.MUXn;
    
    if(tmp_sdc.MUX_ENABLE) {
        for(i=0; i<SDCARD_MAX_NUM; i++) {
            if(Option.SDCARD[i].MUX_ENABLE) ++cnt;
        }
        if(cnt == 1) {
            CheckPin(getinteger(argv[6]), CP_IGNORE_INUSE); // | CP_IGNORE_BOOTRES | CP_IGNORE_RESERVED);
            if(argc > 8) {
                CheckPin(abs(getinteger(argv[8])), CP_IGNORE_INUSE); // | CP_IGNORE_BOOTRES | CP_IGNORE_RESERVED);
                tmp_sdc.CD = getinteger(argv[8]);
            }
            tmp_sdc.CS = getinteger(argv[6]);                    
            CheckPin(abs(getinteger(argv[2])), CP_IGNORE_INUSE); // | CP_IGNORE_BOOTRES | CP_IGNORE_RESERVED);
            tmp_sdc.DRV0 = getinteger(argv[2]);        
            CheckPin(abs(getinteger(argv[4])), CP_IGNORE_INUSE); // | CP_IGNORE_BOOTRES | CP_IGNORE_RESERVED);
            tmp_sdc.DRV1 = getinteger(argv[4]);         
            SetAndReserve(tmp_sdc.DRV0, P_OUTPUT, (tmp_sdc.MUXn&1), EXT_BOOT_RESERVED);            // config DRV0 as an output
            SetAndReserve(tmp_sdc.DRV1, P_OUTPUT, (tmp_sdc.MUXn&2)>>1, EXT_BOOT_RESERVED);         // config DRV1 as an output  
        }
        else if(cnt > 1) {
            for(i=0; i<SDCARD_MAX_NUM; i++) { 
                if(Option.SDCARD[i].MUX_ENABLE && (Option.SDCARD[i].DRV0 > 0)) {
                    tmp_sdc.CS = Option.SDCARD[i].CS;
                    tmp_sdc.CD =  Option.SDCARD[i].CD;
                    tmp_sdc.DRV0 = Option.SDCARD[i].DRV0;
                    tmp_sdc.DRV1 = Option.SDCARD[i].DRV1;
                    break;
                }
            }
        }
    }

    Option.SDCARD[sd_number].CS          = tmp_sdc.CS;
    Option.SDCARD[sd_number].CD          = tmp_sdc.CD;    
    Option.SDCARD[sd_number].DRV0        = tmp_sdc.DRV0;
    Option.SDCARD[sd_number].DRV1        = tmp_sdc.DRV1;    
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// disable the SD card, parameter - sd_number
// this is called by the OPTION SDCARD command
void DisableSDCard(unsigned char sd_number) {
unsigned char i; 
unsigned char cnt = 0; 

    if(sd_number >= SDCARD_MAX_NUM) error("Incorrect argument count");
    if(Option.SDCARD[sd_number].MUX_ENABLE) {
        for(i=0; i<SDCARD_MAX_NUM; i++)
        {
            if(Option.SDCARD[i].MUX_ENABLE) ++cnt;
        }
        if(cnt == 1) {
            SetAndReserve(Option.SDCARD[sd_number].DRV0, P_INPUT, 0, EXT_NOT_CONFIG);
            SetAndReserve(Option.SDCARD[sd_number].DRV1, P_INPUT, 0, EXT_NOT_CONFIG);
        }
    }
    Option.SDCARD[sd_number].CS = Option.SDCARD[sd_number].CD = Option.SDCARD[sd_number].WP = 0;
    Option.SDCARD[sd_number].MUX_ENABLE = FALSE; Option.SDCARD[sd_number].MUXn = 0;
    Option.SDCARD[sd_number].DRV0 = Option.SDCARD[sd_number].DRV1 = 0;    
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// setup the SD Card based on the settings saved in flash
void InitFileIO(void) {
    unsigned char i;
    unsigned char cnt_cs = 0;
    unsigned char cnt_mux = 0;
    
    for(i=0; i<SDCARD_MAX_NUM; i++){
        if(Option.SDCARD[i].CS){
            ++cnt_cs;
            SetAndReserve(Option.SDCARD[i].CS, P_OUTPUT, 1, EXT_BOOT_RESERVED);           // config CS as an output
            if(Option.SDCARD[i].CD) {
                SetAndReserve(abs(Option.SDCARD[i].CD), P_INPUT, 0, EXT_BOOT_RESERVED);       // config card detect as an input
                PinSetBit(abs(Option.SDCARD[i].CD), CNPUSET);                                 // set a pullup on it
            }
            if(Option.SDCARD[i].WP) {
                SetAndReserve(abs(Option.SDCARD[i].WP), P_INPUT, 0, EXT_BOOT_RESERVED);       // config write protect as an input
                PinSetBit(abs(Option.SDCARD[i].WP), CNPUSET);                                 // set a pullup on it
            }
            if(Option.SDCARD[i].MUX_ENABLE && (cnt_mux == 0))
            {
                ++cnt_mux;
                SetAndReserve(Option.SDCARD[i].DRV0, P_OUTPUT, (Option.SDCARD[i].MUXn&1), EXT_BOOT_RESERVED);            // config DRV0 as an output
                SetAndReserve(Option.SDCARD[i].DRV1, P_OUTPUT, (Option.SDCARD[i].MUXn&2)>>1, EXT_BOOT_RESERVED);         // config DRV1 as an output                  
            }            
        }// set a pullup on MISO as the SD card initially uses open collector
    }
    if(cnt_cs)
    {
        OpenSpiChannel();
        PinSetBit(SPI2_INP_PIN, CNPUSET);        
    }
}

    

void cmd_save(void) {
    int fnbr, err;
    char *p, *pp;
    char b[STRINGSIZE];

    OptionErrorAbort = 0;
    if(Option.DEFAULT_DRIVE == NOPRESRDIVE) ErrorThrow(1);
    
//    if(CurrentLinePtr) error("Invalid in a program");
    fnbr = FindFreeFileNbr();

    if(!InitSDCard()) return;
    if(year > 2010) SetClockVars(year, month, day, hour, minute, second);

    p = getCstring(cmdline);                           // get the file name and change to the directory
	if(strchr(p, '.') == NULL) strcat(p, ".BAS");
    OpenFileTable[fnbr] = (unsigned int)FSfopen(p, "w");
    if((err = FSerror()) != 0) {
        ErrorThrow(ErrorMap[err]);
        return;
    }

    p  = ProgFlash;
    while(!(*p == 0 || *p == 0xff)) {                               // this is a safety precaution
        p = llist(b, p);                                            // expand the line
        pp = b;
        while(*pp) FilePutChar(*pp++, fnbr);                        // write the line to the SD card
        FilePutChar('\r', fnbr); FilePutChar('\n', fnbr);           // terminate the line
        if(p[0] == 0 && p[1] == 0) break;                           // end of the listing ?
    }

    FileClose(fnbr);
}


void cmd_load(void) {
    int fnbr, err, autorun = false;
    char *p, *buf;
    int c;

    OptionErrorAbort = 0;
    if(Option.DEFAULT_DRIVE == NOPRESRDIVE) ErrorThrow(1);
    
    p = checkstring(cmdline, "IMAGE");
	if(p) {
        LoadImage(p);
        return;
    }
//    p = checkstring(cmdline, "FONT");
//	if(p) {
//        LoadFont(p);
//        return;
//    }

    // else it must be a normal LOAD program command
    {
        getargs(&cmdline, 3, ",");
        if(!(argc & 1) || argc == 0) error("Syntax");
        if(argc == 3) {
            if(toupper(*argv[2]) == 'R')
                autorun = true;
            else
                error("Syntax");
        }

        ClearProgram();												// clear any leftovers from the previous program
        fnbr = FindFreeFileNbr();

        if(!InitSDCard()) return;
        if(year > 2010) SetClockVars(year, month, day, hour, minute, second);

        p = getCstring(argv[0]);                       // get the file name and change to the directory
        if(strchr(p, '.') == NULL) strcat(p, ".BAS");
        OpenFileTable[fnbr] = (unsigned int)FSfopen(p, "r");
        if((err = FSerror()) != 0) {
            ErrorThrow(ErrorMap[err]);
            return;
        }

        p = buf = GetTempMemory(EDIT_BUFFER_SIZE - 512);
        while(!FileEOF(fnbr)) {                                     // while waiting for the end of file
            if((p - buf) >= EDIT_BUFFER_SIZE - 512) error("Not enough memory");
            c = FileGetChar(fnbr);
            if(c<0 || c>127 || isprint(c) || c == '\r' || c == '\n' || c == TAB) {
                if(c == TAB) c = ' ';
                *p++ = c;                                           // get the input into RAM
            }
        }
        *p = 0;                                                     // terminate the string in RAM
        FileClose(fnbr);
        SaveProgramToFlash(buf, false);
        if(autorun) {
            if(*ProgFlash != 0x01) return;                          // no program to run
            ClearRuntime();
            WatchdogSet = false;
            PrepareProgram(true);
            IgnorePIN = false;
            if(Option.ProgFlashSize != PROG_FLASH_SIZE) ExecuteProgram(ProgFlash + Option.ProgFlashSize);       // run anything that might be in the library
            nextstmt = ProgFlash;
        }
    }
}
// search for a volume label, directory or file
// s$ = DIR$(fspec, VOL|DIR|FILE)       will return the first entry
// s$ = DIR$()                          will return the next
// If s$ is empty then no (more) files found
void fun_dir(void) {
    static SearchRec file;
    int r, flags = 0;
    char *p;

    OptionErrorAbort = 0;
    if(Option.DEFAULT_DRIVE == NOPRESRDIVE) ErrorThrow(1);
    
    getargs(&ep, 3, ",");
    if(!(argc == 0 || argc == 3)) error("Invalid syntax");

    if(argc == 3) {
        if(checkstring(argv[2], "VOL"))
            flags = ATTR_VOLUME;
        else if(checkstring(argv[2], "DIR"))
            flags = ATTR_DIRECTORY;
        else if(checkstring(argv[2], "FILE"))
            flags = ATTR_HIDDEN | ATTR_SYSTEM | ATTR_READ_ONLY | ATTR_ARCHIVE;
        else
            error("Invalid flag specification");
    }

    if(!InitSDCard()) ErrorThrow(1);                            // setup the SD card

    if(argc != 0) {
        // this must be the first call eg:  DIR$("*.*", FILE)
        p = getCstring(argv[0]);
        r = FindFirst(p, flags, &file);
    } else
        // this is a subsequent call for more files
        r = FindNext(&file);

    sret = GetTempStrMemory();                                    // this will last for the life of the command
    if(r) return;                                                   // no more file names so return empty
    ErrorCheck();

    strcpy(sret, file.filename);
    CtoM(sret);                                                     // convert to a MMBasic style string
    targ = T_STR;
}


void cmd_mkdir(void) {
    char *p;

    OptionErrorAbort = 0;
    if(Option.DEFAULT_DRIVE == NOPRESRDIVE) ErrorThrow(1);
    
    p = getCstring(cmdline);                                        // get the directory name and convert to a standard C string
    if(!InitSDCard()) return;
    FSmkdir(p);
    ErrorCheck();
}



void cmd_rmdir(void){
    char *p;

    OptionErrorAbort = 0;
    if(Option.DEFAULT_DRIVE == NOPRESRDIVE) ErrorThrow(1);    
    
    p = getCstring(cmdline);                                        // get the directory name and convert to a standard C string
    if(!InitSDCard()) return;
    FSrmdir(p, false);
    ErrorCheck();
}



void cmd_chdir(void){
    char *p;

    OptionErrorAbort = 0;
    if(Option.DEFAULT_DRIVE == NOPRESRDIVE) ErrorThrow(1);   
    
    p = getCstring(cmdline);                                        // get the directory name and convert to a standard C string
    if(!InitSDCard()) return;
    FSchdir(p);
    ErrorCheck();
}



void fun_cwd(void) {
    MMerrno = 0;
    sret = CtoM(GetCWD());
    targ = T_STR;
}



void fun_drive(void) {
	iret = Option.DEFAULT_DRIVE + 1;                         // first byte is the length
    targ = T_INT;
}



void cmd_kill(void){
    char *p;
    int err;
    
    OptionErrorAbort = 0;
    if(Option.DEFAULT_DRIVE == NOPRESRDIVE) ErrorThrow(1);
    
    
    p = getCstring(cmdline);                                        // get the file name

    if(!InitSDCard()) return;
    if(!CheckFileName(p)) { ErrorThrow(6); return; }
    FSremove(p);
    if((err = FSerror()) != 0) {
        ErrorThrow(ErrorMap[err]);
        return;
    }

    ErrorCheck();
}


void cmd_drive(void){
    char *p;
    char *ptmp_cmd;
    int err = 0;
    int i;
    
    ptmp_cmd = pcmdl;
    pcmdl = 0;
    if(ptmp_cmd) {
        p = getCstring(ptmp_cmd);
    }
    else {
        p = getCstring(cmdline);
    }
    if(Option.DriveASet) {  
        if(*p == 'B' || *p == 'b') {
            if(Option.SDCARD[SDCARD_1].CS) {
                Option.DEFAULT_DRIVE = SDFS1;
            }
            else {
                err = 1;
            }
        }
        else if(*p == 'C' || *p == 'c') {
            if(Option.SDCARD[SDCARD_2].CS) {
                Option.DEFAULT_DRIVE = SDFS2;
            }
            else {
                err = 1;
            }
        }
        else if(*p == 'D' || *p == 'd') {
            if(Option.SDCARD[SDCARD_3].CS) {
                Option.DEFAULT_DRIVE = SDFS3;
            }
            else {
                err = 1;
            }
        }
        else if(*p == 'E' || *p == 'e') {
            if(Option.SDCARD[SDCARD_4].CS) {
                Option.DEFAULT_DRIVE = SDFS4;
            }
            else {
                err = 1;
            }
        }     
        else
        {
            error("Unrecognised drive letter");
        }
    }
    else {
        if(*p == 'A' || *p == 'a') {
            if(Option.SDCARD[SDCARD_1].CS) {
                Option.DEFAULT_DRIVE = SDFS1;
            }
            else {
                err = 1;
            }
        }
        else if(*p == 'B' || *p == 'b') {
            if(Option.SDCARD[SDCARD_2].CS) {
                Option.DEFAULT_DRIVE = SDFS2;
            }
            else {
                err = 1;
            }
        }
        else if(*p == 'C' || *p == 'c') {
            if(Option.SDCARD[SDCARD_3].CS) {
                Option.DEFAULT_DRIVE = SDFS3;
            }
            else {
                err = 1;
            }
        }
        else if(*p == 'D' || *p == 'd') {
            if(Option.SDCARD[SDCARD_4].CS) {
                Option.DEFAULT_DRIVE = SDFS4;
            }
            else {
                err = 1;
            }
        }    
        else
        {
            error("Unrecognised drive letter");
        }        
    }

    if(err != 0) {
        ErrorThrow(err);
    }
    
    // reset mm.errno to zero
    ErrorThrow(0); 
    
    if(Option.SDCARD[Option.DEFAULT_DRIVE].MUX_ENABLE) {
        PinSetBit(Option.SDCARD[Option.DEFAULT_DRIVE].DRV0, (Option.SDCARD[Option.DEFAULT_DRIVE].MUXn&1) ? LATSET : LATCLR);
        PinSetBit(Option.SDCARD[Option.DEFAULT_DRIVE].DRV1, (Option.SDCARD[Option.DEFAULT_DRIVE].MUXn&2)>>1 ? LATSET : LATCLR);
    }
        
    while(1)
    {
        if(!Option.SDCARD[Option.DEFAULT_DRIVE].CS) { 
//            MMPrintString("Cannot access the SD card\r\n");
            err = 15;
            break;
        }
        for(i = 0; i < MAXOPENFILES; i++) 
            if(OpenFileTable[i] > MAXOPENFILES) 
                OpenFileTable[i] = NULL;                                // delete any file handles (but not open COM ports)
        if(!MDD_MediaDetect()) {  
//            MMPrintString("SD card not present\r\n");
            err = 1; 
            break;
        }
        if(!FSInit())  
        { 
//            MMPrintString("Cannot access the SD card\r\n");
            err = 15;
            break;
        }  
        break;
    }
    if(err != 0) {
        Option.DEFAULT_DRIVE = Option.PREV_DRIVE;
        SDCardPresent[Option.DEFAULT_DRIVE] = false;
        if(Option.SDCARD[Option.DEFAULT_DRIVE].MUX_ENABLE) {
            PinSetBit(Option.SDCARD[Option.DEFAULT_DRIVE].DRV0, (Option.SDCARD[Option.DEFAULT_DRIVE].MUXn&1) ? LATSET : LATCLR);
            PinSetBit(Option.SDCARD[Option.DEFAULT_DRIVE].DRV1, (Option.SDCARD[Option.DEFAULT_DRIVE].MUXn&2)>>1 ? LATSET : LATCLR);
        }
        (void)InitSDCard();
        ErrorThrow(err);
    }
    else {
        Option.PREV_DRIVE = Option.DEFAULT_DRIVE;
        SDCardPresent[Option.DEFAULT_DRIVE] = true;
    }
}


void cmd_a_drive(void) {
    
    pcmdl = "\"a\"";
    cmd_drive();
}


void cmd_b_drive(void) {
    
    pcmdl = "\"b\"";
    cmd_drive();
}


void cmd_c_drive(void) {
    
    pcmdl = "\"c\"";
    cmd_drive();
}


void cmd_d_drive(void) {
    
    pcmdl = "\"d\"";
    cmd_drive();
}


void cmd_e_drive(void) {
    
    pcmdl = "\"e\"";
    cmd_drive();
}



void cmd_name(void) {
    FSFILE *fp;
    char *old, *new, ss[2];
    ss[0] = tokenAS;                                                // this will be used to split up the argument line
    ss[1] = 0;
    {                                                               // start a new block
        getargs(&cmdline, 3, ss);                                   // getargs macro must be the first executable stmt in a block
        if(argc != 3) error("Syntax");
        old = getCstring(argv[0]);                                  // get the old file name (does not have to use quote marks in immediate mode)
        new = getCstring(argv[2]);                                  // get the new file name (ditto)
        if(str_equal(old, new)) error("Old and new filenames are the same");
        if(!InitSDCard()) return;
        if(!CheckFileName(old)) { ErrorThrow(6); return; }
        if(CheckFileName(new)) { ErrorThrow(9); return; }
        fp = FSfopen(old, "r");
        if(ErrorCheck() || fp == NULL) return;
        FSrename(new, fp);
        if(ErrorCheck()) return;
        FSfclose(fp);
    }
}



void cmd_seek(void) {
    int fnbr, idx;

    OptionErrorAbort = 0;
    if(Option.DEFAULT_DRIVE == NOPRESRDIVE) ErrorThrow(1);    
    
    getargs(&cmdline, 5, ",");
    if(argc != 3) error("Invalid syntax");
    if(*argv[0] == '#') argv[0]++;
    fnbr = getinteger(argv[0]);
    if(fnbr < 1 || fnbr > MAXOPENFILES || OpenFileTable[fnbr] <= MAXOPENFILES) error("Invalid file number");
    if(OpenFileTable[fnbr] == NULL) error("File number #% is not open", fnbr);
    idx = getinteger(argv[2]) - 1;
    FSfseek((FSFILE *)OpenFileTable[fnbr], idx, SEEK_SET);
    if(FSerror() == 31)                                             // if the error is "invalid argument" it generally means seek beyond end of file
        ErrorThrow(10);                                             // so throw a "cannot read" error.  This could be made more informative
    else
        ErrorCheck();                                               // otherwise the normal error check
}



extern int BMP_bDecode(int x, int y, FSFILE *pFile);

void LoadImage(char *p) {
	int fnbr, i;
	int xOrigin, yOrigin;

	// get the command line arguments
	getargs(&p, 5, ",");                                            // this MUST be the first executable line in the function
    if(argc == 0) error("Argument count");
    if(!InitSDCard()) return;

    p = getCstring(argv[0]);                                        // get the file name

    xOrigin = yOrigin = 0;
	if(argc >= 3) xOrigin = getinteger(argv[2]);                    // get the x origin (optional) argument
	if(argc == 5) yOrigin = getinteger(argv[4]);                    // get the y origin (optional) argument

	// open the file
	if(strchr(p, '.') == NULL) strcat(p, ".BMP");
	fnbr = FindFreeFileNbr();
    OpenFileTable[fnbr] = (unsigned int)FSfopen(p, "r");
    if((i = FSerror()) != 0) {
        ErrorThrow(ErrorMap[i]);
        return;
    }
    BMP_bDecode(xOrigin, yOrigin, (FSFILE *)OpenFileTable[fnbr]);
    FileClose(fnbr);
}


unsigned char GetNextCh(int fnbr) {
    unsigned char c;
    do {
        c = FileGetChar(fnbr);
    } while(c == '\r' || c == '\n' || c == ' ' || c == '\t');
    return c;
}

#if defined(LOADFONT)
#define ELEMENT_BUF_SIZE    40
int GetFontElement(int fnbr, int *n) {
    char buf[ELEMENT_BUF_SIZE], *p, *endptr;
    while(1) {
        p = buf;
        do {
            *p = GetNextCh(fnbr);
            if(*p == 0xff) return false;
        } while(!isdigit(*p));
        tryagain:
        do {
            p++;
            *p = GetNextCh(fnbr);
        } while(!(*p == ',' || *p == 0xff || (p - buf) >= ELEMENT_BUF_SIZE - 1));
        if((p - buf) >= ELEMENT_BUF_SIZE - 1) {
            do {
                memcpy(buf, buf + 1, ELEMENT_BUF_SIZE - 1);
                p--;
            } while(p > buf && !isdigit(*buf));
            if(p == buf) continue;
            goto tryagain;
        }
        do {
            *n = strtol(buf, &endptr, 0);
            if(endptr == p) return true;
            memcpy(buf, buf + 1, ELEMENT_BUF_SIZE - 1);
            p--;
        } while(p > buf);
        if(*p == 0xff) return false;
    }
}



void LoadFont(char *p) {
	int fnbr, font, i, n;
	char *fname;
	char ss[2], c;                                                  // this will be used to split up the argument line

	ss[0] = tokenAS;
	ss[1] = 0;
	{																// start a new block
		getargs(&p, 3, ss);                                         // getargs macro must be the first executable stmt in a block
        if(argc != 3) error("Invalid Syntax");
		fname = getCstring(argv[0]);                                // get the file name
        if(*argv[2] == '#') argv[2]++;                              // skip a #
        font = getint(argv[2], FONT_BUILTIN_NBR + 1, FONT_TABLE_SIZE) - 1;
        FreeMemory(FontTable[font]);
        fnbr = FindFreeFileNbr();
        if(!InitSDCard()) return;
        p = NULL;
        while(1) {
            OpenFileTable[fnbr] = (unsigned int)FSfopen(fname, "r");
            if((i = FSerror()) != 0) {
                ErrorThrow(ErrorMap[i]);
                return;
            }
            do {
                do {
                    c = GetNextCh(fnbr);
                    if(c == 0xff) error("Invalid font format");
                } while(c != '=');
            } while(GetNextCh(fnbr) != '{');
            i = 0;
            while(GetFontElement(fnbr, &n)) {
                if(p == NULL)
                    i++;
                else
                    *p++ = n;
            }
            FileClose(fnbr);
            if(p != NULL) break;
            p = GetMemory(i);
            FontTable[font] = (unsigned char *)p;
        }
    }
}
#endif


#define MAXFILES 200
typedef struct ss_flist {
    char fn[13];
    int fs;
} s_flist;


void cmd_files(void) {
	SearchRec file;
	int r, i, dirs, err, ListCnt;
	char *p;
	int fcnt;
	char ts[STRINGSIZE] = "";
	s_flist flist[MAXFILES];

	if(CurrentLinePtr) error("Invalid in a program");
    OptionErrorAbort = 0;
	OptionFileErrorAbort = 0;
    if(Option.DEFAULT_DRIVE == NOPRESRDIVE) ErrorThrow(1);	
    fcnt = 0;
   if(*cmdline)
		p = getCstring(cmdline);
    else
		p = "*.*";

    if(!InitSDCard()) error((char *)FErrorMsg[1]);					// setup the SD card

    // print the current directory
    MMPrintString(GetCWD()); MMPrintString("\r\n");

    // search for the first file/dir
    r = FindFirst(p, ATTR_HIDDEN | ATTR_SYSTEM | ATTR_READ_ONLY | ATTR_DIRECTORY |ATTR_ARCHIVE, &file);

    // add the file to the list, search for the next and keep looping until no more files
    while(r != -1) {
        if((err = FSerror()) != 0) {
            error((char *)FErrorMsg[ErrorMap[err]]);
        }

        if(fcnt >= MAXFILES) {
                error("Too many files to list");
        }

        // add a prefix to each line so that directories will sort ahead of files
        if(file.attributes & ATTR_DIRECTORY)
            ts[0] = 'D';
        else
            ts[0] = 'F';

        // and concatenate the filename found
        strcpy(&ts[1], file.filename);

        // sort the file name into place in the array
        for(i = fcnt; i > 0; i--) {
            if(strcmp(flist[i - 1].fn, ts) > 0)
                flist[i] = flist[i - 1];
            else
                break;
        }
        strcpy(flist[i].fn, ts);
        flist[i].fs = file.filesize;
        fcnt++;
        r = FindNext(&file);
    }

    // list the files with a pause every screen full
	ListCnt = 2;
	for(i = dirs = 0; i < fcnt; i++) {
		if(flist[i].fn[0] == 'D') {
    		dirs++;
            MMPrintString("   <DIR>  ");
		}
		else {
            IntToStrPad(ts, flist[i].fs, ' ', 8, 10); MMPrintString(ts);
            MMPrintString("  ");
        }
        MMPrintString(flist[i].fn + 1);
		MMPrintString("\r\n");
		// check if it is more than a screen full
		if(++ListCnt >= Option.Height && i < fcnt) {
			MMPrintString("PRESS ANY KEY ...");
			MMgetchar();
			MMPrintString("\r                 \r");
			ListCnt = 1;
		}
	}
    // display the summary
    IntToStr(ts, dirs, 10); MMPrintString(ts);
    MMPrintString(" director"); MMPrintString(dirs==1?"y, ":"ies, ");
    IntToStr(ts, fcnt - dirs, 10); MMPrintString(ts);
    MMPrintString(" file"); MMPrintString((fcnt-dirs)==1?"":"s");
	MMPrintString("\r\n");
	longjmp(mark, 1);							// jump back to the input prompt
}





//////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////// ERROR HANDLING ////////////////////////////////////////////


int ErrorThrow(int e) {
    MMerrno = e;
    MMErrMsg = (char *)FErrorMsg[e];
//    if(e && OptionErrorAbort) error(MMErrMsg);
//!!    if(e > 0 && e < NBRERRMSG && OptionErrorAbort == 0) error((char *)FErrorMsg[e]);
    if(e && OptionFileErrorAbort) error(MMErrMsg);
    return e;
}

int ErrorCheck(void) {
    int e;
    e = FSerror();
    if(e < 1 || e > 33) return e;
    return ErrorThrow(ErrorMap[e]);
}

//////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////// GENERAL I/O ////////////////////////////////////////////



void SDCardClose(void) {
    int i;
    if(!Option.SDCARD[Option.DEFAULT_DRIVE].CS) return;
    for(i = 1; i <= MAXOPENFILES; i++)
        if(OpenFileTable[i] > MAXOPENFILES)
            FileClose(i);                                           // close any open files
}



void FileOpen(char *fname, char *fmode, char *ffnbr) {
    int fnbr;
    char *mode = NULL;
                                                                // start a new block
    if(str_equal(fmode, "OUTPUT"))
        mode = "w";
    else if(str_equal(fmode, "APPEND"))
        mode = "a";
    else if(str_equal(fmode, "INPUT"))
        mode = "r";
    else if(str_equal(fmode, "RANDOM"))
        mode = "x";
    else
        error("File access mode");

    if(*ffnbr == '#') ffnbr++;
    fnbr = getinteger(ffnbr);
    (void)BasicFileOpen(fname, fnbr, mode);
}


// this performs the basic duties of opening a file, all file opens in MMBasic should use this
// it will open the file, set the FileTable[] entry and populate the file descriptor
// it returns with true if successful or false if an error
int BasicFileOpen(char *fname, int fnbr, char *mode) {
    
    if(fnbr < 1 || fnbr > MAXOPENFILES) error("File number");
    if(OpenFileTable[fnbr] != NULL) error("File number is already open");

    if(!InitSDCard()) return false;
    if(year > 2010) SetClockVars(year, month, day, hour, minute, second);

    switch(*mode) {
        case 'r':   if(!CheckFileName(fname)) {
                        ErrorThrow(6);
                        return false;
                    }
                    break;
        case 'w':
        case 'a':
        case 'x':   if(Option.SDCARD[Option.DEFAULT_DRIVE].WP == 0 ? false : (Option.SDCARD[Option.DEFAULT_DRIVE].WP > 0 ? PinRead(Option.SDCARD[Option.DEFAULT_DRIVE].WP) : !PinRead(-Option.SDCARD[Option.DEFAULT_DRIVE].WP))) {
                        ErrorThrow(2);
                        return false;
                    } else
                        CheckFileName(fname);
                    break;
    }

    if(*mode == 'x')
        OpenFileTable[fnbr] = (unsigned int)FSfopen(fname, "a+");
    else
        OpenFileTable[fnbr] = (unsigned int)FSfopen(fname, mode);

    if(OpenFileTable[fnbr] == NULL) ErrorThrow(9);

    if(FSerror() != 0) {
        FileClose(fnbr);
        return false;
    } else
        return true;
}


//close the file and free up the file handle
// it will generate an error if needed
void FileClose(int fnbr) {
    if(!InitSDCard()) return;
    if(year > 2010) SetClockVars(year, month, day, hour, minute, second);
    FSfclose((FSFILE *)OpenFileTable[fnbr]);
    OpenFileTable[fnbr] = 0;
    ErrorCheck();
}



char FileGetChar(int fnbr) {
    char ch;
    if(!InitSDCard()) return 0;
    if(FSfread(&ch, 1, 1, (FSFILE *)OpenFileTable[fnbr]) == 0) ch = 0xff;
    ErrorCheck();
    return ch;
}



char FilePutChar(char c, int fnbr) {
    static char t;
    static int nbr;
    t = c;
    nbr = fnbr;
    if(!InitSDCard()) return 0;
    if(FSfwrite(&t, 1, 1, (FSFILE *)OpenFileTable[nbr]) == 0) if(ErrorCheck() == 0) ErrorThrow(9);
    return t;
}



int FileEOF(int fnbr) {
    int i;
    if(!InitSDCard()) return 0;
    if(OpenFileTable[fnbr] == NULL) error("File number is not open");
    i = (FSfeof((FSFILE *)OpenFileTable[fnbr]) != 0) ? -1 : 0;
    ErrorCheck();
    return i;
}



unsigned long FileLOC(int fnbr) {
    FSFILE *t;
    t = (FSFILE *)OpenFileTable[fnbr];
    return(t->seek + 1); 
}



unsigned long FileLOF(int fnbr) {
    FSFILE *t;
    t = (FSFILE *)OpenFileTable[fnbr];
    return(t->size);
}



char *GetCWD(void) {
    char *b;
    b = GetTempStrMemory();
    if(!InitSDCard()) return b;
    if(Option.DriveASet) {
        switch(Option.DEFAULT_DRIVE)
        {
            case    SDFS1:
                *b = 'B';
                break;
            case    SDFS2:
                *b = 'C';
                break;
            case    SDFS3:
                *b = 'D';
                break;
            case    SDFS4:
                *b = 'E';
                break;            
        }   
    }
    else {
        switch(Option.DEFAULT_DRIVE)
        {
            case    SDFS1:
                *b = 'A';
                break;
            case    SDFS2:
                *b = 'B';
                break;
            case    SDFS3:
                *b = 'C';
                break;
            case    SDFS4:
                *b = 'D';
                break;            
        }          
    }
    *(b+1) = ':';
    FSgetcwd(b+2, STRINGSIZE-2);
    ErrorCheck();
    return b;
}



int InitSDCard() {
    int i;
    ErrorThrow(0);                                                                  // reset mm.errno to zero
    if(SDCardPresent[Option.DEFAULT_DRIVE]) return true;                            // if the card is present and has been initialised we have nothing to do
    if(!Option.SDCARD[Option.DEFAULT_DRIVE].CS) { ErrorThrow(15); return false; }
    for(i = 0; i < MAXOPENFILES; i++) 
        if(OpenFileTable[i] > MAXOPENFILES) 
            OpenFileTable[i] = NULL;                                                // delete any file handles (but not open COM ports)
    if(!MDD_MediaDetect()) { ErrorThrow(1); return false; }
    if(!FSInit())  { ErrorThrow(15); return false; }
    SDCardPresent[Option.DEFAULT_DRIVE] = true;
    return true;
}



// finds the first available free file number.  Throws an error if no free file numbers
int FindFreeFileNbr(void) {
    int i;
    for(i = 1; i <= MAXOPENFILES; i++)
        if(OpenFileTable[i] == NULL) return i;
    error("Too many files open");
    return 0;
}



// confirm that a file exists and get its case mapping.
// first this searches the file system looking for a file that has the same name regardless of the case
// if found it rewrites the argument with the file name (and case) as found on the card and returns true.
// if not found it will return false.
// This is needed because the MDD file system is case sensitive and we do not want that.
int CheckFileName(char *p) {
    SearchRec file;
    char fn[256];
    int r;
    #if defined(SUPPORT_LFN)
    int i;
    #endif

    if(!InitSDCard()) return false;
    r = FindFirst("*.*", ATTR_HIDDEN | ATTR_SYSTEM | ATTR_READ_ONLY | ATTR_DIRECTORY |ATTR_ARCHIVE, &file);
    while(r != -1) {
        if(FSerror()) {
            ErrorCheck();
            longjmp(mark, 1);
        }
        strcpy(fn, file.filename);

        if(str_equal(fn, p)) {
            strcpy(p, fn);
            return true;
        }

        r = FindNext(&file);
    }

    return false;
}

void cmd_verinfo(void) {
    
    MMPrintString(MES_SIGNON);                                  // print sign on message
    MMPrintString(COPYRIGHT);                                   // print copyright message
    MMPrintString("\r\n");
}
