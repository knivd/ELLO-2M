
#define __COMPILER_H
#define BOOL_ALREADY_DEFINED

#include "HardwareProfile.h"
#include "Microchip/Include/MDD File System/FSIO.h"
#include "Microchip/Include/MDD File System/FSDefs.h"

#define NBRERRMSG 16
extern int ErrorCheck(void);
extern int ErrorThrow(int e);
