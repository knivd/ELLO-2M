/***********************************************************************************************************************
MMBasic

External.c

Handles reading and writing to the digital and analog input/output pins ising the SETPIN and PIN commands

Copyright 2011 - 2017 Geoff Graham.  All Rights Reserved.

This file and modified versions of this file are supplied to specific individuals or organisations under the following
provisions:

- This file, or any files that comprise the MMBasic source (modified or not), may not be distributed or copied to any other
  person or organisation without written permission.

- Object files (.o and .hex files) generated using this file (modified or not) may not be distributed or copied to any other
  person or organisation without written permission.

- This file is provided in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

************************************************************************************************************************/


#include "../MMBasic_Includes.h"
#define DEFINE_PINDEF_TABLE
#include "../Hardware_Includes.h"

int ExtCurrentConfig[MAXNBRPINS + 1];

volatile int INT1Count, INT1Value, INT1InitTimer, INT1Timer;
volatile int INT2Count, INT2Value, INT2InitTimer, INT2Timer;
volatile int INT3Count, INT3Value, INT3InitTimer, INT3Timer;
volatile int INT4Count, INT4Value, INT4InitTimer, INT4Timer;

int InterruptUsed;

extern void CallCFuncInt2(void);                                    // this is implemented in CFunction.c
extern unsigned int CFuncInt2;                                      // we should call the CFunction Int2 function if this is non zero





/*******************************************************************************************
External I/O related commands in MMBasic
========================================
These are the functions responsible for executing the ext I/O related  commands in MMBasic
They are supported by utility functions that are grouped at the end of this file

Each function is responsible for decoding a command
all function names are in the form cmd_xxxx() (for a basic command) or fun_xxxx() (for a
basic function) so, if you want to search for the function responsible for the LOCATE command
look for cmd_name

There are 4 items of information that are setup before the command is run.
All these are globals.

int cmdtoken	This is the token number of the command (some commands can handle multiple
				statement types and this helps them differentiate)

char *cmdline	This is the command line terminated with a zero char and trimmed of leading
				spaces.  It may exist anywhere in memory (or even ROM).

char *nextstmt	This is a pointer to the next statement to be executed.  The only thing a
				y=spi(1,2,3command can do with it is save it or change it to some other location.

char *CurrentLinePtr  This is read only and is set to NULL if the command is in immediate mode.

The only actions a command can do to change the program flow is to change nextstmt or
execute longjmp(mark, 1) if it wants to abort the program.

********************************************************************************************/


// this is invoked as a command (ie, pin(3) = 1)
// first get the argument then step over the closing bracket.  Search through the rest of the command line looking
// for the equals sign and step over it, evaluate the rest of the command and set the pin accordingly
void cmd_pin(void) {
	int pin, value;

	pin = getinteger(cmdline);
    CheckPin(pin, CP_IGNORE_INUSE);
	while(*cmdline && tokenfunction(*cmdline) != op_equal) cmdline++;
	if(!*cmdline) error("Syntax");
	++cmdline;
	if(!*cmdline) error("Syntax");
	value = getinteger(cmdline);
	ExtSet(pin, value);
}



// this is invoked as a function (ie, x = pin(3) )
void fun_pin(void) {
	// these two defines control the averaging of analog samples.  ANA_AVERAGE is the total number of samples to take
	// while ANA_DISCARD is the the number of highest value samples to discard and the same for the lowest samples
	// this leaves us with ANA_AVERAGE - ANA_DISCARD*2 samples which are averaged to give the final value
	#define ANA_AVERAGE		10
	#define ANA_DISCARD		2

	int pin, i, j, b[ANA_AVERAGE];
	float t;

	pin = getinteger(ep);
    targ = T_INT;

#if defined(MX470)
  //  if(pin == Option.SD_CD || pin == Option.SD_WP || pin == Option.TOUCH_IRQ) {
    if(pin == Option.TOUCH_IRQ) {
        iret = PinRead(pin);
        return;
    }
#endif
    
    CheckPin(pin, CP_IGNORE_INUSE);
    switch(ExtCurrentConfig[pin]) {
        case EXT_DIG_IN:
        case EXT_CNT_IN:
        case EXT_INT_HI:
        case EXT_INT_LO:
        case EXT_INT_BOTH:
        case EXT_DIG_OUT:
        case EXT_OC_OUT:    iret = ExtInp(pin);
                            return;
        case EXT_PER_IN:	// if period measurement get the count and average it over the number of cycles
                            if(pin == INT1PIN) fret = (float)ExtInp(pin) / INT1InitTimer;
                            else if(pin == INT2PIN)  fret = (float)ExtInp(pin) / INT2InitTimer;
                            else if(pin == INT3PIN)  fret = (float)ExtInp(pin) / INT3InitTimer;
                            else if(pin == INT4PIN)  fret = (float)ExtInp(pin) / INT4InitTimer;
                            targ = T_NBR;
                            return;
        case EXT_FREQ_IN:	// if frequency measurement get the count and scale the reading   				
                            if(pin == INT1PIN) fret = (float)(ExtInp(pin) * 1000) / INT1InitTimer;
                            else if(pin == INT2PIN)  fret = (float)(ExtInp(pin) * 1000) / INT2InitTimer;
                            else if(pin == INT3PIN)  fret = (float)(ExtInp(pin) * 1000) / INT3InitTimer;
                            else if(pin == INT4PIN)  fret = (float)(ExtInp(pin) * 1000) / INT4InitTimer;
                            targ = T_NBR;
                            return;
        case EXT_ANA_IN:    break;
        default:            error("Pin % not input", pin);
    }

    // if we got to here it must be an analog input
    // for analog we take ANA_AVERAGE readings and sort them into descending order in buffer b[].
    for(i = 0; i < ANA_AVERAGE; i++) {
        b[i] = ExtInp(pin);									    // get the value
        for(j = i; j > 0; j--) {							    // and sort into position
            if(b[j - 1] < b[j]) {
                t = b[j - 1];
                b[j - 1] = b[j];
                b[j] = t;
            }
            else
                break;
        }
    }
    // we then discard the top ANA_DISCARD samples and the bottom ANA_DISCARD samples and add up the remainder
    for(j = 0, i = ANA_DISCARD; i < ANA_AVERAGE - ANA_DISCARD; i++) j += b[i];

    // the total is averaged and scaled
    fret = ((float)j * 3.3) / (float)(1023 * (ANA_AVERAGE - ANA_DISCARD*2));
    targ = T_NBR;
}



// this is invoked as a command (ie, port(3, 8) = Value)
// first get the arguments then step over the closing bracket.  Search through the rest of the command line looking
// for the equals sign and step over it, evaluate the rest of the command and set the pins accordingly
void cmd_port(void) {
	int pin, nbr, value;
    int i;
	getargs(&cmdline, NBRPINS * 4, ",");

	if((argc & 0b11) != 0b11) error("Argument count");

    // step over the equals sign and get the value for the assignment
	while(*cmdline && tokenfunction(*cmdline) != op_equal) cmdline++;
	if(!*cmdline) error("Syntax");
	++cmdline;
	if(!*cmdline) error("Syntax");
	value = getinteger(cmdline);

    for(i = 0; i < argc; i += 4) {
        pin = getinteger(argv[i]);
        nbr = getint(argv[i + 2], 1, MAX_ARG_COUNT);

        while(nbr) {
            CheckPin(pin, CP_IGNORE_INUSE | CP_IGNORE_BOOTRES);
            if(!(ExtCurrentConfig[pin] == EXT_DIG_OUT || ExtCurrentConfig[pin] == EXT_OC_OUT)) error("Pin % not output", pin);
            ExtSet(pin, value & 1);
            value >>= 1;
            nbr--;
            pin++;
        }
    }
}



// this is invoked as a function (ie, x = port(10,8) )
void fun_port(void) {
	int pin, nbr, i, value = 0;

	getargs(&ep, NBRPINS * 4, ",");
	if((argc & 0b11) != 0b11) error("Argument count");

    for(i = argc - 3; i >= 0; i -= 4) {
        pin = getint(argv[i], 0, INT_MAX);
        nbr = getint(argv[i + 2], 0, INT_MAX);

        if(nbr < 0 || pin <= 0) error("Invalid argument");
        pin += nbr - 1;                                             // we start by reading the most significant bit

        while(nbr) {
            CheckPin(pin, CP_IGNORE_INUSE | CP_IGNORE_BOOTRES);
            if(!(ExtCurrentConfig[pin] == EXT_DIG_IN || ExtCurrentConfig[pin] == EXT_INT_HI || ExtCurrentConfig[pin] == EXT_INT_LO || ExtCurrentConfig[pin] == EXT_INT_BOTH || ExtCurrentConfig[pin] == EXT_DIG_OUT || ExtCurrentConfig[pin] == EXT_OC_OUT)) error("Pin % not input", pin);
            value <<= 1;
            value |= PinRead(pin);
            nbr--;
            pin--;
        }
    }

    iret = value;
    targ = T_INT;
}



void __attribute__((microinstr)) cmd_setpin(void) {
	int i, pin, value, option = 0;
	getargs(&cmdline, 7, ",");
	if(argc%2 == 0 || argc < 3) error("Argument count");

    if(checkstring(argv[2], "OFF") || checkstring(argv[2], "0"))
        value = EXT_NOT_CONFIG;
    else if(checkstring(argv[2], "AIN"))
        value = EXT_ANA_IN;
    else if(checkstring(argv[2], "DIN"))
        value = EXT_DIG_IN;
    else if(checkstring(argv[2], "FIN"))
        value = EXT_FREQ_IN;
    else if(checkstring(argv[2], "PIN"))
        value = EXT_PER_IN;
    else if(checkstring(argv[2], "CIN"))
        value = EXT_CNT_IN;
    else if(checkstring(argv[2], "INTH"))
        value = EXT_INT_HI;
    else if(checkstring(argv[2], "INTL"))
        value = EXT_INT_LO;
    else if(checkstring(argv[2], "DOUT"))
        value = EXT_DIG_OUT;
    else if(checkstring(argv[2], "OOUT"))
        value = EXT_OC_OUT;
    else if(checkstring(argv[2], "INTB"))
        value = EXT_INT_BOTH;
    else
        value = getint(argv[2], 1, 9);

    // check for any options
    switch(value) {
        case EXT_DIG_IN:    if(argc == 5) {
                                if(checkstring(argv[4], "PULLUP")) option = CNPUSET;
                                else if(checkstring(argv[4], "PULLDOWN")) option = CNPDSET;
                                else error("Invalid option");
                            } else
                                option = 0;
                            break;
        case EXT_INT_HI:
        case EXT_INT_LO:
        case EXT_INT_BOTH:  if(argc == 7) {
                                if(checkstring(argv[6], "PULLUP")) option = CNPUSET;
                                else if(checkstring(argv[6], "PULLDOWN")) option = CNPDSET;
                                else error("Invalid option");
                            } else
                                option = 0;
                            break;
        case EXT_FREQ_IN:   if(argc == 5)
                                option = getint((argv[4]), 10, 100000);
                            else
                                option = 1000;
                            break;
        case EXT_PER_IN:   if(argc == 5)
                                option = getint((argv[4]), 1, 10000);
                            else
                                option = 1;
                            break;
        case EXT_DIG_OUT:   if(argc == 5) {
                                if(checkstring(argv[4], "OC"))
                                    value = EXT_OC_OUT;
                            else
                                error("Invalid option");
                            }
                            break;
        default:            if(argc > 3) error("Unexpected text");
    }

	pin = getinteger(argv[0]);
#if defined(MX170)
    // this allows the MX170 version to set a software interrupt on the touch IRQ pin
	if(pin == Option.TOUCH_IRQ) {
        if(value == EXT_INT_HI || value == EXT_INT_LO || value == EXT_INT_BOTH)
            ExtCurrentConfig[pin] = value;
        else if(value == EXT_NOT_CONFIG) {
            ExtCurrentConfig[pin] = EXT_BOOT_RESERVED;
            for(i = 0; i < NBRINTERRUPTS; i++)
                if(inttbl[i].pin == pin)
                    inttbl[i].pin = 0;                              // disable the software interrupt on this pin
        }
        else
            error("Pin % is reserved on startup", pin);
    }
    else
#endif
    {
        CheckPin(pin, CP_IGNORE_INUSE);
        ExtCfg(pin, value, option);
    }

	if(value == EXT_INT_HI || value == EXT_INT_LO || value == EXT_INT_BOTH) {
		// we need to set up a software interrupt
		if(argc < 5) error("Argument count");
        for(i = 0; i < NBRINTERRUPTS; i++) if(inttbl[i].pin == 0) break;
        if(i >= NBRINTERRUPTS) error("Too many interrupts");
        inttbl[i].pin = pin;
		inttbl[i].intp = GetIntAddress(argv[4]);					// get the interrupt routine's location
		inttbl[i].last = ExtInp(pin);								// save the current pin value for the first test
        switch(value) {                                             // and set trigger polarity
            case EXT_INT_HI:    inttbl[i].lohi = T_LOHI; break;
            case EXT_INT_LO:    inttbl[i].lohi = T_HILO; break;
            case EXT_INT_BOTH:  inttbl[i].lohi = T_BOTH; break;
        }
		InterruptUsed = true;
	}
}



void cmd_pulse(void) {
    int pin, i, x, y, state;
    float f;

	getargs(&cmdline, 3, ",");
	if(argc != 3) error("Argument count");
	pin = getinteger(argv[0]);
    CheckPin(pin, CP_IGNORE_INUSE | CP_IGNORE_BOOTRES);
	if(!(ExtCurrentConfig[pin] == EXT_DIG_OUT || ExtCurrentConfig[pin] == EXT_OC_OUT)) error("Pin is not an output");

    f = getnumber(argv[2]);                                         // get the pulse width
    if(f < 0) error("Number out of bounds");
    if(f > 0 && (float)BusSpeed * f < 200000) error("CPU speed too low");
    x = f;                                                          // get the integer portion (in mSec)
    y = (int)((f - (float)x) * 1000.0);                             // get the fractional portion (in uSec)

    for(i = 0; i < NBR_PULSE_SLOTS; i++)                            // search looking to see if the pin is in use
        if(PulseCnt[i] != 0 && PulsePin[i] == pin) {
            mT4IntEnable(0);       									// disable the timer interrupt to prevent any conflicts while updating
            PulseCnt[i] = x;                                        // and if the pin is in use, set its time to the new setting or reset if the user wants to terminate
            mT4IntEnable(1);
            if(x == 0) PinSetBit(PulsePin[i], PulseDirection[i] ? LATSET : LATCLR);
            return;
        }

    if(x == 0 && y == 0) return;                                    // silently ignore a zero pulse width

    state = ((*GetPortAddr(pin, LAT) >> GetPinBit(pin)) & 1);       // get the current state of the output

    if(x < 3) {                                                     // if this is under 3 milliseconds just do it now
        PinSetBit(pin, state ? LATCLR : LATSET);                    // starting edge of the pulse
        uSec(x * 1000 + y);
        PinSetBit(pin, state ? LATSET : LATCLR);                    // finishing edge
        return;
    }

    for(i = 0; i < NBR_PULSE_SLOTS; i++)
        if(PulseCnt[i] == 0) break;                                 // find a spare slot

    if(i >= NBR_PULSE_SLOTS) error("Too many concurrent PULSE commands");

    PinSetBit(pin, state ? LATCLR : LATSET);                        // starting edge of the pulse
    if(x == 1) uSec(500);                                           // prevent too narrow a pulse if there is just one count
    PulsePin[i] = pin;                                              // save the details
    PulseDirection[i] = state;
    PulseCnt[i] = x;
    PulseActive = true;
}


void fun_pulsin(void) {
    int pin, polarity;
    unsigned int t1, t2;

	getargs(&ep, 7, ",");
	if((argc &1) != 1 || argc < 3) error("Argument count");
    pin = getinteger(argv[0]);
    CheckPin(pin, CP_IGNORE_INUSE | CP_IGNORE_BOOTRES);
	if(!ExtCurrentConfig[pin] == EXT_DIG_IN) error("Pin is not an input");
    polarity = getinteger(argv[2]);

    t1 = t2 = 100000;                                               // default timeout is 100mS
    if(argc >= 5) t1 = t2 = getint(argv[4], 5, 1000000);
    if(argc == 7) t2 = getint(argv[6], 5, 1000000);
    t1 = ((t1 * 200) - 180) / (400000000/BusSpeed);                 // convert the timeouts to core timer ticks
    t2 = ((t2 * 200) - 180) / (400000000/BusSpeed);
    
    fret = -1;                                                      // in anticipation of a timeout
    WriteCoreTimer(0);
    if(polarity) {
        while(PinRead(pin)) if(ReadCoreTimer() > t1) return;
        while(!PinRead(pin)) if(ReadCoreTimer() > t1) return;
        WriteCoreTimer(0);
        while(PinRead(pin)) if(ReadCoreTimer() > t2) return;
    } else {
        while(!PinRead(pin)) if(ReadCoreTimer() > t1) return;
        while(PinRead(pin)) if(ReadCoreTimer() > t1) return;
        WriteCoreTimer(0);
        while(!PinRead(pin)) if(ReadCoreTimer() > t2) return;
    }
    t1 = ReadCoreTimer();
    fret = ((t1 * 200) / (BusSpeed/ 100000));
    fret = (float)((int)(fret - (fret / 220))) / 10.0;              // (fret / 220) is compensation for the time required to exit the loop
    targ = T_NBR;
}



/****************************************************************************************************************************
IR routines
*****************************************************************************************************************************/

void __attribute__((microinstr)) cmd_ir(void) {
#if defined(INCL_IR_SEND)
    char *p;
    int i, pin, dev, cmd;
#endif
    if(checkstring(cmdline, "CLOSE")) {
        T1CON = 0;
        IrState = IR_CLOSED;
        mINT4IntEnable(0);
        IrInterrupt = NULL;
        ExtCfg(WAKEUP_PIN, EXT_NOT_CONFIG, 0);
#if defined(INCL_IR_SEND)
    } else if((p = checkstring(cmdline, "SEND"))) {
        getargs(&p, 5, ",");
        if(BusSpeed < 10000000) error("CPU speed too low");
        pin = getinteger(argv[0]);
        dev = getint(argv[2], 0, 0b11111);
        cmd = getint(argv[4], 0, 0b1111111);
        CheckPin(pin, CP_CHECKALL);
        ExtCfg(pin, EXT_DIG_OUT, 0);
        cmd = (dev << 7) | cmd;
        IRSendSignal(pin, 186);
        for(i = 0; i < 12; i++) {
            if(cmd & 1)
                IRSendSignal(pin, 92);
            else
                IRSendSignal(pin, 46);
            cmd >>= 1;
        }
        ExtCfg(pin, EXT_NOT_CONFIG, 0);
#endif
    } else {
        getargs(&cmdline, 5, ",");
        if(IrState != IR_CLOSED) error("Already open");
        if(argc%2 == 0 || argc == 0) error("Argument count");
        IrVarType = 0;
        IrDev = findvar(argv[0], V_FIND);
        if(vartbl[VarIndex].type & T_CONST) error("Cannot change a constant");
        if(vartbl[VarIndex].type & T_STR)  error("Invalid variable");
        if(vartbl[VarIndex].type & T_NBR) IrVarType |= 0b01;
        IrCmd = findvar(argv[2], V_FIND);
        if(vartbl[VarIndex].type & T_CONST) error("Cannot change a constant");
        if(vartbl[VarIndex].type & T_STR)  error("Invalid variable");
        if(vartbl[VarIndex].type & T_NBR) IrVarType |= 0b10;
        InterruptUsed = true;
        IrInterrupt = GetIntAddress(argv[4]);							// get the interrupt location
        IrInit();
    }
}


void __attribute__((microinstr)) IrInit(void) {
    PR1 = 0xffff;
    TMR1 = 0;
    T1CON = 0b1000000000100000;                                     // turn timer 1 on, use 1:64 prescale peripheral bus clock
    if(ExtCurrentConfig[WAKEUP_PIN] >= EXT_COM_RESERVED)  error("Pin is in use");
    ExtCfg(WAKEUP_PIN, EXT_DIG_IN, 0);
    ExtCfg(WAKEUP_PIN, EXT_COM_RESERVED, 0);
    IrReset();
}



void __attribute__((microinstr)) IrReset(void) {
    ConfigINT4(EXT_INT_PRI_2 | FALLING_EDGE_INT | EXT_INT_ENABLE);  // setup the interrupt for the start piulse
    IrState = IR_WAIT_START;
    IrCount = 0;
    TMR1 = 0;
}


#if defined(INCL_IR_SEND)
// this modulates (at about 38KHz) the IR beam for transmit
// half_cycles is the number of half cycles to send.  ie, 186 is about 2.4mSec
void IRSendSignal(int pin, int half_cycles) {
    while(half_cycles--) {
        PinSetBit(pin, LATINV);
        uSec(13);
    }
}
#endif



#if defined(INCL_LCD)

/****************************************************************************************************************************
 The LCD command
*****************************************************************************************************************************/

static char lcd_pins[6];

#if !defined(LITE)

void __attribute__((microinstr)) LCD_Nibble(int Data, int Flag, int Wait_uSec);
void __attribute__((microinstr)) LCD_Byte(int Data, int Flag, int Wait_uSec);
void LcdPinSet(int pin, int val);

void __attribute__((microinstr)) cmd_lcd(void)
 {
    char *p;
    int i, j;

    if((p = checkstring(cmdline, "INIT"))) {
        getargs(&p, 11, ",");
        if(argc != 11) error("Argument count");
        if(*lcd_pins) error("Already open");
        for(i = 0; i < 6; i++) {
            lcd_pins[i] = getinteger(argv[i * 2]);
            CheckPin(lcd_pins[i], CP_CHECKALL);
            ExtCfg(lcd_pins[i], EXT_DIG_OUT, 0);
            ExtCfg(lcd_pins[i], EXT_COM_RESERVED, 0);
        }
        LCD_Nibble(0b0011, 0, 5000);                                // reset
        LCD_Nibble(0b0011, 0, 5000);                                // reset
        LCD_Nibble(0b0011, 0, 5000);                                // reset
        LCD_Nibble(0b0010, 0, 2000);                                // 4 bit mode
        LCD_Byte(0b00101100, 0, 600);                               // 4 bits, 2 lines
        LCD_Byte(0b00001100, 0, 600);                               // display on, no cursor
        LCD_Byte(0b00000110, 0, 600);                               // increment on write
        LCD_Byte(0b00000001, 0, 3000);                              // clear the display
        return;
    }

    if(!*lcd_pins) error("Not open");
    if(checkstring(cmdline, "CLOSE")) {
        for(i = 0; i < 6; i++) {
			ExtCfg(lcd_pins[i], EXT_NOT_CONFIG, 0);					// all set to unconfigured
            *lcd_pins = 0;
        }
    } else if((p = checkstring(cmdline, "CLEAR"))) {                // clear the display
        LCD_Byte(0b00000001, 0, 3000);
    } else if((p = checkstring(cmdline, "CMD")) || (p = checkstring(cmdline, "DATA"))) { // send a command or data
        getargs(&p, MAX_ARG_COUNT * 2, ",");
        for(i = 0; i < argc; i += 2) {
            j = getint(argv[i], 0, 255);
            LCD_Byte(j, toupper(*cmdline) == 'D', 0);
        }
    } else {
        const char linestart[4] = {0, 64, 20, 84};
        int center, pos;

        getargs(&cmdline, 5, ",");
        if(argc != 5) error("Argument count");
        i = getint(argv[0], 1, 4);
        pos = 1;
        if(checkstring(argv[2], "C8"))
            center = 8;
        else if(checkstring(argv[2], "C16"))
            center = 16;
        else if(checkstring(argv[2], "C20"))
            center = 20;
        else if(checkstring(argv[2], "C40"))
            center = 40;
        else {
            center = 0;
            pos = getint(argv[2], 1, 256);
        }
        p = getstring(argv[4]);                                     // returns an MMBasic string
        i = 128 + linestart[i - 1] + (pos - 1);
        LCD_Byte(i, 0, 600);
        for(j = 0; j < (center - *p) / 2; j++) {
            LCD_Byte(' ', 1, 0);
        }
        for(i = 1; i <= *p; i++) {
            LCD_Byte(p[i], 1, 0);
            j++;
        }
        for(; j < center; j++) {
            LCD_Byte(' ', 1, 0);
        }
    }
}



void __attribute__((microinstr)) LCD_Nibble(int Data, int Flag, int Wait_uSec) {
    int i;
    LcdPinSet(lcd_pins[4], Flag);
    for(i = 0; i < 4; i++)
        LcdPinSet(lcd_pins[i], (Data >> i) & 1);
    LcdPinSet(lcd_pins[5], 1); uSec(250); LcdPinSet(lcd_pins[5], 0);
    if(Wait_uSec)
        uSec(Wait_uSec);
    else
        uSec(250);
}


void __attribute__((microinstr)) LCD_Byte(int Data, int Flag, int Wait_uSec) {
    LCD_Nibble(Data/16, Flag, 0);
    LCD_Nibble(Data, Flag, Wait_uSec);
}


void LcdPinSet(int pin, int val) {
    PinSetBit(pin, val ? LATSET : LATCLR);
}

#endif
#endif


/****************************************************************************************************************************
 The DISTANCE function
*****************************************************************************************************************************/
#if defined(INCL_DISTANCE)
void __attribute__((microinstr)) fun_distance(void) {
    int trig, echo;

	getargs(&ep, 3, ",");
	if((argc &1) != 1) error("Argument count");
    trig = getinteger(argv[0]);
    if(argc == 3)
        echo = getinteger(argv[2]);
    else
        echo = trig;                                                // they are the same if it is a 3-pin device
    CheckPin(trig, CP_CHECKALL);
    CheckPin(echo, CP_CHECKALL);
    if(ClockSpeed < 10000000) error("CPU speed too low");
    ExtCfg(echo, EXT_DIG_IN, CNPUSET);                              // setup the echo input
    PinSetBit(trig, LATCLR);                                        // trigger output must start low
    ExtCfg(trig, EXT_DIG_OUT, 0);                                   // setup the trigger output
    PinSetBit(trig, LATSET); uSec(20); PinSetBit(trig, LATCLR);     // pulse the trigger
    uSec(50);
    ExtCfg(echo, EXT_DIG_IN, CNPUSET);                              // this is in case the sensor is a 3-pin type
    uSec(50);
    PauseTimer = 0;                                                 // this is our timeout
    while(PinRead(echo)) if(PauseTimer > 50) { fret = -2; goto exitfun; } // wait for the acknowledgement pulse start
    while(!PinRead(echo)) if(PauseTimer > 100) { fret = -2; goto exitfun;}// then its end
    PauseTimer = 0;
    WriteCoreTimer(0);
    while(PinRead(echo)) {                                          // now wait for the echo pulse
        if(PauseTimer > 32) {                                       // timeout is 32mS
            fret = -1;
            goto exitfun;
        }
    }
    // we have the echo, convert the time to centimeters
    fret = (int)((float)(ReadCoreTimer() * (2000000000u/ClockSpeed)) / 5782.0) / 10.0;
    exitfun:
    targ = T_NBR;
    ExtCfg(trig, EXT_NOT_CONFIG, 0);
    ExtCfg(echo, EXT_NOT_CONFIG, 0);
}
#endif



/****************************************************************************************************************************
 The KEYPAD command
*****************************************************************************************************************************/
#if !defined(LITE)

static char keypad_pins[8];
float *KeypadVar;
char *KeypadInterrupt = NULL;
void __attribute__((microinstr)) KeypadClose(void);

void __attribute__((microinstr)) cmd_keypad(void) {
    int i, j;

    if(checkstring(cmdline, "CLOSE"))
        KeypadClose();
    else {
        getargs(&cmdline, 19, ",");
        if(argc%2 == 0 || argc < 17) error("Argument count");
        if(KeypadInterrupt != NULL) error("Already open");
        KeypadVar = findvar(argv[0], V_FIND);
        if(vartbl[VarIndex].type & T_CONST) error("Cannot change a constant");
        if(!(vartbl[VarIndex].type & T_NBR)) error("Floating point variable required");
        InterruptUsed = true;
        for(i = 0; i < 8; i++) {
            if(i == 7 && argc < 19) {
                keypad_pins[i] = 0;
                break;
            }
            j = getinteger(argv[(i + 2) * 2]);
            CheckPin(j, CP_CHECKALL);
            if(i < 4) {
                ExtCfg(j, EXT_DIG_IN, CNPUSET);
            } else {
                ExtCfg(j, EXT_OC_OUT, 0);
                PinSetBit(j, LATSET);
            }
            ExtCfg(j, EXT_COM_RESERVED, 0);
            keypad_pins[i] = j;
        }
        KeypadInterrupt = GetIntAddress(argv[2]);					// get the interrupt location
    }
}


void __attribute__((microinstr)) KeypadClose(void) {
    int i;
    if(KeypadInterrupt == NULL) return;
    for(i = 0; i < 8; i++) {
        if(keypad_pins[i]) {
            ExtCfg(keypad_pins[i], EXT_NOT_CONFIG, 0);				// all set to unconfigured
        }
    }
    KeypadInterrupt = NULL;
}


int KeypadCheck(void) {
    static unsigned char count = 0, keydown = false;
    int i, j;
    const char PadLookup[16] = { 1, 2, 3, 20, 4, 5, 6, 21, 7, 8, 9, 22, 10, 0, 11, 23 };

    if(count++ % 64) return false;                                  // only check every 64 loops through the interrupt processor

    for(j = 4; j < 8; j++) {                                        // j controls the pull down pins
        if(keypad_pins[j]) {                                        // we might just have 3 pull down pins
            PinSetBit(keypad_pins[j], LATCLR);                      // pull it low
            for(i = 0; i < 4; i++) {                                // i is the row sense inputs
                if(PinRead(keypad_pins[i]) == 0) {                  // if it is low we have found a keypress
                    if(keydown) goto exitcheck;                     // we have already reported this, so just exit
                    uSec(40 * 1000);                                // wait 40mS and check again
                    if(PinRead(keypad_pins[i]) != 0) goto exitcheck;// must be contact bounce if it is now high
                    *KeypadVar = PadLookup[(i << 2) | (j - 4)];     // lookup the key value and set the variable
                    PinSetBit(keypad_pins[j], LATSET);
                    keydown = true;                                 // record that we know that the key is down
                    return true;                                    // and tell the interrupt processor that we are good to go
                }
            }
            PinSetBit(keypad_pins[j], LATSET);                      // wasn't this pin, clear the pulldown
        }
    }
    keydown = false;                                                // no key down, record the fact
    return false;

exitcheck:
    PinSetBit(keypad_pins[j], LATSET);
    return false;
}

#endif


#if defined(INCL_DHT22)
/****************************************************************************************************************************
 The DHT22 function
*****************************************************************************************************************************/

#define CoreTicks(us) (((us * 1000u) / (2000000000u/ClockSpeed)))   // how many core timer ticks does the argument in uS represent

void __attribute__((microinstr)) cmd_dht22(void) {
    int pin;
    long long int r;
    int i, timeout;
    float *temp, *humid;
    
    getargs(&cmdline, 5, ",");
    if(argc != 5) error("Argument count");
    if(BusSpeed < 10000000) error("CPU speed too low");
    
    // get the two variables
	temp = findvar(argv[2], V_FIND);
	if(!(vartbl[VarIndex].type & T_NBR)) error("Invalid variable");
	humid = findvar(argv[4], V_FIND);
	if(!(vartbl[VarIndex].type & T_NBR)) error("Invalid variable");

    // get the pin number and set it up
    pin = getinteger(argv[0]);
    CheckPin(pin, CP_CHECKALL);
    PinSetBit(pin, LATSET);
    ExtCfg(pin, EXT_OC_OUT, 0);
    PinSetBit(pin, CNPUSET);

    // pulse the pin low for 1mS
    PinSetBit(pin, LATCLR);
    uSec(1000);
    PinSetBit(pin, LATSET);

    // wait for the DHT22 to pull the pin low and return it high then take it low again
    WriteCoreTimer(0);
    timeout = CoreTicks(400);
    while(PinRead(pin)) if(ReadCoreTimer() > timeout) goto error_exit;
    while(!PinRead(pin)) if(ReadCoreTimer() > timeout) goto error_exit;
    while(PinRead(pin)) if(ReadCoreTimer() > timeout) goto error_exit;

    // now we wait for the pin to go high and measure how long it stays high (> 50uS is a one bit, < 50uS is a zero bit)
    for(r = i = 0; i < 40; i++) {
        while(!PinRead(pin)) if(ReadCoreTimer() > timeout) goto error_exit;
        WriteCoreTimer(0);
        while(PinRead(pin)) if(ReadCoreTimer() > timeout) goto error_exit;
        r <<= 1;
        r |= (ReadCoreTimer() > CoreTicks(50));
    }

    // we have all 40 bits
    // first validate against the checksum
    if( ( ( ((r >> 8) & 0xff) + ((r >> 16) & 0xff) + ((r >> 24) & 0xff) + ((r >> 32) & 0xff) ) & 0xff) != (r & 0xff)) goto error_exit;                                           // returning temperature
    *temp = (float)((r >> 8) &0x7fff) / 10.0;                       // get the temperature
    if((r >> 8) &0x8000) *temp = -*temp;                            // the top bit is the sign
    *humid = (float)(r >> 24) / 10.0;                               // get the humidity
    goto normal_exit;

error_exit:
    *temp = *humid = 1000.0;                                        // an obviously incorrect reading

normal_exit:
    ExtCfg(pin, EXT_NOT_CONFIG, 0);
}
#endif


/*******************************************************************************************
********************************************************************************************

Utility routines for the external I/O commands and functions in MMBasic

********************************************************************************************
********************************************************************************************/


void __attribute__((microinstr)) ClearExternalIO(void) {
	int i;

    PWMClose(0); PWMClose(1);                                       // close any running PWM output
    SerialClose(1); SerialClose(2);                                 // same for serial ports
    SPIClose();                                                    // close the SPI
#if defined(MX470)
    SerialClose(3); SerialClose(4);
    SPI2Close();                                                    // close SPI2 if not being used for SD Card, touch, etc
#endif
    ResetDisplay();
    i2c_disable();                                                  // close I2C
	i2c_slave_disable();
    IrState = IR_CLOSED;
    IrInterrupt = NULL;
    IrGotMsg = false;
#if !defined(LITE)
    KeypadInterrupt = NULL;
#endif
    mmOWvalue = 0;
#if defined(INCL_LCD)
    *lcd_pins = 0;                                                  // close the LCD
#endif

	for(i = 1; i < NBRPINS + 1; i++) {
		if(CheckPin(i, CP_NOABORT | CP_IGNORE_INUSE | CP_IGNORE_RESERVED)) {    // don't reset invalid or boot reserved pins
//            if(i == 27) dp("reset %d  %d", i, ExtCurrentConfig[i]);
			ExtCfg(i, EXT_NOT_CONFIG, 0);							// all set to unconfigured
		}
	}

	for(i = 0; i < NBRINTERRUPTS; i++) {
		inttbl[i].pin = 0;                                          // disable all interrupts
	}
	InterruptReturn = NULL;
	InterruptUsed = false;
    OnKeyGOSUB = NULL;

    for(i = 0; i < NBRSETTICKS; i++) TickInt[i] = NULL;

	for(i = 0; i < NBR_PULSE_SLOTS; i++) PulseCnt[i] = 0;           // disable any pending pulse commands
    PulseActive = false;
}



/****************************************************************************************************************************
Initialise the I/O pins
 Do not use console debugging here - the console is not set up
*****************************************************************************************************************************/
void __attribute__((microinstr)) initExtIO(void) {
	int i;

	for(i = 1; i < NBRPINS + 1; i++) {
        if(CheckPin(i, CP_NOABORT | CP_IGNORE_INUSE | CP_IGNORE_RESERVED | CP_IGNORE_BOOTRES))
            ExtCfg(i, EXT_NOT_CONFIG, 0);							// all set to unconfigured
	}

    // setup the inputs for external interrupts (used for the counting inputs)
#ifndef ELLO_2M 
#if 0
    INT1PIN_OPEN;
    INT2PIN_OPEN;
    INT3PIN_OPEN;
    INT4PIN_OPEN;
#endif
#endif
}



/****************************************************************************************************************************
Configure an I/O pin
*****************************************************************************************************************************/
void __attribute__((microinstr)) ExtCfg(int pin, int cfg, int option) {
	int i, tris, ana, oc;

    CheckPin(pin, CP_IGNORE_INUSE | CP_IGNORE_RESERVED);

    if(cfg >= EXT_COM_RESERVED) {
        ExtCurrentConfig[pin] = cfg;                                // don't do anything except set the config type
        return;
    }

	// make sure that interrupts are disabled in case we are changing from an interrupt input
	if(pin == INT1PIN) ConfigINT1(EXT_INT_PRI_2 | RISING_EDGE_INT | EXT_INT_DISABLE);
	if(pin == INT2PIN) ConfigINT2(EXT_INT_PRI_2 | RISING_EDGE_INT | EXT_INT_DISABLE);
	if(pin == INT3PIN) ConfigINT3(EXT_INT_PRI_2 | RISING_EDGE_INT | EXT_INT_DISABLE);
	if(pin == INT4PIN && IrState == IR_CLOSED) ConfigINT4(EXT_INT_PRI_2 | RISING_EDGE_INT | EXT_INT_DISABLE);

    // make sure any pullups/pulldowns are removed in case we are changing from a digital input
    PinSetBit(pin, CNPUCLR);  PinSetBit(pin, CNPDCLR);

	for(i = 0; i < NBRINTERRUPTS; i++)
        if(inttbl[i].pin == pin)
            inttbl[i].pin = 0;                                           // start off by disable a software interrupt (if set) on this pin

	switch(cfg) {
		case EXT_NOT_CONFIG:	tris = 1; ana = 1; oc = 0;
                                break;

		case EXT_ANA_IN:        if(!(PinDef[pin].mode & ANALOG_IN)) error("Invalid configuration");
								tris = 1; ana = 0; oc = 0;
								break;

   		case EXT_FREQ_IN:		// same as counting, so fall through
		case EXT_PER_IN:		// same as counting, so fall through
		case EXT_CNT_IN:        if(pin == INT1PIN) {
						    		ConfigINT1(EXT_INT_PRI_2 | RISING_EDGE_INT | EXT_INT_ENABLE);
									INT1Count = INT1Value = 0;
                                    INT1Timer = INT1InitTimer = option;  // only used for frequency and period measurement
						    		tris = 1; ana = 1; oc = 0;
									break;
								}
								if(pin == INT2PIN) {
						    		ConfigINT2(EXT_INT_PRI_2 | RISING_EDGE_INT | EXT_INT_ENABLE);
									INT2Count = INT2Value = 0;
                                    INT2Timer = INT2InitTimer = option;  // only used for frequency and period measurement
						    		tris = 1; ana = 1; oc = 0;
									break;
								}
								if(pin == INT3PIN) {
						    		ConfigINT3(EXT_INT_PRI_2 | RISING_EDGE_INT | EXT_INT_ENABLE);
									INT3Count = INT3Value = 0;
                                    INT3Timer = INT3InitTimer = option;  // only used for frequency and period measurement
						    		tris = 1; ana = 1; oc = 0;
									break;
								}
								if(pin == INT4PIN) {
						    		ConfigINT4(EXT_INT_PRI_2 | RISING_EDGE_INT | EXT_INT_ENABLE);
									INT4Count = INT4Value = 0;
                                    INT4Timer = INT4InitTimer = option;  // only used for frequency and period measurement
						    		tris = 1; ana = 1; oc = 0;
									break;
								}
								error("Invalid configuration");		// not an interrupt enabled pin
								return;

		case EXT_INT_LO:											// same as digital input, so fall through
		case EXT_INT_HI:											// same as digital input, so fall through
		case EXT_INT_BOTH:											// same as digital input, so fall through
		case EXT_DIG_IN:		if(!(PinDef[pin].mode & DIGITAL_IN)) error("Invalid configuration");
                                if(option) PinSetBit(pin, option);
		                        tris = 1; ana = 1; oc = 0;
								break;

		case EXT_DIG_OUT:		if(!(PinDef[pin].mode & DIGITAL_OUT)) error("Invalid configuration");
		                        tris = 0; ana = 1; oc = 0;
								break;

		case EXT_OC_OUT:		if(!(PinDef[pin].mode & DIGITAL_OUT)) error("Invalid configuration");
								tris = 0; ana = 1; oc = 1;
								break;

		default:				error("Invalid configuration");
		                        return;
	}

	ExtCurrentConfig[pin] = cfg;
    *GetPortAddr(pin, ana ? ANSELCLR : ANSELSET) = (1 << GetPinBit(pin));// if ana = 1 then it is a digital I/O
	PinSetBit(pin, tris ? TRISSET : TRISCLR);                       // if tris = 1 then it is an input
	if(cfg == EXT_NOT_CONFIG) ExtSet(pin, 0);						// set the default output to low
	PinSetBit(pin, oc ? ODCSET : ODCCLR);                           // if oc = 1 then open collector is turned ON
}



/****************************************************************************************************************************
Set the output of a digital I/O pin
*****************************************************************************************************************************/
void ExtSet(int pin, int val){

//    if(ExtCurrentConfig[pin] == EXT_NOT_CONFIG || ExtCurrentConfig[pin] == EXT_DIG_OUT || ExtCurrentConfig[pin] == EXT_OC_OUT) {
        PinSetBit(pin, val ? LATSET : LATCLR);
        INTEnableInterrupts();
//    }
//    else
//        error("Pin is not an output");
}



/****************************************************************************************************************************
Get the value of an I/O pin and returns it
For digital returns 0 if low or 1 if high
For analog returns the reading as a 10 bit number with 0b1111111111 = 3.3V
*****************************************************************************************************************************/
int ExtInp(int pin){
    int val;

	// read from an analog input
	if(ExtCurrentConfig[pin] == EXT_ANA_IN) {
#ifndef MZEF
        CloseADC10();                                               // ensure the ADC is off before setting the configuration

        // Setup the multiplexer inputs
        // ============================
        // ADC_CH0_NEG_SAMPLEA_NVREF = Negative Input Select bit for Sample A Multiplexer Setting - Channel 0 negative input is VREFL
        // anChan                    = Channel 0 positive input select for sample A
        SetChanADC10( ADC_CH0_NEG_SAMPLEA_NVREF | (PinDef[pin].anChan << _AD1CHS_CH0SA_POSITION) );

        // Open the ADC
        // ============
        // ADC_FORMAT_INTG           = Data format 16-bit integer
        // ADC_CLK_AUTO              = Internal counter ends sampling and starts conversion (Auto convert)
        // ADC_AUTO_SAMPLING_ON      = Sampling begins immediately after last conversion completes; SAMP bit is automatically set
        // ADC_VREF_AVDD_AVSS        = Voltage reference configuration Vref+ is AVdd and Vref- is AVss
        // ADC_OFFSET_CAL_DISABLE    = Offset calibration disable (normal operation)
        // ADC_SCAN_OFF              = Do notScan Input Selections for CH0+ during SAMPLE A
        // ADC_SAMPLES_PER_INT_1     = Interrupt at the completion of conversion for each sample
        // ADC_ALT_BUF_ON            = Buffer configured as 2 8-word buffers
        // ADC_ALT_INPUT_ON          = Alternate input sample mode select - alternate between MUXA and MUXB
        // ADC_CONV_CLK_INTERNAL_RC  = A/D Conversion Clock Source internal RC Clock
        // ADC_SAMPLE_TIME_15        = Auto Sample Time 1 Tad
        // anInput                   = Enable analog channel input pin SEE WARNING BELOW
        // SKIP_SCAN_ALL             = Channels to skip during auto scan mode (all of them)

        // WARNING: OpenADC10() has a bug where it assumes that the analogue input is always on ANSEL B
        //          This becomes an issue when the pin is on ANSEL A and it configures ANSEL B as an input and an analogue input
        //          For example, when reading pin 2 on the 28-pin Micromite (bit zero in ANSELA) it will set bit zero in ANSEL B
        //          Because the SETPIN command sets ANSEL A or B as needed there is no need for OpenADC10() to also set it.  This
        //          means that we can use zero for the fourth parameter to OpenADC10() and nothing will be changed.
        OpenADC10( ADC_FORMAT_INTG | ADC_CLK_AUTO | ADC_AUTO_SAMPLING_ON , \
                   ADC_VREF_AVDD_AVSS | ADC_OFFSET_CAL_DISABLE | ADC_SCAN_OFF | ADC_SAMPLES_PER_INT_1| ADC_ALT_BUF_ON | ADC_ALT_INPUT_OFF , \
                   ADC_CONV_CLK_INTERNAL_RC | ADC_SAMPLE_TIME_15 , \
                   0 /* anInput */ , \
                   SKIP_SCAN_ALL \
                 );

        EnableADC10();                                              // Enable the ADC
        WriteCoreTimer(0);
#if defined(MX170)
        while(ReadCoreTimer() < 85);                                // let the ADC settle for at least 2uS
#elif defined(MX470)
        while(ReadCoreTimer() < 240);
#endif
        while ( ! mAD1GetIntFlag()) ;
        val = ReadADC10(0);                                         // read the result of the conversion
        mAD1ClearIntFlag();
        CloseADC10();                                               // turn off the ADC so that it does not add to the power drain (particularly in sleep)
#else
        ADC12_AN_INPUT analogInput = (ADC12_AN_INPUT)PinDef[pin].anChan;
        CloseADC12();
        SetChanADC12(analogInput);
        ADC12SetupChannel(ADC12GetChannel(analogInput), ADC12_DATA_10BIT, 2, 14, ADC12_EARLY_INTERRUPT_PRIOR_CLOCK_1);
        ADC12SelectAnalogInputMode(analogInput , ADC12_INPUT_MODE_SINGLE_ENDED_UNSIGNED);
        ADC12Setup(ADC12_VREF_AVDD_AVSS, ADC12_CHARGEPUMP_DISABLE, ADC12_OUTPUT_DATA_FORMAT_INTEGER, 
                false, ADC12_FAST_SYNC_SYSTEM_CLOCK_DISABLE, ADC12_FAST_SYNC_PERIPHERAL_CLOCK_DISABLE, ADC12_INTERRUPT_BIT_SHIFT_LEFT_0_BITS, 
                0, ADC12_CLOCK_SOURCE_FRC, 1, ADC12_WARMUP_CLOCK_128);  
        EnableADC12();
        OpenADC12(analogInput);
        uSec(100);        
        val = ReadADC12(analogInput);
        CloseADC12();
        val >>= 2;  
#endif  
        return val;
    }

	// read from a frequency/period input
	if(ExtCurrentConfig[pin] == EXT_FREQ_IN || ExtCurrentConfig[pin] == EXT_PER_IN) {
		// select input channel
        if(pin == INT1PIN) return INT1Value;
        if(pin == INT2PIN) return INT2Value;
        if(pin == INT3PIN) return INT3Value;
        if(pin == INT4PIN) return INT4Value;
	}

	// read from a counter input
	if(ExtCurrentConfig[pin] == EXT_CNT_IN) {
		// select input channel
        if(pin == INT1PIN) return INT1Count;
        if(pin == INT2PIN) return INT2Count;
        if(pin == INT3PIN) return INT3Count;
        if(pin == INT4PIN) return INT4Count;
	}

	// read from any input
    return  PinRead(pin);
}



/****************************************************************************************************************************
New, more portable, method of manipulating an I/O pin
*****************************************************************************************************************************/

// set or clear a bit in the pin's sfr register
inline void PinSetBit(int pin, unsigned int offset) {
    *(PinDef[pin].sfr + offset) = (1 << PinDef[pin].bitnbr);
}


// return the value of a pin's input
inline int PinRead(int pin) {
    return (*(PinDef[pin].sfr) >> PinDef[pin].bitnbr) & 1;
}



// return a pointer to the pin's sfr register
inline volatile unsigned int *GetPortAddr(int pin, unsigned int offset) {
    return PinDef[pin].sfr + offset;
}


// return an integer representing the bit number in the sfr corresponding to the pin's bit
inline int GetPinBit(int pin) {
    return PinDef[pin].bitnbr;
}


void *IrDev, *IrCmd;
char IrVarType;
char IrState, IrGotMsg;
int IrBits, IrCount;
char *IrInterrupt;



/****************************************************************************************************************************
Interrupt service routines for the counting functions (eg, frequency, period)
*****************************************************************************************************************************/

// perform the counting functions for INT1
void __ISR( _EXTERNAL_1_VECTOR , IPL2AUTO) INT1Interrupt(void) {
	if(ExtCurrentConfig[INT1PIN] == EXT_PER_IN) {
        if(--INT1Timer <= 0) {
            INT1Value = INT1Count;
            INT1Timer = INT1InitTimer;
            INT1Count = 0;
        }
	}
	else
		INT1Count++;

    mINT1ClearIntFlag();    										// Clear the interrupt flag
    return;
}



// perform the counting functions for INT2
void __ISR( _EXTERNAL_2_VECTOR , IPL2AUTO) INT2Interrupt(void) {
    if(ExtCurrentConfig[INT2PIN] == EXT_PER_IN) {
        if(--INT2Timer <= 0) {
            INT2Value = INT2Count;
            INT2Timer = INT2InitTimer;
            INT2Count = 0;
        }
    }
    else {
        if(CFuncInt2)
            CallCFuncInt2();                                        // Hardware interrupt 2 for a CFunction (see CFunction.c)
        else
            INT2Count++;
    }
    mINT2ClearIntFlag();    										// Clear the interrupt flag
    return;
}




// perform the counting functions for INT3
void __ISR( _EXTERNAL_3_VECTOR , IPL2AUTO) INT3Interrupt(void) {
	if(ExtCurrentConfig[INT3PIN] == EXT_PER_IN) {
        if(--INT3Timer <= 0) {
            INT3Value = INT3Count;
            INT3Timer = INT3InitTimer;
            INT3Count = 0;
        }
	}
	else
		INT3Count++;

    mINT3ClearIntFlag();    										// Clear the interrupt flag
    return;
}




// perform the counting functions for INT4
// this interrupt is also used by the IR command and also to wake us from sleep
void __ISR( _EXTERNAL_4_VECTOR , IPL2AUTO) INT4Interrupt(void) {
    int ElapsedMicroSec;
    static unsigned int LastIrBits;
    if(IrState == IR_CLOSED) {
        // this is a COUNTING interrupt
        if(ExtCurrentConfig[INT4PIN] == EXT_PER_IN) {
            if(--INT4Timer <= 0) {
                INT4Value = INT4Count;
                INT4Timer = INT4InitTimer;
                INT4Count = 0;
            }
        }
        else
            INT4Count++;
    } else {
        // this is an IR interrupt
        ElapsedMicroSec = ((1000 * TMR1) / (BusSpeed / 64000));
        switch(IrState) {
            case IR_WAIT_START:
                TMR1 = 0;                                           // reset the timer
                ConfigINT4(EXT_INT_PRI_2 | RISING_EDGE_INT | EXT_INT_ENABLE);   // now trigger on the trailing edge of the start pulse
                IrState = IR_WAIT_START_END;                        // wait for the end of the start bit
                break;
            case IR_WAIT_START_END:
                if(ElapsedMicroSec > 2000 && ElapsedMicroSec < 2800)
                    IrState = SONY_WAIT_BIT_START;                  // probably a Sony remote, now wait for the first data bit
                else if(ElapsedMicroSec > 8000 && ElapsedMicroSec < 10000)
                    IrState = NEC_WAIT_FIRST_BIT_START;             // probably an NEC remote, now wait for the first data bit
                else {
                    IrReset();                                      // the start bit was not valid
                    break;
                }
                IrCount = 0;                                        // count the bits in the message
                IrBits = 0;                                         // reset the bit acumulator
                TMR1 = 0;                                           // reset the timer
                ConfigINT4(EXT_INT_PRI_2 | FALLING_EDGE_INT | EXT_INT_ENABLE);   // now trigger on the leading edge of the first data bit
                break;
            case SONY_WAIT_BIT_START:
                if(ElapsedMicroSec < 300 || ElapsedMicroSec > 900) { IrReset(); break; }
                TMR1 = 0;                                           // reset the timer
                ConfigINT4(EXT_INT_PRI_2 | RISING_EDGE_INT | EXT_INT_ENABLE);   // now trigger on the trailing edge of a data bit
                IrState = SONY_WAIT_BIT_END;                         // wait for the end of this data bit
                break;
            case SONY_WAIT_BIT_END:
                if(ElapsedMicroSec < 300 || ElapsedMicroSec > 1500 || IrCount > 20) { IrReset(); break; }
                IrBits |= (ElapsedMicroSec > 900) << IrCount;       // get the data bit
                IrCount++;                                          // and increment our count
                TMR1 = 0;                                           // reset the timer
                ConfigINT4(EXT_INT_PRI_2 | FALLING_EDGE_INT | EXT_INT_ENABLE);   // now trigger on the leading edge of the next data bit
                IrState = SONY_WAIT_BIT_START;                       // go back and wait for the next data bit
                break;
            case NEC_WAIT_FIRST_BIT_START:
                if(ElapsedMicroSec > 2000 && ElapsedMicroSec < 2500) {
                    IrBits = LastIrBits;                            // key is held down so just repeat the last code
                    IrCount = 32;                                   // and signal that we are finished
                    IrState = NEC_WAIT_BIT_END;
                    break;
                }
                else if(ElapsedMicroSec > 4000 && ElapsedMicroSec < 5000)
                    IrState = NEC_WAIT_BIT_END;                     // wait for the end of this data bit
                else {
                    IrReset();                                      // the start bit was not valid
                    break;
                }
                TMR1 = 0;                                           // reset the timer
                ConfigINT4(EXT_INT_PRI_2 | RISING_EDGE_INT | EXT_INT_ENABLE);   // now trigger on the trailing edge of a data bit
                break;
            case NEC_WAIT_BIT_START:
                if(ElapsedMicroSec < 400 || ElapsedMicroSec > 1800) { IrReset(); break; }
                IrBits |= (ElapsedMicroSec > 840) << (31 - IrCount);// get the data bit
                LastIrBits = IrBits;
                IrCount++;                                          // and increment our count
                TMR1 = 0;                                           // reset the timer
                ConfigINT4(EXT_INT_PRI_2 | RISING_EDGE_INT | EXT_INT_ENABLE);   // now trigger on the trailing edge of a data bit
                IrState = NEC_WAIT_BIT_END;                         // wait for the end of this data bit
                break;
            case NEC_WAIT_BIT_END:
                if(ElapsedMicroSec < 400 || ElapsedMicroSec > 700) { IrReset(); break; }
                if(IrCount == 32) break;
                TMR1 = 0;                                           // reset the timer
                ConfigINT4(EXT_INT_PRI_2 | FALLING_EDGE_INT | EXT_INT_ENABLE);   // now trigger on the leading edge of the next data bit
                IrState = NEC_WAIT_BIT_START;                       // go back and wait for the next data bit
                break;
        }
    }

    mINT4ClearIntFlag();    										// Clear the interrupt flag
    return;
}



int __attribute__((microinstr)) CheckPin(int pin, int action) {

#if defined(DEBUGMODE)
    #if defined(MX170)
        if(!(action & CP_NOABORT) && ((HAS_28PINS && (pin == 4 || pin == 5)) || (HAS_44PINS && (pin == 21 || pin == 22)))) error("Pin % used by ICSP", pin);
    #endif
    #if defined(MX470)
        if(!(action & CP_NOABORT) && ((HAS_64PINS && (pin == 15 || pin == 16)) || (HAS_100PINS && (pin == 24 || pin == 25)))) error("Pin % used by ICSP", pin);
    #endif
#endif

    if(pin < 1 || pin > NBRPINS || (PinDef[pin].mode & UNUSED) || (HAS_USB && (pin == USB_1_PIN || pin == USB_2_PIN))) {
        if(!(action & CP_NOABORT)) error("Pin % is invalid", pin);
        return false;
    }
    
    if(!(action & CP_IGNORE_INUSE) && ExtCurrentConfig[pin] > EXT_NOT_CONFIG && ExtCurrentConfig[pin] < EXT_COM_RESERVED) {
        if(!(action & CP_NOABORT)) error("Pin % is in use", pin);
        return false;
    }
    
    if(!(action & CP_IGNORE_BOOTRES) && ExtCurrentConfig[pin] == EXT_BOOT_RESERVED) {
        if(!(action & CP_NOABORT)) {
            error("Pin % is reserved on startup", pin);
            uSec(1000000);
        }
        return false;
    }
    
    if(!(action & CP_IGNORE_RESERVED) && ExtCurrentConfig[pin] >= EXT_COM_RESERVED) {
        if(!(action & CP_NOABORT)) error("Pin % is in use", pin);
        return false;
    }
    
    return true;
}

