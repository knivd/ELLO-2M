/***********************************************************************************************************************
MMBasic

PWM.c

Handles the PWM command.

Copyright 2011 - 2017 Geoff Graham.  All Rights Reserved.

This file and modified versions of this file are supplied to specific individuals or organisations under the following
provisions:

- This file, or any files that comprise the MMBasic source (modified or not), may not be distributed or copied to any other
  person or organisation without written permission.

- Object files (.o and .hex files) generated using this file (modified or not) may not be distributed or copied to any other
  person or organisation without written permission.

- This file is provided in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

************************************************************************************************************************/


#include "../MMBasic_Includes.h"
#include "../Hardware_Includes.h"

unsigned int *GetSendDataList(char *p, unsigned int *nbr);
long long int *GetReceiveDataBuffer(char *p, unsigned int *nbr);
void SPI1Close(void);

int SPIOpen = false;


////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
// SPI1 functions
//
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


void cmd_spi(void) {
    int t, SPIMode, SPISpeed;
    char *p;
    unsigned int nbr, *d;
    long long int *dd;

    if((p = checkstring(cmdline, "OPEN")) != NULL) {
    	getargs(&p, 5, ",");
        if(argc != 5) error("Argument count");
        if(SPIOpen) error("Already open");

        SPISpeed = getint(argv[0], 10, BusSpeed/2);
        SPISpeed = BusSpeed/SPISpeed;

        SPIMode = SPI_OPEN_MSTEN;
        switch(getinteger(argv[2])) {
            case 0:  SPIMode |= SPI_OPEN_CKE_REV;      break;
            case 1:                                    break;
            case 2:  SPIMode |= SPI_OPEN_CKP_HIGH | SPI_OPEN_CKE_REV; break;
            case 3:  SPIMode |= SPI_OPEN_CKP_HIGH;     break;
            default: error("Invalid mode");
        }
        switch(getinteger(argv[4])) {
            case 8:  SPIMode |= SPI_OPEN_MODE8;        break;
            case 16: SPIMode |= SPI_OPEN_MODE16;       break;
            case 32: SPIMode |= SPI_OPEN_MODE32;       break;
            default: error("Invalid size");
        }
        
        if(ExtCurrentConfig[SPI_OUT_PIN] != EXT_BOOT_RESERVED) {
            ExtCfg(SPI_OUT_PIN, EXT_DIG_OUT, 0); ExtCfg(SPI_OUT_PIN, EXT_COM_RESERVED, 0);
            ExtCfg(SPI_INP_PIN, EXT_DIG_IN, 0); ExtCfg(SPI_INP_PIN, EXT_COM_RESERVED, 0);
            ExtCfg(SPI_CLK_PIN, EXT_DIG_OUT, 0); ExtCfg(SPI_CLK_PIN, EXT_COM_RESERVED, 0);
            SPI_PPS_OPEN;
        }
        SpiChnOpen(SPI_CHANNEL1, SPIMode, SPISpeed);
        SPIOpen = true;
        return;
    }

    if(!SPIOpen) error("Not open");

    if(checkstring(cmdline, "CLOSE")) {
        SPIClose();
        return;
    }

    if((p = checkstring(cmdline, "WRITE")) != NULL) {
        SpiChnGetRov(SPI_CHANNEL1, true);
        while(!SpiChnTxBuffEmpty(SPI_CHANNEL1));                    // wait for the buffer to empty
        d = GetSendDataList(p, &nbr);
        while(nbr--) {
            while(!SpiChnTxBuffEmpty(SPI_CHANNEL1));                // wait for the buffer to empty
            INTDisableInterrupts();                                 // see Errata #10
            SpiChnPutC(SPI_CHANNEL1, *d++);
            INTEnableInterrupts();
            t = SpiChnGetC(SPI_CHANNEL1);                           // discard any received data
        }
        return;
    }

    if((p = checkstring(cmdline, "READ")) != NULL) {
        SpiChnGetRov(SPI_CHANNEL1, true);
        while(!SpiChnTxBuffEmpty(SPI_CHANNEL1));                    // wait for the buffer to empty
        dd = GetReceiveDataBuffer(p, &nbr);        
        while(nbr--) {
            while(!SpiChnTxBuffEmpty(SPI_CHANNEL1));                // wait for the buffer to empty
            INTDisableInterrupts();                                 // see Errata #10
            SpiChnPutC(SPI_CHANNEL1, 0);
            INTEnableInterrupts();
            *dd++ = SpiChnGetC(SPI_CHANNEL1);
        }
        return;
    }
    
    error("Unknown command");
}



// output and get a byte via SPI
void fun_spi(void) {
    if(!SPIOpen) error("Not open");
    SpiChnGetRov(SPI_CHANNEL1, true);                               // clear any receive buffer overrun
    while(!SpiChnTxBuffEmpty(SPI_CHANNEL1));                        // wait for the buffer to empty
    INTDisableInterrupts();                                         // see Errata #10
    SpiChnPutC(SPI_CHANNEL1, getinteger(ep));
    INTEnableInterrupts();
    iret = SpiChnGetC(SPI_CHANNEL1);
    targ = T_INT;
}



void SPIClose(void){
    if(SPIOpen && ExtCurrentConfig[SPI_OUT_PIN] != EXT_BOOT_RESERVED) {// don't close if it is not open or if it is being used by the LCD
        SpiChnClose(SPI_CHANNEL1);
        SPI_PPS_CLOSE;
        ExtCfg(SPI_OUT_PIN, EXT_NOT_CONFIG, 0); ExtCfg(SPI_INP_PIN, EXT_NOT_CONFIG, 0);      // reset to not in use
        ExtCfg(SPI_CLK_PIN, EXT_NOT_CONFIG, 0);
    }
    SPIOpen = false;                                                // show that we are not using it
}


#if defined(MX470)


////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
// SPI2 functions
//
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

void SPI2Close(void);

int SPI2Open = false;

void cmd_spi2(void) {
    int t, SPIMode, SPISpeed;;
    char *p;
    unsigned int nbr, *d;
    long long int *dd;

    if((p = checkstring(cmdline, "OPEN")) != NULL) {
        getargs(&p, 5, ",");
        if(argc != 5) error("Argument count");
        if(SPI2Open) error("Already open");
        if(ExtCurrentConfig[SPI2_OUT_PIN] == EXT_BOOT_RESERVED) error("SPI2 is in use");

        SPISpeed = getinteger(argv[0]);
        if(SPISpeed > BusSpeed/2) error("Invalid speed");
        SPISpeed = BusSpeed/SPISpeed;

        SPIMode = SPI_OPEN_MSTEN;
        switch(getinteger(argv[2])) {
            case 0:  SPIMode |= SPI_OPEN_CKE_REV;      break;
            case 1:                                    break;
            case 2:  SPIMode |= SPI_OPEN_CKP_HIGH | SPI_OPEN_CKE_REV; break;
            case 3:  SPIMode |= SPI_OPEN_CKP_HIGH;     break;
            default: error("Invalid mode");
        }
        switch(getinteger(argv[4])) {
            case 8:  SPIMode |= SPI_OPEN_MODE8;        break;
            case 16: SPIMode |= SPI_OPEN_MODE16;       break;
            case 32: SPIMode |= SPI_OPEN_MODE32;       break;
            default: error("Invalid size");
        }
        
        ExtCfg(SPI2_OUT_PIN, EXT_DIG_OUT, 0); ExtCfg(SPI2_OUT_PIN, EXT_COM_RESERVED, 0);
        ExtCfg(SPI2_INP_PIN, EXT_DIG_IN, 0); ExtCfg(SPI2_INP_PIN, EXT_COM_RESERVED, 0);
        ExtCfg(SPI2_CLK_PIN, EXT_DIG_OUT, 0); ExtCfg(SPI2_CLK_PIN, EXT_COM_RESERVED, 0);
        SPI2_PPS_OPEN;
        SpiChnOpen(SPI_CHANNEL2, SPIMode, SPISpeed);
        SPI2Open = true;
        return;
    }

    if(!SPI2Open) error("Not open");

    if(checkstring(cmdline, "CLOSE")) {
        SPI2Close();
        return;
    }
    
    if((p = checkstring(cmdline, "WRITE")) != NULL) {
        SpiChnGetRov(SPI_CHANNEL2, true);
        while(!SpiChnTxBuffEmpty(SPI_CHANNEL2));                    // wait for the buffer to empty
        d = GetSendDataList(p, &nbr);
        while(nbr--) {
            while(!SpiChnTxBuffEmpty(SPI_CHANNEL2));                // wait for the buffer to empty
            INTDisableInterrupts();                                 // see Errata #10
            SpiChnPutC(SPI_CHANNEL2, *d++);
            INTEnableInterrupts();
            t = SpiChnGetC(SPI_CHANNEL2);                           // discard any received data
        }
        return;
    }

    if((p = checkstring(cmdline, "READ")) != NULL) {
        SpiChnGetRov(SPI_CHANNEL2, true);
        while(!SpiChnTxBuffEmpty(SPI_CHANNEL2));                    // wait for the buffer to empty
        dd = GetReceiveDataBuffer(p, &nbr);        
        while(nbr--) {
            while(!SpiChnTxBuffEmpty(SPI_CHANNEL2));                // wait for the buffer to empty
            INTDisableInterrupts();                                 // see Errata #10
            SpiChnPutC(SPI_CHANNEL2, 0);
            INTEnableInterrupts();
            *dd++ = SpiChnGetC(SPI_CHANNEL2);
        }
        return;
    }
    
    error("Unknown command");
}



// output and get a byte via SPI
void fun_spi2(void) {
    if(!SPI2Open) error("Not open");
    SpiChnGetRov(SPI_CHANNEL2, true);                               // clear any receive buffer overrun
    while(!SpiChnTxBuffEmpty(SPI_CHANNEL2));                        // wait for the buffer to empty
    INTDisableInterrupts();                                         // see Errata #10
    SpiChnPutC(SPI_CHANNEL2, getinteger(ep));
    INTEnableInterrupts();
    iret = SpiChnGetC(SPI_CHANNEL2);
    targ = T_INT;
}



void SPI2Close(void){
    if(SPI2Open) {                                                  // don't close if it is not open
        SpiChnClose(SPI_CHANNEL2);
        SPI2_PPS_CLOSE;
        ExtCfg(SPI2_OUT_PIN, EXT_NOT_CONFIG, 0); ExtCfg(SPI2_INP_PIN, EXT_NOT_CONFIG, 0);      // reset to not in use
        ExtCfg(SPI2_CLK_PIN, EXT_NOT_CONFIG, 0);
    }
    SPI2Open = false;                                               // show that we are not using it
}

#endif


////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
// Utility functions used by both SPI and SPI2
//
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


unsigned int *GetSendDataList(char *p, unsigned int *nbr) {
    unsigned int *buf;
    int i;
    void *ptr;

    getargs(&p, MAX_ARG_COUNT, ",");
    if(!(argc & 1)) error("Syntax");
    *nbr = getint(argv[0], 0, 9999999);
    if(!*nbr) return NULL;
    buf = GetTempMemory(*nbr * sizeof(unsigned int));

    // first check if this is the situation with just two arguments where the second argument could be a string or a simple variable or an array
    // check the correct arg count AND that the second argument looks like a variable AND it is not a function
    if(argc == 3 && isnamestart(*argv[2]) && *skipvar(argv[2], false) == 0 && !(FindSubFun(argv[2], 1) >= 0 && strchr(argv[2], '(') != NULL)) {
    	ptr = findvar(argv[2], V_EMPTY_OK | V_NOFIND_ERR);

        // now check if it is a non array string
		if(vartbl[VarIndex].type & T_STR) {
            if(vartbl[VarIndex].dims[0] != 0) error("Invalid variable");
            if(*((char *)ptr) < *nbr) error("Insufficient data");
            ptr += sizeof(char);                                    // skip the length byte in a MMBasic string
            for (i = 0; i < *nbr; i++) {
                buf[i] = *(char *)ptr;
                ptr += sizeof(char);
            }
            return buf;
		}

        // if it is a float or integer do some sanity checks
        if(vartbl[VarIndex].dims[1] != 0) error("Invalid variable");
        if(*nbr > 1) {
            if(vartbl[VarIndex].dims[0] == 0) error("Invalid variable");
            if(*nbr > (vartbl[VarIndex].dims[0] + 1 - OptionBase)) error("Insufficient data");
        }

        // now check if it is a float
        if(vartbl[VarIndex].type & T_NBR) {
            for (i = 0; i < *nbr; i++) {
                buf[i] = FloatToInt32(*(float *)ptr);
                ptr += sizeof(float);
            }
            return buf;
        }

        // try for an integer
        if(vartbl[VarIndex].type & T_INT)  {
            for (i = 0; i < *nbr; i++) {
                buf[i] = *(unsigned int *)ptr;
                ptr += sizeof(long long int);
            }
            return buf;
        }

    }

    // if we got to here we must have a simple list of expressions to send (phew!)
    if(*nbr != ((argc - 1) >> 1)) error("Argument count");
    for (i = 0; i < *nbr; i++) {
        buf[i] = getinteger(argv[i + i + 2]);
    }
    return buf;
}


long long int *GetReceiveDataBuffer(char *p, unsigned int *nbr) {
    void *ptr;

    getargs(&p, 3, ",");
    if(argc != 3) error("Syntax");
    *nbr = getinteger(argv[0]);
    ptr = findvar(argv[2], V_EMPTY_OK | V_NOFIND_ERR);
	if((vartbl[VarIndex].type & T_INT) && vartbl[VarIndex].dims[0] > 0 && vartbl[VarIndex].dims[1] == 0) {		// integer array
        if( (((long long int *)ptr - vartbl[VarIndex].val.ia) + *nbr) > (vartbl[VarIndex].dims[0] + 1 - OptionBase) )
            error("Insufficient array size");
	}
        else error("Invalid variable");
    return ptr;
}

