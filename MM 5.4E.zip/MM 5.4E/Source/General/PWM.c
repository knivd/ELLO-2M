/***********************************************************************************************************************
MMBasic

PWM.c

Handles the PWM and SERVO commands

Copyright 2011 - 2017 Geoff Graham.  All Rights Reserved.

This file and modified versions of this file are supplied to specific individuals or organisations under the following
provisions:

- This file, or any files that comprise the MMBasic source (modified or not), may not be distributed or copied to any other
  person or organisation without written permission.

- Object files (.o and .hex files) generated using this file (modified or not) may not be distributed or copied to any other
  person or organisation without written permission.

- This file is provided in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

************************************************************************************************************************/


#include "../MMBasic_Includes.h"
#include "../Hardware_Includes.h"


static unsigned int p2 = -1, p3 = -1;                               // a place to save the current prescales for the timers
static char oc1, oc2, oc3, oc4, oc5;                                // flags which are true is the OCx module is opened
static int dcy[2][3];

// the PWM and SERVO commands use the same function
void cmd_pwm(void) {
	int i, j, channel, f, period, prescale, servo;

	getargs(&cmdline, 9, ",");
	if((argc & 0x01) == 0 || argc < 3) error("Argument count");

    channel = getint(argv[0], 1, 2) - 1;
#ifdef MX470
    if((!(CurrentlyPlaying == P_NOTHING || CurrentlyPlaying == P_STOPPED)) && channel == 1) error("In use for audio");
#endif

    if(checkstring(argv[2], "STOP")){
        PWMClose(channel);
        return;
    }

	if(cmdtoken == GetCommandValue("PWM")) {
        servo = false;
        f = getint(argv[2], 20, 500000);
        if(argc < 5) error("Argument count");
        period = BusSpeed/f;                                        // convert the frequency into bus cycles
        if(f < 1250) {
            period /= 64;                                           // adjust if we need to scale the timer's clock
            prescale = T2_PS_1_64;
        } else
            prescale = T2_PS_1_1;
        j = 4;
        for(i = 0; i < 3; i++, j += 2) {
            if(argc < j)
                dcy[channel][i] = -1;
            else {
                float duty = getnumber(argv[j]);
                if(duty < 0.0 || duty > 100.0) error("Number out of bounds");
                dcy[channel][i] = duty * 100.0;
                if(duty == 100.0) dcy[channel][i] = 10100;
                dcy[channel][i] = (period * dcy[channel][i]) / 10000;
            }
        }
    } else {
        // Command must be SERVO
        servo = true;
        f = getinteger(argv[2]);
        if(f >= 20) { //must be a frequency
            if(f > 1000) error("% out of bounds", f);
            j = 4;
        } else {
            f = 50;
            j = 2;
        }
        period = (BusSpeed/ f) / 64;
        prescale = T2_PS_1_64;

        for(i = 0; i < 3; i++, j += 2) {
            if(argc < j)
                dcy[channel][i] = -1;
            else {
                float ontime = getnumber(argv[j]);
                if(ontime < 0.01 || ontime > 18.9) error("Number out of bounds");
                dcy[channel][i] = ((BusSpeed/6.4) * ontime)/10000 ;
            }
        }
    }

    if(dcy[channel][0] < 0) error("Syntax");
    
    // this is channel 1
    if(channel == 0) {
        // this is output 1A
        if(!oc3) {
            ExtCfg(PWM_CH1_PIN, EXT_DIG_OUT, 0);                    // this is the first time so initialise everything
            ExtCfg(PWM_CH1_PIN, EXT_COM_RESERVED, 0);
            PWM_CH1_OPEN;
            OpenOC3( OC_ON | OC_TIMER_MODE16 | OC_TIMER2_SRC | OC_PWM_FAULT_PIN_DISABLE , dcy[0][0], 0x0000 );
            oc3 = true;
        }
        if(!servo) OC3RS = dcy[0][0];                               // update PWM only (servos update in the timer interrupt)
        
        // this is output 1B
        if(dcy[0][1] >= 0) {
            if(!oc2) {
                ExtCfg(PWM_CH2_PIN, EXT_DIG_OUT, 0);                // this is the first time so initialise everything
                ExtCfg(PWM_CH2_PIN, EXT_COM_RESERVED, 0);
                PWM_CH2_OPEN;
                OpenOC2( OC_ON | OC_TIMER_MODE16 | OC_TIMER2_SRC | OC_PWM_FAULT_PIN_DISABLE , dcy[0][1], 0x0000 );
                oc2 = true;
            }
            if(!servo) OC2RS = dcy[0][1];                           // update PWM only (servos update in the timer interrupt)
        }
        
        // this is output 1C
        if(dcy[0][2] >= 0) {
            if(!oc5) {
                ExtCfg(PWM_CH3_PIN, EXT_DIG_OUT, 0);                // this is the first time so initialise everything
                ExtCfg(PWM_CH3_PIN, EXT_COM_RESERVED, 0);
                PWM_CH3_OPEN;
                OpenOC5( OC_ON | OC_TIMER_MODE16 | OC_TIMER2_SRC | OC_PWM_FAULT_PIN_DISABLE , dcy[0][2], 0x0000 );
                oc5 = true;
            }
            if(!servo) OC5RS = dcy[0][2];                           // update PWM only (servos update in the timer interrupt)
        }

        // now set the timer for channel 1
        if(p2 == prescale)
            WritePeriod2(period);
        else {
            OpenTimer2(T2_ON | prescale, period);
            if(servo) ConfigIntTimer2(T2_INT_ON | T2_INT_PRIOR_4);  // servo outputs only update when the timer count is zero
        }
        p2 = prescale;
    } else {
        // this is channel 2
        // and this is output 2A
        if(!oc1) {
            ExtCfg(PWM_CH4_PIN, EXT_DIG_OUT, 0);                    // this is the first time so initialise everything
            ExtCfg(PWM_CH4_PIN, EXT_COM_RESERVED, 0);
            PWM_CH4_OPEN;
            OpenOC1( OC_ON | OC_TIMER_MODE16 | OC_TIMER3_SRC | OC_PWM_FAULT_PIN_DISABLE , dcy[1][0], 0x0000 );
            oc1 = true;
        } 
        if(!servo) OC1RS = dcy[1][0];                               // update PWM only (servos update in the timer interrupt)
        
        
        // this is output 2B
        if(dcy[1][1] >= 0) {
#ifndef MZEF            
            if(!oc4) {
                ExtCfg(PWM_CH5_PIN, EXT_DIG_OUT, 0);                // this is the first time so initialise everything
                ExtCfg(PWM_CH5_PIN, EXT_COM_RESERVED, 0);
                PWM_CH5_OPEN;
                OpenOC4( OC_ON | OC_TIMER_MODE16 | OC_TIMER3_SRC | OC_PWM_FAULT_PIN_DISABLE , dcy[1][1], 0x0000 );
                oc4 = true;
            }
            if(!servo) OC4RS = dcy[1][1];                           // update PWM only (servos update in the timer interrupt)
#else
            if(!oc4) {
                ExtCfg(PWM_CH5_PIN, EXT_DIG_OUT, 0);                // this is the first time so initialise everything
                ExtCfg(PWM_CH5_PIN, EXT_COM_RESERVED, 0);
                PWM_CH5_OPEN;
                OpenOC6( OC_ON | OC_TIMER_MODE16 | OC_TIMER3_SRC | OC_PWM_FAULT_PIN_DISABLE , dcy[1][1], 0x0000 );
                oc4 = true;
            }
            if(!servo) OC6RS = dcy[1][1];                           // update PWM only (servos update in the timer interrupt)
#endif            
        }

        if(dcy[1][2] >= 0) error("Syntax");

        // now set the timer for channel 2
        if(p3 == prescale)
            WritePeriod3(period);
        else {
            OpenTimer3(T3_ON | prescale, period);
            if(servo) ConfigIntTimer3(T3_INT_ON | T3_INT_PRIOR_4);  // servo outputs only update when the timer count is zero
        }
        p3 = prescale;
#if defined(MX470)
        CurrentlyPlaying = P_NOTHING;
#endif
    }
}


// These two interrupts are called when the timer counter is reset to zero
// The servo outputs are updated at this time because updating a compare 
// register in the middle of a timer count may cause a runt pulse and
// upset the servo
// PWM outputs do not use these interrupts
void __ISR(_TIMER_2_VECTOR, IPL4AUTO) Timer2Handler(void)
{
    OC3RS = dcy[0][0];
    OC2RS = dcy[0][1];
    OC5RS = dcy[0][2];
    mT2ClearIntFlag();                                              // clear the interrupt flag
}


void __ISR(_TIMER_3_VECTOR, IPL4AUTO) Timer3Handler(void)
{
#ifdef MX470
    if(CurrentlyPlaying != P_NOTHING) 
	    audioInterrupt();
    else {
        OC1RS = dcy[1][0];
#ifndef MZEF    
        OC4RS = dcy[1][1];
#else
        OC6RS = dcy[1][1];
#endif
    }
#else 
    OC1RS = dcy[1][0];
    OC4RS = dcy[1][1];
#endif
    mT3ClearIntFlag();                                              // clear the interrupt flag
}


// close the PWM output
void PWMClose(int channel) {
    switch(channel) {
        case 0:
            CloseTimer2();
            
            CloseOC3();
            PWM_CH1_CLOSE;
            if(ExtCurrentConfig[PWM_CH1_PIN] == EXT_COM_RESERVED) ExtCfg(PWM_CH1_PIN, EXT_NOT_CONFIG, 0);
            p2 = -1;

            CloseOC2();
            PWM_CH2_CLOSE;
            if(ExtCurrentConfig[PWM_CH2_PIN] == EXT_COM_RESERVED) ExtCfg(PWM_CH2_PIN, EXT_NOT_CONFIG, 0);

            CloseOC5();
            PWM_CH3_CLOSE;
            if(ExtCurrentConfig[PWM_CH3_PIN] == EXT_COM_RESERVED) ExtCfg(PWM_CH3_PIN, EXT_NOT_CONFIG, 0);
            oc3 = oc2 = oc5 = false;
            break;
        case 1:
            CloseTimer3();

            CloseOC1();
            PWM_CH4_CLOSE;
            if(ExtCurrentConfig[PWM_CH4_PIN] == EXT_COM_RESERVED) ExtCfg(PWM_CH4_PIN, EXT_NOT_CONFIG, 0);
            p3 = -1;
#ifndef MZEF
            CloseOC4();
#else
            CloseOC6();
#endif
            PWM_CH5_CLOSE;
            if(ExtCurrentConfig[PWM_CH5_PIN] == EXT_COM_RESERVED) ExtCfg(PWM_CH5_PIN, EXT_NOT_CONFIG, 0);
            oc1 = oc4 = false;
            break;
    }
}
