/***********************************************************************************************************************
MMBasic

Misc.c

Handles all the miscelaneous commands and functions in MMBasic.  These are commands and functions that do not
comfortably fit anywhere else.

Copyright 2011 - 2017 Geoff Graham.  All Rights Reserved.

This file and modified versions of this file are supplied to specific individuals or organisations under the following
provisions:

- This file, or any files that comprise the MMBasic source (modified or not), may not be distributed or copied to any other
  person or organisation without written permission.

- Object files (.o and .hex files) generated using this file (modified or not) may not be distributed or copied to any other
  person or organisation without written permission.

- This file is provided in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

************************************************************************************************************************/


#include "../MMBasic_Includes.h"
#include "../Hardware_Includes.h"

extern void CallCFuncInt(void);                                    // this is implemented in CFunction.c
extern unsigned int CFuncInt;                                      // we should call the CFunction mSec function if this is non zero

struct s_inttbl inttbl[NBRINTERRUPTS];
char *InterruptReturn;

int TickPeriod[NBRSETTICKS];
volatile int TickTimer[NBRSETTICKS];
char *TickInt[NBRSETTICKS];
char *OnKeyGOSUB = NULL;

char EchoOption = true;

unsigned int ClockSpeed = CLOCKFREQ;
unsigned int BusSpeed;


// this is invoked as a command (ie, TIMER = 0)
// search through the line looking for the equals sign and step over it,
// evaluate the rest of the command and save in the timer
void cmd_timer(void) {
	while(*cmdline && tokenfunction(*cmdline) != op_equal) cmdline++;
	if(!*cmdline) error("Syntax");
	mSecTimer = getinteger(++cmdline);
}



// this is invoked as a function
void fun_timer(void) {
	iret = mSecTimer;
    targ = T_INT;
}



void cmd_pause(void) {
	static int interrupted = false;
    float f;

    f = getnumber(cmdline);                                     // get the pulse width
    if(f < 0) error("Number out of bounds");
    if(f < 0.05) return;

	if(f < 1.5) {
		uSec(f * 1000);                                         // if less than 1.5mS do the pause right now
		return;                                                 // and exit straight away
    }

	if(InterruptReturn == NULL) {
		// we are running pause in a normal program
		// first check if we have reentered (from an interrupt) and only zero the timer if we have NOT been interrupted.
		// This means an interrupted pause will resume from where it was when interrupted
		if(!interrupted) PauseTimer = 0;
		interrupted = false;

		while(PauseTimer < FloatToInt32(f)) {
			CheckAbort();
#if defined(MX470)
            if(CurrentlyPlaying == P_WAV)checkWAVinput();
#endif
			if(check_interrupt()) {
				// if there is an interrupt fake the return point to the start of this stmt
				// and return immediately to the program processor so that it can send us off
				// to the interrupt routine.  When the interrupt routine finishes we should reexecute
				// this stmt and because the variable interrupted is static we can see that we need to
				// resume pausing rather than start a new pause time.
				while(*cmdline && *cmdline != cmdtoken) cmdline--;	// step back to find the command token
				InterruptReturn = cmdline;							// point to it
				interrupted = true;								    // show that this stmt was interrupted
				return;											    // and let the interrupt run
			}
#if defined(MX470)
            ProcessTouch();
#endif

		}
        interrupted = false;
	}
	else {
		// we are running pause in an interrupt, this is much simpler but note that
		// we use a different timer from the main pause code (above)
		IntPauseTimer = 0;
		while(IntPauseTimer < FloatToInt32(f)) CheckAbort();
	}
}



// this is invoked as a command (ie, date$ = "6/7/2010")
// search through the line looking for the equals sign and step over it,
// evaluate the rest of the command, split it up and save in the system counters
void cmd_date(void) {
	char *arg;
	int d, m, y;
	while(*cmdline && tokenfunction(*cmdline) != op_equal) cmdline++;
	if(!*cmdline) error("Syntax");
	++cmdline;
	arg = getCstring(cmdline);
	{
		getargs(&arg, 5, "-/");										// this is a macro and must be the first executable stmt in a block
		if(argc != 5) error("Syntax");
		d = atoi(argv[0]);
		m = atoi(argv[2]);
		y = atoi(argv[4]);
		if(y >= 0 && y < 100) y += 2000;
		if(d < 1 || d > 31 || m < 1 || m > 12 || y < 2000 || y > 2999) error("Invalid date");

		mT4IntEnable(0);       										// disable the timer interrupt to prevent any conflicts while updating
		day = d;
		month = m;
		year = y;
		mT4IntEnable(1);       										// enable interrupt
	}
}

// this is invoked as a function
void fun_date(void) {
    sret = GetTempStrMemory();                                    // this will last for the life of the command
	mT4IntEnable(0);       											// disable the timer interrupt to prevent any conflicts while updating
    IntToStrPad(sret, day, '0', 2, 10);
    sret[2] = '-'; IntToStrPad(sret + 3, month, '0', 2, 10);
    sret[5] = '-'; IntToStr(sret + 6, year, 10);
	mT4IntEnable(1);                                                // enable interrupt
	CtoM(sret);
    targ = T_STR;
}



// this is invoked as a command (ie, time$ = "6:10:45")
// search through the line looking for the equals sign and step over it,
// evaluate the rest of the command, split it up and save in the system counters
void cmd_time(void) {
	char *arg;
	int h = 0;
	int m = 0;
	int s = 0;

	while(*cmdline && tokenfunction(*cmdline) != op_equal) cmdline++;
	if(!*cmdline) error("Syntax");
	++cmdline;
	arg = getCstring(cmdline);
	{
		getargs(&arg, 5, ":");								// this is a macro and must be the first executable stmt in a block
		if(argc%2 == 0) error("Syntax");
		h = atoi(argv[0]);
		if(argc >= 3) m = atoi(argv[2]);
		if(argc == 5) s = atoi(argv[4]);
		if(h < 0 || h > 23 || m < 0 || m > 59 || s < 0 || s > 59) error("Invalid time");
		mT4IntEnable(0);       										// disable the timer interrupt to prevent any conflicts while updating
		hour = h;
		minute = m;
		second = s;
		SecondsTimer = 0;
		mT4IntEnable(1);       										// enable interrupt
    }
}




// this is invoked as a function
void fun_time(void) {
	sret = GetTempStrMemory();									// this will last for the life of the command
	mT4IntEnable(0);       											// disable the timer interrupt to prevent any conflicts while updating
//	sprintf(sret, "%02d:%02d:%02d", hour, minute, second);
    IntToStrPad(sret, hour, '0', 2, 10);
    sret[2] = ':'; IntToStrPad(sret + 3, minute, '0', 2, 10);
    sret[5] = ':'; IntToStrPad(sret + 6, second, '0', 2, 10);
	mT4IntEnable(1);  	     										// enable interrupt
	CtoM(sret);
    targ = T_STR;
}



void cmd_ireturn(void){
	if(InterruptReturn == NULL) error("Not in interrupt");
	checkend(cmdline);
	nextstmt = InterruptReturn;
	InterruptReturn = NULL;
	if(LocalIndex) 	ClearVars(LocalIndex--);                        // delete any local variables
#if defined(MX470)
    if(DelayedDrawKeyboard) {
        DelayedDrawKeyboard = false;
        DrawKeyboard(1);                                            // the pop-up GUI keyboard should be drawn AFTER the pen down interrupt
    }
#endif
}


// set up the tick interrupt
void cmd_settick(void){
	int period;
	int irq;
	getargs(&cmdline, 5, ",");
	if(!(argc == 3 || argc == 5)) error("Argument count");
	period = getint(argv[0], 0, INT_MAX);
	if(argc == 5)
	    irq = getint(argv[4], 1, NBRSETTICKS) - 1;
	else
	    irq = 0;
	if(period == 0) {
		TickInt[irq] = NULL;										// turn off the interrupt
    } else {
		TickPeriod[irq] = period;
		TickInt[irq] = GetIntAddress(argv[2]);					    // get a pointer to the interrupt routine
		TickTimer[irq] = 0;										    // set the timer running
		InterruptUsed = true;

	}
}



void cmd_watchdog(void) {
    int i;

    if(checkstring(cmdline, "OFF") != NULL) {
        WDTimer = 0;
    } else {
        i = getint(cmdline, 1, INT_MAX);
        WDTimer = i;
    }
}


void fun_restart(void) {
    iret = WatchdogSet;
    targ = T_INT;
}


void __attribute__((microinstr)) cmd_option(void) {
	char *tp;

	tp = checkstring(cmdline, "BASE");
	if(tp) {
		if(DimUsed) error("Must be before DIM or LOCAL");
		OptionBase = getint(tp, 0, 1);
		return;
	}

	tp = checkstring(cmdline, "EXPLICIT");
	if(tp) {
//        if(varcnt != 0) error("Variables already defined");
		OptionExplicit = true;
		return;
	}

    tp = checkstring(cmdline, "DEFAULT");
	if(tp) {
		if(checkstring(tp, "INTEGER"))	{ DefaultType = T_INT; 	return; }
		if(checkstring(tp, "FLOAT"))	{ DefaultType = T_NBR; 	return; }
		if(checkstring(tp, "STRING"))	{ DefaultType = T_STR; 	return; }
		if(checkstring(tp, "NONE"))	    { DefaultType = T_NOTYPE; 	return; }
	}

#ifndef ELLO_2M    
	tp = checkstring(cmdline, "BREAK");
	if(tp) {
		BreakKey = getinteger(tp);
		return;
	}

    tp = checkstring(cmdline, "AUTORUN");
	if(tp) {
		if(checkstring(tp, "ON"))		{ Option.Autorun = true; SaveOptions(); return; }
		if(checkstring(tp, "OFF"))		{ Option.Autorun = false; SaveOptions(); return;  }
	}
#endif

    tp = checkstring(cmdline, "CASE");
	if(tp) {
		if(checkstring(tp, "LOWER"))	{ Option.Listcase = CONFIG_LOWER; SaveOptions(); return; }
		if(checkstring(tp, "UPPER"))	{ Option.Listcase = CONFIG_UPPER; SaveOptions(); return; }
		if(checkstring(tp, "TITLE"))	{ Option.Listcase = CONFIG_TITLE; SaveOptions(); return; }
	}

    tp = checkstring(cmdline, "TAB");
	if(tp) {
		if(checkstring(tp, "2"))		{ Option.Tab = 2; SaveOptions(); return; }
		if(checkstring(tp, "4"))		{ Option.Tab = 4; SaveOptions(); return; }
		if(checkstring(tp, "8"))		{ Option.Tab = 8; SaveOptions(); return; }
	}

#ifndef ELLO_2M
    tp = checkstring(cmdline, "BAUDRATE");
	if(tp) {
        int i;
		i = getint(tp, 100, BusSpeed/17);
        Option.Baudrate = i;
        SaveOptions();
        initSerialConsole();
		return;
	}

    tp = checkstring(cmdline, "PIN");
	if(tp) {
    	int i;
		i = getint(tp, 0, 99999999);
        Option.PIN = i;
        SaveOptions();
		return;
	}

    tp = checkstring(cmdline, "DISPLAY");
	if(tp) {
        getargs(&tp, 3, ",");
		Option.Height = getint(argv[0], 5, 100);
        if(argc == 3) Option.Width = getint(argv[2], 37, 132);
        SaveOptions();
		return;
	}
#endif

    tp = checkstring(cmdline, "COLOURCODE");
    if(tp == NULL) tp = checkstring(cmdline, "COLORCODE");
	if(tp) {
		if(checkstring(tp, "ON"))		{ Option.ColourCode = true; SaveOptions(); return; }
		if(checkstring(tp, "OFF"))		{ Option.ColourCode = false; SaveOptions(); return;  }
	}

//    tp = checkstring(cmdline, "DUMP");
//	if(tp) {
//        int i, pos, *p;
//        char buf[10];
//        p = (int *)&Option;
//        for(pos = i = 0; i < sizeof(struct option_s); i += 4) {
//            IntToStrPad(buf, (*p++) & 0xffffffff, '0', 8, 16);
//            MMPrintString(buf);
//            pos += 9;
//            if(pos + 8 > Option.Width) {
//                MMPrintString("\r\n");
//                pos = 0;
//            } else
//                MMPrintString(" ");
//        }
//        MMPrintString("\r\n");
//        return;
//    }

    OtherOptions();
}



void fun_errno(void) {
    iret = MMerrno;
    targ = T_INT;
}


void fun_errmsg(void) {
    sret = GetTempStrMemory();
    strcpy(sret, MMErrMsg);
    CtoM(sret);
    targ = T_STR;
}



void __attribute__((microinstr)) __attribute__((optimize("-O0"))) cmd_cpu(void) {
    int i;
    int Div = 0, Mult = 0;
    unsigned int NewClock;
    char *p;

    while(!UARTTransmissionHasCompleted(UART1));                    // wait for the console UART to send whatever is in its buffer
    uSec(5000);                                                     // delay until the USB transmission is complete
    if((p = checkstring(cmdline, "RESTART"))) {
        _excep_code = RESET_COMMAND;
        SoftReset();                                                // this will restart the processor ? only works when not in debug
    }
    else if((p = checkstring(cmdline, "SLEEP"))) {
        int i1, i2, i3, intpin, pinstate;
        skipspace(p);
        if(!(*p == 0 || *p =='\'')) {
#if defined(MX470)
            CloseUSBConsole();
#endif
            // it is: CPU SLEEP seconds
            getargs(&p, 3, ",");
            // go to sleep for 1.024 seconds and on each wakeup count down the sleep time until it reaches zero
            i = getint(argv[0], 0, 999999);                         // get the sleep time
            if(i == 0) return;
            i = ((i * 1000) + 512) / 1024;                          // round it up and scale for the watchdog timer interval (1.024 sec)
            if(argc == 3) {                                         // has the user specifies a wakeup pin also
                intpin = getinteger(argv[2]);
                CheckPin(intpin, CP_IGNORE_INUSE | CP_IGNORE_BOOTRES);
                pinstate = PinRead(intpin);                         // any change from this will terminate the sleep
            } else
                pinstate = intpin = 0;
#ifndef MZEF            
            INTDisableInterrupts();

            // a possible bug in the PIC32?  INTDisableInterrupts() does not seem to disable everything
            // we have to disable individual interrupts, if we don't do this an interrupt can randomly occur fliping the CPU into idle mode
            mT4IntEnable(0);
            INTEnable(INT_SOURCE_UART_RX(UART1), INT_DISABLED);
#if defined(MX470)
            INTEnable(INT_SOURCE_UART_TX(UART1), INT_DISABLED);
#endif
            mSecTimer += i * 1024;                                  // update the TIMER function
            SecondsTimer += i * 1024;                               // and the clock (in Timer.c adjustment is made by subtracting 1000)
            SYSKEY = 0xAA996655; SYSKEY = 0x556699AA;               // unlock the oscillator control register
            OSCCONbits.NOSC = 0;                                    // select the FRC oscillator to reduce power consumption in the wake times
            OSCCONbits.OSWEN = 1; while(OSCCONbits.OSWEN);          // switch to it and wait for the switch to complete
            do {
                EnableWDT();                                        // the watchdog will wake us up in 1.024 seconds
                PowerSaveSleep();
                if(intpin && (PinRead(intpin) != pinstate)) i = 0;  // terminate early if the intpin has changed state
                RCONCLR = (1<<4 | 1<<3);                            // clear the watchdog and sleep flags in the results register
            } while(--i > 0);
#if defined(MX170)
            OSCCONbits.NOSC = 1;                                    // reselect the fast RC oscillator + PLL
#elif defined(MX470)
            OSCCONbits.NOSC = 3;                                    // reselect the crystal oscillator + PLL
#endif
            OSCCONbits.OSWEN = 1; while(OSCCONbits.OSWEN);          // switch to it and wait for the switch to complete
            SYSKEY = 0x33333333;                                    // relock the oscillator control register
            DisableWDT();
            INTEnable(INT_SOURCE_UART_RX(UART1), INT_ENABLED);
#if defined(MX470)
            INTEnable(INT_SOURCE_UART_TX(UART1), INT_ENABLED);
#endif
            mT4IntEnable(1);
            INTEnableInterrupts();
#else
            INTDisableInterrupts();
            mSecTimer += i * 1024;                                  // update the TIMER function
            SecondsTimer += i * 1024;                               // and the clock (in Timer.c adjustment is made by subtracting 1000)
            do {  
                EnableWDT();                                        // the watchdog will wake us up in 1.024 seconds          
                PowerSaveSleep();
                resetNmiEventClear(_RNMICON_WDTS_MASK);
                RCONCLR = (1<<4 | 1<<3);                            // clear the watchdog and sleep flags in the results register
            } while(--i > 0); 
            DisableWDT();
            INTEnableInterrupts();
#endif        
#if defined(MX470)            
            initUSBConsole();
#endif
        } else {
#ifndef ELLO_2M
#if defined(MX470)            
            CloseUSBConsole();
#endif
            // it is just CPU SLEEP
            // the program wants to put the CPU completely to sleep - interrupt 4 is used for the wakeup
            i1 = mINT1GetIntEnable(); i2 = mINT2GetIntEnable(); i3 = mINT3GetIntEnable();  // get the other interrupt flags
            mINT1IntEnable(0); mINT2IntEnable(0); mINT3IntEnable(0);                       // and disable them so that they do not accidently wake us up
            if(IrState == IR_CLOSED) {                                                     // if opened, the IR command will have done most of the work
                CheckPin(WAKEUP_PIN, CP_CHECKALL);
                ExtCfg(WAKEUP_PIN, EXT_DIG_IN, 0);
                uSec(100);                                                                 // allow the input time to settle
                ConfigINT4(EXT_INT_PRI_2 | (ExtInp(WAKEUP_PIN) ? FALLING_EDGE_INT : RISING_EDGE_INT) | EXT_INT_ENABLE);                 // enable our wakeup interrupt
            }
            PowerSaveSleep();                                           // the only thing that will wake us is an interrupt
            if(IrState == IR_CLOSED) {
                mINT4IntEnable(0);
                ExtCfg(WAKEUP_PIN, EXT_NOT_CONFIG, 0);
            } else {
                PauseTimer = 0;
                while(PauseTimer < 200 && !IrGotMsg);                   // wait for the IR msg to be received
            }
            mINT1IntEnable(i1); mINT2IntEnable(i2); mINT3IntEnable(i3); // restore the other interrupts
#if defined(MX470)
            initUSBConsole();
#endif            
#else
            error("Not supported in ELLO!");  
#endif
        }
    } else {
        // the program wants to change the clock speed
        NewClock = getinteger(cmdline) * 1000000;
#ifndef MZEF         
#if defined(MX170)

        switch(NewClock) {                                          // get the new value for the PLL multiplier and output divider
            case 60000000: Div = 0; Mult = 0; break;                // might work on a 50MHz chip
            case 48000000: Div = 1; Mult = 7; break;
            case 40000000: Div = 1; Mult = 5; break;
            case 30000000: Div = 1; Mult = 0; break;
            case 20000000: Div = 2; Mult = 5; break;
            case 10000000: Div = 3; Mult = 5; break;
            case 5000000:  Div = 4; Mult = 5; break;
            case 0:        error("Unknown command");
            default: error("CPU speed"); break;
        }
        if(Option.Baudrate > NewClock / 17u) error("Console baud rate too high");

#elif defined(MX470)
        
        switch(NewClock) {                                          // get the new value for the PLL multiplier and output divider
            case 120000000: Div = 0; Mult = 7; break;
            case 100000000: Div = 0; Mult = 5; break;
            case 80000000:  Div = 0; Mult = 1; break;
            case 60000000:  Div = 1; Mult = 7; break;
            case 48000000:  Div = 1; Mult = 4; break;               //actually 47500000
            case 40000000:  Div = 1; Mult = 1; break;
            case 30000000:  Div = 2; Mult = 7; break;
            case 20000000:  Div = 2; Mult = 1; break;
            case 10000000:  Div = 3; Mult = 1; break;
            case 5000000:   Div = 4; Mult = 1; break;
            case 0:        error("Unknown command");
            default: error("CPU speed"); break;
        }
        if(Option.SerialCon && Option.Baudrate > NewClock / 17u) error("Console baud rate too high");
#endif

        INTDisableInterrupts();
        if(NewClock > ClockSpeed) SYSTEMConfig(NewClock, SYS_CFG_ALL);  // set wait states, etc in anticipation of a faster speed

        // switch the PLL output divider to the new value
        SYSKEY = 0xAA996655; SYSKEY = 0x556699AA;                   // unlock the oscillator control register
#if defined(MX170)
        OSCCONbits.NOSC = 0;                                        // select the FRC oscillator as the temporary source while changing speed
#elif defined(MX470)
        OSCCONbits.NOSC = 2;                                        // select the crystal oscillator without PLL as the temporary source while changing speed
#endif
        OSCCONbits.OSWEN = 1; while(OSCCONbits.OSWEN);              // switch to the temporary source and wait for the switch to complete

        // Undocumented by Microchip but you must separately set the multiplier and divisor, if you do not you will have trouble on the MX470
        OSCCONbits.PLLMULT = Mult;                                  // set the new PLL multiplier
        OSCCONbits.OSWEN = 1; while(OSCCONbits.OSWEN);              // and wait for the switch to complete
        OSCCONbits.PLLODIV = Div;                                   // set the new output divider
        OSCCONbits.OSWEN = 1; while(OSCCONbits.OSWEN);              // and wait for the switch to complete

#if defined(MX170)
        OSCCONbits.NOSC = 1;                                        // select the main oscillator with PLL
#elif defined(MX470)
        OSCCONbits.NOSC = 3;                                        // select the crystal oscillator with PLL
#endif
        OSCCONbits.OSWEN = 1; while(OSCCONbits.OSWEN);              // and wait for the switch to complete
        SYSKEY = 0x33333333;                                        // relock the oscillator control register

        BusSpeed = SYSTEMConfig(NewClock, SYS_CFG_ALL);             // set wait states, etc

#if defined(MX170)
        PR4 = 100 * ((BusSpeed * 10)/2/1000000) - 1;                // Main timer ticks at 1 mSec
        TMR4 = (TMR4 * (NewClock >> 11)) / (ClockSpeed >> 11);      // and adjust its current count
        UARTSetDataRate(UART1,  BusSpeed, Option.Baudrate);         // reset the console baud rate
        if(com2_baud) PR5 = ((BusSpeed/com2_baud) / 3) - 1;         // ditto COM2
#elif defined(MX470)
        PR4 = 500 * (BusSpeed/2/1000000) - 1;                       // Main timer ticks at 500 uSec
        TMR4 = (TMR4 * (NewClock >> 11)) / (ClockSpeed >> 11);      // and adjust its current count
        if(Option.SerialCon) UARTSetDataRate(UART1,  BusSpeed, Option.Baudrate);         // reset the console baud rate
        if(com2_baud) UARTSetDataRate(UART3, BusSpeed, com2_baud);  // reset COM2 baud rate
        if(com3_baud) UARTSetDataRate(UART4, BusSpeed, com3_baud);  // reset COM3 baud rate
        if(com4_baud) UARTSetDataRate(UART1, BusSpeed, com4_baud);  // reset COM4 baud rate
#endif
        if(com1_baud) UARTSetDataRate(UART2, BusSpeed, com1_baud);  // reset COM1 baud rate
        ClockSpeed = NewClock;
        INTEnableInterrupts();
#else
        
        if( (NewClock != 60000000) && (NewClock != 99000000) && (NewClock != 120000000) && (NewClock != 156000000) && (NewClock != 198000000) && 
            (NewClock != 204000000) && (NewClock != 228000000) && (NewClock != 252000000) && (NewClock != 258000000)                                                           )
        {
           error("Invalid CPU speed"); 
        }
        
        CloseUSBConsole();
        INTDisableInterrupts();
        MiscSetSpeed(NewClock);
        ClockSpeed = NewClock;
        INTEnableInterrupts();
        initUSBConsole();
#endif        
    }
}



void cmd_cfunction(void) {
    char *p, EndToken;
    if(cmdtoken == cmdCFUN)
        EndToken = GetCommandValue("End CFunction");                // this terminates a CFUNCTION
    else
        if(cmdtoken == cmdCSUB)
            EndToken = GetCommandValue("End CSub");                 // this terminates a CSUB
        else
            EndToken = GetCommandValue("End DefineFont");           // this terminates a DefineFont
    p = cmdline;
    while(*p != 0xff) {
        if(*p == 0) p++;                                            // if it is at the end of an element skip the zero marker
        if(*p == 0) error("Missing END declaration");               // end of the program
        if(*p == T_LINENBR) {
            p += 3;                                                 // skip over the line number
        }
        skipspace(p);
        if(*p == T_LABEL) {
            p += p[1] + 2;                                          // skip over the label
            skipspace(p);                                           // and any following spaces
        }
        if(*p == EndToken) {                                        // found an END token
            nextstmt = p;
            skipelement(nextstmt);
            return;
        }
        p++;
    }
}



/***********************************************************************************************
interrupt check
************************************************************************************************/

// check if an interrupt has occured and if so, set the next command to the interrupt routine
// will return true if interrupt detected or false if not
int check_interrupt(void) {
	int i, v;
	char *intaddr;
	static char rti[2];
    
	CheckAbort();

#if defined(MX470)
    ProcessTouch();
    if(CheckGuiFlag) CheckGui();                                    // This implements a LED flash
#endif

    if(CFuncInt) CallCFuncInt();                                    // check if the CFunction wants to do anything (see CFunction.c)
    if(!InterruptUsed) return 0;                                    // quick exit if there are no interrupts set
	if(InterruptReturn != NULL || CurrentLinePtr == NULL) return 0;	// skip if we are in an interrupt or in immediate mode

    // check for an  ON KEY loc  interrupt
    if(OnKeyGOSUB && kbhitConsole()) {
        intaddr = OnKeyGOSUB;							            // set the next stmt to the interrupt location
		goto GotAnInterrupt;
    }

//	if ((I2C_Status & I2C_Status_Interrupt) && (I2C_Status & I2C_Status_Completed)) {
//		I2C_Status &= ~I2C_Status_Completed;						// clear completed flag
//		intaddr = I2C_IntLine;										// set the next stmt to the interrupt location
//		goto GotAnInterrupt;
//	}

#ifdef INCLUDE_I2C_SLAVE

	if ((I2C_Status & I2C_Status_Slave_Receive_Rdy)) {
		I2C_Status &= ~I2C_Status_Slave_Receive_Rdy;	            // clear completed flag
		intaddr = I2C_Slave_Receive_IntLine;						// set the next stmt to the interrupt location
		goto GotAnInterrupt;
	}
	if ((I2C_Status & I2C_Status_Slave_Send_Rdy)) {
		I2C_Status &= ~I2C_Status_Slave_Send_Rdy;					// clear completed flag
		intaddr = I2C_Slave_Send_IntLine;							// set the next stmt to the interrupt location
		goto GotAnInterrupt;
	}
#endif

	// interrupt routines for the serial ports
	if(com1_interrupt != NULL && SerialRxStatus(1) >= com1_ilevel) {// do we need to interrupt?
		intaddr = com1_interrupt;									// set the next stmt to the interrupt location
		goto GotAnInterrupt;
	}
	if(com2_interrupt != NULL && SerialRxStatus(2) >= com2_ilevel) {// do we need to interrupt?
		intaddr = com2_interrupt;									// set the next stmt to the interrupt location
		goto GotAnInterrupt;
	}
#if defined(MX470)

	if(com3_interrupt != NULL && SerialRxStatus(3) >= com3_ilevel) {// do we need to interrupt?
		intaddr = com3_interrupt;									// set the next stmt to the interrupt location
		goto GotAnInterrupt;
	}

	if(com4_interrupt != NULL && SerialRxStatus(4) >= com4_ilevel) {// do we need to interrupt?
		intaddr = com4_interrupt;									// set the next stmt to the interrupt location
		goto GotAnInterrupt;
	}

    if(gui_int_down && GuiIntDownVector) {                          // interrupt on pen down
    	intaddr = GuiIntDownVector;                                 // get a pointer to the interrupt routine
        gui_int_down = false;
		goto GotAnInterrupt;
	}

    if(gui_int_up && GuiIntUpVector) {
    	intaddr = GuiIntUpVector;                                   // get a pointer to the interrupt routine
        gui_int_up = false;
		goto GotAnInterrupt;
	}

    if(WAVInterrupt != NULL && WAVcomplete) {
        WAVcomplete=false;
		intaddr = WAVInterrupt;									    // set the next stmt to the interrupt location
		goto GotAnInterrupt;
	}

#endif

    if(IrGotMsg && IrInterrupt != NULL) {
        IrGotMsg = false;
		intaddr = IrInterrupt;									    // set the next stmt to the interrupt location
		goto GotAnInterrupt;
	}

#if !defined(LITE)
    if(KeypadInterrupt != NULL && KeypadCheck()) {
		intaddr = KeypadInterrupt;									// set the next stmt to the interrupt location
		goto GotAnInterrupt;
	}
#endif
    
	for(i = 0; i < NBRINTERRUPTS; i++) {                            // scan through the interrupt table
		if(inttbl[i].pin != 0) {                                    // if this entry has an interrupt pin set
			v = ExtInp(inttbl[i].pin);								// get the current value of the pin
			// check if interrupt occured
			if((inttbl[i].lohi == T_HILO && v < inttbl[i].last) || (inttbl[i].lohi == T_LOHI && v > inttbl[i].last) || (inttbl[i].lohi == T_BOTH && v != inttbl[i].last)) {
				intaddr = inttbl[i].intp;							// set the next stmt to the interrupt location
				inttbl[i].last = v;									// save the new pin value
				goto GotAnInterrupt;
			} else
				inttbl[i].last = v;									// no interrupt, just update the pin value
		}
	}

	// check if one of the tick interrupts is enabled and if it has occured
	for(i = 0; i < NBRSETTICKS; i++) {
    	if(TickInt[i] != NULL && TickTimer[i] > TickPeriod[i]) {
    		// reset for the next tick but skip any ticks completely missed
    		while(TickTimer[i] > TickPeriod[i]) TickTimer[i] -= TickPeriod[i];
    		intaddr = TickInt[i];
    		goto GotAnInterrupt;
    	}
    }

    // if no interrupt was found then return having done nothing
	return 0;

    // an interrupt was found if we jumped to here
GotAnInterrupt:
    LocalIndex++;                                                   // IRETURN will decrement this
    InterruptReturn = nextstmt;                                     // for when IRETURN is executed
    // if the interrupt is pointing to a SUB token we need to call a subroutine
    if(*intaddr == cmdSUB) {
        rti[0] = cmdIRET;                                           // setup a dummy IRETURN command
        rti[1] = 0;
        if(gosubindex >= MAXGOSUB) error("Too many SUBs for interrupt");
        errorstack[gosubindex] = CurrentLinePtr;
    	gosubstack[gosubindex++] = rti;                             // return from the subroutine to the dummy IRETURN command
        LocalIndex++;                                               // return from the subroutine will decrement LocalIndex
        skipelement(intaddr);                                       // point to the body of the subroutine
    }

    nextstmt = intaddr;                                             // the next command will be in the interrupt routine
    return 1;
}



// get the address for a MMBasic interrupt
// this will handle a line number, a label or a subroutine
// all areas of MMBasic that can generate an interrupt use this function
char *GetIntAddress(char *p) {
    int i;
	if(isnamestart(*p)) {                                           // if it starts with a valid name char
    	i = FindSubFun(p, 0);                                       // try to find a matching subroutine
    	if(i == -1)
		    return findlabel(p);					                // if a subroutine was NOT found it must be a label
		else
		    return subfun[i];                                       // if a subroutine was found, return the address of the sub
	}

	return findline(getinteger(p), true);	                        // otherwise try for a line number
}
