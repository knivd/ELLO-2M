/***********************************************************************************************************************
MMBasic

Console.h

Header file defining the public functions and variables in Console.c

Copyright 2011 - 2017 Geoff Graham.  All Rights Reserved.

This file and modified versions of this file are supplied to specific individuals or organisations under the following
provisions:

- This file, or any files that comprise the MMBasic source (modified or not), may not be distributed or copied to any other
  person or organisation without written permission.

- Object files (.o and .hex files) generated using this file (modified or not) may not be distributed or copied to any other
  person or organisation without written permission.

- This file is provided in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

************************************************************************************************************************/

#define CONSOLE_BUF_SIZE 128
extern char ConsoleBuf[CONSOLE_BUF_SIZE];
extern int ConsoleBufHead;
extern int ConsoleBufTail;

extern char* GetPrompt(void);

// declare the console I/O functions
extern void __attribute__((mips16)) initConsole(void);
extern int MMgetchar(void);
extern int kbhitConsole(void);
extern void putConsole(int c);
extern int getConsole(void);

extern inline void CheckAbort(void);

#define initSerialConsole() initConsole()

