/***********************************************************************************************************************
MMBasic

IOPorts.h

Include file that defines the IOPins for the PIC32 chip in MMBasic.
  
Copyright 2011 - 2017 Geoff Graham.  All Rights Reserved.

This file and modified versions of this file are supplied to specific individuals or organisations under the following 
provisions:

- This file, or any files that comprise the MMBasic source (modified or not), may not be distributed or copied to any other
  person or organisation without written permission.

- Object files (.o and .hex files) generated using this file (modified or not) may not be distributed or copied to any other
  person or organisation without written permission.

- This file is provided in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of 
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

************************************************************************************************************************/

#include "../General/Flash.h"

#if !defined(__32MX170F256B__) && !defined(__32MX270F256B__) && !defined(__32MX170F256D__) && !defined(__32MX270F256D__)
       #error Processor not supported
#endif


#define _DEVID_ (*(volatile unsigned int *)0xBF80F220)
#define PIC32MX170F256B_DEVID  0x06610053
#define PIC32MX270F256B_DEVID  0x06600053
#define PIC32MX170F256D_DEVID  0x0661A053
#define PIC32MX270F256D_DEVID  0x0660A053
#define HAS_USB                ((_DEVID_ & 0xfffffff) == PIC32MX270F256B_DEVID || (_DEVID_ & 0xfffffff) == PIC32MX270F256D_DEVID)
#define HAS_28PINS             ((_DEVID_ & 0xfffffff) == PIC32MX170F256B_DEVID || (_DEVID_ & 0xfffffff) == PIC32MX270F256B_DEVID)
#define HAS_44PINS             (!HAS_28PINS)

// these are the valid peek/poke memory ranges for the MX170/MX270
#define PEEKRANGE(a) ((a >= 0xA0000000 && a <= 0xA000FFFF) || (a >= 0x9D000000 && a <= 0x9D03FFFF) || (a >= 0x9FC00000 && a <= 0x9FC00BFF) || (a >= 0xBF800000 && a <= 0xBF8FFFFF))
#define POKERANGE(a) ((a >= 0xA0000000 && a <= 0xA000FFFF) || (a >= 0xBF800000 && a <= 0xBF8FFFFF))

// General defines
#define P_INPUT				1						// for setting the TRIS on I/O bits
#define P_OUTPUT			0
#define P_ON				1
#define P_OFF				0

// Constant definitions of the port registers in the 48-pin chips
#define ADDR_PORTA          (volatile unsigned int *)0xbf886020
#define ADDR_PORTB          (volatile unsigned int *)0xbf886120
#define ADDR_PORTC          (volatile unsigned int *)0xbf886220

// Structure that defines the SFR, bit number and mode for each I/O pin
struct s_PinDef {
    volatile unsigned int *sfr;     // this is the port register (defined above), eg ADDR_PORTB for port B
    unsigned char bitnbr;           // this is the bit number of the port, eg the 7 in B7
    unsigned char mode;             // the various modes that an I/O pin can be set to (defined below)
    unsigned char anChan;           // if the input supports analog this is the analog channel number
};
    
// Defines for the various modes that an I/O pin can be set to
#define UNUSED       (1 << 0)
#define ANALOG_IN    (1 << 1)
#define DIGITAL_IN   (1 << 2)
#define COUNTING     (1 << 3)
#define DIGITAL_OUT  (1 << 4)
#define DO_NOT_RESET (1 << 5)

#define NBR_PINS_28CHIP     26					    // number of pins for external i/o on a 28 pin chip
#define NBR_PINS_44CHIP     44					    // number of pins for external i/o on a 44 pin chip
#define NBRPINS             (HAS_28PINS ? NBR_PINS_28CHIP : NBR_PINS_44CHIP)	// number of pins for external i/o
#define MAXNBRPINS          44
    

// Define the structure for the I/O pins
// the first element of the structure contains a pointer to the SFR for the port to be used
// the second element is the bit number within that port to use
// the third is a set of flags that defines what that I/O pin can do
#if defined(DEFINE_PINDEF_TABLE)
#ifdef __DEBUG
const struct s_PinDef PinDef28[NBR_PINS_28CHIP + 1] = {                                               // debug cannot work with the table in boot flash
#else
const struct s_PinDef __attribute__((address(0x9FC00500))) PinDef28[NBR_PINS_28CHIP + 1] = {  // place the table in boot flash
#endif
    { NULL,  0, UNUSED | DO_NOT_RESET },                                        // pin 0
    { NULL,  0, UNUSED | DO_NOT_RESET },                                        // pin 1
    { ADDR_PORTA,  0, ANALOG_IN | DIGITAL_IN | DIGITAL_OUT, 0 },                // pin 2
    { ADDR_PORTA,  1, ANALOG_IN | DIGITAL_IN | DIGITAL_OUT, 1 },                // pin 3
#if defined(DEBUGMODE)
    { NULL,  0, UNUSED | DO_NOT_RESET },                                        // pin 4  ICSP PGD
    { NULL,  0, UNUSED | DO_NOT_RESET },                                        // pin 5  ICSP PGC
#else
    { ADDR_PORTB,  0, ANALOG_IN | DIGITAL_IN | DIGITAL_OUT, 2 },                // pin 4
    { ADDR_PORTB,  1, ANALOG_IN | DIGITAL_IN | DIGITAL_OUT, 3 },                // pin 5
#endif
    { ADDR_PORTB,  2, ANALOG_IN | DIGITAL_IN | DIGITAL_OUT, 4 },                // pin 6
    { ADDR_PORTB,  3, ANALOG_IN | DIGITAL_IN | DIGITAL_OUT, 5 },                // pin 7
    { NULL,  0, UNUSED | DO_NOT_RESET },                                        // pin 8
    { ADDR_PORTA,  2, DIGITAL_IN | DIGITAL_OUT },                               // pin 9
    { ADDR_PORTA,  3, DIGITAL_IN | DIGITAL_OUT },                               // pin 10
    { NULL,  0, UNUSED | DO_NOT_RESET },                                        // pin 11
    { NULL,  0, UNUSED | DO_NOT_RESET },                                        // pin 12
    { NULL,  0, UNUSED | DO_NOT_RESET },                                        // pin 13
    { ADDR_PORTB,  5, DIGITAL_IN | DIGITAL_OUT },                               // pin 14
//
    { ADDR_PORTB,  6, DIGITAL_IN | DIGITAL_OUT },                               // pin 15
    { ADDR_PORTB,  7, DIGITAL_IN | DIGITAL_OUT },                               // pin 16
    { ADDR_PORTB,  8, DIGITAL_IN | DIGITAL_OUT },                               // pin 17
    { ADDR_PORTB,  9, DIGITAL_IN | DIGITAL_OUT },                               // pin 18
    { NULL,  0, UNUSED | DO_NOT_RESET },                                        // pin 19
    { NULL,  0, UNUSED | DO_NOT_RESET },                                        // pin 20
    { ADDR_PORTB,  10, DIGITAL_IN | DIGITAL_OUT },                              // pin 21
    { ADDR_PORTB,  11, DIGITAL_IN | DIGITAL_OUT },                              // pin 22
    { ADDR_PORTB,  12, ANALOG_IN | DIGITAL_IN | DIGITAL_OUT, 12 },              // pin 23
    { ADDR_PORTB,  13, ANALOG_IN | DIGITAL_IN | DIGITAL_OUT, 11 },              // pin 24
    { ADDR_PORTB,  14, ANALOG_IN | DIGITAL_IN | DIGITAL_OUT, 10 },              // pin 25
    { ADDR_PORTB,  15, ANALOG_IN | DIGITAL_IN | DIGITAL_OUT, 9 },               // pin 26
};

#ifdef __DEBUG
const struct s_PinDef PinDef44[NBR_PINS_44CHIP + 1] = {                                                                // debug cannot work with the table in boot flash
#else
const struct s_PinDef __attribute__((address(0x9FC00500 + sizeof(PinDef28)))) PinDef44[NBR_PINS_44CHIP + 1] = {  // place the table in boot flash
#endif
    { NULL,  0, UNUSED },                                                       // pin 0
    { ADDR_PORTB,  9, DIGITAL_IN | DIGITAL_OUT },                               // pin 1
    { ADDR_PORTC,  6, DIGITAL_IN | DIGITAL_OUT },                               // pin 2
    { ADDR_PORTC,  7, DIGITAL_IN | DIGITAL_OUT },                               // pin 3
    { ADDR_PORTC,  8, DIGITAL_IN | DIGITAL_OUT },                               // pin 4
    { ADDR_PORTC,  9, DIGITAL_IN | DIGITAL_OUT },                               // pin 5
    { NULL,  0, UNUSED },                                                       // pin 6
    { NULL,  0, UNUSED },                                                       // pin 7
    { ADDR_PORTB,  10, DIGITAL_IN | DIGITAL_OUT },                              // pin 8
    { ADDR_PORTB,  11, DIGITAL_IN | DIGITAL_OUT },                              // pin 9
    { ADDR_PORTB,  12, ANALOG_IN | DIGITAL_IN | DIGITAL_OUT, 12 },              // pin 10
    { ADDR_PORTB,  13, ANALOG_IN | DIGITAL_IN | DIGITAL_OUT, 11 },              // pin 11
//
    { ADDR_PORTA,  10, DIGITAL_IN | DIGITAL_OUT },                              // pin 12
    { ADDR_PORTA,  7, DIGITAL_IN | DIGITAL_OUT },                               // pin 13
    { ADDR_PORTB,  14, ANALOG_IN | DIGITAL_IN | DIGITAL_OUT, 10 },              // pin 14
    { ADDR_PORTB,  15, ANALOG_IN | DIGITAL_IN | DIGITAL_OUT, 9 },               // pin 15
    { NULL,  0, UNUSED },                                                       // pin 16
    { NULL,  0, UNUSED },                                                       // pin 17
    { NULL,  0, UNUSED },                                                       // pin 18
    { ADDR_PORTA,  0, ANALOG_IN | DIGITAL_IN | DIGITAL_OUT, 0 },                // pin 19
    { ADDR_PORTA,  1, ANALOG_IN | DIGITAL_IN | DIGITAL_OUT, 1 },                // pin 20
#if defined(DEBUGMODE)
    { NULL,  0, UNUSED | DO_NOT_RESET },                                        // pin 21  ICSP PGD
    { NULL,  0, UNUSED | DO_NOT_RESET },                                        // pin 22  ICSP PGC
#else
    { ADDR_PORTB,  0, ANALOG_IN | DIGITAL_IN | DIGITAL_OUT, 2 },                // pin 21
    { ADDR_PORTB,  1, ANALOG_IN | DIGITAL_IN | DIGITAL_OUT, 3 },                // pin 22
#endif
    { ADDR_PORTB,  2, ANALOG_IN | DIGITAL_IN | DIGITAL_OUT, 4 },                // pin 23
    { ADDR_PORTB,  3, ANALOG_IN | DIGITAL_IN | DIGITAL_OUT, 5 },                // pin 24
    { ADDR_PORTC,  0, ANALOG_IN | DIGITAL_IN | DIGITAL_OUT, 6 },                // pin 25
    { ADDR_PORTC,  1, ANALOG_IN | DIGITAL_IN | DIGITAL_OUT, 7 },                // pin 26
    { ADDR_PORTC,  2, ANALOG_IN | DIGITAL_IN | DIGITAL_OUT, 8 },                // pin 27
    { NULL,  0, UNUSED },                                                       // pin 28
    { NULL,  0, UNUSED },                                                       // pin 29
    { ADDR_PORTA,  2, DIGITAL_IN | DIGITAL_OUT },                               // pin 30
    { ADDR_PORTA,  3, DIGITAL_IN | DIGITAL_OUT },                               // pin 31
    { ADDR_PORTA,  8, DIGITAL_IN | DIGITAL_OUT },                               // pin 32
    { NULL,  0, UNUSED },                                                       // pin 33
//
    { NULL,  0, UNUSED },                                                       // pin 34
    { ADDR_PORTA,  9, DIGITAL_IN | DIGITAL_OUT },                               // pin 35
    { ADDR_PORTC,  3, DIGITAL_IN | DIGITAL_OUT },                               // pin 36
    { ADDR_PORTC,  4, DIGITAL_IN | DIGITAL_OUT },                               // pin 37
    { ADDR_PORTC,  5, DIGITAL_IN | DIGITAL_OUT },                               // pin 38
    { NULL,  0, UNUSED },                                                       // pin 39
    { NULL,  0, UNUSED },                                                       // pin 40
    { ADDR_PORTB,  5, DIGITAL_IN | DIGITAL_OUT },                               // pin 41
    { ADDR_PORTB,  6, DIGITAL_IN | DIGITAL_OUT },                               // pin 42
    { ADDR_PORTB,  7, DIGITAL_IN | DIGITAL_OUT },                               // pin 43
    { ADDR_PORTB,  8, DIGITAL_IN | DIGITAL_OUT },                               // pin 44
};

#else
    const extern struct s_PinDef PinDef28[];
    const extern struct s_PinDef PinDef44[];
#endif      // DEFINE_PINDEF_TABLE

extern struct s_PinDef *PinDef;


// Define the counting pin numbers.  INT1PIN refers to the PIC32 external interrupt #1, an so on for the others
#define INT1PIN             (HAS_44PINS ?  1 : 18)
#define INT1PIN_OPEN        PPSInput(4, INT1, RPB9)
#define INT1PIN_CLOSE       PPSInput(4, INT1, NULL)

#define INT2PIN             (HAS_44PINS ? 42 : 15)
#define INT2PIN_OPEN        PPSInput(3, INT2, RPB6)
#define INT2PIN_CLOSE       PPSInput(3, INT2, NULL)

#define INT3PIN             (HAS_44PINS ? 44 : 17)
#define INT3PIN_OPEN        PPSInput(2, INT3, RPB8)
#define INT3PIN_CLOSE       PPSInput(2, INT3, NULL)

#define INT4PIN             (HAS_44PINS ? 43 : 16)
#define INT4PIN_OPEN        PPSInput(1, INT4, RPB7)
#define INT4PIN_CLOSE       PPSInput(1, INT4, NULL)


// I2C pin numbers
#define P_I2C_SDA           (HAS_44PINS ?  1 : 18)
#define P_I2C_SCL           (HAS_44PINS ? 44 : 17)

// COM1: port pin numbers
#define COM1_RX_PIN         (HAS_44PINS ?  9 : 22)
#define COM1_TX_PIN         (HAS_44PINS ?  8 : 21)
#define COM1_EN_PIN         (HAS_44PINS ? 24 :  7)
#define COM1_RX_PPS_OPEN    PPSInput(2, U2RX, RPB11)
#define COM1_TX_PPS_OPEN    PPSOutput(4, RPB10, U2TX);
#define COM1_TX_PPS_CLOSE   PPSOutput(4, RPB10, NULL)
#define COM1_DE_PPS_OPEN    PPSOutput(1, RPB3, U2RTS)
#define COM1_DE_PPS_CLOSE   PPSOutput(1, RPB3, NULL)

// COM2: port pin numbers
#define COM2_RX_PIN         (HAS_44PINS ? 31 : 10)
#define COM2_TX_PIN         (HAS_44PINS ? 30 :  9)
    
// SPI pin numbers
#define SPI_INP_PIN         (HAS_44PINS ? 41 : 14)
#define SPI_OUT_PIN         (HAS_44PINS ? 20 :  3)
#define SPI_CLK_PIN         (HAS_44PINS ? 14 : 25)
#define SPI_PPS_OPEN        PPSInput(2, SDI1, RPB5); PPSOutput(2, RPA1, SDO1)
#define SPI_PPS_CLOSE       PPSOutput(2, RPA1, NULL)

// touch controller interface
#define TOUCH_SPI_CHANNEL       SPI_CHANNEL1

// SPI LCD controller interface
#define SPI_LCD_SPI_CHANNEL     SPI_CHANNEL1

// PWM CH1
#define PWM_CH1_PIN         (HAS_44PINS ? 21 :  4)
#define PWM_CH1_OPEN        PPSOutput(4, RPB0, OC3)
#define PWM_CH1_CLOSE       PPSOutput(4, RPB0, NULL)

// PWM CH2
#define PWM_CH2_PIN         (HAS_44PINS ? 22 :  5)
#define PWM_CH2_OPEN        PPSOutput(2, RPB1, OC2)
#define PWM_CH2_CLOSE       PPSOutput(2, RPB1, NULL)

// PWM CH3
#define PWM_CH3_PIN         (HAS_44PINS ? 23 :  6)
#define PWM_CH3_OPEN        PPSOutput(3, RPB2, OC5)
#define PWM_CH3_CLOSE       PPSOutput(3, RPB2, NULL)

// PWM CH4
#define PWM_CH4_PIN         (HAS_44PINS ? 15 : 26)
#define PWM_CH4_OPEN        PPSOutput(1, RPB15, OC1)
#define PWM_CH4_CLOSE       PPSOutput(1, RPB15, NULL)

// PWM CH5
#define PWM_CH5_PIN         (HAS_44PINS ? 11 : 24)
#define PWM_CH5_OPEN        PPSOutput(3, RPB13, OC4)
#define PWM_CH5_CLOSE       PPSOutput(3, RPB13, NULL)


// pin used for wakeup from sleep and receiving IR messages
#define WAKEUP_PIN          (HAS_44PINS ? 43 : 16)

// pins used by USB
#define USB_1_PIN           (HAS_44PINS ? 10 : 15)
#define USB_2_PIN           (HAS_44PINS ? 42 : 23)

