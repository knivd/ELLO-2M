/***********************************************************************************************************************
MMBasic

Console.c

Implements the routines to handle all console communications.

Copyright 2011 - 2017 Geoff Graham.  All Rights Reserved.

This file and modified versions of this file are supplied to specific individuals or organisations under the following
provisions:

- This file, or any files that comprise the MMBasic source (modified or not), may not be distributed or copied to any other
  person or organisation without written permission.

- Object files (.o and .hex files) generated using this file (modified or not) may not be distributed or copied to any other
  person or organisation without written permission.

- This file is provided in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

************************************************************************************************************************/

#define _SUPPRESS_PLIB_WARNING                      // required for XC1.33  Later compiler versions will need PLIB to be installed
#include <plib.h>									// the pre Harmony peripheral libraries

#include "../MMBasic_Includes.h"
#include "../Hardware_Includes.h"


//** USB INCLUDES ***********************************************************
//#include "../MX470/USB/Microchip/Include/USB/usb.h"
//#include "../MX470/USB/Microchip/Include/USB/usb_function_cdc.h"
//#include "../MX470/USB/HardwareProfile.h"
//
//#include "../MX470/USB/Microchip/Include/GenericTypeDefs.h"
//#include "../MX470/USB/Microchip/Include/Compiler.h"
//#include "../MX470/USB/usb_config.h"
//#include "../MX470/USB/Microchip/Include/USB/usb_device.h"

char ConsoleBuf[CONSOLE_BUF_SIZE];
int ConsoleBufHead = 0;
int ConsoleBufTail = 0;

//
//
char* GetPrompt(void) {
char* ret = "> ";  
    return ret;
}


// initialize the UART1 serial port
void __attribute__((mips16)) initConsole(void) {
    int ConsoleInvert;
    CNPUASET = (1 << 4);                                            // set a pullup on Rx so that the input does not float

    // check if we are to invert the console (for RS232)
    if(Option.Invert == 2) {
        uSec(200000);
        ConsoleInvert = !PORTAbits.RA4;
    } else
        ConsoleInvert = Option.Invert;

    PPSInput(3, U1RX, RPA4); PPSOutput(1, RPB4, U1TX);

    UARTConfigure(UART1, UART_ENABLE_PINS_TX_RX_ONLY);
    UARTSetFifoMode(UART1, UART_INTERRUPT_ON_TX_NOT_FULL | UART_INTERRUPT_ON_RX_NOT_EMPTY);
    UARTSetLineControl(UART1, UART_DATA_SIZE_8_BITS | UART_PARITY_NONE | UART_STOP_BITS_1);
    UARTSetDataRate(UART1, BusSpeed, 38400);
    UARTEnable(UART1, UART_ENABLE_FLAGS(UART_PERIPHERAL | UART_RX | UART_TX));

    // Configure UART1 RX Interrupt
    INTEnable(INT_SOURCE_UART_RX(UART1), INT_ENABLED);
    INTSetVectorPriority(INT_VECTOR_UART(UART1), INT_PRIORITY_LEVEL_3);
    INTSetVectorSubPriority(INT_VECTOR_UART(UART1), INT_SUB_PRIORITY_LEVEL_0);

    INTEnableInterrupts();

    // this implements the emergency reset routine
    uSec(100000);                                                   // wait for 100mS
    if(getConsole() == '!') {                                       // did we get a !
        uSec(150000);                                               // if so, wait a further 150mS and check that we receive at least four more
        if(getConsole() == '!' && getConsole() == '!' && getConsole() == '!' && getConsole() == '!') {
            int i;
            uSec(2000000);                                          // now wait for 2 sec
            for(i = 0; i < 25; i++)
                if(getConsole() != '!')                             // and check that we get at least 25 consecutive !'s
                    goto exit_test;
            ResetAllFlash();                                        // must be a reset request
            MMPrintString("\r\nMMBasic reset completed\r\n");
            // wait for the user to stop sending characters
            do {
                while(getConsole() != -1);
                uSec(100000);
            } while(getConsole() != -1);
        }
    }
    exit_test:

    // check if we are to invert the console (for RS232)
    if(Option.Invert == 2) {
        uSec(200000);
        ConsoleInvert = !PORTAbits.RA4;
    } else
        ConsoleInvert = Option.Invert;

    if(ConsoleInvert) {
            CNPUACLR = (1 << 4);                                    // clear the pullup on Rx
            CNPDASET = (1 << 4);                                    // set a pulldown on Rx so that the input does not float
    }

    UARTConfigure(UART1, UART_ENABLE_PINS_TX_RX_ONLY | ((ConsoleInvert) ? (UART_INVERT_RECEIVE_POLARITY | UART_INVERT_TRANSMIT_POLARITY): 0));
    UARTSetDataRate(UART1, BusSpeed, Option.Baudrate);
}


// UART 1 interrupt handler
void __ISR(_UART1_VECTOR, IPL3AUTO) IntUart1Handler(void) {

    while(UARTReceivedDataIsAvailable(UART1)) {                     // while there is data to read
        if(UARTGetLineStatus(UART1) & 0b1110) {                     // first check for errors
            UARTGetDataByte(UART1);                                 // and if there was an error throw away the char
            U1STACLR = 0b1110;                                      // clear the error on the UART
            continue;                                               // and try the next char
        }
        ConsoleBuf[ConsoleBufHead]  = UARTGetDataByte(UART1);       // store the byte in the ring buffer
        if(BreakKey && ConsoleBuf[ConsoleBufHead] == BreakKey) {    // if the user wants to stop the progran
            MMAbort = true;                                         // set the flag for the interpreter to see
            ConsoleBufHead = ConsoleBufTail;                        // empty the buffer
            break;
        }
        ConsoleBufHead = (ConsoleBufHead + 1) % CONSOLE_BUF_SIZE;   // advance the head of the queue
        if(ConsoleBufHead == ConsoleBufTail) {                      // if the buffer has overflowed
            ConsoleBufTail = (ConsoleBufTail + 1) % CONSOLE_BUF_SIZE; // throw away the oldest char
        }
    }
    INTClearFlag(INT_SOURCE_UART_RX(UART1));                        // Clear the RX interrupt Flag
}





// get a keystroke from the console.  Will wait forever for input
// if the char is a cr then replace it with a newline (lf)
int MMgetchar(void) {
    int c;
    static char prevchar = 0;

    loopback:
    do {
//        pp1(17);
        c = MMInkey();
    } while(c == -1);
    if(c == '\n' && prevchar == '\r') {
        prevchar = 0;
        goto loopback;
    }
    prevchar = c;
    if(c == '\n') c = '\r';
    return c;
}



// send a character to the Console serial port
void putConsole(int c) {
    while(!UARTTransmitterIsReady(UART1));                          // Wait till the UART transmitter is free.
    INTDisableInterrupts();                                         // see Errata #10
    UARTSendDataByte(UART1, c);                                     // Write data into Tx.
    INTEnableInterrupts();
}


// returns the number of character waiting in the console input queue
int kbhitConsole(void) {
    int i;
    INTEnable(INT_SOURCE_UART_RX(UART1), INT_DISABLED);
    i = ConsoleBufHead - ConsoleBufTail;
    INTEnable(INT_SOURCE_UART_RX(UART1), INT_ENABLED);
    if(i < 0) i += CONSOLE_BUF_SIZE;
    return i;
}



// get a char from the UART1 serial port (the console)
// will return immediately with -1 if there is no character waiting
int getConsole(void) {
    char c;
    CheckAbort();
    if(ConsoleBufHead == ConsoleBufTail) return -1;
    c = ConsoleBuf[ConsoleBufTail];
    ConsoleBufTail = (ConsoleBufTail + 1) % CONSOLE_BUF_SIZE;       // advance the head of the queue
    return c;
}



inline void CheckAbort(void) {
    if(MMAbort) {
        WDTimer = 0;                                                // turn off the watchdog timer
        longjmp(mark, 1);                                           // jump back to the input prompt
    }
}




