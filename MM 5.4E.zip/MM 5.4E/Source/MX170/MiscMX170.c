/***********************************************************************************************************************
MMBasic

MiscMX470.c

Handles the a few miscellaneous functions for the MX170 version.

Copyright 2011 - 2017 Geoff Graham.  All Rights Reserved.

This file and modified versions of this file are supplied to specific individuals or organisations under the following
provisions:

- This file, or any files that comprise the MMBasic source (modified or not), may not be distributed or copied to any other
  person or organisation without written permission.

- Object files (.o and .hex files) generated using this file (modified or not) may not be distributed or copied to any other
  person or organisation without written permission.

- This file is provided in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

************************************************************************************************************************/

#define _SUPPRESS_PLIB_WARNING                      // required for XC1.33  Later compiler versions will need PLIB to be installed
#include <plib.h>                                   // the pre Harmony peripheral libraries

#include "../MMBasic_Includes.h"
#include "../Hardware_Includes.h"



// function (which looks like a pre defined variable) to return the type of platform
void fun_device(void){
	sret = GetTempStrMemory();									// this will last for the life of the command
    strcpy(sret, "Micromite MkII");
    CtoM(sret);
    targ = T_STR;
}

///////////////////////////////////////////////////////////////////////////////////////////////
// constants and functions used in the OPTION LIST command
char *LCDList[] = {"ILI9341", "ILI9163", "ST7735"};
char *OrientList[] = {"LANDSCAPE", "PORTRAIT", "RLANDSCAPE", "RPORTRAIT"};
char *CaseList[] = {"", "LOWER", "UPPER"};

void PO(char *s) {
    MMPrintString("OPTION "); MMPrintString(s); MMPrintString(" ");
}

void PInt(int n) {
    char s[20];
    IntToStr(s, n, 10);
    MMPrintString(s);
}

void PIntComma(int n) {
    MMPrintString(", "); PInt(n);
}

void PO2Str(char *s1, char *s2) {
    PO(s1); MMPrintString(s2); MMPrintString("\r\n");
}


void PO2Int(char *s1, int n) {
    PO(s1); PInt(n); MMPrintString("\r\n");
}

void PO3Int(char *s1, int n1, int n2) {
    PO(s1); PInt(n1); PIntComma(n2); MMPrintString("\r\n");
}
///////////////////////////////////////////////////////////////////////////////////////////////


void __attribute__((mips16)) OtherOptions(void) {
	char *tp;

	tp = checkstring(cmdline, "RESET");
	if(tp) {
        ResetAllOptions();
		goto saveandreset;
	}

    tp = checkstring(cmdline, "CONSOLE");
	if(tp) {
		if(checkstring(tp, "INVERT"))		{ Option.Invert = true;  SaveOptions(); initSerialConsole(); return; }
		if(checkstring(tp, "NOINVERT"))		{ Option.Invert = false; SaveOptions(); initSerialConsole(); return; }
		if(checkstring(tp, "AUTO"))		    { Option.Invert = 2; SaveOptions(); initSerialConsole(); return; }
		if(checkstring(tp, "ECHO"))		    { EchoOption = true; return; }
		if(checkstring(tp, "NOECHO"))		{ EchoOption = false; return; }
	}

    tp = checkstring(cmdline, "CLOCKTRIM");
	if(tp) {
        int i;
		i = getint(tp, -31, +31);
        SYSKEY = 0xAA996655; SYSKEY = 0x556699AA;                   // unlock the oscillator control register
        OSCTUN = i;
        SYSKEY = 0x33333333;                                        // relock the oscillator control register
		return;
	}

    
    tp = checkstring(cmdline, "LCDPANEL");
    if(tp) {
    	if(CurrentLinePtr) error("Invalid in a program");
        if(checkstring(tp, "DISABLE")) {
            Option.LCD_CD = Option.LCD_CS = Option.LCD_Reset = Option.DISPLAY_TYPE = HRes = VRes = 0;
            DrawRectangle = (void (*)(int , int , int , int , int ))DisplayNotSet;
            DrawBitmap =  (void (*)(int , int , int , int , int , int , int , unsigned char *))DisplayNotSet;
        } else
            ConfigDisplaySPI(tp);

        goto saveandreset;
    }


    tp = checkstring(cmdline, "TOUCH");
    if(tp) {
    	if(CurrentLinePtr) error("Invalid in a program");
        if(checkstring(tp, "DISABLE"))
            Option.TOUCH_IRQ = Option.TOUCH_CS = 0;
        else
            ConfigTouch(tp);

        goto saveandreset;
    }

    tp = checkstring(cmdline, "LIST");
    if(tp) {
        if(Option.Autorun == true) PO2Str("AUTORUN", "ON");
        if(Option.Baudrate != CONSOLE_BAUDRATE) PO2Int("BAUDRATE", Option.Baudrate);
        if(Option.Invert == true) PO2Str("CONSOLE", "INVERT");
        if(Option.Invert == 2) PO2Str("CONSOLE", "AUTO");
        if(Option.ColourCode == true) PO2Str("COLOURCODE", "ON");
        if(Option.Listcase != CONFIG_TITLE) PO2Str("CASE", CaseList[(int)Option.Listcase]);
        if(Option.Tab != 2) PO2Int("TAB", Option.Tab);
        if(Option.Height != 24 || Option.Width != 80) PO3Int("DISPLAY", Option.Height, Option.Width);
        if(Option.DISPLAY_TYPE > SSD_PANEL) { 
            PO("LCDPANEL"); MMPrintString(LCDList[Option.DISPLAY_TYPE - SSD_PANEL - 1]); MMPrintString(", "); MMPrintString(OrientList[(int)Option.DISPLAY_ORIENTATION - 1]);
            PIntComma(Option.LCD_CD); PIntComma(Option.LCD_Reset); PIntComma(Option.LCD_CS); MMPrintString("\r\n");
        }
        if(Option.TOUCH_CS) PO3Int("TOUCH", Option.TOUCH_CS, Option.TOUCH_IRQ);
        return;
    }

    error("Invalid option");

saveandreset:
    uSec(200000);
    SaveOptions();
    _excep_code = RESTART_NOAUTORUN;
    SoftReset();                                                    // this will restart the processor
}




void InitProcessor(void) {
    // initial setup of the I/O ports
    // Default all pins to digital

    ODCA = ANSELA = 0; ODCB = ANSELB = 0;                           // Default all pins to digital, open drain off
    if(HAS_44PINS) ODCC = ANSELC = 0;

    mJTAGPortEnable(0);                                             // turn off jtag

    // setup the CPU
    BusSpeed = SYSTEMConfigPerformance(ClockSpeed);                 // System config performance

    // clear all port I/O (they are not cleared by a watchdog reset)
    LATACLR = LATBCLR = 0xffffffff;
    TRISASET = TRISBSET = 0xffffffff;
    CNENACLR = CNENBCLR = CNCONACLR = CNCONBCLR = 0xffffffff;
    CNPUACLR = CNPUBCLR = CNPDACLR = CNPDBCLR = 0xffffffff;
    #if defined(__32MX250F128D__) || defined(__32MX150F128D__)
        LATCCLR = 0xffffffff;
        TRISCSET = 0xffffffff;
        CNENCCLR = CNCONCCLR = 0xffffffff;
        CNPUCCLR = CNPDCCLR = 0xffffffff;
    #endif
    SpiChnClose(SPI_CHANNEL1); PPSOutput(2, RPA1, NULL);            // SPI is not reset by the watchdog
    CloseOC1(); PPSOutput(1, RPB15, NULL);                          // nor the output compare (PWM)
    CloseOC4(); PPSOutput(3, RPB13, NULL);

    // clear both UARTs (again not reset by the watchdog)
    UARTEnable(UART1, UART_ENABLE_FLAGS(UART_DISABLE | UART_PERIPHERAL));
    PPSOutput(1, RPB4, NULL);
    UARTEnable(UART2, UART_ENABLE_FLAGS(UART_DISABLE | UART_PERIPHERAL));
    PPSOutput(4, RPB10, NULL); PPSOutput(1, RPB3, NULL);

    LATBbits.LATB4 = 1; TRISBbits.TRISB4 = P_OUTPUT;                // immediately set console Tx high to prevent a glitch
    uSec(1000);

    LoadOptions();                                                  // populate the Option struct from flash
    if(Option.Baudrate == 0xffffffff) ResetAllFlash();              // init the options if this is the very first startup
    
    // set the base of the usable memory
    RAMBase = (void *)MRoundUp((unsigned int)&_splim);
    
    if(HAS_44PINS)
        PinDef = (struct s_PinDef *)PinDef44;
    else
        PinDef = (struct s_PinDef *)PinDef28;

    INTEnableSystemMultiVectoredInt();                              // allow vectored interrupts
    initConsole();                                                  // initialise the UART used for the console
    InitHeap();                                                     // initialise memory allocation
    initTimers();                                                   // initialise and startup the timers
    initExtIO();
    INTEnableInterrupts();
}